/// @file Graphviz.cpp
/// Definition of functions to write graphviz files

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include <algorithm>
#include <cstdarg>
#include <cstdio>
#include <sstream>
#include <typeinfo>
#include <unordered_set>

#include "Calibration.h"
#include "Except.h"
#include "Graphviz.h"
#include "Locus.h"
#include "OptionsInit.h"
#include "Replicates.h"
#include "Sequence.h"
#include "SequenceFactory.h"
#include "Taxa.h"
#include "Tree.h"

// *****************************************************************************
// Some useful types

typedef std::unordered_set<Tree::Node*>   NODESET;
typedef std::pair<Tree::Node *, unsigned> OPTPAIR;
typedef std::list<OPTPAIR>                OPTSLIST;

// *****************************************************************************

static
std::string
Last4(void * p)
{
    std::stringstream ss;
    ss << p;
    std::string addrstr = ss.str();
    return addrstr.substr(addrstr.size() - 4);
}

// *****************************************************************************
/// Closure around an output file.

struct GVFile {

    const char * epilog;
    FILE *       gvf;

    GVFile( const std::string & fn,
	    const char *        p,
	    const char *        e )
	: epilog(e)
	{
	    gvf = fopen(fn.c_str(), "w");
	    if (!gvf)
		throw Except::FileOpenError("Graphviz dot output file", "dotfile", errno);
	    fprintf(gvf, "%s", p);
	}

    virtual ~GVFile()
	{
	    fprintf(gvf,  "%s", epilog);
	    fclose(gvf);
	}

    void operator() ( const char * format, ... )
	{
	    va_list args;
	    va_start (args, format);
	    vfprintf (gvf, format, args);
	    va_end (args);
	}
};

// *****************************************************************************
/// DFS visitor for tree output.

struct GraphvizTree : Tree::Dfs {

    GVFile &  gvf;
    NODESET & nodeset;

    GraphvizTree ( GVFile &  fp,
		  NODESET & ns)
	: gvf(fp),
	  nodeset(ns)

	{}

    virtual RC InnerBegin ( const Tree::Position & tPos );

    virtual RC Leaf       ( const Tree::Position & tPos );

    virtual RC RootBegin  ( Tree::Root & r );

};

// *****************************************************************************
/// DFS visitor for the Calibrations output.

struct GraphvizCal : Tree::Dfs {

    GVFile &         gvf;
    NODESET &        nodeSet;
    Tree::NODEPVEC & nodeList;
    OPTSLIST &       optList;

    GraphvizCal ( GVFile &         fp,
                  NODESET &        ns,
                  Tree::NODEPVEC & nl,
                  OPTSLIST &       p )
        : gvf(fp),
          nodeSet(ns),
          nodeList(nl),
          optList(p)
        {}

    virtual RC InnerBegin ( const Tree::Position & tPos );

    virtual RC RootBegin  ( Tree::Root & r );

};

namespace Graphviz {

    // *****************************************************************************

    void
    Calibrations( TreeFactory &                        treeList,
                  const std::list<Calibration::Opts> & optList,
                  const std::string &                  dotfile )
    {

        GVFile    gvf(dotfile, R"(
digraph G{

    label=<Calibration Structures>

    ranksep=.2
    node [ shape=none; fontsize=8; ]

)", "}\n");

        /// - Need both a set and a list of verticies

        NODESET          nodeSet;		  // Need for membership testing
	Tree::NODEPVEC   nodeList;		  // Need for ordering
        OPTSLIST         optsList;

        /// - Generate the per tree items

        for ( auto& root : treeList ) {
            GraphvizCal dfs(gvf, nodeSet, nodeList, optsList);
            dfs(root);
        }

        /// - Knit the trees together

        if ( optsList.size() > 1 ) {
            bool first = true;
            for ( auto & optPair : optsList ) {
                if ( first )
                    first = false;
                else
                    gvf("-> ");
                gvf("N%p_%d_0 ", optPair.first, optPair.second);
            }

            gvf(R"( [style=invis]
)");

        }

        /// - Output the calibration parameter nodes

        for ( auto & opt : optList ) {

            gvf(R"(    C%p [ label=<<table border="0" cellborder="1" cellspacing="0">
        <tr><td colspan="2">%p<br/>%s</td></tr>
)", &opt, &opt, opt._label.c_str());

            bool first = true;
            for ( auto tx : opt._taxaObjs ) {
                if ( first ) {
                    gvf("        <tr><td rowspan=\"%u\">Taxa</td><td>%s</td></tr>\n",
                        opt._taxaObjs.size(), tx->_label.c_str());
                    first = false;
                }
                else
                    gvf("        <tr><td>%s</td></tr>\n",
                        tx->_label.c_str());
            }

            gvf("<tr><td>Distribution</td><td>%s</td></tr>\n", CalibrationTypes[opt._cType].c_str());

            if ( opt._minAge != 0.0 )    gvf("<tr><td>Min Age</td><td>%lg</td></tr>\n", opt._minAge);
            if ( opt._maxAge != 0.0 )    gvf("<tr><td>Max Age</td><td>%lg</td></tr>\n", opt._maxAge);
            if ( opt._leftMass != 0.0 )  gvf("<tr><td>Left Mass</td><td>%lg</td></tr>\n", opt._leftMass);
            if ( opt._rightMass != 0.0 ) gvf("<tr><td>Right Mass</td><td>%lg</td></tr>\n", opt._rightMass);
            if ( opt._offset != 0.0 )    gvf("<tr><td>Offset</td><td>%lg</td></tr>\n", opt._offset);
            if ( opt._scale != 0.0 )     gvf("<tr><td>Scale</td><td>%lg</td></tr>\n", opt._scale);
            if ( opt._alpha != 0.0 )     gvf("<tr><td>Alpha</td><td>%lg</td></tr>\n", opt._alpha);
            if ( opt._beta != 0.0 )      gvf("<tr><td>Beta</td><td>%lg</td></tr>\n", opt._beta);
            if ( opt._mu != 0.0 )        gvf("<tr><td>Mu</td><td>%lg</td></tr>\n", opt._mu);
            if ( opt._sigma != 0.0 )     gvf("<tr><td>Sigma</td><td>%lg</td></tr>\n", opt._sigma);

            gvf("    </table>>]\n");

        }

        // Horizontal alignment of the calibration parameter nodes

        if ( optList.size() > 1 ) {
            bool first = true;
            gvf("    subgraph { rank=sink; ");

            for ( auto & opt : optList ) {
                if ( first )
                    first = false;
                else
                    gvf("-> ");
                gvf("C%p ", &opt);
            }
            gvf("}\n");
        }

        // Setup vertical alignment of the node and calibration info

        bool first = true;
        for ( auto v : nodeList ) {
            if ( first )
                first = false;
            else
                gvf("-> ");
            gvf("N%p ",v);
        }

        if ( optList.size() )
            gvf("-> C%p ", &(optList.front()) );
        gvf("[style=invis]\n");

    }

    // *****************************************************************************

    void
    GeneTrees( TreeFactory &       treeList,
               const std::string & dotfile )
    {

    }
    // *****************************************************************************

    void
    Replicate( struct Replicate &  repl,
               const std::string & dotfile )
    {

        const char* prolog = R"(
digraph G{

    label=<Replicate %d>

)";

        GVFile  gvf( dotfile, "", "}\n" );
        gvf( prolog, repl._id );
        NODESET nodeset;

        for ( auto& root : repl ) {
            GraphvizTree dfs(gvf, nodeset);
            dfs(root);
        }

    }

    // *****************************************************************************

    void
    Taxa( const SequenceFactory &                    seqFactory,
          const std::map<std::string, struct Taxa> & taxaMap,
          const std::string &                        dotfile )
    {

        const char* prolog = R"(
digraph G{

    label=<Taxa Structures>

    ranksep=.2
    node [ shape=none; fontsize=8; ]

)";

        GVFile              gvf(dotfile, prolog, "}\n");
        const struct Taxa * prevTx = 0;
        std::string         alphabet = seqFactory._alphabet + seqFactory._gapCh + seqFactory._missingCh;

        for ( auto & tx : taxaMap ) {

            auto & taxa = tx.second;

            // Output the taxa name and base object information

            const char * base = R"(
    T%p [label=<<table border="1" cellborder="0">
        <tr><td>%u) %s</td></tr>
        <tr><td>%p</td></tr>
    </table>>]

)";

            gvf(base,
                &taxa,
                taxa._id,
                taxa._label.c_str(),
                &taxa);

            // Output the locus information

            const char * lsProlog = R"(
   T%p_loci [ label=< <table border="0" cellborder="1" cellspacing="0">
)";
            const char * lsItem1  = R"(
      <tr><td rowspan="%u">%s</td><td align="left">%s</td></tr>
)";
            const char * lsItemn  = R"(
      <tr><td align="left">%s</td></tr>
)";
            const char * lsEpilog = R"(
   </table> > ]
)";

            gvf(lsProlog, &taxa);

            if ( taxa._seqVec.size() == 0 )
                gvf("        <tr><td>Empty</td></tr>");
            else {

                const unsigned lineLen = 50;

                for ( Sequence * seq : taxa._seqVec ) {

                    if ( !seq )
                        continue;

                    std::string seqStr;
                    for ( unsigned char c : *seq )
                        seqStr += alphabet[c];

                    unsigned lines = (seqStr.size() / lineLen) + (seqStr.size() % lineLen == 0 ? 0 : 1);

                    for ( unsigned i = 0; i < lines; i ++) {
                        if ( i == 0 )
                            gvf(lsItem1,
                                lines,
                                seq->_locus._label.c_str(),
                                seqStr.substr(i * lineLen, lineLen).c_str());
                        else
                            gvf(lsItemn,
                                seqStr.substr(i * lineLen, lineLen).c_str());
                    }

                }

            }

            gvf(lsEpilog);

            // Write the lines between the taxa objects

            const char * txEpilog = R"(
subgraph { rank=same; T%p -> T%p_loci }
)";

            gvf(txEpilog, &taxa, &taxa, &taxa, &taxa, &taxa);

            // Chain the records together for alignments sake

            const char * chain = R"(
    T%p -> T%p [style=invis]
)";

            if ( prevTx )
                gvf(chain, prevTx, &taxa);
            prevTx = &taxa;

        }

    }

    // *****************************************************************************

    void
    Trees( TreeFactory &       treeList,
           const std::string & dotfile )
    {

        GVFile  gvf(dotfile, "digraph G {\n", "}\n");
        NODESET nodeset;

        for ( auto& root : treeList ) {
            GraphvizTree dfs(gvf, nodeset);
            dfs(root);
        }

    }

}

// *****************************************************************************

static
std::string
LenStr ( const Tree::TreeNode::VEC & tv )
{
    std::stringstream ss;
    ss << "<td>" << "BrLens:" << "</td>";
    for ( auto & tn : tv )
        ss << "<td>" << tn._brLen << "</td>";
    return ss.str();
}

// *****************************************************************************

static
std::string
ParentStr ( const Tree::TreeNode::VEC & tv )
{
    std::stringstream ss;
    ss << "<td>" << "Parents:" << "</td>";
    for ( auto & tn : tv )
        ss << "<td>" << Last4(tn._parent._node) << '/' << tn._parent._treeIdx << "</td>";
    return ss.str();
}

// *****************************************************************************

static
std::string
ChildStr ( const Tree::Node::CHILDREN & cv )
{
    std::stringstream ss;
    ss << "<td>" << "Children:" << "</td>";
    for ( auto & cp : cv ) {
        ss << "<td>" << Last4(cp.first) << '/';
        for ( auto ti = cp.second.begin();
              ti != cp.second.end();
              ti++ ) {
            if ( ti != cp.second.begin() )
                ss << ',';
            ss << *ti;
        }
        ss << "</td>";
    }
    return ss.str();
}

// *****************************************************************************

    const char* pointerTemplate = R"(
   x%p -> x%p;
)";

// *****************************************************************************
/// Process an inner node

Tree::Dfs::RC
GraphvizTree::InnerBegin( const Tree::Position & tPos )
{
    const char* innerTemplate = R"(
   x%p [shape=none,
        fontsize=11,
        fontcolor="blue",
        label=<
           <table border="1" cellborder="0">
              <tr><td colspan="%d"><font point-size="10">%p</font></td></tr>
              <tr>%s</tr>
              <tr>%s</tr>
              <tr>%s</tr>
           </table>
      >];
)";

    auto i(tPos._node);

    if ( nodeset.count(i) )
        return STOPDOWN;

    nodeset.insert(i);

    unsigned maxCols = std::max(3U, unsigned(i->_treeVec.size()+1));

    gvf(innerTemplate,
        i,
        maxCols, i,
        LenStr(i->_treeVec).c_str(),
        ParentStr(i->_treeVec).c_str(),
        ChildStr(i->_children).c_str());

    for ( auto & child : tPos._node->_children )
        gvf(pointerTemplate,
            tPos._node,
            child.first);

    return CONTINUE;
}

// *****************************************************************************
/// Process a leaf node

Tree::Dfs::RC
GraphvizTree::Leaf( const Tree::Position & tPos )
{
    const char* leafTemplate = R"(
   x%p [shape=none,
        fontsize=11,
        fontcolor="brown",
        label=<
           <table border="1" cellborder="0">
              <tr><td colspan="%d">%u: %s</td></tr>
              <tr><td colspan="%d"><font point-size="10">%p</font></td></tr>
              <tr>%s</tr>
              <tr>%s</tr>
           </table> >
       ];
    )";

    auto l(tPos._node);

    gvf(leafTemplate,
        l,
        l->_treeVec.size() + 1, l->_taxa->_id, l->_taxa->_label.c_str(),
        l->_treeVec.size() + 1, l,
        LenStr(l->_treeVec).c_str(),
        ParentStr(l->_treeVec).c_str());

    return CONTINUE;
}

// *****************************************************************************
/// Process the root node

Tree::Dfs::RC
GraphvizTree::RootBegin( Tree::Root & r )
{

const char* rootTemplate = R"(
   x%p [shape=none,
        fontsize=11,
        fontcolor="red"
        label=<
           <table border="1" cellborder="0">
              <tr><td colspan="3">%u: %s</td></tr>
              <tr><td colspan="3"><font point-size="10">%p</font></td></tr>
              <tr>%s</tr>
	   </table>
        >];
)";

    gvf(rootTemplate,
        (void*)&r,
        r._rootIdx,
        r._label.c_str(),
        (void*)&r,
        ChildStr(r._children).c_str());

    for ( auto & child : r._children )
        gvf(pointerTemplate,
            &r,
            child.first);

    return CONTINUE;
}

// *****************************************************************************
/// Templates for the calibration graph

static const char* cNode         = R"(    N%p [label=< <table border="1" cellborder="0">
        <tr><td>%s<br/>%p</td></tr>
    </table> >];

)";

static const char* cvNode        = R"(    N%p_CV [ label=<<table border="0" cellborder="1" cellspacing="0">
)";

static const char* cvItem        = R"(        <tr><td port="%d">%d</td></tr>
)";
static const char* cvItemNull    = R"(        <tr><td port="%d">%d (NULL)</td></tr>
)";

static const char* cvEpilog      = R"(    </table>> ]

    subgraph { rank=same;  N%p -> N%p_CV }

)";

static const char* ciItem        = R"(    N%p_%d_%d [ label=<<table border="0" cellborder="1" cellspacing="0">
        <tr><td>%p<br/>%s</td></tr>
    </table>> ]

)";

static const char* cItem         = R"(    subgraph { N%p_CV:%d -> N%p_%d_0 [ constraint=false ] }

)";
static const char* cItemMidpoint = R"(    subgraph { rank=same;  N%p_CV:%d -> N%p_%d_0 }

)";

static const char* cRankProlog   = R"(    subgraph { rank=same; )";
static const char* cRankNode     = R"(N%p )";
static const char* cRankItem     = R"(N%p_%d_%d )";
static const char* cRankEpilog   = R"(}

)";

// *****************************************************************************
/// Process an inner node including roots

Tree::Dfs::RC
GraphvizCal::InnerBegin( const Tree::Position & tPos )
{
    auto node (tPos._node);

    /// - If we've seen this vertex before bail out now

    if ( nodeSet.count(node) )
	return CONTINUE;

    /// - If no calibrations on this node bail

    bool found = false;
    for ( auto& tn : node->_treeVec )
        if ( tn._calList.size() ) {
            found = true;
            break;
        }
    if ( !found )
        return CONTINUE;

    nodeSet.insert(node);
    nodeList.push_back(node);

    /// - Write prolog for the node

    gvf(cNode,
	node,
	"Node",
	node);

    /// - Output the set of calibrations

    int activeNodes = 0;

    gvf(cvNode, node);

    for ( unsigned i = 0; i < node->_treeVec.size(); i++ )

        if ( node->_treeVec[i]._calList.size()) {
            gvf(cvItem, i, i + 1);
            activeNodes++;
        }
        else
            gvf(cvItemNull, i, i + 1);

    gvf(cvEpilog, node, node);

    unsigned midPoint = activeNodes ? (activeNodes - 1) / 2 : 0;
    for ( unsigned i = 0; i < node->_treeVec.size(); i++ ) {

        auto & tn (node->_treeVec[i]);
        std::list<Calibration::Data*> & cList = tn._calList;;

        if ( !cList.size() )
            continue;

        optList.emplace_back(node, i);

        /// - Output a single calibration

        unsigned  j = 0;
        for ( auto  cData : cList ) {
            gvf(ciItem, node, i, j, &cData->_opts, cData->_opts._label.c_str());
            j++;
        }

        if ( i == midPoint )
            gvf(cItemMidpoint, node, i, node, i);
        else
            gvf(cItem,  node, i, node, i);

        if ( cList.size() > 1 ) {

            gvf(cRankProlog);

            for ( unsigned j = 0; j < cList.size(); j++) {
                if ( j > 0 )
                    gvf("-> ");
                gvf(cRankItem, node, i, j);
            }

            gvf(cRankEpilog);

        }

    }

    return CONTINUE;
}

// *****************************************************************************
/// Process an inner node including roots

Tree::Dfs::RC
GraphvizCal::RootBegin( Tree::Root &  r )
{

    /// - If no calibrations on this node bail

    if ( !r._calList.size() )
        return CONTINUE;

    /// - Write prolog for the node

    gvf(cNode,
	&r,
	"Root Node",
	&r);

    std::list<Calibration::Data*> & cList = r._calList;

    optList.emplace_back(&r, 0);

    /// - Output a single calibration

    unsigned  j = 0;
    for ( auto cData : cList ) {
        gvf(ciItem, &r, 0, j, &cData->_opts, cData->_opts._label.c_str());
        j++;
    }

    gvf(cRankProlog);
    gvf(cRankNode, &r);

    for ( unsigned j = 0; j < cList.size(); j++) {
        gvf("-> ");
        gvf(cRankItem, &r, 0, j);
    }

    gvf(cRankEpilog);

    return CONTINUE;
}
