/// @file OutputManager.h
/// Create output file objects

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _OUTPUTMANAGER_H_
#define _OUTPUTMANAGER_H_

#include <cstdio>
#include <ctime>
#include <string>
#include <vector>

class  Logger;
struct OutputFile;
struct Replicate;
struct ReplicateVec;

namespace Tree {
    struct Root;
}

// *****************************************************************************
/// Output file interface.

struct IOutputFile {

    /// The function operator will generate whatever output is required for the
    /// type of file requested.
    /// @param gen Current MCMC generation (or omitted if not required).
    virtual void              operator()( const unsigned gen=0 ) = 0;

    /// Close the file.
    /// Generally done in the destuctor but included here to allow the trace file
    /// to be opened and read.
    virtual void              Close() = 0;

    /// Get the name of the output file.
    /// @return Output file name.
    virtual const std::string Filename() = 0;

    /// For sampled output files, return the number of sample taken.
    virtual unsigned          NSamples()
	{
	    return 0;
	}

};

// *****************************************************************************
/// Output manager class.
/// Controls creation of the various files and owns the objects to allow the
/// files to be closed automajically when the manager is destroyed.

struct OutputManager : std::vector<OutputFile*> {

    /// Types of output files
    enum FileType : unsigned char {

	/// File of  sampled trees
	TreeSamples,

	/// File of trace records
	Trace,

	/// File of final consensus trees
	FinalTree,

	/// File of parameter summaries
	ParameterDetails

    };

    OutputManager(const std::string & fnBase,
		  bool                fileOverWrite,
		  Logger &            logger,
		  const std::tm &     startTime);

    virtual ~OutputManager();

    /// Create an output file instance of the specified type associated with
    /// the replicate and species tree provided.
    /// @return Output file interface.
    /// @param repl Associated replicate.
    /// @param root Associated species tree.
    /// @param type type of file to generate.
    IOutputFile * operator() ( const Replicate &  repl,
			       Tree::Root &       root,
			       FileType           type );

    Logger &    _logger;	                  ///< To write file status messages
    std::string _fnBase;			  ///< Base for file names
    char        _tmStamp[80];			  ///< Run starting timestamp

};

#endif // _OUTPUTMANAGER_H_
