/// @file RatesPrior.h
/// Declarations for the classes associated with prior on the rates.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _RATESPRIOR_H_
#define _RATESPRIOR_H_

#include "Prior.h"

namespace Tree {
    struct LocusRoot;
    struct LocusNode;
    struct TreeNode;
}

// *****************************************************************************
/// Pure virtual base class for the rates prior at a gene tree root.

struct RatesPriorRoot : Prior {

    RatesPriorRoot( Replicate       & repl,
		    Tree::LocusRoot & lRoot )
	: Prior(repl),
	  _lRoot(lRoot)
	{}

    virtual ~RatesPriorRoot()
	{}

    /// Compute the prior for a gene tree assuming no saved values.
    /// Intended for setting the initial values on the tree.
    /// Sets the the prior values in the gene tree nodes but not in the locus root.
    virtual void InitialValues () = 0;

    /// Compute the prior for a gene tree when the rates mean changes.
    /// Sets the the prior values in the gene tree nodes but not in the locus root.
    virtual void NewMean       () = 0;

    /// Compute the prior for a gene tree when the rates variance changes.
    /// Sets the the prior values in the gene tree nodes but not in the locus root.
    virtual void NewVariance   () = 0;

    /// Log the proposal at the root in case of rollback;
    /// Not pure virtual since all the models do the same thing
    virtual void LogRollback   ();

    /// Update the log prior value by the amount passed.
    /// @param delta Change in the log of the prior
    virtual void UpdatePrior ( FLOAT  delta )
	{
	    _value += delta;
	}

    /// Factory to create the appropriate prior module.
    /// @return Pointer to prior module created.
    /// @param repl Reference to owning replicate.
    /// @param lRoot Reference to the gene tree root for this prior.
    static RatesPriorRoot * Factory  ( Replicate &       repl,
				       Tree::LocusRoot & lRoot );

protected:

    Tree::LocusRoot & _lRoot;			  ///< Owning gene tree

};

// *****************************************************************************
/// Pure virtual base class for the rates prior at a gene tree node.

struct RatesPriorNode : Prior {

    RatesPriorNode( Replicate       & repl,
		    Tree::LocusNode & lNode,
		    RatesPriorRoot &  pRoot )
	: Prior(repl),
	  _lNode(lNode),
	  _pRoot(pRoot)
	{}

    virtual ~RatesPriorNode()
	{}

    /// Update the gene tree prior after changing an age.
    /// Not pure virtual since only the correlated model requires it.
    /// Updates the log of the prior in the gene tree root.
    virtual void NewAge        ()
	{}

    /// Return the prior ratio at a specific gene tree node when a rate changes.
    /// Not pure virtual since the molecular clock model doesn't require it.
    /// Updates the log of the prior in the gene tree root.
    virtual void NewRate       ()
	{}

    /// Factory to create the appropriate prior module.
    /// @return Pointer to prior module created.
    /// @param repl Reference to owning replicate.
    /// @param lNode Reference to the gene tree node for this prior.
    static RatesPriorNode * Factory  ( Replicate &       repl,
			   	       Tree::LocusNode & lNode );

protected:

    Tree::LocusNode & _lNode;		          ///< Owning gene tree node
    RatesPriorRoot &  _pRoot;			  ///< Owning gene tree prior

};

#endif // _RATESPRIOR_H_
