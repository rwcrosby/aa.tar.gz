/// @file Dump.h
/// Declarations for various dump functions.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _DUMP_H_
#define _DUMP_H_

#include <iomanip>
#include <string>
#include <sstream>
#include <vector>

#include "Config.h"

class Logger;

/// Name space of the dumper templates and functions

namespace Dump {

    /// Dump a set of trees to the log.
    /// Done with a template to allow specializations for either the
    /// dag or the set of replicates.
    /// Dump strings for objects should be materialized using a to_string() function.
    /// For virtual classes, the str() method should be implemented but not
    /// exposed fof general use. A to_string() function should call the str() method.
    /// @param todump Thing to dump
    /// @param heading Heading for output
    /// @param log Logger to output to
    template<typename T>
    void
    Trees ( T &                 todump,
	    const std::string & heading,
	    Logger &            log );

    // *********************************************************************
    /// Template to dump a pointer only
    template <typename T>
    std::string
    ptr(const T * const   ptr,
	const std::string hdg = "")
    {
	std::stringstream ss;

	if ( hdg.size() )
	    ss << hdg << "<";

	if (!ptr)
	    ss << "null";
	else
	    ss << std::showbase << std::hex << (long long)ptr;

	if ( hdg.size() )
	    ss << ">";

	return ss.str();
    }

    // *********************************************************************
    /// Template to dump a pointer and associated data
    template <typename T>
    std::string
    pstr(const T * const   ptr,
	 const std::string hdg = "")
    {
	std::stringstream ss;

	if ( hdg.size() )
	    ss << hdg << "<";

	if (!ptr)
	    ss << "null";
	else
	    ss << ptr->str();

	if ( hdg.size() )
	    ss << ">";

	return ss.str();
    }

    // *********************************************************************
    /// Template to dump a scalar.
    template <typename T>
    std::string
    str(const T &         scalar,
	const std::string hdg = "");

    // *********************************************************************
    /// Template to dump a pair of scalars.
    /// Used for value/oldvalue pairs
    template <typename T>
    std::string
    str(const T &         scalar1,
	const T &         scalar2,
	const std::string hdg = "");

    // *********************************************************************
    /// Template to dump a pair of scalars.
    /// Used for value/oldvalue pairs
    template <typename T>
    std::string
    ptr(const T * const   ptr1,
	const T * const   ptr2,
	const std::string hdg = "")
    {
	std::stringstream ss;

	if ( hdg.size() )
	    ss << hdg << "<";

	if (!ptr1)
	    ss << "null";
	else
	    ss << std::showbase << std::hex << (long long)ptr1;

	ss << '/';

	if (!ptr2)
	    ss << "null";
	else
	    ss << std::showbase << std::hex << (long long)ptr2;

	if ( hdg.size() )
	    ss << ">";

	return ss.str();
    }

    // *********************************************************************
    /// Template to dump a vector just calling the objects string methods.
    template <typename T>
    std::string
    str( const std::vector<T> & v,
	 const std::string      hdg = "")
    {
	std::string s;
	if ( hdg.size() ) s += hdg;
	s += '<';
	for ( auto it = v.begin(); it != v.end(); it++ ) {
	    if ( it != v.begin() ) s += ',';
	    s += (*it).str();
	}
	s += '>';
	return s;
    }

    /// Specialization to dump a vector of doubles
    template <>
    std::string
    str( const std::vector<double> & v,
	 const std::string           hdg );

    /// Specialization to dump a vector of floats
    template <>
    std::string
    str( const std::vector<float> &  v,
	 const std::string           hdg );

    /// Specialization to dump a vector of unsigned ints
    template <>
    std::string
    str( const UINTVEC &   v,
	 const std::string hdg );

    // *********************************************************************
    /// Template to dump a vector of pointers.
    template <typename T>
    std::string
    str( const std::vector<T*> & v,
	 const std::string      hdg = "")
    {
	std::stringstream ss;
	ss << hdg << '<';
	for ( auto it = v.begin(); it != v.end(); it++ ) {
	    if ( it != v.begin() )
		ss << ',';
	    ss << std::showbase << std::hex << (long long)(*it);
	}
	ss << '>';
	return ss.str();
    }

    // *********************************************************************
    /// Template to return a line of floating point code values
    template <typename T>
    std::string
    str(T * &             copy1,
	T * &             copy2,
	const unsigned    n,
	const std::string hdg = "")
    {
	std::stringstream ss;
	ss << std::fixed
	   << std::setprecision(6);
	for ( unsigned j = 0; j < n; j++ )
	    ss << std::setw(9)
	       << *copy1++
	       << ' ';
	ss << " / ";
	for ( unsigned j = 0; j < n; j++ )
	    ss << std::setw(9)
	       << *copy2++
	       << ' ';
	return ss.str();
    }

    // *********************************************************************
    /// Trim off trailing whitespace and last new line on the right

    std::string
    rtrim ( const std::string s );

    // *********************************************************************
    /// Add a fixed indent to the front of each line in a string and trim the last
    /// newline.

    std::string
    indent ( std::string s,
	     unsigned    n = 4 );

    // *********************************************************************
    /// Add a heading to the first line of a string indenting subsequent lines
    /// by the amount of the heading.
    /// Last line is trimmed.
    /// @param s String to append heading to
    /// @param h Heading to append to the first line of the output

    std::string
    indent_heading ( std::string       s,
		     const std::string h );

    // *********************************************************************
    /// Setup the standard heading for a vector line
    /// @param i Index to print
    /// @param h Heading to append to the first line of the output
    /// @param width Width of the vector index

    std::string
    vector_heading ( const unsigned    i,
		     const std::string h,
		     const size_t      width = 2);

}

#endif // _DUMP_H_
