/// @file OutputManager.cpp
/// Definitions for the various output methods.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include <ctime>
#include <iomanip>
#include <fstream>
#include <regex>
#include <sstream>

#include "AgePrior.h"
#include "Calibration.h"
#include "DivTime.h"
#include "Except.h"
#include "Logger.h"
#include "OutputManager.h"
#include "Parameter.h"
#include "RatesPrior.h"
#include "Replicates.h"
#include "Taxa.h"
#include "Tree.h"

// *****************************************************************************

static
void
WriteNexusHeader( const DivTime & dt,
		  FILE *          fp);

static
void
WriteNexusTrailer( FILE * fp );

// *****************************************************************************
/// Base class containing implementation for the output files.

struct OutputFile : IOutputFile {

    OutputFile( const std::string & filename,
		const Replicate &   repl,
		Tree::Root &        root );

    virtual ~OutputFile()
	{
	    Close();
	};

    virtual void Close()
	{
	    if ( _fp ) {
		fclose(_fp);
		_fp = nullptr;
	    }
	}

    virtual const std::string Filename()
	{
	    return _filename;
	}

    FILE *             _fp;			  ///< The output file, null if closed.
    const std::string  _filename;		  ///< Actual file name
    const Replicate &  _repl;			  ///< Associated replicate
    Tree::Root &       _root;			  ///< Associated species tree

};

// *****************************************************************************
/// Generate the final tree.

struct OutputFinalTree : OutputFile {

    /// Create the final tree output file.
    /// @param fnBase Base of the filename.
    /// @param repl Associated replicate.
    /// @param root Associated tree
    OutputFinalTree ( const std::string  fnBase,
		      const Replicate &  repl,
		      Tree::Root &       root )
	: OutputFile( fnBase + fnSuffix,
		      repl,
		      root )
	{
	    WriteNexusHeader(repl._dt, _fp);
	}

    virtual ~OutputFinalTree()
	{
	    WriteNexusTrailer(_fp);
	}

    virtual void operator() ( const unsigned gen );

    static const char * fnSuffix;

};

const char * OutputFinalTree::fnSuffix = "_tree.nexus";

// *****************************************************************************
/// Generate the parameter detail file.

struct OutputParameterDetails : OutputFile {

    /// Create the parameter detail output file.
    /// @param fnBase Base of the filename.
    /// @param repl Associated replicate.
    /// @param root Associated tree
    /// @param tmStamp String with the timestamp to display in the output.
    OutputParameterDetails ( const std::string  fnBase,
			     const Replicate &  repl,
			     Tree::Root &       root,
			     const char * const tmStamp)
	: OutputFile( fnBase + fnSuffix,
		      repl,
		      root ),
	  _tmStamp(tmStamp)
	{}

    virtual void operator() ( const unsigned gen );

    void WriteStats( const Tree::TraceType         type,
		     const Tree::TraceInfo * const ti );

    const char * const _tmStamp;

    static const char * fnSuffix;

};

const char * OutputParameterDetails::fnSuffix = "_summary.lst";

// *****************************************************************************
/// Generate trace output

struct OutputTrace : OutputFile {

    /// Create the trace output file.
    /// @param fnBase Base of the filename.
    /// @param repl Associated replicate.
    /// @param root Associated tree
    OutputTrace ( const std::string  fnBase,
		  const Replicate &  repl,
		  Tree::Root &       root );

    virtual void operator() ( const unsigned gen );

    virtual unsigned NSamples()
	{
	    return _nSamples;
	}

    unsigned _nSamples;

    static const char * fnSuffix;

};

const char * OutputTrace::fnSuffix = "_diagnostics.trace";

// *****************************************************************************
/// Generate tree samples.

struct OutputTreeSamples : OutputFile {

    /// Create the tree sample output file.
    /// @param fnBase Base of the filename.
    /// @param repl Associated replicate.
    /// @param root Associated tree
    OutputTreeSamples ( const std::string  fnBase,
			const Replicate &  repl,
			Tree::Root &       root )
	: OutputFile( fnBase + fnSuffix,
		      repl,
		      root ),
	  _nSamples(0)
	{
	    WriteNexusHeader(repl._dt, _fp);
	}

    virtual ~OutputTreeSamples()
	{
	    WriteNexusTrailer(_fp);
	}

    virtual void operator() ( const unsigned gen );

    virtual unsigned NSamples()
	{
	    return _nSamples;
	}

    unsigned _nSamples;

    static const char * fnSuffix;

};

const char * OutputTreeSamples::fnSuffix = "_samples.nexus";

// *****************************************************************************

static
std::string
ExpandBase( const std::string & base,
	    const unsigned      rid,
	    const unsigned      tid )
{
    std::stringstream ss;
    ss << base
       << "_r" << std::setw(3) << std::setfill('0') << rid
       << "_t" << std::setw(3) << std::setfill('0') << tid;
    return ss.str();
}

// *****************************************************************************

static
std::string
FmtVal( FLOAT  v )
{

    std::stringstream ss;
    ss << std::setw(12) << std::scientific << v;
    return ss.str();

}

// *****************************************************************************
/// Generate attributes for node in the final tree

static
void
FinalAttrFn ( Tree::Root::AttrList & aList,
	      const Tree::Position   tPos )
{
    if ( tPos.IsLeaf() )
	return;

    aList.emplace_back("id", "N" + std::to_string(tPos._node->_id));
    auto aParm = tPos.IsRoot()
	? tPos.AsRoot()._ageParm
	: tPos.AsTNode()._ageParm;
    auto ti = aParm->_tInfo;
    aList.emplace_back("mean", FmtVal(ti->_mean));
    aList.emplace_back("stddev", FmtVal(ti->_stdDev));
    aList.emplace_back("median", FmtVal(ti->_median));
    aList.emplace_back("95%",  "{" + FmtVal(ti->_ci025) + "," + FmtVal(ti->_ci975) + "}");
}

// *****************************************************************************
/// Generate attributes for node for a tree sample

static
void
SampleAttrFn ( Tree::Root::AttrList & aList,
	       const Tree::Position   tPos )
{
    if ( tPos.IsLeaf() )
	return;

    aList.emplace_back("id", "N" + std::to_string(tPos._node->_id));
    auto age = tPos.IsRoot()
	? (*tPos.AsRoot()._ageParm)()
	: (*tPos.AsTNode()._ageParm)();
    aList.emplace_back("age", std::to_string(age));
}

// *************************************************************************
/// Generate the branch length for the node for a tree sample

static
FLOAT
SampleBrLenFn ( const Tree::Position tPos )
{
    Tree::Position parentTPos;
    if ( !tPos.Parent(parentTPos) )
	return 0.0;

    auto parentAge = parentTPos.IsRoot()
	? (*parentTPos.AsRoot()._ageParm)()
	: (*parentTPos.AsTNode()._ageParm)();

    auto myAge = tPos.IsLeaf()
	? 0.0
	: (*tPos.AsTNode()._ageParm)();
    return parentAge - myAge;
}

// *****************************************************************************

OutputFile::OutputFile( const std::string & filename,
			const Replicate &   repl,
			Tree::Root &        root )
    : _fp(nullptr),
      _filename(filename),
      _repl(repl),
      _root(root)
{
    _fp = fopen(filename.c_str(), "w");
    if ( !_fp )
	throw Except::IOError("opening", filename, strerror(errno) );
}

// *****************************************************************************

OutputManager::OutputManager(const std::string & fnBase,
			     bool                fileOverWrite,
			     Logger &            logger,
			     const std::tm &     startTime)
    : _logger(logger),
      _fnBase(fnBase)
{

    /// - Insert any date/time values requested into the string.

    char dateStr[80];
    std::strftime(dateStr, 80, "%Y-%m-%d", &startTime);
    char timeStr[80];
    std::strftime(timeStr, 80, "%H-%M-%S", &startTime);

    std::regex  dateRegex ("%\\(date\\)");
    std::regex  timeRegex ("%\\(time\\)");

    _fnBase = std::regex_replace(_fnBase, dateRegex, std::string(dateStr));
    _fnBase = std::regex_replace(_fnBase, timeRegex, std::string(timeStr));

    /// - See if an output file exists. Just check for replicate 1, tree 1 samples file

    auto exists = [] ( const std::string  & fn )
	{
	    std::ifstream infile(fn);
	    return infile.good();
	};

    if ( exists(ExpandBase(_fnBase, 1, 1) + OutputTreeSamples::fnSuffix) ) {
	if ( fileOverWrite )
	    _logger("Warning: Output files exist, will be overwritten");
	else
	    throw Except::OutputsExist(_fnBase);
    }

    /// - Setup the timestamp string

    std::strftime(_tmStamp,
		  80,
		  "%Y-%m-%d %H:%M:%S",
		  &startTime);

}

// *****************************************************************************
/// Delete the output file instances closing the files.

OutputManager::~OutputManager()
{
    for ( auto of : *this )
	delete of;
}

// *****************************************************************************

IOutputFile * OutputManager::operator() ( const Replicate &  repl,
					  Tree::Root &       root,
					  FileType           type )
{

    OutputFile * of = nullptr;

    /// - Create a filename from the base, replicate id and tree id

    std::string expandedBase = ExpandBase(_fnBase, repl._id + 1, root._rootIdx + 1);

    switch ( type ) {

	case TreeSamples:
	    of = new OutputTreeSamples(expandedBase, repl, root);
	    break;

	case Trace:
	    of = new OutputTrace(expandedBase, repl, root);
	    break;

	case FinalTree:
	    of = new OutputFinalTree(expandedBase, repl, root);
	    break;

	case ParameterDetails:
	    of = new OutputParameterDetails(expandedBase, repl, root, _tmStamp);
	    break;

	default:
	    assert( 0 && "Invalid output file type");
    }

    push_back(of);

    return of;

}

// *************************************************************************

void OutputFinalTree::operator() (const unsigned gen)
{
    fprintf(_fp, "\ttree final = %s\n",
	    _root.NewickString(FinalAttrFn, SampleBrLenFn, false).c_str());
}

// *************************************************************************

static const char * const hdg1Fmt = "    Mean        Median      Std. Dev.   95%% Credibility Interval\n";
static const char * const hdg2Fmt = "------------ ------------ ------------ ---------------------------\n";
static const char * const detailFmt = "% 12.4e % 12.4e % 12.4e (% 12.4e, % 12.4e)\n";

void OutputParameterDetails::operator() (const unsigned gen)
{

    bool jackknifing = _repl._dt._nJackRepl > 1;

    fprintf(_fp, "FDivT: %s, Version %s, At %s\n", projectName, projectVersion, _tmStamp);
    fputc('\n', _fp);
    fprintf(_fp, "Summary for %s %u, Tree %d(%s)\n",
	    jackknifing ? "Jackknife Replicate" : "MCMC Chain",
	    _repl._id + 1,
	    _root._rootIdx + 1,
	    _root._label.c_str());

    fputc('\n', _fp);

    /// - If this is a jackknife run, output calibration information

    if ( jackknifing ) {
	fprintf(_fp, "Calibrations:\n");
	for ( auto & cOpt : _repl._dt._calOptList )
	    fprintf(_fp, "%04u %-20.20s : %s\n", cOpt._id,
		                                 cOpt._label.c_str(),
		                                 _repl._calsIncluded[cOpt._id]
		                                     ? "Included"
		                                     : "Omitted");
	fputc('\n', _fp);
    }

    auto tii = _root._traceList.begin();

    /// - Output the posterior

    fprintf(_fp, "Posterior:\n");
    fprintf(_fp, hdg1Fmt);
    fprintf(_fp, hdg2Fmt);
    WriteStats(Tree::TraceType::Posterior, *tii++);
    fputc('\n', _fp);

    /// - Output the likelihood

    fprintf(_fp, "Likelihood:\n");
    fprintf(_fp, hdg1Fmt);
    fprintf(_fp, hdg2Fmt);
    WriteStats(Tree::TraceType::Likelihood, *tii++);
    fputc('\n', _fp);

    /// - Output the node ages

    fprintf(_fp, "Node Ages (Sampled from Posterior):\n");
    fprintf(_fp, " Node %s", hdg1Fmt);
    fprintf(_fp, "----- %s", hdg2Fmt);
    fprintf(_fp, "Prior "); WriteStats(Tree::TraceType::AgePrior, *tii++);

    while ( (*tii)->_type == Tree::TraceType::AgeParm ) {
	fprintf(_fp, "%5d ", std::get<2>((*tii)->_key) + 1);
	WriteStats(Tree::TraceType::AgeParm, *tii++);
    }

    fputc('\n', _fp);

    /// - Output the rates

    fprintf(_fp, "Rate Parameters:\n");
    fprintf(_fp, "Locus  Node %s", hdg1Fmt);
    fprintf(_fp, "----- ----- %s", hdg2Fmt);
    fprintf(_fp, "Prior       "); WriteStats(Tree::TraceType::RatePrior, *tii++);

    while ( (*tii)->_type == Tree::TraceType::RateParm ) {
	fprintf(_fp, "%5d %5d ", std::get<1>((*tii)->_key) + 1,
		                 std::get<2>((*tii)->_key) + 1);
	WriteStats(Tree::TraceType::RateParm, *tii++);
    }

    fputc('\n', _fp);

    /// - Output the other parameters

    fprintf(_fp, "Nuisance Parameters:\n");
    fprintf(_fp, "Locus Parameter                 %s", hdg1Fmt);
    fprintf(_fp, "----- ------------------------- %s", hdg2Fmt);
    fprintf(_fp, "Prior                           "); WriteStats(Tree::TraceType::NuisancePrior, *tii++);

    while ( tii != _root._traceList.end() ) {
	fprintf(_fp, "%5d %-25.25s ", std::get<1>((*tii)->_key) + 1, (*tii)->_label.c_str() );
	WriteStats(Tree::TraceType::NuisanceParm, *tii++);
    }


}

// *************************************************************************

void OutputParameterDetails::WriteStats( const Tree::TraceType         type,
					 const Tree::TraceInfo * const ti )
{
    assert ( ti->_type == type && "Trace info out of sync");
    fprintf(_fp, detailFmt, ti->_mean, ti->_median, ti->_stdDev, ti->_ci025, ti->_ci975);
}

// *************************************************************************

void OutputTreeSamples::operator() (const unsigned gen)
{
    fprintf(_fp, "\ttree gen_%u = %s\n", gen,
	    _root.NewickString(SampleAttrFn, SampleBrLenFn, false).c_str());
    _nSamples++;
}

// *************************************************************************

OutputTrace::OutputTrace ( const std::string  fnBase,
			   const Replicate &  repl,
			   Tree::Root &       root )
    : OutputFile( fnBase + fnSuffix,
		  repl,
		  root ),
      _nSamples(0)
{

    /// - Output the common headers

    fprintf(_fp, "Generation");

    /// - Output headers for the parameters

    for ( auto ti : _root._traceList )
	fprintf(_fp, "\t%s", ti->_heading.c_str());

    fputc('\n', _fp);

}

// *************************************************************************

void OutputTrace::operator() (const unsigned gen)
{

    /// - Accumulate the prior of rates values

    _root._lnPR = 0.0;
    for ( auto & lRoot : _root._locusVec )
	_root._lnPR += (*lRoot._rLnPR)();

    fprintf(_fp, "%8u", gen);

    for ( auto ti : _root._traceList )
	fprintf(_fp, "\t%22.15e", ti->_dSource(ti));

    fputc('\n', _fp);

    _nSamples++;
}

// *****************************************************************************

static
void
WriteNexusHeader( const DivTime & dt,
		  FILE *          fp )
{

    fprintf(fp, "#NEXUS\n");
    fprintf(fp, "begin taxa;\n");
    fprintf(fp, "\tdimensions ntax=%lu;\n", dt._taxaVec.size());
    fprintf(fp, "\ttaxlabels\n");
    for ( auto tx : dt._taxaVec )
	fprintf(fp, "\t\t%s\n",  tx->_label.c_str());
    fprintf(fp, "\t\t;\n");
    fprintf(fp, "end;\n");
    fprintf(fp, "begin trees;\n");
    fprintf(fp, "\ttranslate\n");
    for ( auto txIter = dt._taxaVec.begin(); txIter != dt._taxaVec.end(); txIter++) {
	if ( txIter !=  dt._taxaVec.begin())
	    fprintf(fp, ",\n");
	fprintf(fp, "\t\t%d\t%s", (*txIter)->_id + 1,  (*txIter)->_label.c_str());
    }
    fputc('\n', fp);
    fprintf(fp, "\t\t;\n");

}

// *****************************************************************************

static
void
WriteNexusTrailer( FILE * fp)
{
    fprintf(fp, "end;\n:");
}
