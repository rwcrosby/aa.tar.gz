/// @file OptionsInit.h
/// Module that consolidates option handling (get/set/log)

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _OPTIONSINIT_H_
#define _OPTIONSINIT_H_

#include <algorithm>

#include "PerfInterface.h"
#include "SequenceFactory.h"
#include "TreeFactory.h"
#include "TreeStats.h"

// *****************************************************************************
/// Map to generate descriptions for the clock models

static std::map<Options::ClockModel, std::string> ClockModelNames = {
    {Options::ClockModel::GLOBAL,      "Single rate for each tree/locus"},
    {Options::ClockModel::INDEPENDENT, "Independent rates for each branch"},
    {Options::ClockModel::CORRELATED,  "Branch auto-correlated rates"}
};

// *****************************************************************************
/// Map to generate descriptions for the multi-tree models

static std::map<Options::MultiTreeModel, std::string> MultiTreeModelNames = {
    {Options::MultiTreeModel::INDEPENDENT, "Independent rates, ages for shared subtrees"},
    {Options::MultiTreeModel::COMMONRATES, "Common ages, independent rates for shared subtrees"},
    {Options::MultiTreeModel::COMMONBOTH, "Common ages, common rates for shared subtrees"}
};

// *****************************************************************************
/// Map to generate descriptions for the calibration types

static std::map<Options::CalType, std::string> CalibrationTypes = {
    {Options::CalType::LOWER_BOUND, "Lower Soft Bound"},
    {Options::CalType::UPPER_BOUND, "Upper Soft Bound"},
    {Options::CalType::LOWER_UPPER, "Lower and Upper Soft Bounds"},
    {Options::CalType::GAMMA_DIST,  "Gamma Distribution"},
    {Options::CalType::NORMAL_DIST, "Normal Distribution"}
};

#ifdef GENOPTINFO

// *****************************************************************************
/// Options information block.
/// Contains function pointers to perform the various tasks associated with
/// options (e.g. init, log).

struct OptInfo {

    /// Function to initialize the option in the DivTime object.
    /// Called prior to instantiation of any other objects.
    void            (*_initFn)  ( DivTime&         dt);    ///< DivTime instance to manipulate.

    /// Set the option from a DivOpt object passed.
    void            (*_setFn)   ( DivTime&         dt,    ///< DivTime instance to manipulate.
                                  Options::DivOpt* opt);  ///< Option id

    /// This function is called to check whether the option
    /// is available for output.
    /// @return True if option can be accessd, false otherwise
    bool            (*_checkFn) ( const DivTime&   dt);   ///< DivTime instance to access.

    /// Return a constructed DivTime object.
    /// @return DivOpt object.
    Options::DivOpt (*_getFn)   ( Options::OptType oType,
                                  const DivTime&   dt);   ///< DivTime instance to manipulate.

    /// Return the value of the option
    /// @return String for the option value.
    std::string     (*_valueFn) ( const DivTime&   dt);   ///< DivTime instance to access.

    /// Caption to use for the option on output
    const char *    _caption;

};


// *****************************************************************************
/// Options information.
/// Contains an entry for each option

static std::map<Options::OptType, OptInfo> OptionInit = {

    { Options::OptType::LogFile, {
            nullptr,
            [](DivTime& dt,
               Options::DivOpt *opt) { dt._logger->AddDestination(opt->data.cstr); },
            [](const DivTime& dt)    { return false; },
            nullptr,
            nullptr,
            ""
        }
    },
    { Options::OptType::LogFileNo, {
            nullptr,
            [](DivTime& dt,
               Options::DivOpt *opt) { dt._logger->AddDestination(opt->data.uintVal); },
            [](const DivTime& dt)    { return false; },
            nullptr,
            nullptr,
            ""
        }
    },
    { Options::OptType::LogSink, {
            nullptr,
            [](DivTime& dt,
               Options::DivOpt *opt) { dt._logger->AddDestination(opt->data.logSink); },
            [](const DivTime& dt)    { return false; },
            nullptr,
            nullptr,
            ""
        }
    },
    { Options::OptType::LogDebug, {
            nullptr,
            [](DivTime& dt,
               Options::DivOpt *opt) { dt._logger->Debug(opt->data.tf); },
            [](const DivTime& dt)    { return false; },
            nullptr,
            nullptr,
            ""
        }
    },
    { Options::OptType::LogPerf, {
            nullptr,
            [](DivTime& dt,
               Options::DivOpt *opt) { dt._perf = opt->data.tf; },
            [](const DivTime& dt)    { return false; },
            nullptr,
            nullptr,
            ""
        }
    },
    { Options::OptType::LogStats, {
            [](DivTime& dt)          { dt._logStats = true; },
            [](DivTime& dt,
               Options::DivOpt *opt) { dt._logStats = opt->data.tf; },
            [](const DivTime& dt)    { return false; },
            nullptr,
            nullptr,
            ""
        }
    },
    { Options::OptType::DumpTrees, {
            [](DivTime& dt)          { dt._dumpTrees = false; },
            [](DivTime& dt,
               Options::DivOpt *opt) { dt._dumpTrees = opt->data.tf; },
            [](const DivTime& dt)    { return false; },
            nullptr,
            nullptr,
            ""
        }
    },
    { Options::OptType::DumpReplicates, {
            [](DivTime& dt)          { dt._dumpRepl = false; },
            [](DivTime& dt,
               Options::DivOpt *opt) { dt._dumpRepl = opt->data.tf; },
            [](const DivTime& dt)    { return false; },
            nullptr,
            nullptr,
            ""
        }
    },
    { Options::OptType::Filename, {
            [](DivTime& dt)          { dt._filename = "FDivT"; },
            [](DivTime& dt,
               Options::DivOpt *opt) { dt._filename = opt->data.cstr; },
            [](const DivTime&   dt)  { return true; },
            [](Options::OptType oType,
               const DivTime&   dt)  { return Options::DivOpt( oType, dt._filename.c_str() ); },
            [](const DivTime&   dt)  { return std::string(dt._filename); },
            "Filename Root"
        }
    },
    { Options::OptType::FileOverwrite, {
            [](DivTime& dt)          { dt._fileOverwrite = false; },
            [](DivTime& dt,
               Options::DivOpt *opt) { dt._fileOverwrite = opt->data.tf; },
            [](const DivTime&   dt)  { return true; },
            [](Options::OptType oType,
               const DivTime&   dt)  { return Options::DivOpt( oType, dt._fileOverwrite); },
            [](const DivTime& dt) -> std::string
                                     { return dt._fileOverwrite ? "Yes" : "No"; },
            "Overwrite Output Files?"
        }
    },
    { Options::OptType::Seed, {
            [](DivTime& dt)          { dt._seedSet = false;
                                       dt._seed    = 0;},
            [](DivTime& dt,
               Options::DivOpt *opt) { dt._seed    = opt->data.uintVal;
                                       dt._seedSet = true;},
            [](const DivTime& dt)    { return true; },
            [](Options::OptType oType,
               const DivTime& dt)    { return Options::DivOpt( oType, dt._seed ); },
            [](const DivTime& dt)    { return std::to_string(dt._seed); },
            "Random Seed"
        }
    },
    { Options::OptType::ClockModel, {
            [](DivTime& dt)          { dt._cModelSet = false; },
            [](DivTime& dt,
               Options::DivOpt *opt) { dt._cModelSet = true;
                                       dt._cModel = opt->data.cmodel; },
            [](const DivTime& dt)    { return dt._cModelSet; },
            [](Options::OptType oType,
               const DivTime& dt)    { return Options::DivOpt( oType,
                                                               dt._cModel ); },
            [](const DivTime& dt)    { return ClockModelNames[dt._cModel]; },
            "Clock Model"
        }
    },
    { Options::OptType::MultiTreeModel, {
            [](DivTime&         dt)  { dt._mtModel = Options::MultiTreeModel::INDEPENDENT; },
            [](DivTime&         dt,
               Options::DivOpt* opt) { dt._mtModel = opt->data.mtmodel; },
            [](const DivTime&   dt)    { return true; },
            [](Options::OptType oType,
               const DivTime&   dt)    { return Options::DivOpt( oType,
								 dt._mtModel ); },
            [](const DivTime&   dt)    { return MultiTreeModelNames[dt._mtModel]; },
            "Multi-Tree Model"
        }
    },
    { Options::OptType::HashBits, {
            nullptr,
            [](DivTime& dt,
               Options::DivOpt *opt) {
                if (opt->data.uintVal == 0 || opt->data.uintVal > 31 )
                    throw Except::BadOptValue("HashBits",
                                              std::to_string(opt->data.uintVal));
                dt._treeFactory->HashBits(opt->data.uintVal);
            }  ,
            [](const DivTime& dt) -> bool
                                     { return dt._treeFactory != nullptr; },
            [](Options::OptType oType,
               const DivTime& dt)    { return Options::DivOpt( oType,
                                                               dt._treeFactory->HashBits()); },
            [](const DivTime& dt)    { return std::to_string(dt._treeFactory->HashBits()); },
            "Bits in Dag Hash Table"
        }
    },
    { Options::OptType::NThreads, {
            [](DivTime& dt)          { dt._nThreadsSet = false; },
            [](DivTime& dt,
               Options::DivOpt *opt) {
                if ( opt->data.uintVal == 0 )
                    throw Except::BadOptValue("NThreads", std::to_string(opt->data.uintVal));
                dt._nThreadsSet = true;
                dt._nThreads = opt->data.uintVal;
            },
            [](const DivTime& dt)    { return true; },
            [](Options::OptType oType,
               const DivTime& dt)    { return Options::DivOpt( oType,
                                                               dt._nThreads); },
            [](const DivTime& dt)    { return std::to_string(dt._nThreads); },
            "Number of Threads"
        }
    },
    { Options::OptType::UseGpu, {
            [](DivTime& dt)          { dt._useGpu = false; },
            [](DivTime& dt,
               Options::DivOpt *opt) { dt._useGpu = opt->data.tf; },
            [](const DivTime& dt)    { return true; },
            [](Options::OptType oType,
               const DivTime& dt)    { return Options::DivOpt( oType,
                                                               dt._useGpu); },
            [](const DivTime& dt) -> std::string
                                     { return dt._useGpu ? "Yes" : "No"; },
            "Use GPU?"
        }
    },
    { Options::OptType::SeqChars, {
            nullptr,
            [](DivTime& dt,
               Options::DivOpt *opt) { dt._seqFactory->_alphabet = std::string(opt->data.cstr); },
            [](const DivTime& dt)    { return true; },
            [](Options::OptType oType,
               const DivTime& dt)    { return Options::DivOpt( oType,
                                                               dt._seqFactory->_alphabet.c_str()); },
            [](const DivTime& dt)    { return dt._seqFactory->_alphabet; },
            "Sequence Characters"
        }
    },
    { Options::OptType::GapChar, {
            nullptr,
            [](DivTime& dt,
               Options::DivOpt *opt) { dt._seqFactory->_gapCh = opt->data.ch; },
            [](const DivTime& dt)    { return true; },
            [](Options::OptType oType,
               const DivTime& dt)    { return Options::DivOpt( oType,
                                                               dt._seqFactory->_gapCh); },
            [](const DivTime& dt)    { return std::string(1, dt._seqFactory->_gapCh); },
            "Gap Character"
        }
    },
    { Options::OptType::MissingChar, {
            nullptr,
            [](DivTime& dt,
               Options::DivOpt *opt) { dt._seqFactory->_missingCh = opt->data.ch; },
            [](const DivTime& dt)    { return true; },
            [](Options::OptType oType,
               const DivTime& dt)    { return Options::DivOpt( oType,
                                                               dt._seqFactory->_missingCh); },
            [](const DivTime& dt)    { return std::string(1, dt._seqFactory->_missingCh); },
            "Missing Data Character"
        }
    },
    { Options::OptType::NGen, {
            [](DivTime& dt)          { dt._nGenSet = false;
                                       dt._nGen    = 0; },
            [](DivTime& dt,
               Options::DivOpt *opt) {
                if (opt->data.uintVal == 0 )
                    throw Except::BadOptValue("NGen", std::to_string(opt->data.uintVal));
                dt._nGenSet = true;
                dt._nGen = opt->data.uintVal;
            },
            [](const DivTime& dt)    { return true; },
            [](Options::OptType oType,
               const DivTime& dt)    { return Options::DivOpt( oType,
                                                               dt._nGen); },
            [](const DivTime& dt)    { return std::to_string(dt._nGen); },
            "MCMC Generations"
        }
    },
    { Options::OptType::Burnin, {
            [](DivTime& dt)          { dt._burninSet = false;
                                       dt._burnin    = 0; },
            [](DivTime& dt,
               Options::DivOpt *opt) { dt._burninSet = true;
                                       dt._burnin    = opt->data.uintVal; },
            [](const DivTime& dt)    { return true; },
            [](Options::OptType oType,
               const DivTime& dt)    { return Options::DivOpt( oType,
                                                               dt._burnin); },
            [](const DivTime& dt)    { return std::to_string(dt._burnin); },
            "Burnin Generations"
        }
    },
    { Options::OptType::SampleFreq, {
            [](DivTime& dt)          { dt._sampleFreq = dt._nGen ? std::min(1000u, dt._nGen/10) : 10; },
            [](DivTime& dt,
               Options::DivOpt *opt) {
                if (opt->data.uintVal == 0)
                    throw Except::BadOptValue("SampleFreq", std::to_string(opt->data.uintVal));
                dt._sampleFreq = opt->data.uintVal;
            },
            [](const DivTime& dt)    { return true; },
            [](Options::OptType oType,
               const DivTime& dt)    { return Options::DivOpt( oType,
                                                               dt._sampleFreq); },
            [](const DivTime& dt)    { return std::to_string(dt._sampleFreq); },
            "Sampling Frequency"
        }
    },
    { Options::OptType::NRuns, {
            [](DivTime& dt)          { dt._nRunsSet = false; },
            [](DivTime& dt,
               Options::DivOpt *opt) {
                if (opt->data.uintVal == 0 )
                    throw Except::BadOptValue("NRuns", std::to_string(opt->data.uintVal));
                dt._nRunsSet = true;
                dt._nRuns = opt->data.uintVal;
            },
            [](const DivTime& dt)    { return true; },
            [](Options::OptType oType,
               const DivTime& dt)    { return Options::DivOpt( oType,
                                                               dt._nRuns); },
            [](const DivTime& dt)    { return std::to_string(dt._nRuns); },
            "MCMC Chains per Tree"
        }
    },
    { Options::OptType::NReplicates, {
            [](DivTime& dt)          { dt._nJackReplSet = false;
                                       dt._nJackRepl    = 0; },
            [](DivTime& dt,
               Options::DivOpt *opt) { dt._nJackReplSet = true;
                                       dt._nJackRepl    = opt->data.uintVal; },
            [](const DivTime& dt)    { return true; },
            [](Options::OptType oType,
               const DivTime& dt)    { return Options::DivOpt( oType,
                                                               dt._nJackRepl); },
            [](const DivTime& dt)    { return std::to_string(dt._nJackRepl); },
            "Jackknife Replicates"
        }
    },
    { Options::OptType::ReplicatePct, {
            [](DivTime& dt)          { dt._jackPctSet = false;
                                       dt._jackPct    = 100.0; },
            [](DivTime& dt,
               Options::DivOpt *opt) { dt._jackPctSet = true;
                                       dt._jackPct    = opt->data.doubleVal; },
            [](const DivTime&   dt)  { return true; },
            [](Options::OptType oType,
               const DivTime&   dt)  { return Options::DivOpt( oType,
                                                               dt._jackPct); },
            [](const DivTime& dt)    { return std::to_string(dt._jackPct); },
            "Jackknife Calibration Percentage"
        }
    },
    { Options::OptType::BDLambda, {
            [](DivTime& dt)          { dt._bdLambda = 1.0; },
            [](DivTime& dt,
               Options::DivOpt *opt) {
                if (opt->data.doubleVal <= 0.0)
                    throw Except::BadOptValue("BDLambda", std::to_string(opt->data.doubleVal));
		dt._bdLambda = opt->data.doubleVal;
            },
            [](const DivTime& dt)    { return true; },
            [](Options::OptType oType,
               const DivTime& dt)    { return Options::DivOpt( oType,
                                                               dt._bdLambda); },
            [](const DivTime& dt)    { return std::to_string(dt._bdLambda); },
            "Birth-Death Lambda"
        }
    },
    { Options::OptType::BDMu, {
            [](DivTime& dt)          { dt._bdMu = 1.0; },
            [](DivTime& dt,
               Options::DivOpt *opt) {
                if (opt->data.doubleVal <= 0.0)
                    throw Except::BadOptValue("BDMu", std::to_string(opt->data.doubleVal));
		dt._bdMu = opt->data.doubleVal;
            },
            [](const DivTime& dt)    { return true; },
            [](Options::OptType oType,
               const DivTime& dt)    { return Options::DivOpt( oType,
                                                               dt._bdMu); },
            [](const DivTime& dt)    { return std::to_string(dt._bdMu); },
            "Birth-Death Mu"
        }
    },
    { Options::OptType::BDRho, {
            [](DivTime& dt)          { dt._bdRho = 0.1; },
            [](DivTime& dt,
               Options::DivOpt *opt) {
                if (opt->data.doubleVal <= 0.0)
                    throw Except::BadOptValue("BDRho", std::to_string(opt->data.doubleVal));
		dt._bdRho = opt->data.doubleVal;
            },
            [](const DivTime& dt)    { return true; },
            [](Options::OptType oType,
               const DivTime& dt)    { return Options::DivOpt( oType,
                                                               dt._bdRho); },
            [](const DivTime& dt)    { return std::to_string(dt._bdRho); },
            "Birth-Death Rho"
        }
    },
    { Options::OptType::ClockMeanAlpha, {
            [](DivTime& dt)          { dt._cMMeanAlpha = 2.0; },
            [](DivTime& dt,
               Options::DivOpt *opt) { dt._cMMeanAlpha = opt->data.doubleVal; },
            [](const DivTime& dt)    { return true; },
            [](Options::OptType oType,
               const DivTime& dt)    { return Options::DivOpt( oType,
                                                               dt._cMMeanAlpha); },
            [](const DivTime& dt)    { return std::to_string(dt._cMMeanAlpha); },
            "Rates Mean - Gamma Alpha"
        }
    },
    { Options::OptType::ClockMeanBeta, {
            [](DivTime& dt)          { dt._cMMeanBeta = 2.0; },
            [](DivTime& dt,
               Options::DivOpt *opt) { dt._cMMeanBeta = opt->data.doubleVal; },
            [](const DivTime& dt)    { return true; },
            [](Options::OptType oType,
               const DivTime& dt)    { return Options::DivOpt( oType,
                                                               dt._cMMeanBeta); },
            [](const DivTime& dt)    { return std::to_string(dt._cMMeanBeta); },
            "Rates Mean - Gamma Beta"
        }
    },
    { Options::OptType::ClockMeanDCon, {
            [](DivTime& dt)          { dt._cMMeanDCon = 1.0; },
            [](DivTime& dt,
               Options::DivOpt *opt) { dt._cMMeanDCon = opt->data.doubleVal; },
            [](const DivTime& dt)    { return true; },
            [](Options::OptType oType,
               const DivTime& dt)    { return Options::DivOpt( oType,
                                                               dt._cMMeanDCon); },
            [](const DivTime& dt)    { return std::to_string(dt._cMMeanDCon); },
            "Rates Mean - Dirichlet Concentration"
        }
    },
    { Options::OptType::ClockVarAlpha, {
            [](DivTime& dt)          { dt._cMVarAlpha = 1.0; },
            [](DivTime& dt,
               Options::DivOpt *opt) { dt._cMVarAlpha = opt->data.doubleVal; },
            [](const DivTime& dt)    { return true; },
            [](Options::OptType oType,
               const DivTime& dt)    { return Options::DivOpt( oType,
                                                               dt._cMVarAlpha); },
            [](const DivTime& dt)    { return std::to_string(dt._cMVarAlpha); },
            "Rates Variance - Gamma Alpha"
        }
    },
    { Options::OptType::ClockVarBeta, {
            [](DivTime& dt)          { dt._cMVarBeta = 1.0; },
            [](DivTime& dt,
               Options::DivOpt *opt) { dt._cMVarBeta = opt->data.doubleVal; },
            [](const DivTime& dt)    { return true; },
            [](Options::OptType oType,
               const DivTime& dt)    { return Options::DivOpt( oType,
                                                               dt._cMVarBeta); },
            [](const DivTime& dt)    { return std::to_string(dt._cMVarBeta); },
            "Rates Variance - Gamma Beta"
        }
    },
    { Options::OptType::ClockVarDCon, {
            [](DivTime& dt)          { dt._cMVarDCon = 1.0; },
            [](DivTime& dt,
               Options::DivOpt *opt) { dt._cMVarDCon = opt->data.doubleVal; },
            [](const DivTime& dt)    { return true; },
            [](Options::OptType oType,
               const DivTime& dt)    { return Options::DivOpt( oType,
                                                               dt._cMVarDCon); },
            [](const DivTime& dt)    { return std::to_string(dt._cMVarDCon); },
            "Rates Variance - Dirichlet Concentration"
        }
    }
};

// *****************************************************************************
/// Provides the ordering to use for output of the options since map's aren't ordered.
/// An entry of NumOptions is used to divide option groups.

static const std::vector<Options::OptType> OptionsOrder = {
    Options::OptType::Filename,
    Options::OptType::FileOverwrite,
    Options::OptType::Seed,
    Options::OptType::NumOptions,
    Options::OptType::MultiTreeModel,
    Options::OptType::HashBits,
    Options::OptType::NThreads,
    Options::OptType::UseGpu,
    Options::OptType::NumOptions,
    Options::OptType::SeqChars,
    Options::OptType::GapChar,
    Options::OptType::MissingChar,
    Options::OptType::NumOptions,
    Options::OptType::NGen,
    Options::OptType::Burnin,
    Options::OptType::SampleFreq,
    Options::OptType::NumOptions,
    Options::OptType::NRuns,
    Options::OptType::NReplicates,
    Options::OptType::ReplicatePct,
    Options::OptType::NumOptions,
    Options::OptType::BDLambda,
    Options::OptType::BDMu,
    Options::OptType::BDRho,
    Options::OptType::NumOptions,
    Options::OptType::ClockModel,
    Options::OptType::ClockMeanAlpha,
    Options::OptType::ClockMeanBeta,
    Options::OptType::ClockMeanDCon,
    Options::OptType::ClockVarAlpha,
    Options::OptType::ClockVarBeta,
    Options::OptType::ClockVarDCon
};

#endif

#endif // _OPTIONSINIT_H_
