/// @file TaskBase.h
/// Header for the task base class.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _TASKBASE_H_
#define _TASKBASE_H_

#include <functional>

struct DivTime;
struct StepProcessor;

// *****************************************************************************
/// Base class for the tasks that will be dispatched to the threads.

/// This is a pure virtual class even though the Init() and Term() methods
/// in particular might not be overridden. The () operator must be though.

class TaskBase {

public:

    StepProcessor & _sp;                          ///< Reference to the parent step processor

    /// Constructor just setting the step processor reference
    TaskBase (StepProcessor & sp)
        : _sp (sp)
        {};

    /// Virtual destructor.
    virtual ~TaskBase()
        {}

    /// "Do it" method.
    ///
    /// The parenthesis method is used to actually do whatever is
    /// required on the thread.
    /// It is required that it be overridden.
    virtual void operator()( unsigned tno         ///< Thread number
	                   )  = 0;

};

#endif // _TASKBASE_H_
