/// @file AgeParameter.h
/// Declaration of the branch time parameter class

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _AGEPARAMETER_H_
#define _AGEPARAMETER_H_

struct Parameter;
struct AgePriorNode;
struct Replicate;

namespace Tree {
    struct Position;
}

/// Factory to construct an age parameter.
namespace Ages {

    /// Construct an age parameter.
    /// @param repl Owning replicate.
    /// @param tPos Owning species tree node.
    Parameter * Factory ( Replicate &            repl,
			  const Tree::Position & tPos );

}

#endif // _AGEPARAMETER_H_
