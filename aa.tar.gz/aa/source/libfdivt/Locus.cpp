/// @file Locus.cpp
/// Definitions for the Locus class methods.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include <set>

#include "Locus.h"
#include "Logger.h"
#include "Sequence.h"
#include "SequenceFactory.h"
#include "Taxa.h"

// *****************************************************************************
void
Locus::AddSequence ( Sequence * seq ) ///< Pointer to the sequence object
{
    auto idx = seq->_taxa._id;
    if ( idx + 1 > _seqVec.size() )
	_seqVec.resize(idx + 1, nullptr);
    _seqVec[idx] = seq;
};

// *****************************************************************************

void
Locus::ComputeStatistics()
{
    if ( _charPct.size() )                        ///< Already done?
        return;

    _charCnts.resize(_seqFac._alphabet.size());

    /// Set used to accumulate the site patterns
    std::set<UCHARVEC> patterns;

    /// - Loop through the columns of the sequences

    for ( unsigned col = 0; col < _seqLen; col++ ) {
        bool missingData = false;
        bool invariant   = true;
        bool allMissing  = true;

        /// - Loop throught the sequences for this column

        UCHARVEC sitePattern;
        signed char lastCh(-1);

        for ( auto seq : _seqVec ) {

            if ( !seq )
                continue;

            _totalAllChars++;

            unsigned char c = (*seq)[col];

            if ( c >= _seqFac._alphabet.size() )
                missingData = true;
            else
                allMissing = false;

            sitePattern.emplace_back(c);

            if ( lastCh == -1 )
                lastCh = c;
            else if ( c != lastCh )
                invariant = false;

        }

        if ( invariant )
            _invariantCols++;

        if ( allMissing )
            _allMissingCols++;

        if ( missingData )
            _missingDataCols++;

        patterns.emplace(sitePattern);

    }

    _charPct.resize(_seqFac._alphabet.size());
    for ( unsigned i = 0; i < _seqFac._alphabet.size(); i++ )
        _charPct[i] = FLOAT (_charCnts[i]) / FLOAT (_totalChars);

    _uniquePatterns = patterns.size();

}

// *****************************************************************************
/// Output locus summary information (sequence length, char percentages)

void
Locus::Log( Logger & logger ) const
{

    logger("Locus %d: %s", _id + 1, _label.c_str());

    logger("%*cSequence length                    : %6d", Logger::indent, ' ',
           _seqLen);
    logger("%*cUnique site patterns               : %6d", Logger::indent, ' ',
           _uniquePatterns);
    logger("%*cInvariant columns                  : %6d (%.2f%%)", Logger::indent, ' ',
           _invariantCols,
           100.0 * FLOAT (_invariantCols) / FLOAT (_seqLen));
    logger("%*cColumns with missing/gap chars     : %6d (%.2f%%)", Logger::indent, ' ',
           _missingDataCols,
           100.0 * FLOAT (_missingDataCols) / FLOAT (_seqLen));
    logger("%*cColumns with only missing/gap chars: %6d (%.2f%%)", Logger::indent, ' ',
           _allMissingCols,
           100.0 * FLOAT (_allMissingCols) / FLOAT (_seqLen));
    logger("%*cNumber of missing/gap chars        : %6d (%.2f%%)", Logger::indent, ' ',
           _totalAllChars - _totalChars,
           100.0 * FLOAT (_totalAllChars - _totalChars) / FLOAT (_totalAllChars) );

    logger("%*cChar:  Count:", Logger::indent, ' ');
    for ( unsigned i = 0; i < _seqFac._alphabet.length(); i++)
        logger("%*c '%c'  %6d (%.2f%%)", Logger::indent, ' ',
               _seqFac._alphabet[i], _charCnts[i], 100.0 * _charPct[i]);

}
