/// @file PerfInterface.h
/// Interface to the performance data output

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _PERFINTERFACE_H_
#define _PERFINTERFACE_H_

#include <cstdlib>

#include "Config.h"

class  Logger;
class  PAPI;
class  PAPIThread;
struct PerfBlock;
struct Thread;

// *****************************************************************************
/// Interface to the performance data.

/// For performance data to output it must both be compiled in (as evidenced in
/// config.h) and either the associated environment variable must be in the environment
/// or the options must be set.

class PerfInterface {

    bool        _initialized;			  ///< Interface is operational

    Logger &    _logger;                          ///< Output logger

    PerfBlock * _initBlk;                         ///< Starting performance data
    PerfBlock * _lastBlk;                         ///< Last performance data block

    PAPI *      _papi;                            ///< Hardware performance tracing
    PAPIThread *_papiThread;                      ///< PAPI block for master thread

    /// Handle the actual initialization of the interface
    /// @throw PerfError Error returned from performance interface.
    void _Initialize();

    /// Handle the actual shutdown of the interface
    void _Terminate();

    /// Actual performance data output
    /// @throw PerfError Error returned from performance interface.
    void _Output( const std::string );            ///< Header for the output.

public:


    /// Constructor just setting the initial values.
    /// Real initialization occurs in the Initialize method.

    PerfInterface( Logger & logger )		  ///< Logger to use.
        : _initialized(false),
          _logger(logger),
          _papi(nullptr),
          _papiThread(nullptr)
	{}

    /// Initialize the interface for operation.
    /// The test occurs here to allow the compiler to ignore the calls
    /// when performance tracing was not compiled in.
    /// @throw PerfError Error returned from performance interface.

    void Initialize()                            ///< Actual instance initialization.
	{
	    if ( perfSet && !_initialized ) {
		_initialized = true;
		_Initialize();
	    }
	}

    /// Destructor to clean up the perf blocks.

    virtual ~PerfInterface()
	{
	    if ( perfSet && _initialized )
		_Terminate();
	}

    /// Do the actual tracing.
    /// The test occurs here to allow the compiler to ignore the calls
    /// when performance tracing was not compiled in.

    void operator()( const std::string heading )  ///< String to print as the data heading.
	{
	    if ( perfSet && _initialized )
		_Output(heading);
	}

    /// Return initialization state.

    bool Active()
	{
	    return _initialized;
	}

    friend struct        Thread;

};

#endif // _PERFINTERFACE_H_
