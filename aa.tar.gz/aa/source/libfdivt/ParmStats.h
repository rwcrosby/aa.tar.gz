/// @file ParmStats.h
/// Parameters statistics object definition.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _PARMSTATS_H_
#define _PARMSTATS_H_

#include <list>

#include "LogStats.h"

// *****************************************************************************
/// Parameters Statistics structure

struct ParmStats : public LogStats {

    enum Type : unsigned char {
	RATE     = 0,
	AGE      = 1,
	NUISANCE = 2,
	EOL
    };

    // Counters for performance information

    unsigned  _nParms;                            ///< Total number of parameters
    unsigned  _memParms;                          ///< Total memory for parameters

    struct {
	unsigned  _n;                             ///< Total number of parameters
	unsigned  _mem;                           ///< Total memory for parameters
    } _parms[EOL];

    STATSLIST _statsList;                         ///< Dag Statistics

    ParmStats(Logger &    log)                    ///< Logger instance pointer
        : LogStats(log, "Parameters Statistics")
        {

	    for ( auto& p : _parms ) {
		p._n = 0;
		p._mem = 0;
	    }

            _statsList.push_back (STATSITEM ("Total Parameters",       &_nParms));
            _statsList.push_back (STATSITEM ("Total Parameter Memory", &_memParms));

            _statsList.push_back (STATSITEM ("Rate Parameters",        &_parms[0]._n));
            _statsList.push_back (STATSITEM ("Rate Parameter Memory",  &_parms[0]._mem));

            _statsList.push_back (STATSITEM ("Time Parameters",        &_parms[1]._n));
            _statsList.push_back (STATSITEM ("Time Parameter Memory",  &_parms[1]._mem));

            _statsList.push_back (STATSITEM ("Other Parameters",       &_parms[2]._n));
            _statsList.push_back (STATSITEM ("Other Parameter Memory", &_parms[2]._mem));

        }

    virtual ~ParmStats()
        {}

    virtual void Log()
        {
            _nParms = 0;
	    _memParms = 0;
	    for ( auto& p : _parms ) {
		_nParms += p._n;
		_memParms += p._mem;
	    }
            _DoLogging(_statsList);
        }

};

#endif // _PARMSTATS_H_
