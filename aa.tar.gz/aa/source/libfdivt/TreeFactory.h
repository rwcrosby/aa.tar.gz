/// @file TreeFactory.h
/// Declaration of the tree factory.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _TREEFACTORY_H_
#define _TREEFACTORY_H_

#include <list>
#include <map>
#include <unordered_map>
#include <vector>

// *****************************************************************************
/// Forward declarations

struct HashStats;
struct Locus;
class  Logger;
struct Taxa;
struct TreeStats;

template < typename KeyT, typename ValT>  class  HashTable;

namespace Tree {
    struct Init;
    struct Node;
    struct Position;
    struct Root;
}

namespace InputTree {
    struct Node;
}

// *****************************************************************************
/// Dag factory class declaration

/// Create a Dag style tree from an input tree.

struct TreeFactory : std::list<Tree::Root> {

    /// Constructor for the factory, just initialize things.
    TreeFactory( HashStats &                    hashStats, ///< Hash table statistics
		 std::map<std::string, Taxa> &  taxaMap,   ///< Taxa name/instance map
		 std::vector<Locus* > &         locusVec,  ///< Ordered set of loci
                 Logger &                       logger     ///< Log to output to
	       );

    ~TreeFactory();

    /// Initialize the hash table size.
    /// @param hb Bits in the hash table key
    void HashBits( const unsigned hb )
        {
            _hashBits = hb;
        }

    /// Return the hash table size.
    /// @return Hash table key size.
    unsigned HashBits( void ) const
        {
            return _hashBits;
        }

    /// Add the tree to the factory collection.
    /// @throw Except::MissingTaxa Taxa not already added
    /// @throw Except::InvalidTree Error in tree structure
    void operator()( const InputTree::Node * const  node,  ///< User supplied tree.
		     const std::string              label  ///< Name for the tree.
	           );

    /// Find the leaf node for a taxa
    /// @param root Tree to look for the taxa in
    /// @param taxa Taxa to look for
    /// @return Tree position block (empty if taxa isn't in the tree).
    Tree::Position   FindLeaf ( const Tree::Root & root,
                                const Taxa &       taxa ) const;

    /// Fill out locus and site data.
    /// All trees must have been loaded prior to this being run.
    /// Disallows adding any additional trees after this point.
    void             Finish   ( TreeStats & stats );

private:

    /// Perform the actual hash table lookup
    std::pair<Tree::Node *&,
              bool>  HashLookup         ( const std::string & key );

    /// Build the hash key for an inner node
    /// The hash depends on the order of the branches being consistent.
    /// In order to handle this the branches are sorted by their taxa id's.
    /// @param cList List of children from which to build the key.
    /// @return String with key.
    std::string      MakeKey           ( std::list<Tree::Position> & cList );

    /// Build the hash key for a leaf.
    /// @param id Taxa id number from which to build the key.
    /// @return String with key.
    std::string      MakeKey           ( const unsigned id );

    /// Restrict the gene trees to only the set of taxa for which there are sequences.
    void             RestrictGeneTrees ( void );

    /// Reduce a gene tree by a leaf.
    /// Used to handle the case where there isn't a sequence for a
    /// particular taxa for particular locus.
    /// @param tPos Leaf position in tree
    /// @param locusIdx  Locus to remove it from
    void             ReduceTree        ( const Tree::Position & tPos,
                                         const unsigned         locusIdx );

    HashStats &                    _hashStats;	  ///< Hash table statistics

    std::map<std::string, Taxa> &  _taxaMap;	  ///< Taxa name/instance map
    std::vector<Locus* > &         _locusVec;	  ///< Vector of loci

    std::vector<Tree::Node *>      _leafVec;      ///< Leaves indexed by taxa id

    unsigned                       _hashBits;     ///< Bits in the dag hash keys
    HashTable< std::string,
               Tree::Node * > *    _hashTable;    ///< Vector hash table

    Logger &                       _logger;       ///< Log to output to

    bool                           _treeBlks;	  ///< True if the tree blocks exist

    friend struct DivTime;

};

#endif // _TREEFACTORY_H_
