/// @file RatesParameters.cpp
/// Definitions for the rate parameters

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include "DivTime.h"
#include "Dump.h"
#include "EvoModel.h"
#include "ITransaction.h"
#include "Likelihood.h"
#include "Locus.h"
#include "Parameter.h"
#include "ParmStats.h"
#include "RatesParameters.h"
#include "RatesPrior.h"
#include "Replicates.h"
#include "StatsFn.h"
#include "Tree.h"

// *****************************************************************************
/// Parameter for a rate at a gene tree node.

struct RateParameter : Parameter {

    RateParameter ( Replicate &       repl,     ///< Chain or jackknife replicate.
                    Tree::LocusNode & lNode     ///< Owning locus node
                   )
	: Parameter(repl, lNode._lRoot._root, ParmStats::RATE),
	  _lNode(lNode),
	  _lRoot(_lNode._lRoot)
	{
	    _repl._stats._parms[ParmStats::RATE]._mem += sizeof(*this);
	    SetTraceInfo(Tree::TraceType::RateParm,
			 lNode._lRoot._locus._id,
			 lNode._tNode->_node->_id,
			 "Rate");
	}

    /// Accept the proposal
    virtual
    void
    Accept()
	{
	    _repl._rateAccepted++;
	    Parameter::Accept();
	}

    /// Propose a new parameter value.
    /// @return Prior ratio for the proposal.
    virtual
    FLOAT
    Propose();

    /// Accept the proposal
    virtual
    void
    Reject()
	{
	    _repl._rateRejected++;
	    Parameter::Reject();
	}

    /// Just to base clase rollback stuff
    virtual
    void
    Rollback()
	{
	    Parameter::Rollback();
	}

    virtual
    std::string
    str()
	const
	{
	    std::stringstream ss;
	    ss << Parameter::str() << ' '
	       << Dump::str(_root._rootIdx, "tid") << ' '
	       << Dump::str(_lRoot._locus._id, "lid") << ' '
	       << Dump::str(_lNode._tNode->_node->_id, "nid");
	    return ss.str();
	}

private:

    Tree::LocusNode & _lNode;			  ///< Owning gene tree node
    Tree::LocusRoot & _lRoot;			  ///< Owning gene tree

};

// *****************************************************************************
/// Base class for the rates hyperparameters \f$\mu\f$ and \f$\sigma^2\f$.
/// Handles the compututation of the gamma-dirichlet prior.

struct RateHyperparameter : NuisanceParameter {

    /// Sets up the initial value for the parameter and the constants used.
    /// Does not compute the initial prior. All the initial rate values need
    /// to be in place before that happens

    RateHyperparameter( Replicate &       repl,     ///< Chain or jackknife replicate.
			Tree::LocusRoot & lRoot,    ///< Owning gene tree
			FLOAT  &          sumRates, ///< Sum of parameter values across genes
			const FLOAT       alpha,    ///< Alpha for distribution
			const FLOAT       beta,     ///< Beta for distribution
			const FLOAT       dcon,     ///< Dirichlet concentration
			const std::string label,    ///< Label for trace
			const std::string heading   ///< Heading for trace
	              )
        : NuisanceParameter(repl, lRoot._root),
	  _lRoot(lRoot),
	  _sumRates(sumRates),
	  _oldSumRates(0.0),
	  _oldLnL(0.0),
	  _alpha(alpha),
	  _beta(beta),
	  _dcon(dcon),
	  _nGenes(_repl._dt._locusVec.size())
	{
	    /// - Set initial parameter value

	    _value = repl._statsObj->DrawGamma(alpha, beta);
	    _sumRates += _value;

	    /// - Setup constants

	    _c1 = _alpha - _nGenes * _dcon;
	    _c2 = - (_beta / _nGenes);
	    _c3 = _dcon - 1.0;

	    SetTraceInfo( Tree::TraceType::NuisanceParm, _lRoot._locus._id, label, heading );
	}

    /// Compute the full value of the prior for use as the starting point.
    /// The gamma-dirichlet prior on mu_i and sigma2_i (dos reis et al. 2014: eq. 5) is used.
    inline
    void
    ComputePrior(const FLOAT lnSumRates )
	{
	    _prior = _alpha * log(_beta / _nGenes) -
		     lgamma(_alpha) +
		     lgamma(_nGenes * _dcon) -
		     _nGenes * lgamma(_dcon) +
  		     _c1 * log(_sumRates) +
		     _c2 * _sumRates +
		     _c3 * lnSumRates;
	    _lnPN += _prior;
	}

    inline
    virtual
    FLOAT
    Propose()
	{
	    NuisanceParameter::Propose();
	    _oldSumRates = _sumRates;
	    return 1.0;
	}

    inline
    virtual
    void
    Rollback()
	{
	    NuisanceParameter::Rollback();
	    _sumRates = _oldSumRates;
	    _repl.LogRollback(this);
	}

    /// Update the sum of rates and prior.
    /// The gamma-dirichlet prior on mu_i and sigma2_i (dos reis et al. 2014: eq. 5) is used.
    inline
    void
    UpdateValues( const FLOAT newLnValue,
		  const FLOAT oldLnValue )
	{
	    _sumRates += _value - _oldValue;
	    FLOAT deltaLnPr = _c1 * log(_sumRates / _oldSumRates) +
		              _c2 * _value - _oldValue +
		              _c3 * ( newLnValue - oldLnValue);
	    _prior += deltaLnPr;
	    _lnPN += deltaLnPr;
	}

    virtual
    std::string
    str()
	const
	{
	    std::stringstream ss;
	    ss << NuisanceParameter::str() << ' '
	       << Dump::str(_root._rootIdx, "tid") << ' '
	       << Dump::str(_lRoot._locus._id, "lid") << ' '
	       << Dump::str(_c1, "c1") << ' '
	       << Dump::str(_c2, "c2") << ' '
	       << Dump::str(_c3, "c3");
	    return ss.str();
	}

protected:

    Tree::LocusRoot & _lRoot;			  ///< Owning gene tree.

    FLOAT  &          _sumRates;		  ///< Sum of the parameter values across genes
    FLOAT             _oldSumRates;		  ///< Save the value of the rates sum for rollback.
    FLOAT             _oldLnL;			  ///< Saved log likelihood for locus

    const FLOAT       _alpha;			  ///< Alpha for dirichlet prior
    const FLOAT       _beta;			  ///< Beta for dirichlet prior
    const FLOAT       _dcon;			  ///< Dirichlet concentration

    const FLOAT       _nGenes;			  ///< Number of genes (duh)

    float             _c1;			  ///< Constant: \f$\alpha_{\mu} - L \alpha\f$
    FLOAT             _c2;			  ///< Constant: \f$-\frac{\beta_{\mu}}{L}\f$
    FLOAT             _c3;			  ///< Constant: \f$\alpha - 1\f$

};

// *****************************************************************************
/// Mean hyperparameter for rates for the molecular clock.

struct RateMeanClockParameter : RateHyperparameter {

    RateMeanClockParameter ( Replicate &       repl,  ///< Chain or jackknife replicate.
			     Tree::LocusRoot & lRoot  ///< Owning gene tree
  	                    )
	: RateHyperparameter(repl,
			     lRoot,
			     lRoot._root._sumRatesMean,
			     repl._dt._cMMeanAlpha,
			     repl._dt._cMMeanBeta,
			     repl._dt._cMMeanDCon,
			     "Rates Mean",
			     "Rates_Mean")
	{
	    _repl._stats._parms[_pType]._mem += sizeof(*this);
	}

    virtual
    FLOAT
    Propose();

};

// *****************************************************************************
/// Mean hyperparameter for rates for the non-molecular clock models.

struct RateMeanNonClockParameter : RateHyperparameter {

    RateMeanNonClockParameter ( Replicate &       repl, ///< Chain or jackknife replicate.
				Tree::LocusRoot & lRoot ///< Owning gene tree
	                      )
	: RateHyperparameter(repl,
			     lRoot,
			     lRoot._root._sumRatesMean,
			     repl._dt._cMMeanAlpha,
			     repl._dt._cMMeanBeta,
			     repl._dt._cMMeanDCon,
			     "Rates Mean",
			     "Rates_Mean")
	{
	    _repl._stats._parms[_pType]._mem += sizeof(*this);
	}

    virtual
    FLOAT
    Propose();

};

// *****************************************************************************
/// Variance (\f$\sigma^2\f$) hyperparameter value for the rate priors.
/// Only created for the non-molecular clock models.

struct RateVarianceParameter : RateHyperparameter {

    RateVarianceParameter ( Replicate &       repl, ///< Chain or jackknife replicate.
			    Tree::LocusRoot & lRoot ///< Owning gene tree
	                  )
	: RateHyperparameter(repl,
			     lRoot,
			     lRoot._root._sumRatesVar,
			     repl._dt._cMVarAlpha,
			     repl._dt._cMVarBeta,
			     repl._dt._cMVarDCon,
			     "Rates Variance",
			     "Rates_Variance")
	{
	    _repl._stats._parms[_pType]._mem += sizeof(*this);
	}

    virtual
    FLOAT
    Propose();

};

// *****************************************************************************

Parameter *
Rates::Factory ( Replicate &       repl,
		 Tree::LocusNode & lNode )
{
    Parameter * parm = new RateParameter(repl, lNode);
    return parm;
}

// *****************************************************************************

Parameter *
Rates::MeanFactory ( Replicate &       repl,
		     Tree::LocusRoot & lRoot )
{

    Parameter * parm = nullptr;

    switch (repl._cModel ) {

        case Options::ClockModel::GLOBAL:
	    parm = new RateMeanClockParameter ( repl, lRoot);
	    break;

        case Options::ClockModel::INDEPENDENT:
        case Options::ClockModel::CORRELATED:
	    parm = new RateMeanNonClockParameter ( repl, lRoot);
	    break;

        default:
	    assert(0 && "Invalid clock model");

    }

    return parm;

}

// *****************************************************************************

Parameter *
Rates::VarianceFactory ( Replicate &       repl,
			 Tree::LocusRoot & lRoot )
{

    Parameter * parm = nullptr;

    switch (repl._cModel ) {

        case Options::ClockModel::GLOBAL:
	    break;

        case Options::ClockModel::INDEPENDENT:
        case Options::ClockModel::CORRELATED:
	    parm = new RateVarianceParameter ( repl, lRoot);
	    break;

        default:
	    assert(0 && "Invalid clock model");

    }

    return parm;

}

// *****************************************************************************

void
Rates::InitialParmPriors ( Replicate & repl )
{
    for ( auto & root : repl ) {

	FLOAT lnSumMean = 0.0;
	FLOAT lnSumVar  = 0.0;

	for ( auto & lRoot : root._locusVec ) {
	    lnSumMean += log((*lRoot._ratesMeanParm)());

	    if ( lRoot._ratesVarParm )
		lnSumVar += log((*lRoot._ratesVarParm)());
	}

	for ( auto & lRoot : root._locusVec ) {

	    auto p = static_cast<RateHyperparameter*>(lRoot._ratesMeanParm);
	    p->ComputePrior(lnSumMean);

	    if ( lRoot._ratesVarParm ) {
		auto p = static_cast<RateHyperparameter*>(lRoot._ratesVarParm);
		p->ComputePrior(lnSumVar);
	    }

	}

    }
}

// *****************************************************************************

FLOAT
RateParameter::Propose()
{

    REPRENTER(Dump::ptr(&_lNode, "lNode"));

    /// - Setup to rollback if the proposal is rejected

    Parameter::Propose();
    _repl.LogRollback(this);

    /// - Draw a new value for the parameter

    FLOAT  oldLnValue = log(_value);
    FLOAT  newLnValue = oldLnValue + Finetune::rates * _repl._statsObj->DrawNormalMix();
    _value            = exp(newLnValue);

    /// - Compute the new likelihood for the current gene tree.

    FLOAT  lnLRatio = _lNode._lkh->Compute();

    /// - Compute the prior of rates for this node and update the gene tree prior.

    _lNode._lnPR->NewRate();

    /// - Return the proposal ratio as
    ///   \f$\log(\Delta \textrm{likelihood} + \Delta \textrm{rates prior} + \Delta \textrm{value})\f$

    FLOAT  priorRatio = lnLRatio +
	                _lRoot._rLnPR->PriorRatio() +
	                newLnValue - oldLnValue;

     REPREXIT( Dump::str(_value, "value"),
	       Dump::str(priorRatio, "priorRatio"),
	       Dump::str(lnLRatio, "lnLRatio"),
	       Dump::str(_lRoot._rLnPR->PriorRatio(), "lnPRRatio"),
	       Dump::str(newLnValue, "newLnValue"),
	       Dump::str(oldLnValue, "oldLnValue") );

    return priorRatio;

}

// *****************************************************************************

FLOAT
RateMeanClockParameter::Propose()
{

    REPRENTER(Dump::ptr(&_lRoot, "lRoot"),
	      Dump::str(_lRoot._locus._id, "locusId"),
	      Dump::str(_value, "value") );

    /// - Setup to rollback if the proposal is rejected.

    RateHyperparameter::Propose();

    /// - Draw a new value for the parameter.

    FLOAT  oldLnValue = log(_value);
    FLOAT  newLnValue = oldLnValue + Finetune::nuisance * _repl._statsObj->DrawNormalMix();
    _value            = exp(newLnValue);

    /// - Compute the new likelihood for the current gene tree.

    FLOAT  lnLRatio = _lRoot._lkh->Compute();

    /// - Update the rates sum and compute the prior for the new parameter value

    UpdateValues(newLnValue, oldLnValue);

    /// - Return the proposal ratio as
    ///   \f$\log(\Delta \textrm{likelihood} + \Delta \textrm{parameter prior} + \Delta \textrm{value})\f$

    FLOAT  priorRatio =  lnLRatio +
	                 PriorRatio() +
	                 newLnValue  - oldLnValue;

    REPREXIT( Dump::str(_value, "value"),
	      Dump::str(priorRatio, "priorRatio"),
	      Dump::str(lnLRatio,"lnLRatio"),
	      Dump::str(_prior,"prior"),
	      Dump::str(_oldPrior,"oldPrior"),
	      Dump::str(newLnValue, "newLnValue"),
	      Dump::str(oldLnValue, "oldLnValue") );

    return priorRatio;

}

// *****************************************************************************

FLOAT
RateMeanNonClockParameter::Propose()
{

    REPRENTER(Dump::ptr(&_lRoot, "lRoot"),
	      Dump::str(_lRoot._locus._id, "locusId"),
	      Dump::str(_value, "value") );

    /// - Setup to rollback if the proposal is rejected.

    RateHyperparameter::Propose();

    /// - Draw a new value for the parameter.

    FLOAT  oldLnValue = log(_value);
    FLOAT  newLnValue = oldLnValue + Finetune::nuisance * _repl._statsObj->DrawNormalMix();
    _value            = exp(newLnValue);

    /// - Compute the prior of the rates

    _lRoot._rLnPR->NewMean();

    /// - Update the rates sum and compute the prior for the new parameter value

    UpdateValues(newLnValue, oldLnValue);

    /// - Return the proposal ratio as
    ///   \f$\log(\Delta \textrm{rates prior} + \Delta \textrm{parameter prior} + \Delta \textrm{value})\f$

    FLOAT  priorRatio =  _lRoot._trueRoot->_lnPR->PriorRatio() +
	                 PriorRatio() +
	                 newLnValue - oldLnValue;

    REPREXIT( Dump::str(_value, "value"),
	      Dump::str(_prior, _oldPrior, "old/new Prior"),
	      Dump::str((_lRoot._trueRoot->_lnPR->PriorRatio()),"DeltalnPR"),
	      Dump::str(newLnValue, oldLnValue, "old/new lnValue") );

    return priorRatio;

}

// *****************************************************************************

FLOAT
RateVarianceParameter::Propose()
{

    REPRENTER(Dump::ptr(&_lRoot, "lRoot"),
	      Dump::str(_lRoot._locus._id, "locusId"),
	      Dump::str(_value, "value") );

    /// - Setup to rollback if the proposal is rejected.

    RateHyperparameter::Propose();

    /// - Draw a new value for the parameter.

    FLOAT  oldLnValue = log(_value);
    FLOAT  newLnValue = oldLnValue + Finetune::nuisance * _repl._statsObj->DrawNormalMix();
    _value            = exp(newLnValue);

    /// - Compute the prior of the rates

    _lRoot._rLnPR->NewVariance();

    /// - Update the rates sum and compute the prior for the new parameter value

    UpdateValues(newLnValue, oldLnValue);

    /// - Return the proposal ratio as
    ///   \f$\log(\Delta \textrm{likelihood} + \Delta \textrm{parameter prior} + \Delta \textrm{value})\f$

    FLOAT  priorRatio =  _lRoot._trueRoot->_lnPR->PriorRatio() +
	                 PriorRatio() +
	                 newLnValue - oldLnValue;

    REPREXIT( Dump::str(_value, "value"),
	      Dump::str(priorRatio, "priorRatio"),
	      Dump::str((_lRoot._trueRoot->_lnPR->PriorRatio()),"DeltalnPR"),
	      Dump::str(PriorRatio(),"DeltaPrior"),
	      Dump::str(newLnValue, "newLnValue"),
	      Dump::str(oldLnValue, "oldLnValue") );

    return priorRatio;

}
