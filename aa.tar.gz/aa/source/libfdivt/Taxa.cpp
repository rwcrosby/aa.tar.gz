/// @file Taxa.cpp
/// Definitions of methods for the taxa class

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include <string>

#include "Locus.h"
#include "Logger.h"
#include "Sequence.h"
#include "SequenceFactory.h"
#include "Taxa.h"

// *****************************************************************************
/// Destructor for the taxa object.


Taxa::~Taxa( )
{

    /// Delete the sequence objects for the taxa.

    for ( auto seqp : _seqVec )
	delete seqp;
}

// *****************************************************************************

void
Taxa::AddSequence(Sequence * seq)
{
    auto idx = seq->_locus._id;
    if ( idx + 1 > _seqVec.size() )
	_seqVec.resize(idx + 1, nullptr);
    _seqVec[idx] = seq;
}

// *****************************************************************************
/// Output Taxa (name, id, loci and sequences) to the logger.

const unsigned SEQPERLINE = 100;		  ///< Sequence len to print on a line

void
Taxa::Log( Logger &                logger,	  ///< To get locus names
	   const SequenceFactory & seqFactory )   ///< sequence parameters
    const
{

    logger("Taxa %d: %s", _id + 1, _label.c_str());

    std::string alphabet = seqFactory._alphabet + seqFactory._gapCh + seqFactory._missingCh;

    if (!debugSet) {

	bool seqFound = false;

	for ( unsigned i = 0; i < _seqVec.size(); i++) {

	    if ( !_seqVec[i] )
		continue;

	    seqFound = true;

	    logger("%*cLocus %d: %s", Logger::indent, ' ',
		   i + 1,
		   _seqVec[i]->_locus._label.c_str());

	    Sequence * seq = _seqVec[i];

	    for ( unsigned pos = 0; pos < seq->_input.size(); pos += SEQPERLINE) {

		unsigned posEnd = (pos + SEQPERLINE) < seq->_input.size()
		    ? (pos + SEQPERLINE)
		    : seq->_input.size();

		logger("%*c%04d-%04d: %s",
		       Logger::indent * 2, ' ',
		       pos+1, posEnd, seq->_input.substr(pos, SEQPERLINE).c_str());

	    }

	}

	if ( !seqFound )
	    logger("%*cNo DNA sequences for taxa", Logger::indent, ' ');

    }

}

// *****************************************************************************

std::string
Taxa::str ( const std::string hdg )
    const
{
    std::stringstream ss;
    if ( hdg.size() ) ss << hdg << "<";

    ss << _id << '/' << _label;

    if ( hdg.size() ) ss << ">";
    return ss.str();
}

// *****************************************************************************

std::string
Taxa::str ( const std::list<Taxa *> & l,
	    const std::string         hdg )
{
    std::stringstream ss;
    if ( hdg.size() ) ss << hdg << "<";

    for ( auto it = l.begin(); it != l.end(); it++ ) {
	if ( it != l.begin() )
	    ss << ", ";
	ss << (*it)->str();
    }

    if ( hdg.size() ) ss << ">";
    return ss.str();
}
