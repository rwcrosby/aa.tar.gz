/// @file Calibration.h
/// Classes associated with the fossil calibrations

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _CALIBRATION_H_
#define _CALIBRATION_H_

#include <limits>
#include <list>
#include <memory>
#include <string>
#include <vector>

#include "Config.h"

class  Logger;
struct Replicate;
struct Taxa;

namespace Options {
    enum class CalType : unsigned char;
    struct CalOpt;
}

namespace Calibration {

    const FLOAT  maxAge = std::numeric_limits<FLOAT >::infinity();
    const FLOAT  minAge = 0.0;

    struct Data;

    // *****************************************************************************
    /// Calibration options structure

    /// Only one instance of this class will exist for a particular set of
    /// calibrations. It will be referenced from each use of the options.
    /// Values will be populated depending on the calibration type used:
    /// - Lower bound only: minAge, leftMass, offset, scale
    /// - Uppper bound only: maxAge, rightMass
    /// - Upper and lower bounds: minAge, maxAge, leftMass, rightMass
    /// - Gamma: alpha, beta
    /// - Normal: mu, sigma

    struct Opts {

	Opts ( const std::list<Taxa*>&               to,
	       const std::vector<Options::CalOpt*>&  opts,
	       const std::string&                    l,
	       unsigned                              calno );

	/// Output info about the calibration to the log
	void
	Log(Logger & logger) const;

	/// Generate the dump string for the object.
	std::string
	str ( const std::string hdg = "" ) const;

	const std::list<Taxa*> _taxaObjs;	  ///< List of taxa objects
	const std::string      _label;		  ///< Label for the fossil
	const unsigned         _id;		  ///< Position in calibrations list

	Options::CalType       _cType;		  ///< Calibration type

	FLOAT                  _minAge;		  ///< Minimum fossil age
	FLOAT                  _leftMass;	  ///< Percentage of mass to left of min age

	FLOAT                  _maxAge;		  ///< Maximun fossil age
	FLOAT                  _rightMass;	  ///< Percentage of mass to right of max age

	FLOAT                  _offset;		  ///< Offset \f$t_L(1 + p)\f$ of Cauchy used for lower only bound.
	FLOAT                  _scale;		  ///< Scale \f$c t_L\f$ of Cauchy used for lower only bound.

	FLOAT                  _alpha;		  ///< Gamma \f$\alpha\f$ value.
	FLOAT                  _beta;		  ///< Gamma \f$\beta\f$ value.

	FLOAT                  _mu;		  ///< Normal mean.
	FLOAT                  _sigma;		  ///< Normal variance.

    };

    // *****************************************************************************
    /// Calibration data structure

    /// An instance of this structure will be created for each unique node/tree
    /// combination that uses the calibration.

    struct Data {

        /// Basic constructor used to add calibrations.
	Data( const Opts & o)
	    : _opts(o),
              _age(0.0),
	      _repl(nullptr)
            {}

        /// Copy constructor used in replicate generation.
        /// This method will construct the calculation module for the
        /// calibration based on the distribution type selected.
	Data( const Data & d,                     ///< Data block in the Dag
              Replicate &  repl                   ///< Owning replicate
            )
	    : _opts(d._opts),
	      _age(d._age),
	      _repl(&repl)
	    {}

	/// Needced by the compiler
	virtual
	~Data()
	    {}

        /// Set the initial value as the calibration age.
	/// @param maxAge Upper limit on the calibration age
        virtual
	void
	InitialValue ( FLOAT  maxAge ) = 0;

	/// Static method to create the appropriate data object.
	/// @return Pointer to the created object
	/// @param o Reference to the associated options instance.
	static
	Data *
	Factory ( const Opts &  o );

	/// Create a new object in the replicate based on a source object.
	/// This is really a factory pattern copy constructor.
	/// @return Pointer to the created object
	/// @param d Pointer to source calibration object
	/// @param repl Reference to owning replicate

	static
	Data *
	Replicate ( const Data * d,
		    Replicate &  repl );

	/// Generate the dump string for the object.
	std::string
	str ( const std::string hdg = "" ) const;

	/// Get the PDF for the age passed.
	/// @return Log of the PDF of the age.
	/// @param age Age to check
	virtual
	FLOAT
	operator() (const FLOAT  age) const = 0;

	const Opts &        _opts;	          ///< Associated option block
        FLOAT               _age;                 ///< Initial age for the calibration
	struct Replicate *  _repl;		  ///< Owning replicate, null in the initial tree.

    };

    /// Generate the dump string for a list of calibrations
    std::string
    str ( const std::list<Calibration::Data*> & l,
	  const std::string                     hdg = "" );

}

#endif // _CALIBRATION_H_
