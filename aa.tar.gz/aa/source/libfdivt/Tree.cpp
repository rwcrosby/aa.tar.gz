/// @file Tree.cpp
/// Definitions for the methods on the tree objects.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include <iostream>
#include <sstream>
#include <stack>

#include "AgePrior.h"
#include "Calibration.h"
#include "Dump.h"
#include "EvoModel.h"
#include "Likelihood.h"
#include "Locus.h"
#include "Parameter.h"
#include "RatesPrior.h"
#include "Replicates.h"
#include "StatsFn.h"
#include "Taxa.h"
#include "TransitionMatrix.h"
#include "Tree.h"

// *************************************************************************
/// Generate the attributes for the tree output to the log.

static
void
LogAttrFn ( Tree::Root::AttrList & aList,
	    const Tree::Position   tPos )
{

    auto & calibrations =  tPos.GetCalList();

    if ( calibrations.size() ) {
	std::stringstream ss;
	if ( calibrations.size() > 1 )
	    ss << '{';
	for ( auto it = calibrations.begin(); it != calibrations.end(); it++ ) {
	    if ( it != calibrations.begin() )
		ss << ',';
	    ss << (*it)->_opts._id + 1;
	}
	if ( calibrations.size() > 1 )
	    ss << '}';
	aList.emplace_back("Calibrations", ss.str());
    }

}

// *************************************************************************
/// Generate the branch length for the tree output to the log.

static
FLOAT
LogBrLenFn ( const Tree::Position tPos )
{
    return tPos.BrLen();
}

// *************************************************************************
/// Generate a string for attributes to include in the newick output.

static
std::string
MakeAttrString(Tree::Root::AttrList  & aList)
{
    std::stringstream ss;
    if ( aList.size() ) {
	ss << "[&";
	for ( auto it = aList.begin(); it != aList.end(); it++ ) {
	    if ( it != aList.begin() )
		ss << ',';
	    ss << (*it).first << "=" << (*it).second;
	}
	ss << "]";
    }
    return ss.str();
}

// *************************************************************************
/// Generate a string for the branch length to include in the newick output.

static
std::string
MakeBrLenString(const FLOAT  brLen )
{
    std::stringstream ss;
    if ( brLen != 0.0 )
	ss << ':' << brLen;
    return ss.str();
}

// *************************************************************************
/// Calling this a depth first traversal is something of a misnomer since
/// methods are call at both entry and exit from any given node.
/// The traversal is not done recursively since large trees could exceed the
/// compiler stack. In theory at least the size of the heap is greater therefore
/// an stl container is used non-recursively.

void
Tree::Dfs::operator()(const Position & startPos)
{

    /// Stack entry to maintain tree position

    struct TreeStack {

	TreeStack ( const Position & tPos )
	    : _tPos    (tPos),
	      _children(_tPos._node->_children.begin())
	    {}

	TreeStack ( Node * n, unsigned ti )
	    : _tPos(n, ti),
	      _children(_tPos._node->_children.begin())
	    {}

	Position                 _tPos;      ///< Current node in the species tree
	Node::CHILDREN::iterator _children;  ///< Position in the list of children

    };

    std::stack<TreeStack,
	       std::list<TreeStack>> ts;      // Use a list as the underlying container
    ts.emplace(startPos);                     // Push the starting stack entry

    while ( !ts.empty() ) {

	TreeStack & stackTop  = ts.top();
	Position &  tPos      = stackTop._tPos;

	if ( tPos.IsLeaf() ) {
	    if ( Leaf(tPos) == CANCEL )
		break;
	    ts.pop();
	}
	else {

	    if ( stackTop._children == tPos._node->_children.end() ) {
		RC cbrc = tPos.IsInner()
		    ? InnerEnd(tPos)
		    : RootEnd(tPos.AsRoot());
		if ( cbrc == CANCEL )
		    break;
		ts.pop();
	    }

	    else {

		if ( stackTop._children == tPos._node->_children.begin() ) {

		    RC cbrc = tPos.IsInner()
			? InnerBegin(tPos)
			: RootBegin(tPos.AsRoot());
		    if ( cbrc == CANCEL )
			break;
		    if ( cbrc == STOPDOWN ) {
			ts.pop();
			continue;
		    }

		}

		auto & childPair = *stackTop._children++;
		if ( childPair.first )            // Make sure there's a real pointer here
		    ts.emplace(childPair.first, childPair.second[tPos._treeIdx]);

	    }

	}

    }

}

// *************************************************************************

void
Tree::LocusDfs::operator()(LocusNode & startNode )
{

    /// Stack entry to maintain tree position

    struct TreeStack {

	TreeStack ( LocusNode & lNode )
	    : _lNode    (lNode),
	      _children(_lNode._children.begin())
	    {}

	LocusNode &               _lNode;     ///< Current node in the gene tree
	LNODEPVEC::iterator _children;        ///< Position in the list of children

    };

    std::stack<TreeStack,
	       std::list<TreeStack>> ts;      // Use a list as the underlying container
    ts.emplace(startNode);                    // Push the starting stack entry

    while ( !ts.empty() ) {

	TreeStack & stackTop  = ts.top();
	LocusNode & lNode     = stackTop._lNode;

	if ( lNode.IsLeaf() ) {
	    if ( Leaf(lNode) == CANCEL )
		break;
	    ts.pop();
	}
	else {

	    if ( stackTop._children == lNode._children.end() ) {
		RC cbrc = !lNode._parent
		    ? RootEnd(lNode)
		    : InnerEnd(lNode);
		if ( cbrc == CANCEL )
		    break;
		ts.pop();
	    }

	    else {

		if ( stackTop._children == lNode._children.begin() ) {

		    RC cbrc = !lNode._parent
			? RootBegin(lNode)
			: InnerBegin(lNode);
		    if ( cbrc == CANCEL )
			break;
		    if ( cbrc == STOPDOWN ) {
			ts.pop();
			continue;
		    }

		}

		auto child = *stackTop._children++;
		if ( child )
		    ts.emplace(*child);

	    }

	}

    }

}

// *************************************************************************
/// Constructor used during initial tree build.

Tree::LocusNode::LocusNode( LocusRoot &       lRoot,
			    TreeNode * const  tNode,
			    LocusNode * const parent )
    : _lRoot(lRoot),
      _tNode(tNode),
      _missing(false),
      _parent(parent),
      _siteVec(nullptr),
      _rateParm(nullptr),
      _rateParmToUse(nullptr),
      _ageParmToUse(nullptr),
      _tMatrix(nullptr),
      _lkh(nullptr),
      _lnPR(nullptr)
{
}

/// Copy constructor used during tree replication.

Tree::LocusNode::LocusNode( const LocusNode & lNode,
			    LocusRoot &       lRoot,
			    TreeNode * const  tNode )
    : _lRoot(lRoot),
      _tNode(tNode),
      _missing(lNode._missing),
      _parent(nullptr),
      _siteVec(nullptr),
      _rateParm(nullptr),
      _rateParmToUse(nullptr),
      _ageParmToUse(nullptr),
      _tMatrix(nullptr),
      _lkh(nullptr),
      _lnPR(nullptr)
{
}

/// At least one of the compilers needs this to exist. If it gets called it
/// generally indicates that a vector was not correctly sized and stl is trying
/// to reallocate and move it.

Tree::LocusNode::LocusNode( LocusNode && lNode )
    : _lRoot(lNode._lRoot),
      _tNode(lNode._tNode),
      _siteVec(lNode._siteVec)
{
    assert(false && "Trying to execute Tree::LocusNode move constructor");
}

/// Clean up the objects.

Tree::LocusNode::~LocusNode()
{
    delete _rateParm;
    delete _lkh;
    delete _lnPR;
}

std::string
Tree::LocusNode::str ( const std::string hdg )
    const
{
    std::stringstream ss;
    if ( hdg.size() ) ss << hdg << "<";

    ss << Dump::ptr(this) << ' ';

    if ( _missing )
	ss << "Missing";
    else{
	ss << Dump::ptr(&_lRoot, "lRoot") << ' '
	   << Dump::ptr(_tNode, "tNode") << ' '
	   << Dump::ptr(_parent, "parent") << ' '
	   << Dump::str(_children, "children") << ' '
	   << Dump::ptr(_rateParmToUse, "rateParmtoUse") << '\n';

	ss << Dump::indent(Dump::pstr(_rateParm, "rateParm")) << '\n'
	   << Dump::indent(Dump::pstr(_lnPR,"ratePrior")) << '\n'
	   << Dump::indent(Dump::pstr(_tMatrix, "tMatrix")) << '\n';

	if (_siteVec) {
	    std::string str;
	    for ( auto it = _siteVec->begin(); it != _siteVec->end(); it++ )
		str += (*it).str() + '\n';
	    ss << Dump::indent(Dump::indent_heading(str, "Sites")) << '\n';
	}

	ss << Dump::rtrim(Dump::indent(Dump::pstr(_lkh, "Likelihood")));
    }

    if ( hdg.size() ) ss << ">";
    return ss.str();
}

/// Update the transition matrix at this node to reflect the current
/// branch time and rate.

void
Tree::LocusNode::UpdateTMatrix()
{
    if ( _missing || IsRoot() )
	return;

    const FLOAT  time = (*_parent->_ageParmToUse)() - ( IsLeaf() ? 0.0 : (*_ageParmToUse)() );
    const FLOAT  rate = (*_rateParmToUse)();


    _lRoot._eModel->UpdateTMatrix( _tMatrix, time * rate );

    auto & _repl = _lRoot._eModel->_repl;
    REPRDEBUG(Dump::ptr(this),
	      Dump::str(time, "time"),
	      Dump::str(rate, "rate"),
	      Dump::str(*_tMatrix, "tMatrix"));


}

// *************************************************************************
/// Constructor used during initial tree construction.

Tree::LocusRoot::LocusRoot( Root &  root,
			    Locus & locus )
    : LocusNode(*this, nullptr, nullptr),
      _root(root),
      _locus(locus),
      _eModel(nullptr),
      _ratesMeanParm(nullptr),
      _ratesVarParm(nullptr),
      _trueRoot(this),
      _lkh(nullptr),
      _rLnPR(nullptr),
      _nInnerNodes(0),
      _nSeqSites(0),
      _nRootSites(0),
      _nTotalSites(0)
{
}

/// Copy constructor used during tree replication

Tree::LocusRoot::LocusRoot ( const LocusRoot & lRoot,
			     Root &            root )
    : LocusNode(lRoot, *this, nullptr),
      _root(root),
      _locus(lRoot._locus),
      _eModel(nullptr),
      _ratesMeanParm(nullptr),
      _ratesVarParm(nullptr),
      _trueRoot(this),
      _lkh(nullptr),
      _rLnPR(nullptr),
      _nInnerNodes(lRoot._nInnerNodes),
      _nSeqSites(lRoot._nSeqSites),
      _nRootSites(lRoot._nRootSites),
      _nTotalSites(lRoot._nTotalSites)
{
    _missing = lRoot._missing;
}

/// At least one of the compilers needs this to exist. If it gets called it
/// generally indicates that a vector was not correctly sized and stl is trying
/// to reallocate and move it.

Tree::LocusRoot::LocusRoot( LocusRoot && locusRoot )
    : LocusNode( std::move(locusRoot) ),
      _root(locusRoot._root),
      _locus(locusRoot._locus)
{
    assert(false && "Trying to execute Tree::LocusRoot move constructor");
}

/// Clean up the various owned objects.

Tree::LocusRoot::~LocusRoot()
{
    delete _eModel;
    delete _ratesMeanParm;
    delete _ratesVarParm;
    delete _lkh;
    delete _rLnPR;
}

std::string
Tree::LocusRoot::str ( const std::string hdg )
    const
{
    std::stringstream ss;
    if ( hdg.size() ) ss << hdg << "<";

    ss << Dump::ptr(&_root, "root") << ' '
       << Dump::str(_locus._id, "lid") << ' '
       << Dump::ptr(&_locus, "locus") << ' '
       << Dump::ptr(_trueRoot, "trueRoot") << ' '
       << Dump::pstr(_rLnPR,"rLnPR") << ' '
       << Dump::str(_nInnerNodes, "nInnerNodes")  << ' '
       << Dump::str(_nSeqSites, "nSeqSites")  << ' '
       << Dump::str(_nRootSites, "nRootSites")  << ' '
       << Dump::str(_nTotalSites, "nTotalSites")  << '\n';

    ss << Dump::indent(Dump::pstr(_eModel, "eModel")) << '\n'
       << Dump::indent(Dump::pstr(_lkh, "likelihood")) << '\n'
       << Dump::indent(Dump::pstr(_ratesMeanParm, "ratesMeanParm")) << '\n'
       << Dump::indent(Dump::pstr(_ratesVarParm, "ratesVarParm"))  << '\n';

    ss << Dump::indent(static_cast<const Tree::LocusNode*>(this)->str("LocusNode"));

    if ( hdg.size() ) ss << ">";
    return ss.str();
}

// *************************************************************************

Tree::Node::Node( const Node && v)
    : _taxa(nullptr)
{
    assert(false && " Tried to execute Tree::Node move constructor");
}

Tree::Node::Node( Taxa * const taxa)
    : _id(0),
      _taxa(taxa),
      _init(new Tree::Init(*this))
{
}

/// Replicate a tree node.
Tree::Node::Node( const Node & node,
		  Replicate &  repl )
    : _id(repl._nodeId++),
      _taxa(node._taxa),
      _locusSiteVec(node._locusSiteVec),
      _init(nullptr)
{
    _treeVec.reserve(node._treeVec.size());
}

Tree::Node::~Node()
{
    delete _init;
}

void
Tree::Node::VecSize( unsigned & longTreeVec,
		     unsigned & treeMem,
		     unsigned & locusMem,
		     unsigned & siteMem) const
{

    if ( _treeVec.size() > longTreeVec )
	longTreeVec = _treeVec.size();

    treeMem += _treeVec.size() * sizeof(TreeNode);

    for ( auto & tn : _treeVec )
	locusMem += tn._locusVec.size() * sizeof(LocusNode);

    for ( auto & sv : _locusSiteVec )
	siteMem += sv.size() * sizeof(Tree::Site);

}

std::string
Tree::Node::str ( const std::string hdg )
    const
{
    std::stringstream ss;
    if ( hdg.size() ) ss << hdg << "<";

    ss << Dump::str(_id, "nid") << ' ';
    if ( IsRoot() )
        ss << Dump::ptr(this, "Node") << ' '
	   << str(_children, "children");
    else if ( IsInner() )
        ss << Dump::ptr(this, "Inner") << ' '
	   << str(_children, "children");
    else
        ss << Dump::ptr(this, "Leaf") << ' '
	   << _taxa->str();

    ss << '\n';

    for ( auto & tn : _treeVec )
	ss << Dump::indent(tn.str("TreeNode")) << '\n';

    auto s = Dump::rtrim(ss.str());
    if ( hdg.size() ) s += ">";
    return ss.str();
}

std::string
Tree::Node::str ( const CHILD &     c,
		  const std::string hdg )
{
    std::stringstream ss;
    if ( hdg.size() ) ss << hdg << "<";

    ss << Dump::ptr(c.first) << '/'
       << Dump::str(c.second);

    if ( hdg.size() ) ss << ">";
    return ss.str();
}

std::string
Tree::Node::str ( const CHILDREN &  c,
		  const std::string hdg )
{
    std::stringstream ss;
    if ( hdg.size() ) ss << hdg << "<";

    for ( auto it = c.begin(); it != c.end(); it++ ) {
	if ( it != c.begin() )
	    ss << ',';
	ss << str(*it);
    }

    if ( hdg.size() ) ss << ">";
    return ss.str();
}

// *************************************************************************

Tree::Path::Path ( const Position & top,
		   const Position & bottom )
{
    /// Build the path starting at the bottom working up to the top.
    Position tp = bottom;
    while ( tp != top ) {
	emplace_front(tp);
	if ( !tp.Parent(tp) )         // Should never try to go up past root
	    assert(false && "Trying to create path through root");
    }
    emplace_front(top);
}

// *************************************************************************

FLOAT
Tree::Position::Age() const
{
    FLOAT  age = 0.0;

    if ( IsRoot() ) {
	auto & r = _node->AsRoot();
	if ( r._ageParm )
	    age = (*r._ageParm)();
    }
    else if ( IsInner() ) {
	auto & ti = _node->_treeVec[_treeIdx];
	if ( ti._ageParm )
	    age = (*ti._ageParm)();
    }

    return age;
}

// *****************************************************************************

std::string
Tree::Position::str ( const std::string      hdg ) const
{

    if ( Empty() )
        return "Empty";

    std::stringstream ss;
    ss << std::showbase << std::hex << (long long)_node << '/';
    ss << _treeIdx;

    return ss.str();
}

// *************************************************************************

namespace Dump {

    template<>
    std::string
    str( const Tree::Position & tPos,
	 const std::string      hdg )
    {
	std::stringstream ss;
	if ( hdg.size() ) ss << hdg << "<";

	if ( tPos.Empty() )
	    ss <<  "Empty";
	else
	    ss << std::showbase << std::hex << (long long)tPos._node << '/'
	       << std::noshowbase << std::dec << tPos._treeIdx;

	if ( hdg.size() ) ss << '>';
	return ss.str();
    }

}

// *************************************************************************

Tree::Root::Root( const std::string& label,
		  const unsigned     rootIdx,
		  unsigned           lc )
    : Node(nullptr),
      _label(label),
      _rootIdx(rootIdx),
      _eModel(nullptr),
      // _mixParm(nullptr),
      _ageParm(nullptr),
      _nLeaves(0),
      _sumRatesMean(0.0),
      _sumRatesVar(0.0),
      _lkh(nullptr),
      _lnPA(nullptr),
      _lnPR(0.0),
      _lnPN(0.0),
      _sampleFile(nullptr),
      _traceFile(nullptr),
      _finalTreeFile(nullptr),
      _detailFile(nullptr)
{
    _locusVec.reserve(lc);
}

Tree::Root::Root( const Root & r,
		  Replicate &  repl )
    : Node(r, repl),
      _label(r._label),
      _rootIdx(r._rootIdx),
      _eModel(nullptr),
      // _mixParm(nullptr),
      _ageParm(nullptr),
      _nLeaves(r._nLeaves),
      _sumRatesMean(0.0),
      _sumRatesVar(0.0),
      _lkh(nullptr),
      _lnPA(nullptr),
      _lnPR(0.0),
      _lnPN(0.0),
      _sampleFile(nullptr),
      _traceFile(nullptr),
      _finalTreeFile(nullptr),
      _detailFile(nullptr)
{

    _locusVec.reserve(r._locusVec.size());
    for ( auto & cal : r._calList )
	if ( repl._statsObj->DrawUniform() <= repl._calProb )
	    _calList.emplace_back(Calibration::Data::Replicate(cal, repl));
}

Tree::Root::Root( const Root & r )
    : Node(nullptr),
      _rootIdx(r._rootIdx)
{
    assert(false && "Trying to call Tree::Root::Root copy constructor");
}

Tree::Root::Root( const Root && r )
    : Node(nullptr),
      _rootIdx(r._rootIdx)
{
    assert(false && "Trying to call Tree::Root::Root move constructor");
}

Tree::Root::~Root( )
{

    struct DeleteRootDFS : Dfs {

	virtual RC InnerEnd ( const Position & tPos )
	    {
		for ( auto & tn : tPos._node->_treeVec )
		    if ( tn._parent._node != tPos._node )
			for ( auto & child : tn._parent._node->_children )
			    if ( child.first == tPos._node )
				child.first = nullptr;

		delete tPos._node;
		return CONTINUE;
	    }

	virtual RC Leaf     ( const Position & tPos )
	    {
		return InnerEnd(tPos);
	    }

    } dfs;
    dfs(this);

    delete _eModel;
    // delete _mixParm;
    delete _ageParm;
    delete _lnPA;
    delete _lkh;

    for ( auto cal : _calList )
	delete cal;

    for ( auto ti : _traceList )
	delete ti;

    /// -  Output file instancesare not deleted here, they are owned by the OutputManager.

}

void
Tree::Root::Log( Logger & logger )
{

    logger("%*c%04d: %s%s%s",
    	   logger.indent, ' ',
    	   _rootIdx + 1,
    	   _label.empty() ? "" : _label.c_str(),
    	   _label.empty() ? "" : " = ",
    	   NewickString(LogAttrFn, LogBrLenFn, true).c_str());

    for ( unsigned i = 0; i < _locusVec.size(); i++ ) {
	auto & lRoot = _locusVec[i];

	logger("%*cLocus %d Site Statistics", Logger::indent * 2, ' ',
	       i + 1);
	logger("%*c%-30s : %d", Logger::indent * 3 , ' ',
	       "Inner Nodes in Locus", lRoot._nInnerNodes );
	logger("%*c%-30s : %d", Logger::indent * 3 , ' ',
	       "Sites in Input Sequences", lRoot._nSeqSites );
	logger("%*c%-30s : %d", Logger::indent * 3 , ' ',
	       "Sites at Locus Root", lRoot._nRootSites );
	logger("%*c%-30s : %d", Logger::indent * 3 , ' ',
	       "Total Sites in Locus Tree", lRoot._nTotalSites );
    }

}

std::string
Tree::Root::NewickString( AttrFn  attrFn,
			  BrLenFn brLenFn,
			  bool    useLabels )
{

    struct Newick : Dfs {

	Newick ( AttrFn  attrFn,
		 BrLenFn brLenFn,
		 bool useLabels)
	    : _attrFn(attrFn),
	      _brLenFn(brLenFn),
	      _useLabels(useLabels)
	    {}

	virtual RC InnerBegin ( const Position & tPos ) {
	    _workStack.emplace();
	    return CONTINUE;
	}

	virtual RC InnerEnd   ( const Position & tPos ) {

	    std::stringstream ss;
	    ss << "(";
	    for ( auto it = _workStack.top().begin();
		  it != _workStack.top().end();
		  it++)  {
		if ( it != _workStack.top().begin() )
		    ss <<  ",";
		ss << *it;
	    }
	    ss << ')';

	    _workStack.pop();
	    if ( !_workStack.empty() ) {

		if ( _attrFn ) {
		    AttrList aList;
		    (*_attrFn)(aList, tPos);
		    ss << MakeAttrString(aList);
		}

		if ( _brLenFn ) {
		    auto brLen = (*_brLenFn)(tPos);
		    ss << MakeBrLenString(brLen);
		}

		_workStack.top().push_back(ss.str());
	    }
	    else
		_newick = ss.str() + ';';

	    return CONTINUE;
	}

	virtual RC Leaf      ( const Position & tPos ) {

	    std::stringstream ss;

	    if ( _useLabels )
		ss << tPos._node->_taxa->_label;
	    else
		ss << tPos._node->_taxa->_id + 1;

	    if ( _attrFn ) {
		AttrList aList;
		(*_attrFn)(aList, tPos);
		ss << MakeAttrString(aList);
	    }

	    if ( _brLenFn ) {
		auto brLen = (*_brLenFn)(tPos);
		ss << MakeBrLenString(brLen);
	    }

	    _workStack.top().push_back(ss.str());
	    return CONTINUE;
	}

	/// Treat the root like any other inner node
	virtual RC RootBegin ( Root & r )
	    {
		return InnerBegin(r);
	    }

	/// Treat the root line any other inner node
	virtual RC RootEnd ( Root & r )
	    {
		return InnerEnd(r);
	    }

	AttrFn                             _attrFn;    ///< Use this function to get attributes
	BrLenFn                            _brLenFn;   ///< Use this function to get branch lengths
	bool                               _useLabels; ///< Output labels or id's for taxa
	std::string                        _newick;    ///< Accumulated newick string
	std::stack<std::list<std::string>> _workStack; ///< Stack to build the string

    } newick(attrFn, brLenFn, useLabels);

    newick(this);

    return newick._newick;
}

std::string
Tree::Root::str ( const std::string hdg ) const
{
    std::stringstream ss;
    if ( hdg.size() ) ss << hdg << "<";

    ss << Dump::ptr(this) << ' '
       << Dump::str(_rootIdx, "rid") << ' '
       << Dump::str(_label, "label") << ' '
       << Dump::pstr(_ageParm, "ageParm") << ' '
       << Dump::pstr(_lnPA , "lnPA" ) << ' '
       << Dump::str(_lnPR,"lnPR") << ' '
       << Dump::str(_sumRatesMean,"sumRatesMean") << ' '
       << Dump::str(_sumRatesVar,"sumRatesVar") << ' '
       << Dump::str(_lnPN,"lnPN");

    if ( hdg.size() ) ss << ">\n";

    ss << Dump::indent(Node::str("Node")) << '\n';
    if ( _calList.size() )
	ss << Dump::indent(Calibration::str(_calList)) << '\n';

    ss << Dump::indent(Dump::pstr(_eModel,  "EvoModel")) << '\n';
    ss << Dump::indent(Dump::pstr(_lkh,  "Likelihood")) << '\n';

    for ( auto & lr : _locusVec )
	ss << Dump::indent(lr.str("LocusRoot")) << '\n';

    auto s = Dump::rtrim(ss.str());
    if ( hdg.size() ) s += ">";
    return s;
}

// *************************************************************************

Tree::Site::Site( const unsigned idx,
		const unsigned lhs,
		const unsigned rhs )
        : _idx(idx),
	  _count(1),
          _lhs(lhs),
          _rhs(rhs)
{
}

Tree::Site::Site( const Site &   s )
        : _idx (s._idx),
	  _count(s._count),
          _lhs(s._lhs),
          _rhs(s._rhs)
{
}

std::string
Tree::Site::str ( const std::string hdg )
    const
{
    std::stringstream ss;
    if ( hdg.size() ) ss << hdg << "<";

    ss << Dump::str(_idx, "idx") << ' '
       << Dump::str(_count, "count") << ' '
       << "children<" << _lhs << ',' << _rhs << ">";

    if ( hdg.size() ) ss << ">";
    return ss.str();
}

// *****************************************************************************

Tree::TraceInfo::TraceInfo( Root &            root,
			    Parameter *       parm,
			    TraceType         type,
			    DATASRC           dSource,
			    int               lId,
			    int               nId,
			    unsigned          idx,
			    const std::string label,
			    const std::string heading )
    : _type(type),
      _root(root),
      _parm(parm),
      _dSource(dSource),
      _key(std::make_tuple(type, lId, nId, label)),
      _idx(idx),
      _label(std::move(label)),
      _heading(std::move(heading)),
      _sum(0.0),
      _mean(0.0),
      _median(0.0),
      _stdDev(0.0),
      _ci975(0.0),
      _ci025(0.0),
      _values(nullptr)
{
}

// *****************************************************************************

void
Tree::TraceInfo::ComputeStats()
{

    _mean = _sum / FLOAT (_values->size());
    FLOAT  sq = 0.0;
    for ( auto v : *_values )
	sq += pow(v - _mean,2);
    _stdDev = sqrt(sq);

    /// - Sort the trace vector
    std::sort (_values->begin(), _values->end());

    /// - Pick the median and ci values.

    int size = _values->size();
    _median = _values->size() % 2
	? ((*_values)[size / 2 - 1 ] + (*_values)[size / 2]) / 2.0
	: (*_values)[size / 2 ];
    _ci975 = (*_values)[int(FLOAT (size) * 0.975)];
    _ci025 = (*_values)[int(FLOAT (size) * 0.025)];

}

// *************************************************************************

Tree::TreeNode::TreeNode( Root &         root,
			  const Position node,
			  const unsigned nLoci,
			  const FLOAT    brLen )
    : Position(node),
      _root(root),
      _ageParm(nullptr),
      _lkh(nullptr),
      _brLen(brLen)
{
    _locusVec.reserve(nLoci);
}

Tree::TreeNode::TreeNode ( const TreeNode & tn,
			   Tree::Node *     newNode,
			   Root &           newRoot,
			   Node *           newParentNode,
			   Replicate &      repl)
    : Position(newNode, tn._treeIdx),
      _root(newRoot),
      _parent(newParentNode, tn._parent._treeIdx),
      _ageParm(nullptr),
      _lkh(nullptr),
      _brLen(tn._brLen)
{
    for ( auto & cal : tn._calList )
	if ( repl._statsObj->DrawUniform() <= repl._calProb )
	    _calList.emplace_back(Calibration::Data::Replicate(cal, repl));
}

Tree::TreeNode::TreeNode( TreeNode && tn )
    : Position(tn),
      _root(tn._root),
      _parent(tn._parent),
      _ageParm(std::move(tn._ageParm)),
      _calList(std::move(tn._calList)),
      _locusVec(std::move(tn._locusVec)),
      _lkh(tn._lkh),
      _brLen(tn._brLen)
{
}

Tree::TreeNode::~TreeNode()
{
    /// @todo Figure out the memory management for the ages common model
    // delete _ageParm;
    delete _lkh;
    for ( auto cal : _calList )
	delete cal;
}

std::string
Tree::TreeNode::str ( const std::string hdg )
    const
{
    std::stringstream ss;
    if ( hdg.size() ) ss << hdg << "<";

    ss << static_cast<const Tree::Position *>(this)->str() << ' '
       << Dump::ptr(&_root, "root") << ' '
       << Dump::ptr(&_parent, "parent") << ' '
       << Dump::pstr(_ageParm, "ageParm") << ' '
       << Dump::pstr(_lkh, "lhk") << ' '
       << Dump::str(_brLen, "brLen") << '\n';

    if ( _calList.size() )
	ss << Dump::indent(Calibration::str(_calList)) << '\n';

    for ( auto & ln : _locusVec )
	ss << Dump::indent(ln.str("LocusNode")) << '\n';

    auto s = Dump::rtrim(ss.str());

    if ( hdg.size() ) s +=  ">";
    return s;
}
