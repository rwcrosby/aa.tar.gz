/// @file PerfBlock.h
/// @brief Structure to return consolidated performance information
///
// *************************************************************************

// Copyright© 2010 Texas A&M University,
//                 College Station, Texas
//                 Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef PERFBLOCK_HH
#define PERFBLOCK_HH

#ifndef _WIN32
#include <sys/time.h>
#else
typedef struct timeval {
  long tv_sec;
  long tv_usec;
} timeval;
#endif

// *************************************************************************
/// OS Common performance fields

struct PerfBlock {

    timeval       userTime;                       ///< User CPU time
    timeval       sysTime;                        ///< System CPU time

    unsigned long minorFaults;			  ///< Page faults (no I/O)
    unsigned long majorFaults;			  ///< Page faults (I/O)

    unsigned long volContextSw;			  ///< Voluntary context switches
    unsigned long involContextSw;		  ///< Involuntary context switches

    // Fields calculated per OS

    unsigned long resPrivate;			  ///< Private resident memory (bytes)
    unsigned long virPrivate;			  ///< Private virtual memory (bytes)
    unsigned long virSize;			  ///< Total virtual (private + shared)

    /// Constructor for the block.
    /// Populates the block.
    /// @throw PerfError If an error is returned from the OS.
    PerfBlock();

    /// Copy constructor for the block.
    /// Just copy the fields.

    PerfBlock( const PerfBlock & pb)
        : userTime(pb.userTime),
          sysTime(pb.sysTime),
          minorFaults(pb.minorFaults),
          majorFaults(pb.majorFaults),
          volContextSw(pb.volContextSw),
          involContextSw(pb.involContextSw),
          resPrivate(pb.resPrivate),
          virPrivate(pb.virPrivate),
          virSize(pb.virSize)
        {}

};

// *************************************************************************
/// @brief Function to return performance info
/// @param pb Point to area to return info
/// @return 0 if OK, 1 if an error

int GetPerformanceInfo ( PerfBlock * pb );

#endif
