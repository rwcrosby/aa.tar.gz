/// @file DivTime.h
/// Class definition for the main divergence time module

// *************************************************************************

/// \mainpage
///
/// Infer the phylogenetic divergence time across a set of trees using
/// Bayesian Markov Chain Monte Carlo (MCMC) methods.
///
///
/// Language Bindings
/// ---------------------
/// The library is structured as a shared object on Unix based systems (e.g. Linux, OS/X) and
/// as a dynamic link library on Microsoft Windows.
/// \li [C++ Language Bindings](\ref FDivT.h)
/// \li [Python Language Bindings](../sphinx/index.html)
///
/// Authors
/// -------
/// Ralph W. Crosby\n
/// <rwc@cs.tamu.edu>
///
/// Tiffani L. Williams\n
/// <tlw@cs.tamu.edu>
///
/// Copyright
/// ---------
/// Copyright© 2010-2015\n
/// Texas A&M University,\n
/// College Station, Texas\n
///
/// License
/// -------
/// This program is free software: you can redistribute it and/or modify\n
/// it under the terms of the GNU General Public License as published by\n
/// the Free Software Foundation, either version 3 of the License, or\n
/// (at your option) any later version.
///
/// This program is distributed in the hope that it will be useful,\n
/// but WITHOUT ANY WARRANTY; without even the implied warranty of\n
/// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n
/// GNU General Public License for more details.
///
/// You should have received a copy of the GNU General Public License\n
/// along with this program.  If not, see [http://www.gnu.org/licenses](http://www.gnu.org/licenses).

// *************************************************************************

#ifndef _DIVTIME_H_
#define _DIVTIME_H_

#include <list>
#include <map>
#include <memory>
#include <random>

#include "Config.h"
#include "IDivTime.h"

struct GpuInterface;
struct HashStats;
class  Logger;
struct Locus;
struct OutputManager;
class  PerfInterface;
struct Replicate;
struct ReplicateVec;
struct SequenceFactory;
struct Taxa;
struct TreeFactory;
struct TreeStats;

namespace Calibration {
    struct Opts;
}

namespace Tree {
    struct Root;
}

// *****************************************************************************
/// Declaration of the divergence time controlling object

struct DivTime : public IDivTime {

    // Core objects...

    std::unique_ptr<Logger>          _logger;        ///< Output logging
    std::unique_ptr<PerfInterface>   _perfIntf;	     ///< Performance data output
    std::unique_ptr<HashStats>       _hashStats;     ///< Dag Hash Table Statistics object
    std::unique_ptr<TreeFactory>     _treeFactory;   ///< Factory for converting input to trees
    std::unique_ptr<SequenceFactory> _seqFactory;    ///< Sequence object generator

    // Sets of taxa, loci and calibrations

    std::map<std::string, Taxa>      _taxaMap;       ///< Set of taxa objects, owns the objects
    std::vector<Taxa*>               _taxaVec;	     ///< Indexed by TaxaId.

    std::map<std::string, Locus>     _locusMap;	     ///< Set of locus objects, owns the objects
    std::vector<Locus*>              _locusVec;	     ///< Indexed by LocusId.

    std::list<Calibration::Opts>     _calOptList;    ///< Set of all calibration options, owns the objects

    // Options

    std::string                      _filename;	     ///< Root of the filename for output files
    bool                             _fileOverwrite; ///< Overwrite output files if they exist
    bool                             _logStats;      ///< Log statistics for things
    unsigned                         _seed;          ///< Random number seed
    bool                             _seedSet;       ///< Random seed value set?

    unsigned                         _nThreads;	     ///< Max number of threads to run in parallel
    bool                             _nThreadsSet;   ///< Number of threads set

    bool                             _useGpu;	     ///< Use gpu's?

    Options::MultiTreeModel          _mtModel;	     ///< Multi-tree sharing model

    // MCMC generations and sampling parameters
    unsigned                         _nGen;          ///< MCMC Generations
    bool                             _nGenSet;       ///< Number of generations specified
    unsigned                         _burnin;	     ///< Number of generations to discard
    bool                             _burninSet;     ///< Burnin option specified
    unsigned                         _sampleFreq;    ///< Number of generations between samples
    unsigned                         _diagnFreq;     ///< Number of generations between parm output

    // Replication parameters
    unsigned                         _nRuns;         ///< Number of mcmc chains to run in parallel
    bool                             _nRunsSet;      ///< Number of parallel MCMC chains set
    unsigned                         _nJackRepl;     ///< Number of jackknife replicates
    bool                             _nJackReplSet;  ///< Number of jackknife replicates set
    FLOAT                            _jackPct;       ///< Percent of calibrations to include in each replicate.
    bool                             _jackPctSet;    ///< Jackknife percentage set

    unsigned                         _nRepl;         ///< Number of either runs or jackknife replicates

    // Birth-death process parameters
    FLOAT                            _bdLambda;      ///< Birth-Death process \f$\lambda\f$ parameter.
    FLOAT                            _bdMu;          ///< Birth-Death process \f$\mu\f$ parameter.
    FLOAT                            _bdRho;         ///< Birth-Death process \f$\rho\f$ parameter.


    // Clock model parameters
    bool                             _cModelSet;     ///< Clock model specified?
    Options::ClockModel              _cModel;        ///< Clock model
    FLOAT                            _cMMeanAlpha;   ///< Rates mean parameter gamma alpha
    FLOAT                            _cMMeanBeta;    ///< Rates mean parameter gamma beta
    FLOAT                            _cMMeanDCon;    ///< Rates mean paramater dirichlet concentration
    FLOAT                            _cMVarAlpha;    ///< Rates variance parameter gamma alpha
    FLOAT                            _cMVarBeta;     ///< Rates variance parameter gamma beta
    FLOAT                            _cMVarDCon;     ///< Rates variance paramater dirichlet concentration

    // Evolutionary model and parameters
    Options::EvoModel                _eModel;	     ///< Evolutionary model
    FLOATVEC                         _eMParms;       ///< Model dependent parameters
    FLOATVEC                         _eMFreqParms;   ///< Model dependent character frequence parameters
    unsigned                         _eMGammaCats;   ///< Number of gamma categories
    FLOATVEC                         _eMGammaParms;  ///< Gamma distribution hyperparameters

    /// Master random number generator.
    /// Used to generate random seems for the individual replicate generators.
    std::mt19937                     _randomGen;

    /// Output performance information.
    /// Set to true by the presence of the FDIVT_PERF environment variable
    /// or the LogDebug option being set.
    bool                             _perf;

    bool                             _dumpTrees;     ///< Dump the tree factory prior to replication
    bool                             _dumpRepl;      ///< Dump the replicates prior to mcmc start

    DivTime()
        throw ( Except::PerfError );

    virtual ~DivTime();

    // Methods to handle processing options set by the user.
    virtual
    void
    SetOptions (const std::vector<Options::DivOpt*>& opts)
        throw( Except::BadOpt,
               Except::BadOptValue );

    virtual
    std::vector<Options::DivOpt>*
    GetOptions ()
	const;
    virtual
    void
    LogOptions ()
	const;

    // Set the evolutionary model
    virtual
    void
    SetModel (const Options::EvoModel     eModel,
	      const std::vector<double> & modelParms,
	      const std::vector<double> & freqParms,
	      const unsigned              gammaCats,
	      const std::vector<double> & gammaParms)
        throw (Except::ModelError);

    // Methods to set the various inputs
    virtual
    void
    AddTaxa (const std::string & taxa)
        throw( Except::DuplicateTaxa );

    virtual
    void
    AddLocus (const std::string & locus)
        throw( Except::DuplicateLocus );

    virtual
    void
    AddSequence (const std::string & locus,
		 const std::string & taxa,
		 const std::string & seq)
        throw ( Except::MissingTaxa,
                Except::MissingLocus,
                Except::InvalidSeqCh,
                Except::InvalidSeqLength,
                Except::MissingSeq );

    virtual
    void
    AddTree (InputTree::Node * const root,
	     const std::string &     label)
        throw ( Except::MissingTaxa,
                Except::InvalidTree );

    virtual
    void
    AddCalibration (const std::vector<std::string> &      taxa,
		    const std::vector<Options::CalOpt*> & opts,
		    const std::string &                   label)
        throw( Except::MissingTaxa,
               Except::BadOpt,
               Except::BadCalibrationOpt );

    // Output graphviz depiction of the trees
    virtual void TreeGraphviz ( const std::string & dotfile,
                                bool                taxa = false,
                                bool                calibrations = false,
                                bool                geneTrees = false ) const;

    // Perform the MCMC process.
    virtual void MCMC()
        throw( Except::BadOpt,
               Except::BadOptValue,
	       Except::GpuError,
	       Except::IOError,
               Except::ModelError,
               Except::NoCalibrations,
               Except::NumericError,
	       Except::OutputsExist,
	       Except::PerfError );

private:

    /// Final option checks and settings.
    /// @throw Except::BadOptValue Invalid option value.
    void
    OptionChecks ( void );

    /// Write the entire configuration to the log.
    void
    LogConfig( GpuInterface * gpuintf ) const;

    /// Setup all initial parameter values.
    void
    SetInitialValues( ReplicateVec & rVec ) const;

    /// Setup initial output files.
    void
    SetOutputFiles( ReplicateVec &  rVec,
		    OutputManager & oMgr ) const;

};

#endif // _DIVTIME_H_
