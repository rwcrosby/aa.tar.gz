/// @file Task.h
/// Header for the task class.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _TASK_H_
#define _TASK_H_

// *****************************************************************************
/// Base class for the tasks that will be dispatched to the threads.
/// Defines the interface into the tasks.

struct Task {

    /// A list of pointers to these.
    typedef std::list<Task*> PtrList;

    /// "Do it" method.
    /// The function call operator  method is used to actually do whatever is
    /// required on the thread.
    /// It is required that it be overridden.
    /// @param tno Thread number

    virtual void operator()( const unsigned tno )  = 0;

    virtual ~Task()
        {}

};

#endif // _TASK_H_
