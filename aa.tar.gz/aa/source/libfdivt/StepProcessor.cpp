/// @file StepProcessor.cpp
/// Declarations for the mcmc step processor

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include <string>

#include "Dump.h"
#include "Likelihood.h"
#include "Logger.h"
#include "Parameter.h"
#include "AgePrior.h"
#include "Replicates.h"
#include "StatsFn.h"
#include "StepProcessor.h"
#include "Task.h"
#include "ThreadSet.h"
#include "Tree.h"

// *****************************************************************************
/// Implementation of the step processor.

struct StepProcessorImpl : StepProcessor {

    StepProcessorImpl( ThreadSet &    tSet,
		       ReplicateVec & replVec );

    virtual ~StepProcessorImpl();

    virtual
    FLOAT
    AgeRatio()
	{
	    return FLOAT(_ageAccepted) / FLOAT(_ageAccepted + _ageRejected);
	}

    /// Return the log likelihood summed across all trees in all replicates
    virtual
    FLOAT
    LnL()
	{
	    return _lnL;
	}

    /// Return the log of the posterior summed across all trees in all replicates
    virtual
    FLOAT
    LnP()
	{
	    return _lnL + _lnPA + _lnPR + _lnPN;
	}

    /// Return the acceptance ratio for nusiance parameter proposals
    virtual
    FLOAT
    NuisanceRatio()
	{
	    return FLOAT(_nuisanceAccepted) / FLOAT(_nuisanceAccepted + _nuisanceRejected);
	}

    /// Do the actual MCMC step
    virtual
    void
    operator()    (unsigned currGen);

    virtual
    FLOAT
    RateRatio()
	{
	    return FLOAT(_rateAccepted) / FLOAT(_rateAccepted + _rateRejected);
	}

   void
   ZeroTotals()
	{
	    _lnL = 0.0;
	    _lnPA = 0.0;
	    _lnPR = 0.0;
	    _lnPN = 0.0;
	    _ageAccepted = 0;
	    _ageRejected = 0;
	    _rateAccepted = 0;
	    _rateRejected = 0;
	    _nuisanceAccepted = 0;
	    _nuisanceRejected = 0;
	}

    ReplicateVec & _replVec;                      ///< Set of all replicates
    Logger &       _logger;			  ///< Log to output to

    int            _debugProposal;		  ///< Proposal to debug

    ThreadSet &    _tSet;		          ///< Set of worker threads.

    Task::PtrList  _tasks;		          ///< Set of tasks to process the parameters

    FLOAT          _lnL;			  ///< Log Likelihood over all trees/replicates
    FLOAT          _lnPA;			  ///< Log Prior of ages over all trees/replicates
    FLOAT          _lnPR;			  ///< Log Prior of rates over all trees/replicates
    FLOAT          _lnPN;			  ///< Log Prior of other parms over all trees/replicates

    unsigned       _ageAccepted;		  ///< Total accepted age proposals
    unsigned       _ageRejected;		  ///< total rejected age proposals

    unsigned       _rateAccepted;		  ///< Total accepted rate proposals
    unsigned       _rateRejected;		  ///< Total rejected rate proposals

    unsigned       _nuisanceAccepted;		  ///< Total accepted nuisance parameter proposals
    unsigned       _nuisanceRejected;             ///< Total rejected nuisance parameter proposals

};

// *****************************************************************************
/// Update a list of parameters as a task.

struct StepTask : Task {

    StepTask( Replicate &         repl,
	      StepProcessorImpl & sProc)
	: _repl(repl),
	  _sProc(sProc)
	{}

    /// This is the actual task method that is run on the thread.
    /// @param id Task number.
    virtual void operator()( const unsigned id );

    Replicate &         _repl;			  ///< Associated replicate
    StepProcessorImpl & _sProc;		          ///< Associated step processor

};

// *****************************************************************************

StepProcessor *
StepProcessor::Factory( ThreadSet &    tSet,
			ReplicateVec & replVec )
{
    return new StepProcessorImpl(tSet, replVec);
}

// *****************************************************************************

StepProcessorImpl::StepProcessorImpl ( ThreadSet &    tSet,
				       ReplicateVec & replVec )
    : _replVec(replVec),
      _logger(replVec._logger),
      _tSet(tSet)
{

    ZeroTotals();

    /// - Create the parameter processing tasks.

    for ( auto& repl : replVec )
        _tasks.push_back(new StepTask(repl, *this));

    /// - Setup to dump proposals for a specific parameter
    const char *debugProposal = getenv("FDIVT_DEBUG_PROPOSAL");
    if ( debugProposal )
	_debugProposal = atoi(debugProposal);
    else
	_debugProposal = -1;

}

// *****************************************************************************

StepProcessorImpl::~StepProcessorImpl()
{
    for ( auto t : _tasks )
	delete t;
}

// *****************************************************************************

void
StepProcessorImpl::operator()( unsigned currGen )	          ///< Current mcmc generation
{
    LOGENTER(_logger, 0, Dump::str(currGen,"currGen"));

    /// - Dispatch the tasks to process the replicates

    _tSet(_tasks);

    /// - Accumulate the totals

    ZeroTotals();

    for ( auto & repl : _replVec ) {

        for ( auto & root : repl ) {
            _lnL  += (*root._lkh)();
	    _lnPA += (*root._lnPA)();
	    _lnPR += root._lnPR;
	    _lnPN += root._lnPN;
	}

	_ageAccepted      += repl._ageAccepted;
	_ageRejected      += repl._ageRejected;
	_rateAccepted     += repl._rateAccepted;
	_rateRejected     += repl._rateRejected;
	_nuisanceAccepted += repl._nuisanceAccepted;
	_nuisanceRejected += repl._nuisanceRejected;

    }

    LOGEXIT( _logger, 0,
	     Dump::str(currGen,"currGen"),
	     Dump::str(_lnL,"lnL"),
	     Dump::str(_lnPA,"lnPA"),
	     Dump::str(_lnPR,"lnPR"),
	     Dump::str(_lnPN,"lnPN"),
	     Dump::str(_ageAccepted,"ageAccepted"),
	     Dump::str(_ageRejected,"ageRejected"),
	     Dump::str(_rateAccepted,"rateAccepted"),
	     Dump::str(_rateRejected,"rateRejected"),
	     Dump::str(_nuisanceAccepted,"nuisanceAccepted"),
	     Dump::str(_nuisanceRejected,"nuisanceRejected") );
 }

// *****************************************************************************
/// Operator to process the list of parameters as a task.

void
StepTask::operator()( const unsigned id )
{
    REPRENTER(Dump::str(id, "taskNo"));

    /// - If debug isn't set, setup so we can toggle it for proposal debugging

    bool setDebug = debugSet && !_repl._logger.Debug();

    /// - Loop through the list of parameters

    for ( auto parm : _repl._parmList ) {

	REPRDEBUG("Processing",
		  Dump::str(parm->str()));

	/// - Setup to dump a specific proposal and trees prior to the proposal

	if ( debugSet && _sProc._debugProposal == parm->_id ) {
	    Dump::Trees( _repl,
			 "Dump of replicate before proposal",
			 _repl._logger);
	    if ( setDebug )
		_repl._logger.Debug(true);
	}

	/// - Make the proposal

        FLOAT  delta = parm->Propose();

	/// - Accept or reject the proposal

	if ( delta >= 0.0 ) {
	    REPRDEBUG("Accepted - Delta",
		      Dump::str(delta, "delta"),
		      Dump::str(exp(delta),"exp(delta)"));
	    parm->Accept();
	}
	else {

	    FLOAT  draw = _repl._statsObj->DrawUniform();

	    if ( draw < exp(delta) ) {
		REPRDEBUG("Accepted - Draw",
			  Dump::str(delta, "delta"),
			  Dump::str(draw, "draw"),
			  Dump::str(exp(delta),"exp(delta)"));

		parm->Accept();
	    }
	    else {
		REPRDEBUG("Rejected",
			  Dump::str(delta, "delta"),
			  Dump::str(draw, "draw"),
			  Dump::str(exp(delta),"exp(delta)"));

		parm->Reject();
	    }

	}

	/// - Dump trees after the proposal

	if ( debugSet && _sProc._debugProposal == parm->_id ) {
	    Dump::Trees( _repl,
			 "Dump of replicate after proposal",
			 _repl._logger);
	    if ( setDebug )
		_repl._logger.Debug(false);
	}

    }

    REPREXIT(Dump::str(id, "taskNo"));
}
