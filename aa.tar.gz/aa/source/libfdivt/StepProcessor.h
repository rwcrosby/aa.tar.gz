/// @file StepProcessor.h
/// Declaration for the mcmc step processor

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _STEPPROCESSOR_H_
#define _STEPPROCESSOR_H_

struct  ThreadSet;
struct  ReplicateVec;

// *****************************************************************************
/// MCMC step processor object
/// Handles the multi-tasking and processes for a single mcmc step

struct StepProcessor {

    virtual ~StepProcessor ()
	{};

    /// Return the acceptance ratio for age proposals
    virtual
    FLOAT
    AgeRatio() = 0;

    /// Create one of these.
    /// @param tSet Set of threads to use for processing
    /// @param replVec Set of replicates to process
    static
    StepProcessor *
    Factory ( ThreadSet &    tSet,
	      ReplicateVec & replVec );

    /// Return the log likelihood summed across all trees in all replicates
    virtual
    FLOAT
    LnL() = 0;

    /// Return the log of the posterior summed across all trees in all replicates
    virtual
    FLOAT
    LnP() = 0;

    /// Return the acceptance ratio for nusiance parameter proposals
    virtual
    FLOAT
    NuisanceRatio() = 0;

    /// Perform an mcmc step.
    /// Create the tasks required for the step and dispatch through the work queue.
    /// @param currGen MCMC step number.
    /// @throw runtime_error If a thread task encountered an exception.
    /// @throw NumericError If a floating point error occured.
    virtual
    void
    operator()  (unsigned currGen) = 0;

    /// Return the acceptance ratio for rate proposals
    virtual
    FLOAT
    RateRatio() = 0;

};

#endif // _STEPPROCESSOR_H_
