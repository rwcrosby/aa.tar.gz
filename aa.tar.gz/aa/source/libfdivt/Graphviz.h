/// @file Graphviz.h
/// Generate graphviz file output

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _GRAPHVIZ_H_
#define _GRAPHVIZ_H_

#include <string>
#include <list>
#include <map>

struct Replicate;
struct SequenceFactory;
struct Taxa;
struct TreeFactory;

namespace Graphviz {

    // Write a dot file for the tree structure.
    void
    Trees( TreeFactory &     treeList,		  ///< The trees
           const std::string & dotfile );         ///< Output file name

    // Write a dot file for a replicate
    void
    Replicate( struct Replicate &   treeList,     ///< A set of trees as a replicate
               const std::string &  dotfile );    ///< Output file name

    // Write a dot file for the taxa set
    void
    Taxa( const SequenceFactory &                   seqFactory, ///< Alphabet for sequences
          const std::map<std::string, struct Taxa>& taxaMap,    ///< The taxa map
	  const std::string &                       dotfile );  ///< Output file name

    /// Write a dot file for the calibrations.
    void
    Calibrations( TreeFactory &                       treeList,  ///< The set of trees
		  const std::list<Calibration::Opts>& optList,   ///< List of calibration options
		  const std::string &                 dotfile ); ///< Output file name

    /// Output graphs for the gene trees
    void
    GeneTrees( TreeFactory &                       treeList,  ///< The set of trees
               const std::string &                 dotfile ); ///< Output file name

}

#endif // _GRAPHVIZ_H_
