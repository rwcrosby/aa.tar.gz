/// @file LogStats.h
/// Simple module to handle output of statistics to the log

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University, 
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _LOGSTATS_H_
#define _LOGSTATS_H_

#include <list>
#include <string>

#include "Logger.h"

// *****************************************************************************
/// Stats output class

/// Pure virtual class to be used as a base class for a set of statistics

class LogStats {

protected:

    typedef std::pair<std::string, unsigned*> STATSITEM;
    typedef std::list<STATSITEM>              STATSLIST;

    Logger &    _logger;                          ///< Logger to output to.
    bool        _logFlag;                         ///< Switch to control logging
    std::string _title;                           ///< Title for the output group

    void     _DoLogging ( STATSLIST&  stats );    ///< List of statistics to output
    
public:

    /// Create the logger setting the title and logger object pointer
    LogStats(Logger &    log,                     ///< Log object pointer
             std::string title)                   ///< Title for stats
	: _logger(log),
	  _logFlag(true),			  // Default is to log statistics
          _title(title)
	{}

    virtual void Log() = 0;                       ///< Output the stats

    // Get/set methods for the logging flag

    virtual void LogFlag(bool f) { _logFlag = f; }
    virtual bool LogFlag()       { return _logFlag; }

};

#endif // _LOGSTATS_H_
