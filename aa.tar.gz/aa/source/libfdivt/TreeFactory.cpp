/// @file TreeFactory.cpp
/// Definitions for Tree factory

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include <algorithm>
#include <iostream>
#include <stack>
#include <unordered_set>

#include "Dump.h"
#include "fnv.h"
#include "Except.h"
#include "HashTable.h"
#include "InputTree.h"
#include "Locus.h"
#include "Sequence.h"
#include "Taxa.h"
#include "Tree.h"
#include "TreeFactory.h"
#include "TreeStats.h"

// *****************************************************************************
/// Get the low taxa id for a vertex

inline
unsigned
GetTxId( const Tree::Position & tPos )
{
    return tPos.IsLeaf()
	? tPos._node->_taxa->_id
	: tPos._node->_init->_txId;
}

// *****************************************************************************
/// Create a key vector for a site at a locus

static
UCHARVEC
MakeSiteKey( std::vector<Taxa *>& tv,
             unsigned             l,
             unsigned             i )
{

    UCHARVEC key;
    for ( auto taxa : tv )
        key.push_back((*taxa->_seqVec[l])[i]);
    return key;

}

// *****************************************************************************

static
void
BuildSiteData ( const Tree::Position &  tPos,
                Tree::Init::LInit &     lInit,
                Tree::LocusNode &       lNode )
{

    auto &   locus = lNode._lRoot._locus;
    unsigned lId   = locus._id;
    auto &   node  = *tPos._node;

    /// - Get left and right Taxa vectors

    auto lChild    = lNode._children[0];
    auto rChild    = lNode._children[1];

    auto & lLInit  = lChild->_tNode->_node->_init->_locusVec[lId];
    auto & rLInit  = rChild->_tNode->_node->_init->_locusVec[lId];

    auto & lhsTVec = lLInit._taxaVec;
    auto & rhsTVec = rLInit._taxaVec;

    /// - Create the taxa vector for this node sorted by taxa id.

    std::merge(lhsTVec.begin(), lhsTVec.end(),
               rhsTVec.begin(), rhsTVec.end(),
               back_inserter(lInit._taxaVec),
               [] (const Taxa * t1, const Taxa * t2 ) -> bool { return t1->_id < t2->_id; } );

    /// - Process through the length of the sequences for this locus

    auto & siteVec = node._locusSiteVec[lId];
    siteVec.reserve(locus._seqLen);
    for ( unsigned i = 0; i < locus._seqLen; i++ ) {

        /// - Make keys for the left, right and this node.
        ///   This code generates a bunch of temporaries but
        ///   it's not in the critical path and makes it more readable.

        UCHARVEC lhsKey = MakeSiteKey(lhsTVec, lId, i);
        UCHARVEC rhsKey = MakeSiteKey(rhsTVec, lId, i);
        UCHARVEC key    = MakeSiteKey(lInit._taxaVec, lId, i);

        /// - Do we already have a site data entry for this key?

        auto iter = lInit._siteMap.find(key);
        if ( iter != lInit._siteMap.end() )
            iter->second->_count++;
        else {

            /// - Make a new site data entry and add to the map.

            unsigned lSiteIdx = lChild->IsLeaf()
                ? (*lhsTVec[0]->_seqVec[lId])[i]
                : lLInit._siteMap[lhsKey]->_idx;

            unsigned rSiteIdx = rChild->IsLeaf()
                ? (*rhsTVec[0]->_seqVec[lId])[i]
                : rLInit._siteMap[rhsKey]->_idx;

            siteVec.emplace_back(siteVec.size(),
				 lSiteIdx,
				 rSiteIdx );
            lInit._siteMap[key] = &siteVec.back();

        }

    }

    auto & lRoot = lNode._lRoot;
    lRoot._nInnerNodes++;
    lRoot._nTotalSites += siteVec.size();
    if ( lNode.IsRoot() ) {
	lRoot._nRootSites = siteVec.size();
	lRoot._nSeqSites = lRoot._locus._seqLen;
    }
}

// *****************************************************************************

TreeFactory::TreeFactory( HashStats &                    hashStats,
                          std::map<std::string, Taxa> &  taxaMap,
                          std::vector<Locus*> &          locusVec,
                          Logger &                       logger )
    : _hashStats(hashStats),
      _taxaMap(taxaMap),
      _locusVec(locusVec),
      _hashBits(24),
      _hashTable(0),
      _logger(logger),
      _treeBlks(false)
{
}

// *****************************************************************************

TreeFactory::~TreeFactory()
{
    if (_hashTable)
        delete _hashTable;
    else
        _hashStats.LogFlag(false);
}

// *****************************************************************************

void
TreeFactory::operator() ( const InputTree::Node * const  inNode,
                          const std::string              label )
{
    LOGENTER(_logger, 0, Dump::str((unsigned)size(),"id"), Dump::str(label,"label"));

    /// - If the tree blocks have been created, we can't add any more trees.

    if ( _treeBlks )
	throw Except::InvalidTree("Too late to add new trees.");

    /// - Create the new root.

    emplace_back(label, size(), _locusVec.size());
    auto & root = back();

    /// - Stack entry to maintain position and accumulate the children for a node in the tree.

    struct TreeStack {

        const InputTree::Node * const                  _inNode;     ///< Current position in the tree
        std::list<InputTree::Branch*>::const_iterator  _branches;   ///< Position in the list of branches
	FLOAT                                          _brLen;      ///< Incoming branch length
        Tree::Position::LIST                           _children;   ///< List of accumulated children for this node

	TreeStack ( const InputTree::Node * const inNode )
	    : _inNode(inNode),
              _brLen(0.0)
	    {
                if ( inNode->Type() == InputTree::NodeType::INNER )
                    _branches = static_cast<const InputTree::Inner*>(inNode)->children.begin();
 	    }

    };

    /// - Traversal of the input tree.
    ///   It's not done recursively since the trees may be very large and the size of a list is,
    ///   at least theoretically, infinite, whereas the stack depth is generally compiler limited.

    std::stack<TreeStack,
               std::list<TreeStack>> ts;	  // Stack is implemented via a list
    ts.emplace(inNode);                           // Push the root stack entry

    while( !ts.empty() ) {			  // While there's something on the stack

	TreeStack & top = ts.top();

        /// - Handle an inner node

 	if ( top._inNode->Type() == InputTree::NodeType::INNER ) {

	    auto inner = static_cast<const InputTree::Inner*>(top._inNode);

            /// - Finished all children of the inner node

	    if ( top._branches == inner->children.end() ) { // Processed all edges for the vertex

                /// - If this is the root don't create a key or add to hash, just
                ///   use the root already created.

                Tree::Node *   node;
                Tree::Position tPos;

                if ( top._inNode == inNode ) {

                    node = &root;
                    MakeKey(top._children);       // To sort the taxa properly

                    /// Create the child pointers with empty position lists

                    for ( auto & childPos : top._children )
                        node->_children.emplace_back(Tree::Node::CHILD(childPos._node, {}));

                    tPos = Tree::Position(root);

                }

                else {

                    /// - Hash table lookup for the inner node

                    std::string key = MakeKey(top._children);
                    auto hashPair = HashLookup(key);
                    if ( hashPair.second ) {          // Created a new hash table entry

                        /// Create a new node (with init) and populate the children

                        hashPair.first = new Tree::Node(nullptr);
                        hashPair.first->_init->_key  = key;
                        hashPair.first->_init->_txId = top._children.front()._node->_init->_txId;

                        /// Create the child pointers with empty position lists

                        for ( auto & childPos : top._children )
                            hashPair.first->_children.emplace_back(Tree::Node::CHILD(childPos._node, {}));

                    }

                    node = hashPair.first;

                    /// - Build the TreeNode

                    node->_treeVec.emplace_back(root,
                                                Tree::Position(node, node->_treeVec.size()),
                                                _locusVec.size(),
                                                top._brLen);

                    tPos = node->_treeVec.back();

                }

                /// - Set the child's parents to point to this TreeNode

                for ( auto & childPos : top._children ) {

                    childPos.AsTNode()._parent = tPos;

                    auto iter = node->_children.begin();

                    for ( ; iter != node->_children.end(); iter++ )
                        if ( iter->first == childPos._node )
                            break;

                    if ( iter == node->_children.end() )
                        assert(false && "Missing child building TreeNode");
                    else
                        iter->second.push_back(childPos._treeIdx);

                }

                /// - Pop the stack and add this node to the parente children (if not at the root).

		ts.pop();
                if ( !ts.empty() )
                    ts.top()._children.emplace_back(node, node->_treeVec.size() - 1);

	    }

            /// - Process through the children of the inner node

	    else {
		auto & br = *top._branches++;
		ts.emplace(br->target);

		/// - Zero (or missing) branch lengths are set to 1

		ts.top()._brLen = br->length ? br->length : 1.0;
	    }

	}

        /// - Handle a leaf node

	else if ( top._inNode->Type() == InputTree::NodeType::LEAF ) {

	    auto oLeaf = static_cast<const InputTree::Leaf*>(top._inNode);

	    /// - Find the taxa for this leaf

	    Taxa * taxa;
	    try {
		taxa = &_taxaMap.at(oLeaf->label);
	    }
	    catch (const std::out_of_range & ex) {
		throw Except::MissingTaxa(oLeaf->label);
	    }

            /// - Hash table lookup for the leaf

            std::string key = MakeKey(taxa->_id);
            auto hashPair = HashLookup(key);
            if ( hashPair.second ) {           // Created a new hash table entry
                hashPair.first = new Tree::Node(taxa);
                hashPair.first->_init->_txId = taxa->_id;
                if ( _leafVec.size() <  taxa->_id + 1 )
                    _leafVec.resize(taxa->_id + 1, nullptr);
                _leafVec[taxa->_id] = hashPair.first;
            }
            Tree::Node * node = hashPair.first;

            /// - Increment the tree size

	    root._nLeaves++;

            /// - Add the TreeNode for this leaf

            node->_treeVec.emplace_back(root,
                                        Tree::Position(node, node->_treeVec.size()),
                                        _locusVec.size(),
                                        top._brLen);

            /// - Pop the stack and add this leaf to the parents children

	    ts.pop();
	    assert( !ts.empty() && "Empty stack at leaf" );

            ts.top()._children.emplace_back(node, node->_treeVec.size() - 1);

	}

    }

    LOGEXIT(_logger, 0, Dump::str(label,"label"));
}

// *****************************************************************************

Tree::Position
TreeFactory::FindLeaf( const Tree::Root & root,
                       const Taxa &       taxa ) const
{
    /// - Find the root in the leaf's tree vector, returing an empty position if
    ///   not found.

    auto leaf = _leafVec[taxa._id];
    if ( !leaf )
        return Tree::Position();

    for ( auto & tn : leaf->_treeVec )
        if ( tn._root == root )
            return tn;

    return Tree::Position();
}

// *****************************************************************************

void
TreeFactory::Finish( TreeStats & stats )
{

    /// - Traversal object to create the locus blocks

    struct GeneTreeDfs : Tree::Dfs {

        GeneTreeDfs ( Tree::Root & r,
                      Locus &      l )
            : _root(r),
              _locus(l)
            {}

        virtual RC InnerBegin ( const Tree::Position & tPos )
            {
		auto & tNode = tPos.AsTNode();
                auto & lVec  = tNode._locusVec;
                auto   top   = _vStack.top();

                lVec.emplace_back ( *_locusRoot, &tNode, top );

                top->_children.push_back(&lVec.back());

                _vStack.push(&lVec.back());

                return CONTINUE;
            }

        virtual RC InnerEnd ( const Tree::Position & tPos )
            {
                _vStack.pop();                        // Just pop the stack
                return CONTINUE;
            }

        virtual RC Leaf ( const Tree::Position & tPos )
            {
		auto & tNode = tPos.AsTNode();
                auto & lVec  = tNode._locusVec;
                auto   top   = _vStack.top();

                lVec.emplace_back( *_locusRoot, &tNode, top );

                top->_children.push_back(&lVec.back());

                // Make sure the sequence vector is sized to all loci.
                if ( _locus._id + 1 > tPos._node->_taxa->_seqVec.size() )
                    tPos._node->_taxa->_seqVec.resize(_locus._id + 1, nullptr);

                return CONTINUE;
            }

        virtual RC RootBegin ( Tree::Root &  root )
            {
                auto& lVec = root._locusVec;

                lVec.emplace_back(_root, _locus);
                _locusRoot = &lVec.back();

                _vStack.push(_locusRoot);

                return CONTINUE;
            }

        Tree::Root &       _root;                     ///< Factory tree root
        Locus &            _locus;                    ///< Current locus
        Tree::LocusRoot *  _locusRoot;                ///< Gene tree root

        std::stack<Tree::LocusNode *,
                   std::list<Tree::LocusNode *>> _vStack;  ///< Stack of gene tree nodes hit

    };

    /// - Make a pass creating the gene trees assuming all taxa appear in all trees.

    for ( auto locus : _locusVec)

        /// - Loop through trees in the factory buiding the gene trees

        for ( auto& root : *this ) {
            GeneTreeDfs dfs(root, *locus);
            dfs(root);
        }

    /// - Trim gene trees restricting them to the taxa present.

    RestrictGeneTrees();

    /// Traversal object for site vector creation and tree stats generation

    struct SiteVectorsDfs : Tree::Dfs {

        SiteVectorsDfs( Tree::Root &                      root,
                        TreeStats &                       stats,
                        std::unordered_set<Tree::Node*> & nset,
                        const unsigned                    nLoci )
            : _root(root),
              _stats(stats),
              _nodesFound(nset),
              _nLoci(nLoci)
            {}

        /// If we've seen this node before, stop the downward traverssal
        virtual RC InnerBegin ( const Tree::Position & tPos )
            {
                return  _nodesFound.count(tPos._node) ? STOPDOWN : CONTINUE;
            }

        /// Build the site vector for the inner node
        virtual RC InnerEnd ( const Tree::Position & tPos )
            {
                auto & node = *tPos._node;
                node._locusSiteVec.resize(_nLoci);
                for ( auto& lNode : tPos.AsTNode()._locusVec ) { // Loop through all the loci
                    auto & lVec = node._init->_locusVec;
                    lVec.emplace_back();          // Create an empy entry
                    if ( !lNode._missing )
                        BuildSiteData(tPos, lVec.back(), lNode);
                }

                _nodesFound.insert(&node);

                _stats._nInner++;
                _stats._innerMem += sizeof(Tree::Node);
                node.VecSize(_stats._longTreeVec,
                             _stats._treeMem,
                             _stats._locusMem,
                             _stats._siteMem);


                return CONTINUE;
            }

        /// Build the site vector for a leaf node
        virtual RC Leaf ( const Tree::Position & tPos )
            {
                if ( _nodesFound.count(tPos._node) )  // Been here before? - if so bail out now.
                    return STOPDOWN;

                auto & node = *tPos._node;
                for ( auto& lNode : tPos.AsTNode()._locusVec ) { // Loop through all the loci
                    auto & lVec = node._init->_locusVec;
                    lVec.emplace_back();          // Create an empty entry
                    if ( !lNode._missing )
                        lVec.back()._taxaVec.push_back(node._taxa);
                }

                _nodesFound.insert(&node);

                _stats._nLeaves++;
                _stats._leafMem += sizeof(Tree::Node);
                node.VecSize(_stats._longTreeVec,
                             _stats._treeMem,
                             _stats._locusMem,
                             _stats._siteMem);

                return CONTINUE;
            }

        /// Build the site vectors at the root
        virtual RC RootEnd  ( Tree::Root & root )
            {
                root._locusSiteVec.resize(_nLoci);
                for ( auto& lRoot : root._locusVec ) {
                    auto & lVec = root._init->_locusVec;
                    lVec.emplace_back();          // Create an empy entry
                    if ( !lRoot._missing )
                        BuildSiteData(Tree::Position(root), lVec.back(), lRoot);
                }

                _stats._nRoots++;
                _stats._rootMem  += sizeof(Tree::Root);
                root.VecSize(_stats._longTreeVec,
                             _stats._treeMem,
                             _stats._locusMem,
                             _stats._siteMem);
                _stats._locusMem += sizeof(Tree::LocusRoot) * _nLoci;

                return CONTINUE;
            }

        Tree::Root &                      _root;       ///< Reference to tree root
        TreeStats &                       _stats;      ///< Tree statistics
        std::unordered_set<Tree::Node*>&  _nodesFound; ///< Set of nodes already processed
        const unsigned                    _nLoci;      ///< Number of loci to process

    };

    /// - Create the site data for each tree and locus

    std::unordered_set<Tree::Node *> nodes;       ///< List of nodes already processed

    for ( auto& root : *this ) {
        SiteVectorsDfs dfs(root, stats, nodes, _locusVec.size());
        dfs(root);
    }

}

// *****************************************************************************

std::pair<Tree::Node *&, bool>
TreeFactory::HashLookup ( const std::string & key )
{

   /// - Hit the hash table for the key
    auto slot = fnv_32a_str(key.c_str(), FNV1_32_INIT);
    uint32_t mask = ((uint32_t) 1 << _hashBits ) - 1;
    slot = (slot >> _hashBits) ^ (slot & mask);

    if ( !_hashTable )
	_hashTable = new HashTable<std::string, Tree::Node *>
            (_hashBits,
             [] (const std::string & key1,
                 const std::string & key2)
                 {
                     return key1 == key2 ? 0
                                         : key1 < key2 ? -1
                                                       : 1;
                 },
             _hashStats);

    std::pair<const std::string &, unsigned> keyp(key, slot);

    return _hashTable->Find(keyp);
}

// *****************************************************************************

std::string
TreeFactory::MakeKey ( std::list<Tree::Position> & cList )
{

    /// - Sort the branches by the taxa id.
    cList.sort( [] (Tree::Position & p1, Tree::Position & p2)
                    {
                        return GetTxId(p1) < GetTxId(p2);
                    } );

    /// - Build the key
    std::string key = "(";
    for ( auto iter = cList.begin();
	  iter != cList.end(); ) {

	key += (*iter).IsInner()
	    ? (*iter)._node->_init->_key
	    : std::to_string((*iter)._node->_taxa->_id);

	if ( ++iter == cList.end() )
	    break;

	key += ',';

    }
    key += ')';

    return key;
}

// *****************************************************************************

std::string
TreeFactory::MakeKey ( const unsigned id )
{
    return std::to_string(id);
}

// *****************************************************************************

void
TreeFactory::ReduceTree ( const Tree::Position & tPos,
                          const unsigned         locusIdx )
{
    auto & leaf = *tPos._node;

    LOGENTER(_logger, 0, Dump::str(tPos,"tPos"),
	     Dump::str(leaf._taxa->_label,"taxa label"),
	     Dump::str(tPos._treeIdx,"treeIdx"),
	     Dump::str(tPos.AsTNode()._root._label,"tree label"),
	     Dump::str(locusIdx,"locusIdx"),
	     Dump::str(_locusVec[locusIdx]->_label,"locus label"));

    auto& me          = tPos.AsTNode()._locusVec[locusIdx];
    auto  parent      = me._parent;
    auto  grandParent = parent->_parent;
    auto  sibling     = me.Sibling();

    sibling->_parent  = grandParent;
    if ( grandParent )
	for ( unsigned i = 0; i < grandParent->_children.size(); i++ )
	    if ( grandParent->_children[i] == parent ) {
		grandParent->_children[i] = sibling;
		break;
	    }

    me._missing       = true;
    me._parent        = nullptr;
    parent->_missing  = true;
    parent->_parent   = nullptr;
    parent->_children.clear();

    /// If the parent is the true root, the true root needs to be set to the
    /// sibling of the node and the true roots species list cleared.

    if ( parent == me._lRoot._trueRoot )
        me._lRoot._trueRoot = sibling;

    LOGEXIT(_logger, 0, Dump::str(tPos,"tPos"));
}

// *****************************************************************************
void
TreeFactory::RestrictGeneTrees( void )
{
    LOGENTER(_logger, 0, Dump::ptr(this, "this"));

    /// - Loop through the taxa

    for ( auto& tm : _taxaMap ) {

        auto& taxa = tm.second;

        /// - Loop for loci with missing sequences

        for ( unsigned i = 0; i < taxa._seqVec.size(); i++ ) {

            auto seq = taxa._seqVec[i];
            if ( seq )                            // We have a sequence for this locus: continue
                continue;

            /// - At this point we know that taxa taxa is missing from locus[i]
            /// - Process through each tree removing the taxa from the gene tree

            Tree::Node * leaf = _leafVec[taxa._id];
            for ( auto& tPos : leaf->_treeVec )
                if ( !tPos.Empty() )
                    ReduceTree(tPos, i);

        }

    }

    LOGEXIT(_logger, 0, Dump::ptr(this, "this"));
}
