/// @file EvoModel.h
/// Base classes for the evolutionary models.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _EVOMODEL_H_
#define _EVOMODEL_H_

#include <list>

#include "Config.h"
#include "ITransaction.h"

struct DirichletParameterSet;
struct DivTime;
struct EvoModelRoot;
struct Locus;
struct Parameter;
struct Replicate;
struct TransitionMatrix;

namespace Tree {
    struct LocusRoot;
    struct Root;
}

// *****************************************************************************
/// Common pure virtual base class for the evolutionary models.

struct EvoModel : ITransaction {

    /// Create a gene tree instance
    /// @param parent Species tree evolutionary model instance
    /// @param lRoot Gene tree root
    EvoModel( EvoModelRoot &   parent,
              Tree::LocusRoot& lRoot );

    virtual
    ~EvoModel();

    /// Return the character frequence vector.
    /// @return Array of doubles of length ngcat.
    virtual
    const
    FLOATVEC &
    CharFreq () const = 0;

    /// Do anything required on proposal commit.
    virtual
    void
    Commit()
	{}

    /// Calculate the GTR eigenvalues and multipler matrix.
    /// @param modelParms GTR rate parameters
    /// @param freqParms Character frequency parameters
    /// @param cMat Constant multipler matrix (NxNxN)
    /// @param Wr Eigenvalues (real)
    static
    void
    ComputeGTRLocusConstants ( DirichletParameterSet * modelParms,
			       DirichletParameterSet * freqParms,
			       FLOAT  *                cMat,
			       FLOAT  *                Wr );

    /// Create character frequency parameters.
    /// @param eModel Owning gene tree evolutionary model instance.
    /// @param initValues Set of initial values.
    /// @param hyperParms Set of user specified hyperparameters.
    /// @return Point to created parameter set.
    static
    DirichletParameterSet *
    FrequencyParmsSetup ( EvoModel&        eModel,
			  const FLOATVEC & initValues,
			  const FLOATVEC & hyperParms );

    /// Return true if this model has gamma site variation.
    inline
    bool
    GammaRates ()
	const;

    /// Factory to build a transition matrix based on an evolutionary model.
    /// Does not populate the matrix.
    virtual
    TransitionMatrix *
    MakeTransitionMatrix () = 0;

    /// Do anything required on proposal rollback.
    virtual
    void
    Rollback()
	{}

    /// Output the dump string for the model.
    virtual
    std::string
    str ( const std::string hdg = "")
	const;

    /// Update all transition matrixies for a gene tree.
    /// Assumes distances in the matrixes have been set.
    /// Used for gene tree parameter updates.
    virtual
    void
    UpdateAllTMatrixes ();

    /// Update a transition matrix with a new branch length.
    /// @param tMat Pointer to the matrix to update.
    /// @param dist New branch length
    virtual
    void
    UpdateTMatrix ( TransitionMatrix * tMat,
		    const FLOAT        dist ) = 0;

    /// Update a transition matrix without a branch length change.
    /// @param tMat Pointer to the matrix to update.
    virtual
    void
    UpdateTMatrix ( TransitionMatrix * tMat ) = 0;

    Replicate &       _repl;                      ///< Owning replicate
    EvoModelRoot &    _parent;			  ///< Species tree evo model
    Tree::LocusRoot & _lRoot;                     ///< Root of the associated gene tree

    Parameter *       _alpha;                     ///< \f$\alpha\f$ for gamma rates variation

    FLOATVEC          _rateVec;			  ///< Set of gamma rate category values.

    /// The list of transition matricies for this model.
    /// The list owns the transition matricies.
    /// Used to update the matricies when a model parameter changes
    std::list<TransitionMatrix *>  _tMatrixList;

};

// *****************************************************************************
/// Evolutionary model instance for a species tree.

struct EvoModelRoot {

    EvoModelRoot( Replicate &  repl,
		  Tree::Root & root );

    virtual
    ~EvoModelRoot()
	{}

    /// Check the parms as entered.
    /// @param dt Divergence time instance containing the parameters.
    /// @throw Except::ModelError Error in model specification
    static
    void
    CheckParms ( DivTime& dt );

    /// Check the discrete gamma category parms
    /// @param dt Divergence time instance containing the parameters.
    /// @throw Except::ModelError Error in model specification
    static
    void
    CheckParms_G ( DivTime& dt );

    /// Set initial model defaults.
    /// @param dt Divergence time instance containing the parameters.
    static
    void
    Default ( DivTime& dt );

    /// Get rid of any data loaded prior to dumping.
    /// Used by the GPU routines to clear data pulled down from the gpu.
    virtual
    void
    DisposeData ()
	{};

    /// Create a gene tree evolutionary model instance.
    /// @param lRoot Gene tree root
    /// @returns Pointer to created model instance
    virtual
    EvoModel *
    Factory ( Tree::LocusRoot & lRoot ) = 0;

    /// Create a species tree evolutionary model instance.
    /// @param repl Replicate owning the model.
    /// @param root species tree root
    /// @returns Pointer to created model instance
    static
    EvoModelRoot *
    Factory ( Replicate &  repl,
	      Tree::Root & root );

    /// Load any data required prior to dumping objects.
    /// Used by the GPU routines to pull data down from the gpu.
    virtual
    void
    GetData ()
	{};

    /// Write the description of the model to the log.
    /// @param dt Divergence time instance containing the parameters.
    static
    void
    Log ( const DivTime& dt );

    /// Write the description of the discrete gamma categories to the log
    /// @param dt Divergence time instance containing the parameters.
    static
    void
    Log_G ( const DivTime& dt );

    /// Do anything required for the evolutionary models at the
    /// end of root replication.
    /// Currently only used in the GPU algorithms.
    virtual
    void
    ReplRootEnd()
	{};

    /// Output dump string for the model
    virtual
    std::string
    str ( const std::string hdg = "" )
	const;

    /// Update all transition matrixies for a species tree.
    /// Assumes distances in the matrixes have been set.
    /// Used for setting initial values.
    /// Currently only used in the GPU algorithms.
    virtual
    void
    UpdateAllTMatrixes ()
	{};

    Replicate &           _repl;	          ///< Owning replicate
    Tree::Root &          _root;                  ///< Root of the associated species tree

    const unsigned        _nGCat;                 ///< Number of gamma categories
    const unsigned        _n;                     ///< Infdividual matrix size (nXn)

    std::list<EvoModel *> _eModelList;		  ///< List of gene tree instances

};

// *****************************************************************************

inline
bool
EvoModel::GammaRates ()
const
{
    return _parent._nGCat != 1;
}

#endif // _EVOMODEL_H_
