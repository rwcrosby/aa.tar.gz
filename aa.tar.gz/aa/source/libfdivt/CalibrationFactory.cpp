/// @file CalibrationFactory.cpp
/// Definition of the calibration factory function

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include <cassert>

#include "Calibration.h"
#include "CalibrationFactory.h"
#include "Taxa.h"
#include "Tree.h"
#include "TreeFactory.h"

// *****************************************************************************

typedef std::list<Tree::Path> PATHLIST;

static
Tree::Position
FindMRCA( PATHLIST & paths );

// *****************************************************************************
/// Add a calibration to a tree.

/// This function adds a single calibration to a single tree.

void
CalibrationFactory ( const Calibration::Opts & cOpt,  ///< Calibration options instance
		     Tree::Root &              root,  ///< Tree to process
                     const TreeFactory &       tFac ) ///< Tree factory to lookup leaves
{

    /// - Create the list of paths, one list entry for each taxa's path

    PATHLIST paths;

    // leaf map and then search the set of TreeNodes for the one matching this tree.
    for ( auto tx : cOpt._taxaObjs ) {

	auto tPos = tFac.FindLeaf(root, *tx);
        if (!tPos.Empty())                        // In this tree...
            paths.emplace_back(Tree::Position(root), tPos);

    }

    /// - Did we find enough paths to actually resolve the mrca, if so
    ///   find calibration point and add it to this nodes list

    if ( paths.size() >= 2 )
        FindMRCA(paths).GetCalList().emplace_back(Calibration::Data::Factory(cOpt));

}

// *****************************************************************************
/// Find the Most Recent Common Ancestor for the set of paths passed
/// @return Position defining the MRCA

static
Tree::Position
FindMRCA( PATHLIST & paths )                      ///< List of paths found
{

    Tree::Position mrca;

    while (true) {

        Tree::Position v;

	for ( auto & path : paths ) {

	    if ( path.empty() )
		return mrca;
	    else if ( v.Empty() )
		v = path.front();
	    else if ( path.front() != v )
		return mrca;

	    path.pop_front();

	}

	mrca = v;

    }

    // Should always find at least the root.
    assert(false && "Didn't find root whilst looking for MRCA");

}
