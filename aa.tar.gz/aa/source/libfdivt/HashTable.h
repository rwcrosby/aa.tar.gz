/// @file HashTable.h
/// @brief Class definition for a simple hash table

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                 College Station, Texas
//                 Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef HASHTABLE_HH
#define HASHTABLE_HH

#include <list>
#include <vector>

#include "HashStats.h"

// *****************************************************************************
/// Template for a hash table.
/// User is responsible for generating a slot number for the hash key.
/// @tparam KeyT Type for the hash table key.
/// @tparam ValT Type for the hash table payload.

template < typename KeyT, typename ValT >
class HashTable : private std::vector<std::list<std::pair<KeyT, ValT>> * >
{

public:

    typedef int (*CFN)(const KeyT &, const KeyT &);
    typedef std::pair<KeyT, ValT>                  TENTRY;
    typedef std::pair<const KeyT &, unsigned>      KEYP;
    typedef std::pair<ValT &, bool>                VALP;

    /// Constructor setting the hash table to the size specified.
    HashTable(const unsigned width,		  ///< Bit width of the table
	      CFN            cfn,                 ///< Key compare function
              HashStats &    stats                ///< Statistics block reference
        );

    virtual ~HashTable();

    /// Look for an entry in the table inserting one if needed.
    /// @param key Pair containing a reference to the key and the slot number to use.
    /// @return Pair; first member is a reference to the value found, second is a
    ///         bool indicating whether the value was found (false) or inserted (true).
    ///         Value is inserted using the default constructor.
    ///         This is similar to the std::set::insert semantic.
    virtual VALP Find ( const KEYP & key );

private:

    CFN         _cmpFn;                       /// Key compare function

    HashStats & _stats;                       ///< Statistics block

    /// Set the size of the hash table.
    /// Note the value to tablesize is the bit width of the table (2^s)
    /// e.g. 14 for 16384 slots.
    virtual void    TableSize ( const unsigned s )
	{
	    this->resize(1 << s);
	    _stats._nSlots = 1 << s;
	}

};

// *****************************************************************************

template < typename KeyT, typename ValT >
HashTable < KeyT, ValT >::HashTable( const unsigned width,
                                     CFN            cfn,
                                     HashStats &    stats )
    : std::vector<std::list<TENTRY> * >(1 << width, nullptr),
      _cmpFn(cfn),
      _stats(stats)
{

    _stats._nSlots = 1 << width;

}

// *****************************************************************************

template < typename KeyT, typename ValT >
HashTable < KeyT, ValT >::~HashTable()
{

    unsigned slotsUsed = 0;

    for ( auto te : *this ) {
	if ( !te )
	    continue;

	slotsUsed++;

	if (te->size() >= 10 )
	    (_stats._slotUsage[10])++;
	else
	    (_stats._slotUsage[te->size()])++;

	delete te;
    }
    _stats._slotUsage[0] = this->size() - slotsUsed;

}

inline
void
NewKeyStats ( HashStats &    stats,
              const unsigned size )
{
    stats._keys++;
    if ( size > stats._longestChain )
        stats._longestChain = size;
}

// *****************************************************************************

template < typename KeyT, typename ValT >
typename HashTable < KeyT, ValT >::VALP
HashTable < KeyT, ValT >::Find ( const KEYP & key )
{

    auto & listp = (*this)[key.second];

    if ( !listp ) {		          // Simple case - no table entry
        listp = (*this)[key.second];
	listp = new std::list<TENTRY>;
	listp->push_back(TENTRY(key.first, nullptr));

        NewKeyStats(_stats, listp->size());
	_stats._slotsUsed++;
	_stats._misses++;

        return VALP(listp->back().second, true);
    }

    // Run the chain looking for a node with a key greater than the current

    auto iter = listp->begin();

    for ( ; iter != listp->end(); ++iter ) {
	int cmp = _cmpFn(key.first, (*iter).first);
	if (!cmp) {                               // Key found!
	    _stats._hits++;
	    return VALP((*iter).second, false);
	}
	else if (cmp < 0 ) {			  // Key past chain
	    // printf("Miss ins middle, slot <%d>, key <%s> \n", slot, key->key.c_str());
	    auto newEntry = listp->insert(iter, TENTRY(key.first, nullptr));

            NewKeyStats(_stats, listp->size());

            return VALP((*newEntry).second, true);
	}
    }

    // printf("Miss ins end, slot <%d>, key <%s> \n", slot, key->key.c_str());

    // Not found,

    listp->push_back(TENTRY(key.first, nullptr));

    NewKeyStats(_stats, listp->size());

    _stats._misses++;					  // Not on chain

    return VALP(listp->back().second, true);

}

#endif // HASHTABLE_HH
