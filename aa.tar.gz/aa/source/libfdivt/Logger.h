/// @file Logger.h
/// Handle all "printed" output

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _LOGGER_H_
#define _LOGGER_H_

#include <mutex>

#include "Config.h"

class ILogSink;

namespace LogDest {
    class Base;
}

// *****************************************************************************
/// Define the standard debugging output macros for any object with a logger

#define LOGENTER(LOG, ID, ...) (LOG).DebugStd("Enter", ID, __FILE__, __LINE__, FUNCNAME, __VA_ARGS__);
#define LOGDEBUG(LOG, ID, ...) (LOG).DebugStd("Debug", ID, __FILE__, __LINE__, FUNCNAME, __VA_ARGS__);
#define LOGEXIT(LOG, ID, ...)  (LOG).DebugStd("Exit ", ID, __FILE__, __LINE__, FUNCNAME, __VA_ARGS__);

// *****************************************************************************
/// Log output class.
///
/// This class handles all output that should be "printed".
/// It does no selection on the output, it just writes it to all the registered
/// output destinations.
/// Standard output is via printf style formatting.

class Logger
{

    std::vector<LogDest::Base*> _destinations;	  ///< List of logging destinations
    std::mutex                  _mutex;           ///< Multitasking protection

    int                         _bufferSize;      ///< Logger output buffer size
    char *                      _buffer;          ///< Message output buffer

    bool                        _debug;           ///< Debugging output?

public:

    static const unsigned indent   = 3;
    static const unsigned minWidth = 30;
    static const unsigned hdgWidth = 40;

    /// Basic constructor for the logging object.
    Logger();

    /// Destructor for the logger.
    virtual ~Logger();

    /// Set/reset the debug flag.
    void Debug(bool d)        { _debug = d; }

    /// Get the debug flag.
    bool Debug()              { return _debug; }

    /// Add a file number as a destination.
    void AddDestination (const unsigned fno);

    /// Add a file pointer as a destination.
    /// It is assumed that the file is open for output
    /// in text mode. File is neither opened nor closed
    void AddDestination (FILE * fp);

    /// Add a filename as a destination.
    /// The file will be opened for output (not append) in text mode.
    void AddDestination (char *    filename);

    /// Add a log sink object as a destination.
    void AddDestination (ILogSink* sink);

    /// Log unconditionally.
    /// Interface is printf style options (e.g. format and variables).
    void operator()     (const char * format, ...);

    /// Log unconditionally.
    /// Interface is printf style options (e.g. format and variables).
    template<typename ... Args>
    void Log(const char * format, Args ... args)
        {
            operator()(format, args ...);
        }

    /// Log for debugging.
    /// Logging will only occur if both debug=1 is set in the build
    /// and the debug parameter has been set to True.
    /// Interface is printf style options (e.g. format and variables).
    template<typename ... Args>
    void Debug(const char * format, Args ... args)
        {
            if (debugSet && _debug)
                operator()(format, args ...);
        }

    /// Entry/debug/exit standard format.
    /// id/type/file/line/func args
    /// Logging will only occur if both debug=1 is set in the build
    /// and the debug parameter has been set to True.
    template<typename ... Args>
    void DebugStd( const std::string   type,
		   const unsigned      id,
		   const std::string   file,
		   const unsigned      line,
		   const std::string   func,
		   Args ...            args )
        {
            if (debugSet && _debug) {
		std::vector<std::string> strs;
		strs = {args...};
                DebugStdLine(type, id, file, line, func, strs);
	    }
        }

private:

    /// Produce the standard format debugging line
    void DebugStdLine ( const std::string              type,
			const unsigned                 id,
			const std::string              file,
			const unsigned                 line,
			const std::string              func,
			const std::vector<std::string> strs );

};

#endif // _LOGGER_H_
