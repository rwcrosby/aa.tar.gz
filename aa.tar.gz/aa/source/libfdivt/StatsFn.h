/// @file StatsFn.h
/// A collection of statistical functions largly copied from Yang.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _STATISTICSFN_H_
#define _STATISTICSFN_H_

#include <functional>
#include <random>

#include "Config.h"

namespace StatsFn {

    /// Compute the set of rates for the discrete gamma with nCat categories,
    /// From Yang (1994 and Paml 4.8).
    /// Rates are computed for the mean of the intervals.
    /// @return Fraction of the interval in each category (1/nCat).
    /// @param alpha \f$\alpha\f$ parameter for the distribution
    /// @param nCat Number of discrete intervals to generate
    /// @param rateVec Vector to receive generates rates.

    FLOAT  DiscreteGamma ( FLOAT    alpha,
                           unsigned nCat,
                           FLOAT    rateVec[] );

    /// Compute the pdf of a value using the \f$\Gamma\f$ distribution/
    /// Gamma density: mean=alpha/beta; var=alpha/beta^2
    /// From Yang (1994 and Paml 4.8).
    /// Rates are computed for the mean of the intervals.
    /// @return Probabilitity associated with the input value
    /// @param x Input value
    /// @param alpha \f$\alpha\f$ parameter.
    /// @param beta \f$\beta\f$ parameter.

    double  GammaPDF( double  x,
                      double  alpha,
                      double  beta );

    /// The value 0.94 is useful for generating MCMC proposals
    static const double  defaultDoubleNormalMu = 0.94;

    /// Return a variable in the range (a,b) by reflecting x back into the range.
    /// From Yang (1994 and Paml 4.8).
    /// @return Value in the range
    /// @param x value to reflect into range
    /// @param a lower limit of range
    /// @param b upper limit of range

    inline
    FLOAT  Reflect(FLOAT        x,
		   const FLOAT  a,
		   const FLOAT  b )
    {
	x -= floor((x-a)/(2*(b-a))) *2*(b-a);
	while (true) {
	    if(x<a)       x = a*2 - x;
	    else if(x>b)  x = b*2 - x;
	    else break;
	}
	return x;
    }

}

// *****************************************************************************
/// Object encapsulating various statistical functions and a random number generator

struct StatsObj {

    StatsObj( const FLOAT  seed);

    /// Random draw from the mix of two normal distributions

    FLOAT  DrawNormalMix ( FLOAT  mu = StatsFn::defaultDoubleNormalMu );

    /// Random draw from a uniform real 0-1 distribution

    FLOAT  DrawUniform()
        {
            return _uniform01();
        }

    /// Random draw from a standard normal distribution

    FLOAT  DrawStdNormal ()
        {
            return _stdNormal();
        }

    /// Random draw from a gamma distribution optionally constraining the values.

    FLOAT  DrawGamma     ( const FLOAT  alpha,
                           const FLOAT  beta,
                           const FLOAT  min = std::numeric_limits<FLOAT >::min(),
                           const FLOAT  max = std::numeric_limits<FLOAT >::max() );

    /// Random draw from a normal distribution optionally constraining the values.

    FLOAT  DrawNormal    ( const FLOAT  mu,
                           const FLOAT  sigma,
                           const FLOAT  min = std::numeric_limits<FLOAT >::min(),
                           const FLOAT  max = std::numeric_limits<FLOAT >::max() );

    /// Just get a reference to the generator

    std::mt19937_64& RandomGen()
        {
            return _randomGen;
        }

private:

    std::mt19937_64                        _randomGen;   ///< Generator for this replicate

    std::uniform_real_distribution<FLOAT > _uniformDist; ///< Uniform random distribution
    std::normal_distribution<FLOAT >       _normalDist;  ///< Uniform random distribution

    std::function<FLOAT ()>                _stdNormal;   ///< Draw from a standard normal
    std::function<FLOAT ()>                _uniform01;   ///< Draw from a uniform in 0.0<x<1.0

};


#endif // _STATISTICSFN_H_
