/// @file TransitionMatrix.h
/// Declaration of the transition matrix base class.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _TRANSITIONMATRIX_H_
#define _TRANSITIONMATRIX_H_

#include <string>

#include "ITransaction.h"

struct EvoModel;

// *****************************************************************************
/// Transition probability matrix virtual base class.

struct TransitionMatrix : ITransaction {

    /// Constructor used by the model's MakeTransitionMatrix method.
    /// @param n Matrix size (nxn).
    /// @param nGCat Number of gamma categories (1 for non-gamma models).
    /// @param parent Owning evolutionary model instance.
    TransitionMatrix( const unsigned n,
                      const unsigned nGCat,
                      EvoModel &     parent)
	: _n(n),
	  _nGCat(nGCat),
	  _parent(parent),
	  _dist(0.0),
	  _oldDist(0.0)
	{}

    /// Declare a copy constructor to make sure one isn't used.
    TransitionMatrix( const TransitionMatrix & tm ) = delete;

    virtual
    ~TransitionMatrix()
	{}

    /// Empty commmit.
    virtual
    void
    Commit()
	{}

    /// Rollback the transaction to the prior state on a rejected proposal
    virtual
    void
    Rollback()
        {
            _dist = _oldDist;
        }

    /// Save state and log for rollback
    virtual
    void
    Save();

    /// Output the dump string for the model.
    virtual
    std::string
    str ( const std::string hdg = "")
	const;

    const unsigned _n;                            ///< Size of the matrix (n by n)
    const unsigned _nGCat;                        ///< Number of gamma rate categories

    EvoModel &     _parent;                       ///< Reference to owning evolutionary model

    FLOAT          _dist;                         ///< Distance used to generate matrix
    FLOAT          _oldDist;                      ///< Prior value of distance

};

#endif // _TRANSITIONMATRIX_H_
