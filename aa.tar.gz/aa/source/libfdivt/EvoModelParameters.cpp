/// @file EvoModelParameters.cpp
/// Definition for the methods of the evolutionary model parameters.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include <cmath>
#include <iostream>

#include "Config.h"
#include "Dump.h"
#include "EvoModel.h"
#include "EvoModelParameters.h"
#include "Likelihood.h"
#include "Locus.h"
#include "Replicates.h"
#include "StatsFn.h"
#include "Tree.h"

// *****************************************************************************

static
inline
void
LogSums ( const FLOATVEC & parms,
	  const FLOATVEC & hyperParms,
	  FLOAT  &         lnValue,
	  FLOAT  &         lnPrior )
{

    lnValue = 0.0;
    lnPrior = 0.0;
    for ( unsigned i = 0; i < parms.size(); i++ ) {
	FLOAT  lnV= log(parms[i]);
	lnValue += lnV;
	lnPrior += (hyperParms[i] - 1.0) * lnV;
    }

}

// *****************************************************************************

static const auto dirichletDataSource = [] ( Tree::TraceInfo * ti )
                                           {
					       auto p = static_cast<DirichletParameterSet*>(ti->_parm);
					       return p->_values[ti->_idx];
					   };

DirichletParameterSet::DirichletParameterSet( EvoModel &        eModel,
					      const FLOATVEC &  initValues,
					      const FLOATVEC &  hyperParms,
					      const std::string hdgPrefix,
					      const STRINGVEC   hdgVec )
    : EvoModelParameter( eModel ),
      _hyperParms(hyperParms),
      _values(initValues)
{
    _oldValues.resize(_values.size());
    _repl._stats._parms[_pType]._mem += sizeof(DirichletParameterSet) +
	                                sizeof(FLOAT ) * _values.size();

    /// - Setup multiple trace info blocks for the set of values

    for ( unsigned i = 0; i < _values.size(); i++ )
	SetTraceInfo(Tree::TraceType::NuisanceParm,
		     dirichletDataSource,
		     _lRoot._locus._id,
		     i,
		     hdgPrefix + " " + hdgVec[i],
		     hdgPrefix + "_" + hdgVec[i] );

    /// - Compute the initial value of the prior.

    LogSums(_values, _hyperParms, _value, _prior);
    _lnPN += _prior;

}

// *****************************************************************************
/// Commit the proposal.

void
DirichletParameterSet::Commit()
{
    _eModel.Commit();
}

// *****************************************************************************

FLOAT
DirichletParameterSet::Propose( void )
{
    REPRENTER(Dump::ptr(&_eModel, "eModel"),
	      Dump::str(_value,"value"));

    /// - Setup to rollback if the proposal is rejected

    auto & lRoot = _eModel._lRoot;

    NuisanceParameter::Propose();
    _oldValues.swap(_values);
    _repl.LogRollback(this);

    /// - Draw new values for the parameters

    FLOAT  sum = 0.0;
    for ( unsigned i = 0; i < _oldValues.size(); i++ ) {
	FLOAT  newValue = StatsFn::Reflect(_oldValues[i] + Finetune::dirichletSet * _repl._statsObj->DrawNormalMix(),
					   0.0, 1.0);
	_values[i] = newValue;
	sum += newValue;
    }

    /// - Normalize the parameters

    for ( auto v : _values )
	v /= sum;

    /// - Compute new sums of the logs of the values and the prior

    LogSums(_values, _hyperParms, _value, _prior);
    _lnPN += PriorRatio();

    /// - Compute the new likelihood for the current locus

    FLOAT  lnLRatio = lRoot._lkh->Compute();

    /// - Return the proposal ratio

    FLOAT  priorRatio = lnLRatio +
	                PriorRatio() +
                        _value - _oldValue;

    REPREXIT( Dump::str(lnLRatio, "lnLRatio"),
	      Dump::str(priorRatio, "priorRatio"),
	      Dump::str(_prior, "Prior"),
	      Dump::str(_oldPrior, "oldPrior"),
	      Dump::str(_value, "lnValue"),
	      Dump::str(_oldValue, "oldValue") );

    return priorRatio;
}

// *****************************************************************************

void
DirichletParameterSet::Rollback()
{
    EvoModelParameter::Rollback();
    _values.swap(_oldValues);
    _eModel.Rollback();
}

// *****************************************************************************

std::string
DirichletParameterSet::str ()
    const
{
    return Dump::str(_values);
}

// *****************************************************************************

EvoModelParameter::EvoModelParameter( EvoModel & eModel )
    : NuisanceParameter(eModel._repl, eModel._lRoot._root),
      _eModel(eModel),
      _lRoot(eModel._lRoot)
{
}

// *****************************************************************************

std::string
EvoModelParameter::str ()
    const
{
	    std::stringstream ss;
	    ss << Parameter::str() << ' '
	       << Dump::str(_root._rootIdx, "tid") << ' '
	       << Dump::str(_lRoot._locus._id, "lid");
	    return ss.str();
}

// *****************************************************************************

GammaParameter::GammaParameter( EvoModel  &    eModel,
                                const FLOAT    alpha,
                                const FLOAT    beta,
				const char *   label,
				const char *   hdg )
    : EvoModelParameter(eModel),
      _alpha(alpha),
      _beta(beta)
{

    REPRENTER(Dump::ptr(&eModel, "eModel"));

    _repl._stats._parms[_pType]._mem += sizeof(GammaParameter);

    /// - Initial value set to mean of the distribution

    _value = _alpha * _beta;

    /// - Compute the initial value of the prior.

    auto pdf = StatsFn::GammaPDF(_value, _alpha, _beta);
    _prior = log(pdf);
    _lnPN += _prior;

    /// - Setup trace

    SetTraceInfo ( Tree::TraceType::NuisanceParm, _lRoot._locus._id, label, hdg );

    REPREXIT(Dump::str(alpha, "alpha"),
	Dump::str(beta, "beta"),
	Dump::str(pdf, "pdf"),
	Dump::str(_value, "value"),
	Dump::str(_prior, "prior"));

}

// *****************************************************************************
/// Commit the proposal.

void
GammaParameter::Commit()
{
    _eModel.Commit();
}

// *****************************************************************************
/// Propose a new value for a gamma distributed value (e.g. \f$\kappa\f$ values
/// in the distributions.

FLOAT
GammaParameter::Propose( void )
{

    REPRENTER(Dump::ptr(&_eModel, "eModel"),
	      Dump::str(_value,"value"));

    auto & lRoot = _eModel._lRoot;

    /// - Setup to rollback if the proposal is rejected

    NuisanceParameter::Propose();
    _repl.LogRollback(this);

    /// - Draw a new value for the parameter

    FLOAT  oldLnValue = log(_oldValue);
    FLOAT  newLnValue = oldLnValue + Finetune::nuisance * _repl._statsObj->DrawNormalMix();
    _value            = exp(newLnValue);

    /// - Compute the new likelihood for the current locus

    FLOAT  lnLRatio = lRoot._lkh->Compute();

    /// - Get the prior probability given the new parameter value

    _prior = log(StatsFn::GammaPDF(_value, _alpha, _beta));
    _lnPN += PriorRatio();

    /// - Return the proposal ratio

    FLOAT  priorRatio = lnLRatio +
	                PriorRatio() +
                        newLnValue - oldLnValue;

     REPREXIT(Dump::str(_value, "value"),
	      Dump::str(priorRatio, "priorRatio"),
	      Dump::str(lnLRatio, "lnLRatio"),
	      Dump::str(_prior, "prior"),
	      Dump::str(_oldPrior, "oldPrior"),
	      Dump::str(newLnValue, "newLnValue"),
	      Dump::str(oldLnValue, "oldLnValue"));

    return priorRatio;
}

// *****************************************************************************
/// Roll the proposal back.

void
GammaParameter::Rollback()
{
    EvoModelParameter::Rollback();
    _eModel.Rollback();
}

// *****************************************************************************

GCatAlphaParameter::GCatAlphaParameter( EvoModel  &    eModel,
					const FLOAT    alpha,
					const FLOAT    beta,
					const char *   label,
					const char *   hdg )
    : GammaParameter(eModel, alpha, beta, label, hdg),
      _rateVec(eModel._rateVec)
{
    _rateVec.resize(eModel._parent._nGCat);
    StatsFn::DiscreteGamma( _value, eModel._parent._nGCat, _rateVec.data() );
}

// *****************************************************************************
/// Propose a new value for a gamma distributed value (e.g. \f$\kappa\f$ values
/// in the distributions.

FLOAT
GCatAlphaParameter::Propose( void )
{

    REPRENTER(Dump::ptr(&_eModel, "eModel"),
	      Dump::str(_value,"value"),
	      Dump::str(_rateVec, "rateVec"));

    auto & lRoot = _eModel._lRoot;

    /// - Setup to rollback if the proposal is rejected

    NuisanceParameter::Propose();
    _repl.LogRollback(this);

    /// - Draw a new value for the parameter

    FLOAT  oldLnValue = log(_oldValue);
    FLOAT  newLnValue = oldLnValue + Finetune::nuisance * _repl._statsObj->DrawNormalMix();
    _value            = exp(newLnValue);

    /// - Update the rate vector

    StatsFn::DiscreteGamma( _value, _eModel._parent._nGCat, _rateVec.data() );

    REPRDEBUG(Dump::str(_value, "New value"),
	      Dump::str(_rateVec, "New rateVec"));

    /// - Compute the new likelihood for the current locus

    FLOAT lnLRatio = lRoot._lkh->Compute();

    /// - Get the prior probability given the new parameter value

    _prior = log(StatsFn::GammaPDF(_value, _alpha, _beta));
    _lnPN += PriorRatio();

    /// - Return the proposal ratio

    FLOAT  priorRatio = lnLRatio +
	                PriorRatio() +
                        newLnValue - oldLnValue;

     REPREXIT(Dump::str(_value, "value"),
	      Dump::str(priorRatio, "priorRatio"),
	      Dump::str(lnLRatio, "lnLRatio"),
	      Dump::str(_prior, "prior"),
	      Dump::str(_oldPrior, "oldPrior"),
	      Dump::str(newLnValue, "newLnValue"),
	      Dump::str(oldLnValue, "oldLnValue"));

    return priorRatio;
}

// *****************************************************************************
/// Roll the proposal back.

void
GCatAlphaParameter::Rollback()
{
    EvoModelParameter::Rollback();

    /// - Reset the rate vector
    StatsFn::DiscreteGamma( _value, _eModel._parent._nGCat, _rateVec.data() );

}
