/// @file Replicates.cpp
/// Definitions for the replicate and the set of replicates.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include <iostream>
#include <stack>
#include <sstream>
#include <unordered_map>
#include <unordered_set>

#include "AgeParameter.h"
#include "AgePrior.h"
#include "Calibration.h"
#include "DivTime.h"
#include "Dump.h"
#include "EvoModel.h"
#include "Except.h"
#include "ITransaction.h"
#include "Likelihood.h"
#include "Locus.h"
#include "Parameter.h"
#include "RatesParameters.h"
#include "RatesPrior.h"
#include "Replicates.h"
#include "StatsFn.h"
#include "Tree.h"
#include "TreeFactory.h"

#ifdef OPENCL
#include "GpuInterface.h"
#endif

// *****************************************************************************
/// Map nodes in the factory to nodes in the replicate

typedef std::unordered_map<const Tree::Node *, Tree::Node *> NODEMAP;

// *****************************************************************************
/// DFS Controlling object for the replication

struct DfsRepl : Tree::Dfs {

    DfsRepl ( const DivTime &    dt,
	      Tree::Root &       newRoot,
	      NODEMAP &          nodeMap,
	      Replicate &        repl )
        : _dt(dt),
	  _newRoot(newRoot),
	  _nodeMap(nodeMap),
	  _repl(repl)
        {
        }

    virtual RC InnerBegin ( const Tree::Position & tPos );
    virtual RC InnerEnd   ( const Tree::Position & tPos );
    virtual RC Leaf       ( const Tree::Position & tPos );
    virtual RC RootBegin  ( Tree::Root & oldRoot );
    virtual RC RootEnd    ( Tree::Root & oldRoot );

private:

    void               CreateNewTreeNode    ( const Tree::TreeNode & oldTreeNode,
                                              Tree::Node *           newNode );

    Tree::LocusNode *  FindNewParent        ( const Tree::LocusNode&       oldLocus ) const;

    void               SetLocusChildren     ( const unsigned               lId,
					      const Tree::LocusNode &      oldLNode,
                                              Tree::LocusNode &            newLNode );

    Tree::Node *       MapCheck             (const Tree::Node *            node) const
        {
            try {
                return _nodeMap.at(node);
            }
            catch ( std::out_of_range ) {
                assert(false && "Old node not found in DfsRepl::MapCheck");
            }
            return nullptr;		          // Stupid microsoft compiler
        }

    const DivTime &    _dt;                       ///< Parent divergence time instance
    Tree::Root &       _newRoot;                  ///< New tree root being created
    NODEMAP &          _nodeMap;                  ///< Map old to new nodes
    Replicate &        _repl;                     ///< Replicate being built

};

// *****************************************************************************

void
DfsRepl::CreateNewTreeNode ( const Tree::TreeNode & oldTNode,
			     Tree::Node *           newNode )
{

    Tree::Node * newParentNode ( MapCheck(oldTNode._parent._node) );
    newNode->_treeVec.emplace_back( oldTNode,
                                    newNode,
                                    _newRoot,
                                    newParentNode,
                                    _repl );
    Tree::TreeNode * newTNode = &newNode->_treeVec.back();

    /// Lookup the new node in the parents list of children adding
    /// to the existing list if found or creating a new child entry if not found.

    bool found = false;
    for ( auto & child : newParentNode->_children )
        if ( child.first == newNode ) {
            child.second.push_back(newTNode->_treeIdx);
            found = true;
            break;
        }
    if ( !found )
        newParentNode->_children.emplace_back(Tree::Node::CHILD(newNode, {newTNode->_treeIdx}));

    /// - Create the node likelihood and age parm if not a leaf

    if ( !newTNode->IsLeaf() ) {
	newTNode->_lkh = Likelihood::Factory(_repl, *newTNode);
	if ( !_repl._commonAges || newNode->_treeVec.size() == 1 ) {
	    newTNode->_ageParm = Ages::Factory(_repl, *newTNode);
	}
	else {
	    newTNode->_ageParm = newNode->_treeVec.front()._ageParm;
	}
    }

    /// - Loop creating the locus blocks

    newTNode->_locusVec.reserve(oldTNode._locusVec.size());
    for ( auto& oldLNode : oldTNode._locusVec ) {

	auto lid = oldLNode._lRoot._locus._id;
        auto & newLocusRoot = _newRoot._locusVec[lid];

        newTNode->_locusVec.emplace_back( oldLNode,
					  newLocusRoot,
					  newTNode );
        auto & newLNode = newTNode->_locusVec.back();

        /// - No more for this locus if not part of the gene tree

        if ( newLNode._missing )
            continue;

        newLNode._parent = FindNewParent(oldLNode);
	if ( !newLNode._parent )
	    newLocusRoot._trueRoot = &newLNode;

        /// - If not the glocal clock mode, add a rate parameter to non-root nodes.
	///   Set the rate parm to either the current nodes or the mean parameter

	if ( _dt._cModel != Options::ClockModel::GLOBAL && newLNode._parent ) {

	    if ( !_repl._commonRates ) {
		newLNode._rateParm      = Rates::Factory(_repl, newLNode);
		newLNode._rateParmToUse = newLNode._rateParm;
	    }
	    else {

		/// - So for the common rates model the question is whether
		///   there is already a rate parameter at this node for this
		///   locus. If not, create one. If so just point to the existing.

		auto it = newNode->_treeVec.begin();
		for ( ; it != newNode->_treeVec.end(); it++ )
		    if ( (*it)._locusVec[lid]._rateParm ) {
			newLNode._rateParmToUse = (*it)._locusVec[lid]._rateParm;
			break;
		    }

		if ( it == newNode->_treeVec.end() ) {
		    newLNode._rateParm      = Rates::Factory(_repl, newLNode);
		    newLNode._rateParmToUse = newLNode._rateParm;
		}

	    }

	}
	else
	    newLNode._rateParmToUse = newLNode._lRoot._ratesMeanParm;

        /// - Create the transition matrix for this tree/locus if not the gene tree root.

	if ( !newLNode.IsRoot() )
	    newLNode._tMatrix = newLNode._lRoot._eModel->MakeTransitionMatrix();

	/// - Create the rates prior functor at this gene tree node.

	newLNode._lnPR = RatesPriorNode::Factory(_repl, newLNode);

	/// - Point to the age parameter in the tree node for root and inner locus nodes only
	////  ( _ageParm will be null in leaves).

	newLNode._ageParmToUse = newTNode->_ageParm;

	/// - For leaves we can create the likelihood instance here since
	///   we don't need to wait for the children to be built.
	if ( newTNode->IsLeaf() )
	    newLNode._lkh = Likelihood::Factory(_repl, newLNode);
	/// - For inner nodes setup the site data pointer
	else
	    newLNode._siteVec = &newNode->_locusSiteVec[lid];

    }

}

// *****************************************************************************

Tree::LocusNode*
DfsRepl::FindNewParent ( const Tree::LocusNode & oldLocus ) const
{

    if ( !oldLocus._parent )
        return nullptr;

    unsigned lId = oldLocus._lRoot._locus._id;

    if ( !oldLocus._parent->_tNode )
        return &_newRoot._locusVec[lId];

    auto  oldLocusNode  = oldLocus._parent;

    auto  oldTreeNode   = oldLocusNode->_tNode;
    auto  oldNode       = oldTreeNode->_node;

    auto  newNode       = MapCheck(oldNode);

    auto& newTreeNode  = newNode->_treeVec[oldTreeNode->_treeIdx];
    return &newTreeNode._locusVec[lId];

}

// *****************************************************************************

Tree::Dfs::RC
DfsRepl::InnerBegin ( const Tree::Position & tPos )
{

    auto oldNode     = tPos._node;

    /// - Find or create the new Tree::Node instance

    auto iter = _nodeMap.find(oldNode);

    Tree::Node * newNode;
    if ( iter == _nodeMap.end() ) {
        newNode = new Tree::Node(*oldNode, _repl);
        _nodeMap[oldNode] = newNode;
    }
    else
        newNode = iter->second;

    /// - Create the new Tree::TreeNode instance and connect to it's parent

    CreateNewTreeNode ( tPos.AsTNode(), newNode );

    return CONTINUE;
}

// *****************************************************************************
/// Do things here that require the existence of both the parent and the children.
/// At this point that's only setting the gene tree children of the current node
/// and creation of the likelihood functors.

Tree::Dfs::RC
DfsRepl::InnerEnd   ( const Tree::Position & tPos )
{
    auto oldNode = tPos._node;
    auto newNode = MapCheck(oldNode);

    auto & oldTNode = tPos.AsTNode();
    auto & newTNode = newNode->_treeVec[tPos._treeIdx];

    /// - Loop completing setup of the gene tree nodes.

    for ( unsigned i = 0; i < oldTNode._locusVec.size(); i++ ) {

	auto & oldLNode = oldTNode._locusVec[i];

        if ( oldLNode._missing )
	    continue;

	auto & newLNode = newTNode._locusVec[i];

	SetLocusChildren(i, oldLNode, newLNode);

	/// - Create the likelihood last as it needs pointers to other stuff.

	newLNode._lkh = Likelihood::Factory(_repl, newLNode);

    }

    return CONTINUE;
}

// *****************************************************************************

Tree::Dfs::RC
DfsRepl::Leaf       ( const Tree::Position & tPos )
{

    auto oldNode     = tPos._node;

    /// - Find or create the new leaf node

    auto iter = _nodeMap.find(oldNode);

    Tree::Node * newNode;
    if ( iter == _nodeMap.end() ) {
        newNode = new Tree::Node(*oldNode, _repl);
        _nodeMap[oldNode] = newNode;
    }
    else
        newNode = iter->second;

    /// - Create the new Tree::TreeNode instance and connect to it's parent

    CreateNewTreeNode ( tPos.AsTNode(), newNode );

    return CONTINUE;
}

// *****************************************************************************
/// Do things here that only depend on the existence of the parent and may be
/// needed by the children.

Tree::Dfs::RC
DfsRepl::RootBegin ( Tree::Root &  oldRoot )
{

    _nodeMap[&oldRoot] = &_newRoot;

    /// @todo Decide on mixing parameter implementation
    // _newRoot._mixParm = MakeParameter<MixingParameter>( _repl,
    //                                                     ParmStats::StatType::OTHER,
    //                                                     std::ref(_newRoot) );

    /// - Create the evolutionary model controller for the species tree root.

    _newRoot._eModel = EvoModelRoot::Factory(_repl, _newRoot);

    /// - Create the likelihood controllers for the species tree root.

    _newRoot._lkh     = Likelihood::Factory(_repl, _newRoot);
    _newRoot._lkhNode = Likelihood::Factory(_repl, Tree::Position(_newRoot));

    /// - Create the species tree age prior here since it needs to exist before
    ///   the node priors are created.

    _newRoot._lnPA = AgePriorRoot::Factory( _repl, _newRoot);

    /// - Create the age parameter and prior.

    _newRoot._ageParm = Ages::Factory(_repl, _newRoot);

    /// - Create the locus blocks

    for ( auto & oldLocusRoot : oldRoot._locusVec ) {

        _newRoot._locusVec.emplace_back( oldLocusRoot,
                                         _newRoot );
        auto&    newLRoot = _newRoot._locusVec.back();

        /// - We create the model and parameters here even if the root
        ///   isn't part of the gene tree for this locus so we can always
        ///   find them.

        /// - Create the evolutionary model controller.

        newLRoot._eModel = _newRoot._eModel->Factory ( newLRoot );

	/// - Create the likelihood instance.

	newLRoot._lkh = Likelihood::Factory(_repl, newLRoot);

	/// - Create the rates prior root and node functors

	newLRoot._rLnPR = RatesPriorRoot::Factory(_repl, newLRoot);

        if ( !newLRoot._missing) {
	    newLRoot._lnPR     = RatesPriorNode::Factory(_repl, newLRoot);
	    newLRoot._siteVec = &_newRoot._locusSiteVec[newLRoot._locus._id];
	}

        /// - Add the mean of the rate, \f$\mu\f$ and set it's initial value.
        ///   This is needed regardless of the clock model.
        ///   It (and the other global parms are always set on the gene
        ///   tree root node corresponding to the species tree root even if
        ///   the node itsels isn't  part of the gene tree.

	newLRoot._ratesMeanParm = Rates::MeanFactory ( _repl, newLRoot);

        /// - Add the hyperparameter to control variation across the rates.
	///   The factory might return null if one isn't required.

	newLRoot._ratesVarParm = Rates::VarianceFactory ( _repl, newLRoot );

	/// - Point to the age parameter in the root

	newLRoot._ageParmToUse = _newRoot._ageParm;

    }

    return CONTINUE;
}

// *****************************************************************************

Tree::Dfs::RC
DfsRepl::RootEnd ( Tree::Root & oldRoot )
{

    /// - Set the children for the gene trees.

    for ( unsigned i = 0; i < oldRoot._locusVec.size(); i++ ) {

	auto& oldLRoot = oldRoot._locusVec[i];

        if ( oldLRoot._missing )
	    continue;

	auto & newLRoot = _newRoot._locusVec[i];

	/// - Setup the children of the root (sounds like a bad scifi movie).

	SetLocusChildren(i, oldLRoot, newLRoot);

        /// - Create the likelihood controller at the gene tree tree

	auto & lNode = newLRoot.AsNode();
	lNode._lkh = Likelihood::Factory(_repl, lNode);

    }

    /// - Complete the evolutionary models.
    _newRoot._eModel->ReplRootEnd();

    /// - Complete the species tree likelihood instance.
    _newRoot._lkh->ReplRootEnd();

    return CONTINUE;
}

// *****************************************************************************

void
DfsRepl::SetLocusChildren ( const unsigned          lId,
			    const Tree::LocusNode & oldLNode,
			    Tree::LocusNode &       newLNode )
{

    for ( auto oldChildLNode : oldLNode._children ) {

        auto oldChildTNode  = oldChildLNode->_tNode;
        auto oldChildNode   = oldChildTNode->_node;

        auto newChildNode   = MapCheck(oldChildNode);

        auto& newChildTNode = newChildNode->_treeVec[oldChildTNode->_treeIdx];
        auto& newChildLNode = newChildTNode._locusVec[lId];

        newLNode._children.push_back(&newChildLNode);

	newChildLNode._isLeftChild = newLNode._children.size() == 1;

    }

}

// *****************************************************************************

Replicate::Replicate( const unsigned id,
		      unsigned &     nodeId,
		      unsigned &     parmId,
                      DivTime &      dt,
                      ParmStats &    stats,
                      Logger &       logger,
		      GpuInterface * gpuIntf )
    : _dt(dt),
      _logger(logger),
      _stats(stats),
      _id(id),
      _gpuRepl(nullptr),
      _cModel(dt._cModel),
      _ageAccepted(0),
      _rateAccepted(0),
      _nuisanceAccepted(0),
      _ageRejected(0),
      _rateRejected(0),
      _nuisanceRejected(0),
      _statsObj(new StatsObj(dt._randomGen())),
      _nodeId(nodeId),
      _parmId(parmId),
      _calProb(id == 0 ? 1.0 : dt._jackPct / 100.0 ),
      _commonRates(dt._mtModel != Options::MultiTreeModel::INDEPENDENT),
      _commonAges(dt._mtModel == Options::MultiTreeModel::COMMONBOTH)
{
    LOGENTER(_logger, _id, Dump::ptr(this, "repl"));

    NODEMAP nodeMap;

    /// - Setup the bit vector of included calibrations.
    _calsIncluded.resize(dt._calOptList.size(), false);

    /// - Create the thread level Gpu object

#ifdef OPENCL
    if ( gpuIntf )
	_gpuRepl = GpuReplicate::Factory(*this, gpuIntf);
#endif

    /// - Loop through the roots in the DAG

    reserve(dt._treeFactory->size());
    for ( auto& root : *dt._treeFactory ) {

        /// - Create the new root

        emplace_back( root, *this );
	auto & newRoot ( back() );

        /// - Traverse the dag, replicating the tree

        DfsRepl dfs( dt, newRoot, nodeMap, *this );
        dfs(root);

	/// - Create the trace info blocks for the posterior, likelihihood and priors.

	AddTraceBlocks(newRoot);

	/// - Sort the trace info blocks

	newRoot._traceList.sort([] ( const Tree::TraceInfo * a,
				     const Tree::TraceInfo * b )
				 {
				     return a->_key < b->_key;
				 });

    }

    /// - Reserve space in the transaction logs based on the number of nodes
    ///  in a tree. Hopefully this will eliminate the need to reallocate the vectors .

    _commitLog.reserve( dt._taxaVec.size() * 2 );
    _rollbackLog.reserve( dt._taxaVec.size() * 2 );

    LOGEXIT(_logger, _id, Dump::ptr(this, "repl"));
}

// *****************************************************************************

Replicate::~Replicate()
{
    delete _statsObj;
#ifdef OPENCL
    delete _gpuRepl;
#endif
}

// *****************************************************************************

void
Replicate::AddTraceBlocks( Tree::Root & root )
{

    root._traceList.push_back ( new Tree::TraceInfo( root,
						     nullptr,
						     Tree::TraceType::Posterior,
						     [] ( Tree::TraceInfo * ti )
						         {
							     return (*ti->_root._lkh)() +
								    (*ti->_root._lnPA)() +
								    ti->_root._lnPR +
								    ti->_root._lnPN;
							 },
						     -1, -1, 0,
						     "Posterior", "Posterior" ) );

    root._traceList.push_back ( new Tree::TraceInfo( root,
						     nullptr,
						     Tree::TraceType::Likelihood,
						     [] ( Tree::TraceInfo * ti )
						         {
							     return (*ti->_root._lkh)();
							 },
						     -1, -1, 0,
						     "Likelihood", "Likelihood" ) );

    root._traceList.push_back ( new Tree::TraceInfo( root,
						     nullptr,
						     Tree::TraceType::AgePrior,
						     [] ( Tree::TraceInfo * ti )
						         {
							     return (*ti->_root._lnPA)();
							 },
						     -1, -1, 0,
						     "Prior", "Prior_Ages" ) );

    root._traceList.push_back ( new Tree::TraceInfo( root,
						     nullptr,
						     Tree::TraceType::RatePrior,
						     [] ( Tree::TraceInfo * ti )
						         {
							     return ti->_root._lnPR;
							 },
						     -1, -1, 0,
						     "Prior", "Prior_Rates" ) );

    root._traceList.push_back ( new Tree::TraceInfo( root,
						     nullptr,
						     Tree::TraceType::NuisancePrior,
						     [] ( Tree::TraceInfo * ti )
						         {
							     return ti->_root._lnPN;
							 },
						     -1, -1, 0,
						     "Prior", "Prior_Nuisance" ) );

}

// *****************************************************************************

void
Replicate::DoCommit ()
{
    std::for_each ( _commitLog.begin(),
                    _commitLog.end(),
                    [] (ITransaction * obj) { obj->Commit(); } );
    _commitLog.clear();

}

// *****************************************************************************

void
Replicate::DoRollback ()
{
    std::for_each ( _rollbackLog.begin(),
                    _rollbackLog.end(),
                    [] (ITransaction * obj) { obj->Rollback(); } );
    _rollbackLog.clear();
}

// *****************************************************************************
/// This really is a wrapper aroung the standard Tree::Dfs object.
/// The Tree::Dfs methods are proxied by the ReplicateDfs methods.

void
ReplicateDfs::operator()( Replicate & repl )
{
    typedef std::unordered_set<Tree::Node *> NODESET;

    struct TreeDfs : Tree::Dfs {

	TreeDfs( NODESET & visitedNodes,
		 ReplicateDfs & replDfs )
	    : _visitedNodes(visitedNodes),
	      _replDfs(replDfs)
	    {}

	RC InnerBegin ( const Tree::Position & tPos )
	    {
		if ( !_visitedNodes.insert(tPos._node).second )
		    return STOPDOWN;
		return (RC)_replDfs.InnerBegin(tPos);
	    }

	RC InnerEnd ( const Tree::Position & tPos )
	    {
		return (RC)_replDfs.InnerEnd(tPos);
	    }

	RC Leaf ( const Tree::Position & tPos )
	    {
		if ( !_visitedNodes.insert(tPos._node).second )
		    return STOPDOWN;
		return (RC)_replDfs.Leaf(tPos);
	    }

	RC RootBegin ( Tree::Root & root )
	    {
		return (RC)_replDfs.RootBegin(root);
	    }

	RC RootEnd ( Tree::Root & root )
	    {
		return (RC)_replDfs.RootEnd(root);
	    }


	NODESET      & _visitedNodes;
	ReplicateDfs & _replDfs;

    };

    NODESET visitedNodes;
    TreeDfs dfs(visitedNodes, *this);
    for ( auto & root : repl )
        dfs(root);

}

// *****************************************************************************

ReplicateVec::ReplicateVec( DivTime &      dt,
			    GpuInterface * gpuIntf)
    : _dt(dt),
      _logger(*dt._logger),
      _stats(new ParmStats(*dt._logger))
{

    LOGENTER(_logger, 0, Dump::ptr(this,"this"), Dump::str(dt._nRepl, "dt._nRepl"));

    /// - Counter used to generate unique node id's for all non-leaf nodes
    unsigned nodeId = 0;

    /// - Counter used to generate unique parameter id's for all parameters
    unsigned parmId = 0;

    /// - Loop creating the replicates

    reserve(dt._nRepl);
    for ( unsigned repl = 0; repl < dt._nRepl; repl++ )
        try {
            emplace_back(repl, nodeId, parmId, dt, *_stats, _logger, gpuIntf);
        }
#ifdef OPENCL
	catch (Except::GpuError e) {
	    _logger("%s", e.what());
	    throw;
	}
#endif
        catch (std::exception e) {
            assert(0 && "Unable to create replicate");
        }

    LOGEXIT(_logger, 0, Dump::ptr(this,"this"));
}

// *****************************************************************************

ReplicateVec::~ReplicateVec()
{
//    _stats->Log();
    delete _stats;
}
