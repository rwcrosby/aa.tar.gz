/// @file HashStats.h
/// DAG hash table statistics object definition

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _HASHSTATS_H_
#define _HASHSTATS_H_

#include <list>

#include "LogStats.h"

namespace Dag {
    struct VertexInit;
}

// *****************************************************************************
/// Dag Hash Table Statistics Structure

struct HashStats : public LogStats {

    // Counters for performance information
    unsigned  _hits;			          ///< Found in hash
    unsigned  _misses;			          ///< Not found in hash
    unsigned  _nSlots;			          ///< Slots in table
    unsigned  _slotsUsed;		          ///< Slots in use
    unsigned  _longestChain;		          ///< Longest slot chain
    unsigned  _keys;			          ///< Number of unique keys
    UINTVEC   _slotUsage;		          ///< Slot use by length

    STATSLIST _statsList;			  ///< Dag Statistics

    HashStats(Logger &    log)                    ///< Logger instance pointer
        : LogStats(log, "Tree Factory Hash Table Statistics"),
          _hits(0),
          _misses(0),
          _nSlots(0),
          _slotsUsed(0),
          _longestChain(0),
          _keys(0),
          _slotUsage(11, 0)
        {
        }

    virtual void Log()
        {
            STATSLIST statsList {
                STATSITEM ("Hash Hits",     &_hits),
                STATSITEM ("Hash Misses",   &_misses),
                STATSITEM ("Longest Chain", &_longestChain),
                STATSITEM ("Unique Keys",   &_keys),
                STATSITEM ("Total Slots",   &_nSlots),
                STATSITEM ("Slots Used",    &_slotsUsed),
                STATSITEM ("Empty Slots",   &_slotUsage[0])
            };

            for ( unsigned i = 1; i < 10; i++ ) {
                std::stringstream ss;
                ss << "Slots with " << i << " keys";
                statsList.emplace_back(STATSITEM (ss.str(), &_slotUsage[i]));
            }

            statsList.emplace_back(STATSITEM ("Slots with >= 10 keys", &_slotUsage[10]));

            _DoLogging(statsList);
        }

};

#endif // _HASHSTATS_H_
