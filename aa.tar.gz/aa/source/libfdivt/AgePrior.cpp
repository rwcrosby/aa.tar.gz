/// @file AgePrior.cpp
/// Definitions for the prior of ages methods.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include <iostream>

#define _USE_MATH_DEFINES

#include "AgePrior.h"
#include "Calibration.h"
#include "DivTime.h"
#include "Dump.h"
#include "MBUtils.h"
#include "Parameter.h"
#include "Replicates.h"
#include "Tree.h"

struct CondDensity;
struct CondDensityFn;
struct PriorNodeCal;
struct PriorNodeNoCal;
struct PriorNode;
struct PriorRoot;

// *****************************************************************************
/// Type of the PDF returning function

typedef FLOAT (*PDFFN) (FLOAT             age,
			const PriorRoot & pRoot );

// *****************************************************************************
/// Subclass of the prior at a tree node defining the tree position.
/// The only reason this exists is to eliminate the need to include Tree.h
/// in the AgePrior.h header by pulling the Tree::Position element here.

struct PriorNode : AgePriorNode {

    /// Constructor used only for delegation from the "real" constructors.
    PriorNode ( Replicate &          repl,
		const Tree::Position tPos,
		Parameter &          ageParm );

    /// Return the node cast as a calibration node.
    PriorNodeCal *
    AsCalNode();

    /// Return the node case as a non-calibratio node.
    PriorNodeNoCal *
    AsNoCalNode();

    /// Return if this is calibration node.
    bool
    IsCalNode() const
	{
	    return _tPos.GetCalList().size();
	}

    /// Recalculate with a new root age at the node.
    virtual
    void
    NewRootAge() = 0;

    /// Return true if current node is younger than node passed.
    bool
    operator< (const PriorNode & b) const
	{
	    return _ageParm() < b._ageParm();
	}

    /// Rollback the superclass restoring the saved ageVec entries
    virtual
    void
    Rollback();

    /// Save common fields for the rior at a node.
    virtual
    void
    Save()
	{
	    Prior::Save();
	}

    virtual
    std::string
    str()
	const
	{
	    std::stringstream ss;
	    ss << Prior::str() << ' '
	       << Dump::str(_ageParm, "ageParm") << ' '
	       << Dump::str(_avIdx, "avIdx");
	    return ss.str();
	}

    const Tree::Position _tPos;		          ///< Owning species tree node
    PriorRoot *          _pRoot;		  ///< Owning species tree prior
    Parameter &          _ageParm;		  ///< Node age

    int                  _avIdx;		  ///< This nodes position in the root ageVec
};

// *****************************************************************************
/// Subclass for a node with calibrations.
/// The sum of the prior densities of the calibration nodes \f$g(t)\f$
/// is saved in the _value field in the Prior superclass.

struct PriorNodeCal : PriorNode {

    /// Constructor setting up the computational functions.
    PriorNodeCal ( Replicate &          repl,
		   const Tree::Position tPos,
		   Parameter &          ageParm );

    virtual
    void
    NewAge();

    virtual
    void
    NewRootAge();

    virtual
    void
    Rollback();

    virtual
    void
    Save()
	{
	    PriorNode::Save();
	    _oldCdf    = _cdf;
	    _oldCdvIdx = _cdvIdx;
	}

    virtual
    std::string
    str()
	const
	{
	    std::stringstream ss;
	    ss << PriorNode::str() << ' '
	       << Dump::str(_cdf, _oldCdf, "cdf") << ' '
	       << Dump::str(_cdvIdx, _oldCdvIdx, "cdvIdx");
	    return ss.str();
	}

    /// Pointer to either the root or inner pdf function
    /// @return Log of the pdf (\f$g(t)\f$).
    FLOAT (*_lnPdfFn)( FLOAT                  age,
		       const Tree::Position & tPos );

    /// Pointer to either the \f$\lambda=\mu\f$ or \f$\lambda \ne \mu\f$ cdf function
    /// @return Cdf (\f$G(t)\f$) - Not the log of the cdf
    FLOAT (*_cdfFn)( FLOAT             age,
		     const PriorRoot & pr );

    /// ln(CDF) for the calibration node $G$ in Rannala and Yang 06.
    FLOAT    _cdf;
    FLOAT    _oldCdf;

    /// Index into the conditional density vector
    unsigned _cdvIdx;
    unsigned _oldCdvIdx;

};

// *****************************************************************************
/// Subclass for a node without calibrations.
/// The prior density for this non-calibration node $g$ in Rannala and Yang 07
/// is kept as the value in the Prior superclass.

struct PriorNodeNoCal : PriorNode {

    /// Constructor setting up the computational functions.
    PriorNodeNoCal ( Replicate &          repl,
		     const Tree::Position tPos,
		     Parameter &          ageParm )
	: PriorNode(repl, tPos, ageParm),
	  _lnPdfFn(GetPdfFn(*_pRoot))
		 {}

    /// Return the pdf function for this node.
    static
    PDFFN
    GetPdfFn ( const PriorRoot & _pRoot );

    virtual
    void
    NewAge();

    virtual
    void
    NewRootAge();

    /// Pointer to either the \f$\lambda=\mu\f$ or \f$\lambda \ne \mu\f$ pdf function
    /// @return Log of the pdf (\f$g(t)\f$)
    FLOAT (*_lnPdfFn)( FLOAT            age,
		       const PriorRoot & pr );

};

// *****************************************************************************
/// Subclass for the prior at the root of the species tree

struct PriorNodeRoot : PriorNode {

    PriorNodeRoot( Replicate &          repl,
		   const Tree::Position tPos,
		   Parameter &          ageParm)
	: PriorNode(repl, tPos, ageParm)
	{}

    virtual
    void
    NewAge();

    virtual
    void
    NewRootAge()
	{
	    assert(0 && "NewRootAge on root called");
	};

};

// *****************************************************************************
/// Subclass of the prior at a species tree root.
/// Implemeted here to eliminate requiement for additional headers in AgePrior.h
/// Value of the instance is the log of the prior of ages for the species tree.

struct PriorRoot : AgePriorRoot {

    PriorRoot( Replicate &  repl,
	       Tree::Root & root );

    /// Compute the value of the constants.
    /// @param age Root age to use.
    void
    ComputeConstants( FLOAT age );

    /// Compute the prior for a species tree assuming no saved values.
    /// Intended for setting the initial values on the tree.
    virtual
    void
    InitialValues ();

    /// Compute the prior for the species tree when the root age changes.
    virtual
    void
    NewAge ();

    /// For a given index in the conditional density vector,
    /// recompute the f(i) and G'(i) values and update the
    /// overall prior value.
    void
    RecomputeCDEntry(const unsigned i);

    /// Rollback the changes.
    virtual
    void
    Rollback();

    /// Save values specific to this class and it's bases.
    void
    Save();

    Tree::Root &               _root;	          ///< Owning species tree

    const FLOAT                _lambda;	          ///< Birth death process parameter
    const FLOAT                _mu;               ///< Birth death process parameter
    const FLOAT                _rho;              ///< Birth death process parameter

    typedef std::vector<PriorNode *> AGEVEC;      ///< A vector of node priors
    AGEVEC                     _ageVec;           ///< All root and inner nodes sorted by age
    AGEVEC                     _oldAgeVec;	  ///< Saved for rollback

    /// Entry in the ageVec save stack.
    typedef std::pair<unsigned, PriorNode *> OldAgePair;

    /// Type of the ageVec save stack.
    typedef std::vector<OldAgePair>          OldAgePVec;

    OldAgePVec                 _oldAgePVec;       ///< Stack of changed age entries

    /// The number of nodes with calibrations not including any calibrations at the root.
    unsigned                   _nCalNodes;

    std::vector<CondDensity>   _cdVec;	          ///< Conditional density records
    std::vector<CondDensity>   _oldCdVec;         ///< Saved for rollback
    std::vector<CondDensityFn> _cdFnVec;	  ///< Conditional density function entries

    /// Entry in the conditional density save stack.
    typedef std::pair<unsigned, CondDensity> OldCdPair;

    /// Type of the conditional density save stack.
    typedef std::vector<OldCdPair>           OldCdPVec;

    OldCdPVec                  _oldCdPVec;        ///< Stack of changed conditional density entries

    /// Function to compute the log of the pdf at the root
    PDFFN                      _lnPdfFn;

    /// Pdf log value at the root
    FLOAT                      _rootLnPdf;
    FLOAT                      _oldRootLnPdf;

    /// Sum of the logs of the calibration node PDF values.
    /// \f$f(\mathbf{t}_C)\f$
    FLOAT                      _lnCNodes;
    FLOAT                      _oldLnCNodes;

    // Constants used in the calculations.
    // Some of the constants depend on the current root age and some are
    // truly constant for the entire run.

    /// \f$c_1 = \rho \lambda\f$
    const FLOAT                _c1;

    /// \f$c_2 = 1 + \rho \lambda t_{root}\f$
    FLOAT                      _c2;
    FLOAT                      _oldC2;

    /// \f$c_3 = \mu - \lambda\f$
    const FLOAT                _c3;
    const FLOAT                _c3Rho;

    /// \f$c_4 = \lambda(1-\rho) - \mu\f$
    const FLOAT                _c4;

    /// \f$c_5 = \log \frac{\lambda}{\rho} - \log v_{t_1} - 2 \log((\mu - \lambda) \rho)\f$
    FLOAT                      _c5;
    FLOAT                      _oldC5;
    const FLOAT                _c5c1;

    /// \f$c_6 = \log (\rho \lambda) - \log v_{t_1}\f$
    FLOAT                      _c6;
    FLOAT                      _oldC6;

    /// \f$c_7 = \frac{1 + \rho \lambda t_{root}}{t_{root}}\f$
    FLOAT                      _c7;
    FLOAT                       _oldC7;

};

// *****************************************************************************
/// Conditional Density Entry

struct CondDensity {

    /// Constructor setting the function pointers to compute the log f(t) and log G'(t) values.
    CondDensity()
	: _pNode(nullptr),
	  _lnF(0.0),
	  _lnGp(0.0),
	  _fnv(nullptr)
	{}

    /// Points to the calibration node that actually appears between this node and
    /// the one older than it.
    PriorNodeCal *  _pNode;

    /// log f(t) value (rank factorial)
    FLOAT          _lnF;

    /// log G'(t) value (mass between calibrations)
    FLOAT          _lnGp;

    /// Pointer to the function vector entry
    CondDensityFn * _fnv;

};

// *****************************************************************************
/// Conditional density function vector entry.
/// This is a parallel vector to the conditional density entires
/// for just the static function pointers.

struct CondDensityFn
{

    /// Simple base class for the computation classes.
    struct Fn {

	virtual FLOAT operator()() = 0;

	/// The compiler whines if there isn't a destructor defined
	virtual ~Fn()
	    {}

    };

    /// Functor to return a constant 1 as the factorial in the case of no calibrations other
    /// than the root.
    struct fFn_rootonly : Fn {

	virtual FLOAT operator()()
	    {
		return 1.0;
	    }

    };

    /// Functor to return a constant 1 as the  G'(i) in the case of no calibrations other
    /// than the root.
    struct GpFn_rootonly : Fn {

	virtual FLOAT operator()()
	    {
		return 1.0;
	    }

    };

    /// Functor to compute f(i) at the first conditional density position
    struct fFn_0 : Fn {

	fFn_0 ( const CondDensity & cd )
	    : _cd(cd)
	    {}

	/// Since the avIdx is zero relative, we don't need to subtract one from it here to
	/// get the number of non-cal nodes preceeding the first cal node.
	virtual FLOAT operator()()
	    {
		return lgamma(_cd._pNode->_avIdx);
	    }

	const CondDensity & _cd;

    };

    /// Functor to compute G'(i) at the first conditional density position
    struct GpFn_0 : Fn {

	GpFn_0 ( const CondDensity & cd )
	    : _cd(cd)
	    {}

	/// Since the avIdx is zero relative, we don't need to subtract one from it here to
	/// get the number of non-cal nodes preceeding the first cal node.
	virtual FLOAT operator()()
	    {
		auto  pNode = _cd._pNode;
		return pNode->_avIdx * log(pNode->_cdf);
	    }

	const CondDensity & _cd;

    };

    /// Functor to compute f(i) at a middle conditional density position
    struct fFn_i : Fn {

	fFn_i ( const CondDensity & cd,
		const CondDensity & cd_1)
	    : _cd(cd),
	      _cd_1(cd_1)
	    {}

	/// LnGamma is undefined at zero so return 0! as 1.
	virtual FLOAT operator()()
	    {
		auto diff = _cd._pNode->_avIdx - _cd_1._pNode->_avIdx - 1;
		return diff ? lgamma(FLOAT(diff)) : 0.0;
	    }

	const CondDensity & _cd;
	const CondDensity & _cd_1;

    };

    /// Functor to compute G'(i) at a middle conditional density position
    struct GpFn_i : Fn {

	GpFn_i ( const CondDensity & cd,
		 const CondDensity & cd_1)
	    : _cd(cd),
	      _cd_1(cd_1)
	    {}

	virtual FLOAT operator()()
	    {
		auto  pNode   = _cd._pNode;
		auto  pNode_1 = _cd_1._pNode;
		return ( pNode->_avIdx - pNode_1->_avIdx - 1 ) *
		       log( pNode->_cdf - pNode_1->_cdf );
	    }

	const CondDensity & _cd;
	const CondDensity & _cd_1;
    };

    /// Functor to compute f(i) at the last conditional density position
    struct fFn_c : Fn {

	fFn_c ( const unsigned      nNodes,
		const CondDensity & cd_1 )
	    : _nNodes(nNodes),
	      _cd_1(cd_1)
	    {}

	virtual FLOAT operator()()
	    {
		return lgamma(_nNodes - _cd_1._pNode->_avIdx);
	    }

	const unsigned      _nNodes;
	const CondDensity & _cd_1;
    };

    /// Functor to compute G'(i) at the last conditional density position
    struct GpFn_c : Fn {

	GpFn_c ( const unsigned      nNodes,
		 const CondDensity & cd_1 )
	    : _nNodes(nNodes),
	      _cd_1(cd_1)
	    {}

	virtual FLOAT operator()()
	    {
		auto  pNode_1 = _cd_1._pNode;
		return (_nNodes - pNode_1->_avIdx - 1 ) *
		       log(1.0 - pNode_1->_cdf);
	    }

	const unsigned      _nNodes;
	const CondDensity & _cd_1;
    };

    CondDensityFn( const PriorRoot * root,
		   const unsigned    myIdx )
	: _idx(myIdx)
	{
	    if ( root->_nCalNodes == 0 ) {	  ///< Root only
		_fFn  = new fFn_rootonly  ();
		_GpFn = new GpFn_rootonly ();
	    }
	    else if ( myIdx == 0 ) {			  ///< First entry
		_fFn  = new fFn_0  ( root->_cdVec[myIdx] );
		_GpFn = new GpFn_0 ( root->_cdVec[myIdx] );
	    }
	    else if ( myIdx < root->_nCalNodes ) { ///< Middle entry
		_fFn  = new fFn_i  ( root->_cdVec[myIdx], root->_cdVec[myIdx-1] );
		_GpFn = new GpFn_i ( root->_cdVec[myIdx], root->_cdVec[myIdx-1] );
	    }
	    else {				  ///< Last entry
		_fFn  = new fFn_c  ( root->_ageVec.size(), root->_cdVec[myIdx-1] );
		_GpFn = new GpFn_c ( root->_ageVec.size(), root->_cdVec[myIdx-1] );
	    }
	}

    virtual
    std::string
    str()
	const
	{
	    std::stringstream ss;
	    ss << '<'
	       << Dump::str(_idx, "idx") << ' '
	       << Dump::str(typeid(*_fFn).name()) << ' '
	       << Dump::str(typeid(*_GpFn).name());
	    return ss.str();
	}

    /// Save the index for debugging
    const unsigned _idx;

    /// Functor to compute the log f(t) value.
    Fn *           _fFn;

    /// Functor to compute the log G'(t) value.
    Fn *           _GpFn;

};
// *****************************************************************************

AgePriorNode *
AgePriorNode::Factory( Replicate &            repl,
		       const Tree::Position & tPos,
		       Parameter &            ageParm )
{

    AgePriorNode * prior;

    if ( tPos.IsRoot() )
	prior = new PriorNodeRoot(repl, tPos, ageParm);
    else if ( tPos.GetCalList().size() )
	prior = new PriorNodeCal( repl, tPos, ageParm );
    else
	prior = new PriorNodeNoCal( repl, tPos, ageParm );

    return prior;
}

// *****************************************************************************

AgePriorRoot *
AgePriorRoot::Factory( Replicate &  repl,
		       Tree::Root & root )
{
    return new PriorRoot(repl, root);
}

// *****************************************************************************

namespace Dump {

    template<>
    std::string
    str( const CondDensity & v,
	 const std::string   hdg )
    {
	std::stringstream ss;
	ss << hdg << '<'
	   << Dump::str( v._lnF ,"lnF" ) << ' '
	   << Dump::str( v._lnGp ,"lnGp" ) << ' '
	   << Dump::pstr( v._fnv, "fnv" ) << '>';
	return ss.str();

    }


// *****************************************************************************

    template<>
    std::string
    str( const PriorRoot::AGEVEC & v,
	 const std::string         hdg )
    {
	std::stringstream ss;
	ss << hdg << '<';
	for ( auto it = v.begin(); it != v.end(); it++ ) {
	    if ( it != v.begin() )
		ss << ',';
	    ss << (*it) << '/' << (*it)->_ageParm();
	}
	ss << '>';
	return ss.str();

    }

// *****************************************************************************

    template<>
    std::string
    str( const PriorNodeNoCal & pn,
	 const std::string      hdg )
    {
	std::stringstream ss;
	ss << hdg << '<' << pn.str() << '>';
	return ss.str();
    }

// *****************************************************************************

    template<>
    std::string
    str( const PriorNodeCal & pnc,
	       const std::string    hdg )
    {
	std::stringstream ss;
	ss << hdg << '<' << pnc.str() << '>';
	return ss.str();
    }

}

// *****************************************************************************
/// Dump routine for the prior root.

template<>
std::string
Dump::str ( const PriorRoot & pr,
	    const std::string hdg )
{
    return hdg + pr.str();
}

// *****************************************************************************
/// Will not be called for the root.

PriorNode::PriorNode ( Replicate &          repl,
		       const Tree::Position tPos,
		       Parameter &          ageParm )
    : AgePriorNode(repl),
      _tPos(std::move(tPos)),
      _pRoot(tPos.IsRoot()
	     ? static_cast<PriorRoot*>(tPos.AsRoot()._lnPA)
	     : static_cast<PriorRoot*>(tPos.AsTNode()._root._lnPA)),
      _ageParm(ageParm)
{
    REPRDEBUG(Dump::str(tPos,"tPos"),
	      Dump::ptr(&ageParm,"ageParm"));
    if ( !tPos.IsRoot() ) {
	_pRoot->_ageVec.push_back(this);
	_avIdx = _pRoot->_ageVec.size() - 1;
    }
}

// *****************************************************************************
/// Restore the state rolling back the saved conditional density entries.

void
PriorNode::Rollback()
{
    Prior::Rollback();
    for ( auto & p : _pRoot->_oldAgePVec ) {
	p.second->_avIdx         = p.first;
	_pRoot->_ageVec[p.first] = p.second;
    }
}

// *****************************************************************************

PriorNodeCal::PriorNodeCal ( Replicate &          repl,
			     const Tree::Position tPos,
			     Parameter &          ageParm )
    : PriorNode(repl, tPos, ageParm),
      _cdf(0.0),
      _oldCdf(0.0)
{
    REPRENTER( Dump::str( tPos ,"tPos" ),
	       Dump::ptr( &ageParm ,"ageParm" ));

    /// -  If \f$\lambda=\mu\f$ (or close enough) use the simpler cdf routine

    if ( MrBayes::IsZero(_pRoot->_lambda - _pRoot->_mu) ) {

	/// - Compute CDF ($G(t)$ in Rannala and Yang 06) for the \f$\lambda=\mu\f$ case.
	///   \f$G(t|\lambda = \mu) = c_7  \frac{t}{1 + c_1 t}\f$

	_cdfFn = []  ( FLOAT             age,
		       const PriorRoot & pr) -> FLOAT
	    {
		return pr._c7 * age  / (1.0 + pr._c1 * age);
	    };
	REPRDEBUG( Dump::ptr( &_cdfFn, "Simple cdf fn" ));
    }
    else {

	/// - Compute CDF ($G(t)$ in Rannala and Yang 06) for the \f$\lambda\ne\mu\f$ case.
	///   \f$G(t|\lambda \ne \mu) = c_6  \frac{1 + \mathrm{e}^{c_3t}}{c_1 + c_4 \mathrm{e}^{c_3t}}\f$

	_cdfFn = [] ( FLOAT            age,
		      const PriorRoot & pr) -> FLOAT
	    {
		const FLOAT te = exp(pr._c3 * age);
		return pr._c6 *  (1.0 + te) / (pr._c1 + pr._c4 * te);
	    };
	REPRDEBUG( Dump::ptr( &_cdfFn, "Complex cdf fn" ));
    }

    /// Compute the prior density for an inner node for use in \f$f(\mathbf{t}_C)\f$.
    _lnPdfFn = [] ( FLOAT                  age,
		    const Tree::Position & tPos ) -> FLOAT
	{
	    FLOAT pdf = 0.0;
	    for ( auto cal : tPos.AsTNode()._calList )
		pdf += (*cal)(age);
	    return pdf;
	};

    _pRoot->_nCalNodes++;
    REPREXIT( Dump::str( tPos ,"tPos" ),
	      Dump::str( _pRoot->_nCalNodes ,"nCalNodes" ));
}

// *****************************************************************************

inline
PriorNodeCal *
PriorNode::AsCalNode()
{
    return static_cast<PriorNodeCal*>(this);
}

// *****************************************************************************

inline
PriorNodeNoCal *
PriorNode::AsNoCalNode()
{
    return static_cast<PriorNodeNoCal*>(this);
}

// *****************************************************************************

void
PriorNodeCal::NewAge()
{
    REPRENTER(_tPos.str("tPos"),
	      Dump::str( _value ,"value" ));

    /// - Setup for rollback.

    _repl.LogRollback(this);
    Save();
    _pRoot->_oldValue  = _pRoot->_value;

    /// - Clear the age and conditional density save vectors so we can stack
    ///   changes into them.

    _pRoot->_oldAgePVec.clear();
    _pRoot->_oldAgePVec.push_back(std::make_pair(_avIdx, this));

    _pRoot->_oldCdPVec.clear();
    _pRoot->_oldCdPVec.push_back(std::make_pair(_cdvIdx,     _pRoot->_cdVec[_cdvIdx]));
    _pRoot->_oldCdPVec.push_back(std::make_pair(_cdvIdx + 1, _pRoot->_cdVec[_cdvIdx + 1]));

    /// - Compute new sum of the logs of the pdfs for the calibrations at
    /// this node and update into the overall prior.

    _value = _lnPdfFn(_ageParm(), _tPos);
    REPRDEBUG( Dump::str( _value ,"lnPdf" ) );

    _pRoot->UpdatePrior(PriorRatio());

    /// - Compute the \f$G(t)\f$ cdf value for the node.

    _cdf = _cdfFn(_ageParm(), *_pRoot);
    REPRDEBUG( Dump::str( _cdf ,"cdf" ));

    /// - Work out the change in conditional density for the calibration nodes.

    auto earliest =  _cdvIdx;
    auto latest   =  _cdvIdx;

    assert (_cdvIdx < _pRoot->_cdVec.size());

    /// - Look for downward movements in the age list.

    while (_avIdx > 0 &&
	   _ageParm() < _pRoot->_ageVec[_avIdx - 1]->_ageParm()  ) {

	auto pNode = _pRoot->_ageVec[_avIdx - 1];

	/// - Swap entires in the age vector.
	_pRoot->_oldAgePVec.push_back(std::make_pair(_avIdx - 1, pNode));
	_pRoot->_ageVec[_avIdx]     = pNode;
	_pRoot->_ageVec[_avIdx - 1] = this;
	_avIdx--;
	pNode->_avIdx++;

	/// - If we moved before another calibration node, update conditional density vector.
	if ( pNode->IsCalNode() ) {
	    auto calPNode = pNode->AsCalNode();
	    latest = calPNode->_cdvIdx;

	    _pRoot->_oldCdPVec.push_back(std::make_pair(calPNode->_cdvIdx, _pRoot->_cdVec[calPNode->_cdvIdx]));
	    _pRoot->_cdVec[_cdvIdx]._pNode           = calPNode;
	    _pRoot->_cdVec[calPNode->_cdvIdx]._pNode = this;
	    _cdvIdx--;
	    calPNode->_cdvIdx++;
	    assert (_cdvIdx < _pRoot->_cdVec.size());
	}

    }

    /// - Look for upward movements in the age list.

    while (unsigned(_avIdx) < _pRoot->_ageVec.size() - 1 &&
	   _ageParm() > _pRoot->_ageVec[_avIdx + 1]->_ageParm() ) {

	auto pNode = _pRoot->_ageVec[_avIdx + 1];

	/// - Swap entires in the age vector.
	_pRoot->_oldAgePVec.push_back(std::make_pair(_avIdx + 1, pNode));
	_pRoot->_ageVec[_avIdx]     = pNode;
	_pRoot->_ageVec[_avIdx + 1] = this;
	_avIdx++;
	pNode->_avIdx--;

	/// - If we moved after another calibration node, update conditional density vector.
	if ( pNode->IsCalNode() ) {
	    auto calPNode = pNode->AsCalNode();
	    earliest = calPNode->_cdvIdx;

	    _pRoot->_oldCdPVec.push_back(std::make_pair(calPNode->_cdvIdx, _pRoot->_cdVec[calPNode->_cdvIdx]));
	    _pRoot->_cdVec[_cdvIdx]._pNode          = calPNode;
	    _pRoot->_cdVec[calPNode->_cdvIdx]._pNode = this;
	    // std::cout << "Up before " << this << " " << _cdvIdx <<  " " << calPNode->_cdvIdx << '\n';
	    _cdvIdx++;
	    calPNode->_cdvIdx--;
	    assert (calPNode->_cdvIdx < _pRoot->_cdVec.size());
	}

    }

    /// - If we didn't save anything other than the current node in the age save vector,
    ///   just update the conditional density nodes around this one

    if ( _pRoot->_oldAgePVec.size() > 1 ) {
	_pRoot->RecomputeCDEntry(_cdvIdx);
	_pRoot->RecomputeCDEntry(_cdvIdx+1);
    }

    /// - If the rank did change update from earliest to latest.

    else {
	for ( ; earliest <= latest; earliest++ )
	    _pRoot->RecomputeCDEntry(earliest);
    }

    REPREXIT(Dump::str(_value, "value"));
}

// *****************************************************************************

void
PriorNodeCal::NewRootAge()
{
    /// - Setup for rollback.

    _repl.LogRollback(this);
    Save();

    /// - Compute new sum of the logs of the pdfs for the calibrations at
    ///   this node and update into the overall prior.

    _value = _lnPdfFn(_ageParm(), _tPos);
    _pRoot->UpdatePrior(PriorRatio());

    /// - Compute the \f$G(t)\f$ cdf value for the node.

     _cdf = _cdfFn(_ageParm(), *_pRoot);

     /// - Recompute the f(i) G'(i) values for the entries on either side of this
     ///   calibration node.

     _pRoot->RecomputeCDEntry(_cdvIdx);
     _pRoot->RecomputeCDEntry(_cdvIdx+1);

    REPRDEBUG(Dump::str(*this));
}

// *****************************************************************************

void
PriorNodeCal::Rollback()
{
    PriorNode::Rollback();
    _cdf    = _oldCdf;
    _cdvIdx = _oldCdvIdx;
    for ( auto & p : _pRoot->_oldCdPVec ) {
	if ( p.second._pNode )
	    p.second._pNode->_cdvIdx = p.first;
	_pRoot->_cdVec[p.first]  = p.second;
    }
}

// *****************************************************************************

PDFFN
PriorNodeNoCal::GetPdfFn ( const PriorRoot & _pRoot )
{
    PDFFN lnPdfFn;

    // If \f$\lambda=\mu\f$ (or close enough) use the simpler pdf routine
    if ( MrBayes::IsZero(_pRoot._lambda - _pRoot._mu) )

	/// - Compute the ln(PDF) ($g$ in Rannala and Yang 06) for the \f$\lambda=\mu\f$ case.
	///   \f$g(t|\lambda = \mu) = c_2 - 2 \log(1 + c_1 t)\f$
	lnPdfFn = [] ( FLOAT            age,
		     const PriorRoot & pr) -> FLOAT
	    {
		return log(pr._c7) - 2.0 * log(1.0 + pr._c1 * age);
	    };

    else

	/// - Compute the ln(PDF) ($g$ in Rannala and Yang 06) for the \f$\lambda\ne\mu\f$ case.
	///   \f$g(t|\lambda =\ne \mu) = c_5 + 2 \log(c_1 + c_4 \mathrm{e}^{c_3t}) + c3 t\f$
	lnPdfFn = [] ( FLOAT            age,
		     const PriorRoot & pr) -> FLOAT
	    {
		return pr._c5 -
		2.0 * log(pr._c1 + pr._c4 * exp(pr._c3 * age)) +
		pr._c3 * age;
	    };

    return lnPdfFn;
}

// *****************************************************************************

void
PriorNodeNoCal::NewAge()
{
    REPRENTER(Dump::str(_tPos, "tPos"),
	      Dump::str(_value, "value"),
	      Dump::str(_oldValue, "oldValue"));

    /// - Setup for rollback.

    _repl.LogRollback(this);
    Save();

    /// - Clear the age save vectors so we can stack changes into it.

    _pRoot->_oldAgePVec.clear();
    _pRoot->_oldAgePVec.push_back(std::make_pair(_avIdx, this));

    /// - Compute new log of the pdf for this node  and update it into the overall prior

    _value = _lnPdfFn(_ageParm(), *_pRoot);
    _pRoot->UpdatePrior(PriorRatio());

    /// - Work out the change in conditional density for the non-calibration nodes.

    int earliest =  -1;
    int latest   =  -1;

    /// - Look for downward movements in the age list.

    while (_avIdx > 0 &&
	   _ageParm() < _pRoot->_ageVec[_avIdx - 1]->_ageParm()  ) {

	auto pNode = _pRoot->_ageVec[_avIdx - 1];

	REPRDEBUG("Downward movement", Dump::ptr(pNode,"pNode"));

	/// - Swap entires in the age vector.
	_pRoot->_oldAgePVec.push_back(std::make_pair(_avIdx - 1, pNode));
	_pRoot->_ageVec[_avIdx]     = pNode;
	_pRoot->_ageVec[_avIdx - 1] = this;
	_avIdx--;
	pNode->_avIdx++;

	/// - If we moved before another calibration node, setup to update
	///   conditional density vector.
	if ( pNode->IsCalNode() ) {
	    auto calPNode = pNode->AsCalNode();
	    earliest = calPNode->_cdvIdx;
	    if ( latest == -1 )
		latest = calPNode->_cdvIdx;
	}

    }

    /// - Look for upward movements in the age list.

    while (unsigned(_avIdx) < _pRoot->_ageVec.size() - 1 &&
	   _ageParm() > _pRoot->_ageVec[_avIdx + 1]->_ageParm() ) {

	auto pNode = _pRoot->_ageVec[_avIdx + 1];

	/// - Swap entires in the age vector.
	_pRoot->_oldAgePVec.push_back(std::make_pair(_avIdx + 1, pNode));
	_pRoot->_ageVec[_avIdx]     = pNode;
	_pRoot->_ageVec[_avIdx + 1] = this;
	_avIdx++;
	pNode->_avIdx--;

	/// - If we moved after another calibration node, setup to update
	///   conditional density vector.
	if ( pNode->IsCalNode() ) {
	    auto calPNode = pNode->AsCalNode();
	    latest = calPNode->_cdvIdx;
	    if ( earliest == -1 )
		earliest = calPNode->_cdvIdx;
	}

    }

    /// - If there was a movement before or after a calibration node update the cdv
    if ( earliest != -1 )
	for ( ; earliest <= latest; earliest++ )
	    _pRoot->RecomputeCDEntry(earliest);

    REPREXIT(Dump::str(_value, "value"));
}

// *****************************************************************************

void
PriorNodeNoCal::NewRootAge()
{
    /// - Setup for rollback.

    _repl.LogRollback(this);
    Save();

    /// - Compute new log of the pdf for this node and update it into the overall prior

    _value = _lnPdfFn(_ageParm(), *_pRoot);
    _pRoot->UpdatePrior(PriorRatio());

    REPRDEBUG(Dump::str(*this));

}

// *****************************************************************************

void
PriorNodeRoot::NewAge()
{
    _pRoot->NewAge();
}

// *****************************************************************************
/// c5c1 may be invalid in the case where lambda == mu but it won't be used in
/// this case.

PriorRoot::PriorRoot( Replicate &  repl,
		      Tree::Root & root )
    : AgePriorRoot(repl),
      _root(root),
      _lambda(_repl._dt._bdLambda),
      _mu(_repl._dt._bdMu),
      _rho(_repl._dt._bdRho),
      _nCalNodes(0),
      _c1(_rho * _lambda),
      _c2(0.0),
      _oldC2(0.0),
      _c3(_mu - _lambda),
      _c3Rho(_c3 * _rho),
      _c4(_lambda * ( 1.0 - _rho) - _mu),
      _c5(0.0),
      _oldC5(0.0),
      _c5c1(log(_c1) - 2.0 * (_c3Rho > 0.0 ? log(_c3Rho) : 0.0)),
      _c6(0.0),
      _oldC6(0.0),
      _c7(0.0),
      _oldC7(0.0)
{
    REPRDEBUG( Dump::ptr( this ),
	       Dump::str( _lambda ,"lambda" ),
	       Dump::str( _mu ,"mu" ),
	       Dump::str( _rho ,"rho" ),
	       Dump::str( _c1 ,"c1" ),
	       Dump::str( _c3 ,"c3" ),
	       Dump::str( _c4 ,"c4" ),
	       Dump::str( _c5c1 ,"c5c1" ) );

    if ( _root._calList.size() )

	/// Compute the prior density for a root node with calibrations
	_lnPdfFn = [] ( FLOAT             age,
			const PriorRoot & pRoot ) -> FLOAT
	    {
		FLOAT lnPdf = 0.0;
		for ( auto cal : pRoot._root._calList )
		    lnPdf += (*cal)(age);
		return lnPdf;
	    };

    else
	// If \f$\lambda=\mu\f$ (or close enough) use the simpler pdf routine
	if ( MrBayes::IsZero(_lambda - _mu) )

	    /// - Compute the ln(PDF) ($g$ in Rannala and Yang 06) for the \f$\lambda=\mu\f$ case.
	    ///   \f$g(t|\lambda = \mu) = (s-2) ( \log{t_r} + \log{c_1} ) + 2 \log\rho - (s-2) \log{c_2}\f$
	    _lnPdfFn = [] ( FLOAT            age,
			   const PriorRoot & pr) -> FLOAT
		{
		    FLOAT s = pr._ageVec.size() + 2.0;
		    return (s-2) * ( log(age) + log(pr._c1) ) + 2 * log(pr._rho) - (s+2) * log(pr._c2);
		};

	else

	    /// - Compute the ln(PDF) ($g$ in Rannala and Yang 06) for the \f$\lambda\ne\mu\f$ case.
	    _lnPdfFn = [] ( FLOAT            age,
			   const PriorRoot & pr) -> FLOAT
		{
		    FLOAT s = pr._ageVec.size() + 1.0;
		    FLOAT t1 = age * pr._c3;
		    FLOAT e1 = exp(t1);
		    return 2.0 * t1 +
		           4.0 * log(-pr._c3) +
		           2.0 * log(pr._rho) +
		           (s - 2.0) * log( 1.0 + (e1 * pr._c3) / (e1 * pr._c4 + pr._c1) ) -
		           4.0 * log(e1 + pr._c1);
		};

}

// *****************************************************************************

void
PriorRoot::ComputeConstants( FLOAT age )
{

    /// - Compute the constants that depend on the root age

    const FLOAT te = exp(_c3 * age);
    const FLOAT vt1 = (_c1 + (_c4 + _c3) * te) / (_c1 + _c4 * te);

    _c2 = 1.0 + _c1 * age;
    _c5 = _c5c1 - log(vt1);
    _c6 = _c1 / vt1;
    _c7 = _c2 / age;

    REPRDEBUG( Dump::str( age ,"age" ),
	       Dump::str( te ,"te" ),
	       Dump::str( vt1 ,"vt1" ),
	       Dump::str( _c1 ,"c1" ),
	       Dump::str( _c2 ,"c2" ),
	       Dump::str( _c3 ,"c3" ),
	       Dump::str( _c3Rho ,"c3Rho" ),
	       Dump::str( _c4 ,"c4" ),
	       Dump::str( _c5 ,"c5" ),
	       Dump::str( _c5c1 ,"c5c1" ),
	       Dump::str( _c6 ,"c6" ),
	       Dump::str( _c7 ,"c7" ));
}

// *****************************************************************************

void
PriorRoot::InitialValues()
{
    REPRENTER(Dump::ptr(this),
	      Dump::str( _value ,"value" ));

    /// - Sort the list of node priors ascending by age.

    std::sort( _ageVec.begin(),
	       _ageVec.end(),
	       [] (PriorNode * a, PriorNode * b) { return *a < *b; } );

    REPRDEBUG( Dump::str( _ageVec ,"ageVec" ) );

    _oldAgeVec.reserve(_ageVec.size());
    _oldAgePVec.reserve(_ageVec.size());

    /// - Reset node indicies

    for ( auto pi = _ageVec.begin(); pi < _ageVec.end(); pi++ )
	(*pi)->_avIdx = pi - _ageVec.begin();

    /// - First create the conditional density entries
    ///   Indicies run from 0 to _nCalNodes

    _cdVec.reserve(_nCalNodes + 1);
    for ( unsigned i = 0; i  <= _nCalNodes; i++ )
	_cdVec.emplace_back();

    _oldCdVec.reserve(_cdVec.size());
    _oldCdPVec.reserve(_cdVec.size());

    /// - Second create the function entries and attach to the conditional density entries

    _cdFnVec.reserve(_cdVec.size());
    for ( unsigned i = 0; i  <= _nCalNodes; i++ ) {
	_cdFnVec.emplace_back(this, i);
	_cdVec[i]._fnv = &_cdFnVec.back();
    }

    /// - Compute the initial constant values.

    ComputeConstants((*_root._ageParm)());

    /// - Start with the root pdf

    _rootLnPdf = _lnPdfFn((*_root._ageParm)(), *this);
    _value     = _rootLnPdf;

    REPRDEBUG( Dump::str((*_root._ageParm)() ,"rootAge" ),
	       Dump::str( _rootLnPdf ,"rootLnPdf" ) );

    /// - Compute the initial values for the \f$f(\mathbf{t}_c)\f$ and
    ///   \f$f(\mathbf{t}_{-c}|\mathbf{t}_c)\f$ terms.

    auto cdvIter = _cdVec.begin();

    for ( auto pNode : _ageVec ) {

	if ( pNode->IsCalNode() ) {
	    auto & cNode = *pNode->AsCalNode();

	    /// - Compute pdf and cdf for the calibration node and add the pdf to the total

	    cNode._value  = cNode._lnPdfFn(cNode._ageParm(), cNode._tPos);
	    cNode._cdf    = cNode._cdfFn(cNode._ageParm(), *cNode._pRoot);
	    cNode._cdvIdx = cdvIter - _cdVec.begin();

	    _value += cNode._value;

	    /// - Complete setup of the conditional density vector

	    (*cdvIter)._pNode = &cNode;
	    (*cdvIter)._lnF    = (*(*cdvIter)._fnv->_fFn)();
	    (*cdvIter)._lnGp   = (*(*cdvIter)._fnv->_GpFn)();

	    /// - Add the f(i) and G(i)  terms to the overall prior.

	    _value += (*cdvIter)._lnF;
	    _value -= (*cdvIter)._lnGp;

	    REPRDEBUG ( Dump::str( cNode, "cNode" ),
			Dump::str( (*cdvIter) ,"cdvEntry" ),
			Dump::str( _value ,"value" ) );

	    cdvIter++;
	}
	else {

	    /// - Get the log of the g(t) function for the non-cal node.

	    auto & nNode = *pNode->AsNoCalNode();
	    nNode._value = nNode._lnPdfFn(nNode._ageParm(), *nNode._pRoot);

	    /// - Add the g(i) term to the overall prior

	    _value += pNode->_value;

	    REPRDEBUG ( Dump::str( nNode ,"nNode" ),
			Dump::str( _value ,"value" )  );

	}

    }

    /// - Fill in the last entry in the conditional density vector
    ///   and add to the overall prior value.

    (*cdvIter)._lnF    = (*(*cdvIter)._fnv->_fFn)();
    (*cdvIter)._lnGp   = (*(*cdvIter)._fnv->_GpFn)();

    _value += (*cdvIter)._lnF;
    _value -= (*cdvIter)._lnGp;

    REPREXIT( Dump::str( (*cdvIter) ,"cdvEntry" ),
	      Dump::str( _value ,"value" ));
}

// *****************************************************************************

void
PriorRoot::NewAge()
{

    REPRENTER(Dump::pstr(this, "this"));

    _repl.LogRollback(this);
    Save();

    /// - The root must always be the oldest node

    assert ( (*_root._ageParm)() > (*(_ageVec.end()-1))->_ageParm() &&
    	     "Root age not oldest node");

    /// - Recompute the constants at the root.

    ComputeConstants((*_root._ageParm)());

    /// - Recompute the prior at the root

    _rootLnPdf = _lnPdfFn((*_root._ageParm)(), *this);
    _value += _rootLnPdf - _oldRootLnPdf;

    REPRDEBUG( Dump::pstr(this,"Overall Prior"),
	       Dump::str(_rootLnPdf, "rootLnPdf"),
	       Dump::str(_oldRootLnPdf, "oldRootLnPdf") );

    /// - Recompute \f$f(\mathbf{t}_{-c}|\mathbf{t}_c)\f$ with new root age.

    for ( auto pNode : _ageVec )
	pNode->NewRootAge();

    REPREXIT(Dump::pstr(this, "this"));

}

// *****************************************************************************

void
PriorRoot::RecomputeCDEntry( const unsigned i )
{
    auto & cd = _cdVec[i];
    auto oldLnF  = cd._lnF;
    auto oldLnGp = cd._lnGp;
    cd._lnF = (*cd._fnv->_fFn)();
    cd._lnGp = (*cd._fnv->_GpFn)();

    _value += cd._lnF - oldLnF;
    _value -= cd._lnGp - oldLnGp;

    REPRDEBUG(Dump::str(cd._lnF, "cd._lnF"),
	      Dump::str(oldLnF, "oldLnF"),
	      Dump::str(cd._lnGp, "cd._lnGp"),
	      Dump::str(oldLnGp, "oldLnGp"));

}

// *****************************************************************************

void
PriorRoot::Rollback()
{
    Prior::Rollback();
    _c2        = _oldC2;
    _c5        = _oldC5;
    _c6        = _oldC6;
    _c7        = _oldC7;
    _cdVec     = _oldCdVec;
    _ageVec    = _oldAgeVec;
    _rootLnPdf = _oldRootLnPdf;
}

// *****************************************************************************
void
PriorRoot::Save()
{
    Prior::Save();
    _oldC2        = _c2;
    _oldC5        = _c5;
    _oldC6        = _c6;
    _oldC7        = _c7;
    _oldCdVec     = _cdVec;
    _oldAgeVec    = _ageVec;
    _oldRootLnPdf = _rootLnPdf;
}
