/// @file Dump.cpp
/// Definitions of the dump functions

// *************************************************************************

// Copyright© 2014-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include <iomanip>
#include <unordered_set>

#include "Dump.h"
#include "EvoModel.h"
#include "Likelihood.h"
#include "Logger.h"
#include "Replicates.h"
#include "Tree.h"
#include "TreeFactory.h"

// *********************************************************************

static const unsigned indent_amount      = 2;

typedef std::unordered_set<Tree::Node *> NODESET;

// *************************************************************************
/// Simple template to print floats the way I want...
template<typename T>
std::string
FloatStr( const T & v)
{
    std::stringstream ss;
    if ( v == std::numeric_limits<double>::max() )
	ss << "Inf";
    if ( v == std::numeric_limits<double>::min() )
	ss << "-Inf";
    else
	ss << std::setprecision(6) << v;
    return ss.str();
}

// *************************************************************************
// Doxygen seems to have a problem with template specializations
/// @cond Dump

namespace Dump {

    // *************************************************************************
    // Scalar specializations of the dump string function for scalars

    template<>
    std::string
    str (const bool &        b,
	 const std::string   hdg )
    {
	std::stringstream ss;
	ss << hdg << '<' << (b ? "True" : "False") << '>';
	return ss.str();
    }

    template<>
    std::string
    str (const char * const & cs,
	 const std::string    hdg )
    {
	std::stringstream ss;
	ss << hdg << '<' << cs << '>';
	return ss.str();
    }

    template<>
    std::string
    str (const double &    d,
	 const std::string hdg )
    {
	std::stringstream ss;
	ss << hdg << '<' << FloatStr(d) << '>';
	return ss.str();
    }

    template<>
    std::string
    str (const float     & f,
	 const std::string hdg )
    {
	std::stringstream ss;
	ss << hdg << '<' << FloatStr(f) << '>';
	return ss.str();
    }

    template<>
    std::string
    str (const int &       i,
	 const std::string hdg )
    {

	std::stringstream ss;
	ss << hdg << "<" << i << ">";
	return ss.str();
    }

    template<>
    std::string
    str (const std::string & s,
	 const std::string   hdg )
    {
	std::stringstream ss;
	ss << hdg << '<' << s << '>';
	return ss.str();
    }

    template<>
    std::string
    str (const unsigned &  u,
	 const std::string hdg )
    {
	std::stringstream ss;
	ss << hdg << "<" << u << ">";
	return ss.str();
    }

    // *************************************************************************
    // Scalar specializations of the dump string function for pairs of scalars

    template<>
    std::string
    str (const double &    d1,
	 const double &    d2,
	 const std::string hdg )
    {
	std::stringstream ss;
	ss << hdg << '<' << FloatStr(d1) << '/' << FloatStr(d2) << '>';
	return ss.str();
    }

    template<>
    std::string
    str (const float     & f1,
	 const float     & f2,
	 const std::string hdg )
    {
	std::stringstream ss;
	ss << hdg << '<' << FloatStr(f1) << '/' << FloatStr(f2) << '>';
	return ss.str();
    }

    template<>
    std::string
    str (const unsigned &  u1,
	 const unsigned &  u2,
	 const std::string hdg )
    {
	std::stringstream ss;
	ss << hdg << "<" << u1 << '/' << u2 << ">";
	return ss.str();
    }

    // *************************************************************************
    // Specializations of the dump vectors for basic types

    template<>
    std::string
    str ( const std::vector<double> &  v,
	  const std::string            hdg )
    {
	std::stringstream ss;

	ss << hdg
	   << "<"
	   << std::setprecision(6);

	for ( std::vector<double>::const_iterator it = v.begin(); it != v.end(); it++) {
	    if ( it != v.begin() )
		ss << ',';
	    ss << *it;
	}

	ss << ">";

	return ss.str();
    }

    template<>
    std::string
    str ( const std::vector<float> &  v,
	  const std::string           hdg )
    {
	std::stringstream ss;

	ss << hdg
	   << "<"
	   << std::setprecision(6);

	for ( std::vector<float>::const_iterator it = v.begin(); it != v.end(); it++) {
	    if ( it != v.begin() )
		ss << ',';
	    ss << *it;
	}

	ss << ">";

	return ss.str();
    }

    template<>
    std::string
    str ( const UINTVEC &   v,
	  const std::string hdg )
    {
	std::stringstream ss;

	if ( hdg.size() )
	    ss << hdg;
	ss << "<";
	for ( UINTVEC::const_iterator it = v.begin(); it != v.end(); it++) {
	    if ( it != v.begin() )
		ss << ',';
	    ss << *it;
	}
	ss << ">";

	return ss.str();
    }

    /// @endcond dump

    // *****************************************************************************

    std::string
    rtrim ( const std::string s )
    {
	size_t endpos = s.find_last_not_of(" \t\n");
	return std::string::npos != endpos
	    ? s.substr( 0, endpos+1 )
	    : s;
    }

    // *****************************************************************************

    std::string
    indent ( std::string s,
	     unsigned    n )
    {
	if ( s.size() == 0 )
	    return s;

	std::string istr = '\n' + std::string(n, ' ');
	s.insert(0, std::string(n, ' '));

	std::size_t pos = s.find('\n');
	while ( pos != std::string::npos ) {
	    s.replace(pos, 1, istr);
	    pos = s.find('\n', pos + 1);
	}

	return rtrim(s);
    }

    // *****************************************************************************

    std::string
    indent_heading ( std::string       s,
		     const std::string h )
    {
	if ( s.size() == 0 )
	    return h;

	s.insert(0, h + ' ');

	std::string istr = std::string(h.size() + 1, ' ');

	for (std::size_t pos = s.find('\n');
	     pos != std::string::npos;
	     pos = s.find('\n', pos + 1) )

	    s.insert(pos + 1, istr);

	return rtrim(s);
    }

    // *****************************************************************************

    std::string
    vector_heading ( const unsigned    i,
		     const std::string h,
		     const size_t      width )
    {
	std::stringstream ss;
	ss << h
	   << '<'
	   << std::setfill('0')
	   << std::setw(width)
	   << i
	   << std::setfill(' ')
	   << '>';

	return ss.str();
    }

}

// *****************************************************************************

static
void
DumpRoot ( Tree::Root & r,
           NODESET &    seenNodes,
           Logger &     log,
           unsigned     ind = 0)

{

    struct DumpDfs : Tree::Dfs {


        NODESET & _seenNodes;
        Logger &  _log;
        unsigned  _indent;

        DumpDfs(NODESET & seenNodes,
                Logger  & log,
                unsigned  indent = 0)
            : _seenNodes(seenNodes),
              _log(log),
              _indent(indent)
            {}

        virtual RC InnerBegin ( const Tree::Position & tPos )
            {
                if ( _seenNodes.count(tPos._node) ) {
                    _log("%*c%s<%p> Already Visited",
                         _indent, ' ',
                         "Inner",
                         tPos._node);
                    return STOPDOWN;
                }
                else {
                    _seenNodes.insert(tPos._node);
                    _log(Dump::indent(tPos._node->str("Inner"), _indent).c_str());
                    _indent += indent_amount;
                    return CONTINUE;
                }

            }

        virtual RC InnerEnd   ( const Tree::Position & tPos )
            {
                _indent -= indent_amount;
                return CONTINUE;
            }

        virtual RC Leaf       ( const Tree::Position & tPos )
            {
                if ( _seenNodes.count(tPos._node) ) {
                    _log("%*c%s<%p> Already Visited",
                         _indent, ' ',
                         "Leaf",
                         tPos._node);
                }
                else {
                    _seenNodes.insert(tPos._node);
                    _log(Dump::indent(tPos._node->str("Leaf"), _indent).c_str());
                }
                return CONTINUE;
            }

        virtual RC RootBegin ( Tree::Root &  r )
            {
                _log(Dump::indent(r.str("Root"), _indent).c_str());
                _indent += indent_amount;
                return CONTINUE;
            }

    }  dfs(seenNodes, log, ind);

    r._eModel->GetData();
    r._lkh->GetData();

    dfs(r);

    r._eModel->DisposeData();
    r._lkh->DisposeData();

}

// Doxygen seems to have a problem with template specializations
/// @cond Dump

namespace Dump {

    // *****************************************************************************
    /// Specialization to dump the tree factory

    template<>
    void
    Trees( TreeFactory &       tf,
	   const std::string & heading,
	   Logger &            log )
    {

	if ( heading.size() )
	    log("\n%s:", heading.c_str());

	NODESET seenNodes;

	for ( auto & root : tf )
	    DumpRoot( root, seenNodes, log );

    }

    // *****************************************************************************
    /// Specialization to dump a set of replicates

    template<>
    void
    Trees( ReplicateVec &       rv,
	   const std::string &  heading,
	   Logger &             log )
    {

	if ( heading.size() )
	    log("\n%s:", heading.c_str());

	NODESET seenNodes;

	for ( auto & repl : rv ) {
	    log("Replicate %d", repl._id);
	    for ( auto & root : repl )
		DumpRoot( root, seenNodes, log, 2 );
	}

    }

    // *****************************************************************************
    /// Specialization to dump a single replicates

    template<>
    void
    Trees( Replicate &         repl,
	   const std::string & heading,
	   Logger &            log )
    {

	if ( heading.size() )
	    log("\n%s:", heading.c_str());

	NODESET seenNodes;

	for ( auto & root : repl )
	    DumpRoot( root, seenNodes, log, 2 );

    }

}
/// @endcond
