/// @file SequenceFactory.h
/// Convert an input sequence into internal format

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _SEQUENCEFACTORY_H_
#define _SEQUENCEFACTORY_H_

#include <string>

struct Locus;
struct Sequence;
struct Taxa;

// *****************************************************************************
/// Factory class to generate a sequence object validating and converting the
/// input

struct SequenceFactory {

    std::string _alphabet;			  ///< Valid alphabet of characters
    char        _gapCh;				  ///< Character indicating a gep
    char        _missingCh;			  ///< Character indicating missing data

    /// Constructor setting all the initial parameter values
    SequenceFactory(std::string alphabet,	  ///< Alphabet to honor
		    char        gapCh,		  ///< Gap character to use
		    char        missingCh)	  ///< Missing data character
	: _alphabet(alphabet), _gapCh(gapCh), _missingCh(missingCh) {};

    // Make a sequence object
    Sequence * MakeSequence(std::string seqIn,
			    Taxa &      taxa,
			    Locus &     locus);


};

#endif // _SEQUENCEFACTORY_H_
