/// @file Parameter.h
/// Definition of the base class for all MCMC parameters

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _PARAMETER_H_
#define _PARAMETER_H_

#include <string>

#include "Config.h"
#include "Dump.h"
#include "ITransaction.h"

struct Replicate;

namespace Tree {
    struct     TraceInfo;
    struct     Root;
    enum class TraceType  : unsigned char;
    typedef    FLOAT  (*DATASRC) ( TraceInfo * ti );

}

// *****************************************************************************
/// Pure virtual base class for all MCMC parameters.
/// The _root and _replIdx members comprise the common portion of the parameter
/// address. Subclasses may add additional fields to the address as required.

struct Parameter : ITransaction {

    /// Destructor required by the compiler.
    virtual
    ~Parameter()
	{};

    /// Return values as a vector
    virtual
    FLOATVEC
    ValueVector() const
	{
	    return FLOATVEC({_value});
	}

    /// Return the number of values in the parameter.
    virtual
    unsigned
    NValues() const
	{
	    return 1;
	}

    /// Accept the new parameter value
    virtual
    void
    Accept();

    /// Empty commit method
    virtual
    void
    Commit()
	{}

    /// Propose a new parameter value.
    /// This base class method really just saves the proposal value.
    /// @return Prior ratio for the proposal.
    virtual
    FLOAT
    Propose()
	{
	    _oldValue = _value;
	    return 1.0;
	};

    /// Reject the new parameter value, rollback the object updates.
    virtual
    void
    Reject();

    /// Return the parameter value during sampling.
    /// Also accumulate the paramete value to the sum.
    /// @return Current parameter value
    FLOAT
    Sample();

    /// Return the dump string for the parameter
    virtual
    std::string
    str ()
	const;

    /// Virtual operator to return the parameter value
    /// @return Parameter value
    virtual
    FLOAT
    operator()() const
        {
            return _value;
        }

    /// Virtual operator to set the parameter value
    virtual
    void
    operator()( FLOAT  v )           ///< New parameter value
        {
            _value = v;
        }

    const unsigned    _id;                        ///< Parameter id
    Replicate  &      _repl;	                  ///< MCMC chain or jackknife replicate.
    Tree::Root &      _root;			  ///< Owning species tree.
    Tree::TraceInfo * _tInfo;			  ///< Associated trace info block
    unsigned          _pType;			  ///< Parameter type

    FLOAT             _value;                     ///< Parameter value.
    FLOAT             _oldValue;                  ///< Prior parameter value

    static unsigned   _maxId;			  ///< Where to get the parameter ids

protected:

    /// Constructor setting the common address fields.
    Parameter( Replicate &    repl,               ///< Chain or jackknife replicate.
	       Tree::Root &   root,		  ///< Owning species tree
	       const unsigned pType               ///< Parameter type
	     );

    /// Rollback the parameter value.
    /// Intentionally not virtual. Just used by subclasses.
    inline
    void
    Rollback()
	{
	    _value = _oldValue;
	}

    /// Setup trace info block with all parameters
    void
    SetTraceInfo( Tree::TraceType   type,
		  Tree::DATASRC     dsource,
		  int               lId,
		  int               nId,
		  unsigned          idx,
		  const std::string label,
		  const std::string heading );

    /// Setup trace info block with node id and heading only
    void
    SetTraceInfo( Tree::TraceType   type,
		  int               nId,
		  const std::string heading );

    /// Setup trace info block for vector parameter
    void
    SetTraceInfo( Tree::TraceType   type,
		  Tree::DATASRC     dsource,
		  int               lId,
		  unsigned          idx,
		  const std::string label,
		  const std::string heading );

    /// Setup trace info for gene parameters
    void
    SetTraceInfo( Tree::TraceType   type,
		  int               lId,
		  const std::string label,
		  const std::string heading );

    /// Setup trace info for gene tree node parameters
    void
    SetTraceInfo( Tree::TraceType   type,
		  int               lId,
		  int               nId,
		  const std::string heading );

    friend
    std::string
    Dump::str<>( const Parameter & p,
		 const std::string hdg );

    friend
    std::string
    Dump::pstr<>( const Parameter * const  p,
		  const std::string        hdg );

};

// *****************************************************************************
/// base class for the various nuisance parameters
/// Provides a common Accept method for all the statistical parameters.

struct NuisanceParameter : Parameter {

    /// Accept the proposal
    virtual
    void
    Accept();

    /// Propose a new parameter value.
    /// This base class method really just saves the prior value.
    /// @return Prior ratio for the proposal (constant 1.0).
    inline
    virtual
    FLOAT
    Propose()
	{
	    Parameter::Propose();
	    _oldPrior = _prior;
	    return 1.0;
	};

    virtual
    FLOAT
    Prior()
	{
	    return _prior;
	}

    /// Return the prior ratio for an inflight proposal
    inline
    virtual
    FLOAT
    PriorRatio()
	{
	    return _prior - _oldPrior;
	}

    /// Reject the proposal
    virtual
    void
    Reject();

    /// Return the dump string for the parameter
    std::string
    str ()
	const;

protected:

    NuisanceParameter( Replicate&   repl,
		       Tree::Root & root );

    /// Rollback the parameter and prior value.
    inline
    void
    Rollback()
	{
	    _lnPN -= PriorRatio();
	    _prior = _oldPrior;
	    Parameter::Rollback();
	}

    FLOAT    _prior;	                          ///< Value of the prior.
    FLOAT    _oldPrior;		                  ///< Save the value of the prior for rollback.
    FLOAT  & _lnPN;			          ///< Prior for all nuisance parameters

};

#endif // _PARAMETER_H_
