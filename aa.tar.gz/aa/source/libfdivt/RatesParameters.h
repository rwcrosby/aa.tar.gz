/// @file RatesParameters.h
/// Declarations for the parameters associated with the rates.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _RATESPARAMETERS_H_
#define _RATESPARAMETERS_H_

struct Parameter;
struct Replicate;
namespace Tree {
    struct LocusRoot;
    struct LocusNode;
}

/// Common function to operate on the parameters associated with the rates.
namespace Rates {

    /// Construct a rate parameter.
    /// @param repl Owning replicate.
    /// @param lNode Owning gene tree node.
    Parameter * Factory     ( Replicate &       repl,
			      Tree::LocusNode & lNode );

    /// Construct a rate mean hyperparameter.
    /// @param repl Owning replicate.
    /// @param lRoot Owning gene tree.
    Parameter * MeanFactory ( Replicate &       repl,
			      Tree::LocusRoot & lRoot );

    /// Construct a rate variance hyperparameter.
    /// @param repl Owning replicate.
    /// @param lRoot Owning gene tree.
    Parameter * VarianceFactory  ( Replicate &       repl,
				   Tree::LocusRoot & lRoot );

    /// Setup the inital priors for the parameters
    /// @param repl Replicate containing parameters to process.
    void        InitialParmPriors ( Replicate & repl );

}

#endif // _RATESPARAMETERS_H_
