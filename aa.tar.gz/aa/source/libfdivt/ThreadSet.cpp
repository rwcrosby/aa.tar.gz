/// @file ThreadSet.cpp
/// Definitions for the thread set methods.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include <atomic>
#include <cassert>
#include <condition_variable>
#include <queue>
#include <stdexcept>
#include <thread>

#ifdef PAPIAvail
#include "PAPI.h"
#endif

#include "DivTime.h"
#include "Logger.h"
#include "PerfInterface.h"
#include "Task.h"
#include "ThreadSet.h"

struct ThreadSetImpl;
struct WorkQueue;

// *****************************************************************************
/// Main thread processing object.
/// The constructor and destructor are run on the parent thread.
/// The () operator is the function run on the child thread.

struct Thread {

    /// Constructor for the thread processor.
    /// @param dt Owning divergence time object.
    /// @param tSet Thread set collection
    /// @param id Thread number.
    Thread ( DivTime &       dt,
	     ThreadSetImpl & tSet,
	     const unsigned  id )
    : _dt(dt),
      _logger(*_dt._logger),
      _tSet(tSet),
      _thread(nullptr),
      _id(id)
	{}

    virtual ~Thread()
	{
	    delete _thread;
	}

    void operator()();

    DivTime &        _dt;                         ///< Parent divergence time
    Logger &         _logger;                     ///< Log to output to
    ThreadSetImpl &  _tSet;			  ///< Owning thread set.

    std::thread *    _thread;                     ///< STL thread object for the thread

    const unsigned   _id;                         ///< My thread number

};

// *****************************************************************************
/// Implementation of the thread set.

struct ThreadSetImpl : ThreadSet {

    ThreadSetImpl( DivTime & dt );

    virtual ~ThreadSetImpl();

    virtual void operator()(Task::PtrList & tasks);

    /// Decrement the thread idle counter.
    void DecrIdle()
        {
            _thIdle--;
        }

    /// Increment the thread idle counter.
    /// If all threads are idle, post the Step Processor.
    void IncrIdle()
        {
            _thIdle++;
            if ( _thIdle == _threads.size() )
                _spEvent.notify_all();
        }

    // Wait for all the threads to complete.
    /// @throw runtime_error A thread crashed...
    void WaitForThreads();

    DivTime &                 _dt;                ///< Reference to the parent divergence time object.
    Logger &                  _logger;            ///< Log to output to

    WorkQueue *               _wQueue;            ///< Thread safe work queue
    std::list<Thread>         _threads;           ///< List of thread objects

    std::atomic<unsigned>     _thIdle;            ///< Count of idle threads
    std::exception_ptr        _thExcpPtr;

    std::mutex                _mutex;             ///< Access control mutex
    std::condition_variable   _spEvent;           ///< Step processor event

};

// *****************************************************************************
/// Work queue, a thread-safe STL queue
/// Note the design is based on composition not inheretance since only a subset
/// of the methods available to the full queue are needed and overridden in a
/// thread safe manner.

struct WorkQueue {

    WorkQueue ( ThreadSetImpl & tSet,
		std::mutex &    mutex )
        : _tSet(tSet),
	  _mutex(mutex),
          _shutdown(false)
        {}

    virtual ~WorkQueue()
        {}

    // Set the shutdown flag for the queue.
    virtual void       Shutdown();

    // Push an entry onto the queue.
    virtual void       Push(Task * task);

    // This pop will both return the top of queue and pop it in one operation.
    virtual Task *     Pop();

    /// Test queue state.
    ///
    /// @return True if the queue is empty, false otherwise.
    virtual bool       Empty()
        {
            return _q.empty();
        }

private:

    ThreadSetImpl &         _tSet;		  ///< Owning thread set.

    std::queue<Task*>       _q;                   ///< The actual queue

    std::mutex &            _mutex;               ///< Access control mutex
    std::condition_variable _not_empty;           ///< Queue state indicator
    std::atomic<bool>       _shutdown;            ///< Task shutdown request

};

// *****************************************************************************
/// Thread processor.
/// This is the method that is actually called to run the thread.
/// It runs on the actual thread.

void
Thread::operator()()
{
    _logger.Debug("Thread::operator() Entry id<%d>", _id);

    /// - Create a thread specific papi inteface (if available).

#ifdef PAPIAvail
    PAPIThread * papi = nullptr;
    if ( _dt._perfIntf->_papi ) {
        try {
            papi = new PAPIThread(_dt._perfIntf->_papi,
                                  _id);
        }
        catch (Except::PAPIError e) {
            _logger(e.what());
        }
    }
#endif

    /// - Loop processing the tasks

    while(1) {

        Task * workItem = _tSet._wQueue->Pop();
        if ( !workItem )
            break;

        try {
            (*workItem)(_id);
        }
        catch (...) {
            _logger("<%d> Thread terminating on exception");
            _tSet._spEvent.notify_all();
            _tSet._thExcpPtr = std::current_exception();
            break;
        }

    }

#ifdef PAPIAvail
    try {
        delete papi;
    }
    catch (Except::PAPIError e) {
        _logger(e.what());
    }
#endif

    _logger.Debug("Thread::operator() Exit id<%d>", _id);
}

// *****************************************************************************

ThreadSet *
ThreadSet::Factory( DivTime & dt )
{
    return new ThreadSetImpl(dt);
}

// *****************************************************************************

ThreadSetImpl::ThreadSetImpl( DivTime & dt)
    : _dt (dt),
      _logger(*dt._logger),
      _wQueue(new WorkQueue(*this, std::ref(_mutex))),
      _thExcpPtr(nullptr)
{

    /// -  Set all threads idle

    _thIdle.store(0);

    /// - Create the threads

    for (unsigned i = 1; i <= _dt._nThreads; i++) {
        _threads.emplace_back(_dt, *this, i);
        Thread & thrd = _threads.back();
        thrd._thread = new std::thread(std::ref(thrd));
    }

    /// - Wait for all the threads to go idle

    WaitForThreads();
}

// *****************************************************************************

ThreadSetImpl::~ThreadSetImpl()
{

    // Tell all the threads to terminate
    _wQueue->Shutdown();

    // Wait for all the threads to finish
    for (auto & thrd : _threads)
        if ( thrd._thread->joinable() )
            thrd._thread->join();

    delete _wQueue;

}

// *****************************************************************************

void
ThreadSetImpl::operator()( Task::PtrList & tasks )
{

    _logger.Debug("ThreadSetImpl::operator(): Starting");

    for ( auto task : tasks )
        _wQueue->Push(task);

    /// -  Wait till all the tasks are completed
    WaitForThreads();

    /// -  Make sure the queue cleared
    assert(_wQueue->Empty());

    _logger.Debug("ThreadSetImpl::operator(): Ended");

}

// *****************************************************************************

void
ThreadSetImpl::WaitForThreads()
{

    std::unique_lock<std::mutex> lk(_mutex);
    while (  !_thExcpPtr &&
	     (_thIdle != _threads.size() || !_wQueue->Empty() ) )
        _spEvent.wait(lk);

    if (_thExcpPtr)
        std::rethrow_exception(_thExcpPtr);

}

// *****************************************************************************
/// Set the shutdown flag for the queue.

void
WorkQueue::Shutdown()
{
    _shutdown = true;
    _not_empty.notify_all();
}

// *****************************************************************************
/// Push an entry onto the queue.
///
/// Notify a task that there is an entry available.

void
WorkQueue::Push (Task * tb)                       ///< Pointer to task to perform.
{
    std::unique_lock<std::mutex> lk(_mutex);
    _not_empty.notify_one();
    _q.push(tb);
}

// *****************************************************************************
/// This pop will both return the top of queue and pop it in one operation.
///
/// @return Zero if shudown is set or pointer to task to perform.

Task *
WorkQueue::Pop()
{
    std::unique_lock<std::mutex> lk(_mutex);
    _tSet.IncrIdle();
    _not_empty.wait( lk, [this] () { return !_q.empty() || _shutdown; } );

    // If shutdown is requested, just return zero regardless of queue contents
    if ( _shutdown )
        return 0;
    // If something in the queue, return it...
    else if ( !_q.empty() ) {
        _tSet.DecrIdle();
        Task * task = _q.front();
        _q.pop();
        return task;
    }
    else
        assert(0);

    return nullptr;				  // Stupid microsoft compiler.
}
