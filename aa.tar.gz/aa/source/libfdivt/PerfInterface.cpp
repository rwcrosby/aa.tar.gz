/// @file PerfInterface.cpp
/// Definitions for the performance interface methods.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include <sstream>
#include <iomanip>

#ifdef PAPIAvail
#include "PAPI.h"
#endif

#include "Except.h"
#include "Logger.h"
#include "PerfBlock.h"
#include "PerfInterface.h"

using namespace std;

// *****************************************************************************
/// Format a time difference for output

static string
TimeDiff ( const timeval & t1,
           const timeval & t2 )
{

    long long sec;
    long long usec;

    if ( t2.tv_usec > t1.tv_usec ) {
        sec  = t1.tv_sec - t2.tv_sec - 1;
        usec = t1.tv_usec - t2.tv_usec + 1000000;
    }
    else {
        sec  = t1.tv_sec - t2.tv_sec;
        usec = t1.tv_usec - t2.tv_usec;
    }

    long long hh = sec / 3600;
    long long mm = ( sec - (hh * 3600) ) / 60;
    long long ss = sec - hh * 3600 - mm * 60;

    stringstream sstr;
    sstr << setw(3) << hh << ':'
         << setw(2) << setfill('0') << mm << ':'
         << setw(2) << setfill('0') << ss << '.'
         << setw(6) << setfill('0') << usec;

    return sstr.str();

}

// *****************************************************************************
/// Output information for a time value

static void
WriteLine( Logger &        log,                   ///< Logger to output to.
           const char *    header,                ///< Header for the line
           const timeval & currTime,              ///< Current value.
           const timeval & lastTime,              ///< Last interval value.
           const timeval & initTime)              ///< Starting value.
{

    log( "%*c%-*s: %s %s",
         Logger::indent, ' ',
         Logger::minWidth, header,
         TimeDiff(currTime, lastTime).c_str(),
         TimeDiff(currTime, initTime).c_str() );

}

// *****************************************************************************
/// Output information for an integer value

static void
WriteLine( Logger &            log,          ///< Logger to output to.
           const char *        header,       ///< Header for the line
           const unsigned long curr,         ///< Current value.
           const unsigned long last,         ///< Last interval value.
           const unsigned long init)         ///< Starting value.
{

    log( "%*c%-*s: %16ld %16ld",
         Logger::indent, ' ',
         Logger::minWidth, header,
         (long long)curr - (long long)last,
         (long long)curr - (long long)init );

}

// *****************************************************************************

void
PerfInterface::_Initialize()
{

    /// - Get the initial values for the counters.

    _initBlk = new PerfBlock();
    _lastBlk = new PerfBlock( *_initBlk );

    /// - If PAPI is available, initialize it.

#ifdef PAPIAvail
    try {
        _papi       = new PAPI(_logger);
        _papiThread = new PAPIThread( _papi, 0);
    }
    catch ( Except::PAPIError e) {
        _logger.Log(e.what());
    }
#endif

    _logger("Performance Trace Active");

}

// *****************************************************************************

void
PerfInterface::_Terminate()
{

    delete _initBlk;
    delete _lastBlk;

#ifdef PAPIAvail
    try {
        delete _papiThread;
        delete _papi;
    }
    catch ( Except::PAPIError e) {
        _logger.Log(e.what());
    }
#endif

}

// *****************************************************************************

void
PerfInterface::_Output( string heading )
{

    /// - Get current counters.

    PerfBlock * currBlk = new PerfBlock();

    _logger("Performance Data: %s", heading.c_str());

    /// - Process through the various counters.

    WriteLine( _logger, "User CPU Time",                  currBlk->userTime,       _lastBlk->userTime,       _initBlk->userTime );
    WriteLine( _logger, "System CPU Time",                currBlk->sysTime,        _lastBlk->sysTime,        _initBlk->sysTime );
    WriteLine( _logger, "Page faults (no I/O)",           currBlk->minorFaults,    _lastBlk->minorFaults,    _initBlk->minorFaults );
    WriteLine( _logger, "Page faults (I/O)",              currBlk->majorFaults,    _lastBlk->majorFaults,    _initBlk->majorFaults );
    WriteLine( _logger, "Voluntary context switches",     currBlk->volContextSw,   _lastBlk->volContextSw,   _initBlk->volContextSw );
    WriteLine( _logger, "Involuntary context switches",   currBlk->involContextSw, _lastBlk->involContextSw, _initBlk->involContextSw );
    WriteLine( _logger, "Private resident bytes",         currBlk->resPrivate,     _lastBlk->resPrivate,     _initBlk->resPrivate );
    WriteLine( _logger, "Private virtual bytes",          currBlk->virPrivate,     _lastBlk->virPrivate,     _initBlk->virPrivate );
    WriteLine( _logger, "Total virtual private + shared", currBlk->virSize,        _lastBlk->virSize,        _initBlk->virSize );
    _logger("");

    /// - Save the current block.

    delete _lastBlk;
    _lastBlk = currBlk;

}
