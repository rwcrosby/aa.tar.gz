/// @file Calibration.cpp
/// Definitions for the calibration methods.
/// A set of the Calibration::Data structure are defined for each of the
/// possible calibration types:
/// - Lower bound only
/// - Upper bound only
/// - Lower and upper bounds
/// - Gamma distributed
/// - Normally distributed

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#define _USE_MATH_DEFINES

#include <cassert>
#include <iostream>
#include <random>

#include "Calibration.h"
#include "Dump.h"
#include "Except.h"
#include "Logger.h"
#include "OptionsInit.h"
#include "Replicates.h"
#include "StatsFn.h"
#include "Taxa.h"

// *****************************************************************************
/// Maximun number of attempts to get an age in the specified range.

static const unsigned max_tries = 100;

// *****************************************************************************
/// Helper function to generate an age within a truncated distribution

static
FLOAT
DrawAge ( std::function<FLOAT ()> & distFn,
          FLOAT                     maxAge,
          const Calibration::Opts & opts )
{

    /// - Get the limits on the age of the calibration

    FLOAT  maxLimit = maxAge < Calibration::maxAge
			       ? std::min(maxAge, opts._maxAge)
			       : opts._maxAge;
    FLOAT  minLimit = opts._minAge;

    /// - Loop drawing random values from the distribution until
    ///   we get one in the range (or spend too long at it...

    for ( unsigned i = 0; i < max_tries; i++ ) {

        FLOAT  age =  distFn();

        if ( minLimit < age && age < maxLimit )
            return age;

    }

    std::stringstream ss;

    ss << "Unable to obtain initial age for calibration in range ("
       << minLimit
       << ", "
       << maxLimit
       << ") for calibration "
       << opts._label;

    throw Except::NumericError(ss.str());

}

// *****************************************************************************
/// Subclass for a lower bound only calibration

struct LowerBound : Calibration::Data {

    LowerBound( const Calibration::Opts & o )
	: Calibration::Data(o)
	{}

    LowerBound( const Calibration::Data & d,
		struct Replicate &        r )
	: Calibration::Data(d, r)
	{
	    const auto a  = _opts._minAge;
	    const auto p  = _opts._offset;
	    const auto c  = _opts._scale;
	    const auto tL = _opts._leftMass;

	    /// - \f$t_0 = a(1-p)\f$
	    t0 = a * ( 1.0 - p);

	    /// - \f$s = a c\f$
	    s  = a * c;

	    /// - \f$A = \frac{1}{2} + \frac{1}{\pi} \tan^{-1} \frac{p}{c}\f$
	    const auto A      = 0.5 + atan(p / c) / M_PI;
	    /// - \f$\theta_L = \frac{1-t_L}{\pi t_L A c (1 + (p/c)^2)}\f$
	    const auto thetaL = (1.0 - tL) / (tL * M_PI * A * c * (1 + pow(p/c,2)));

	    /// - \f$c_0 = \log (1-t_L) - log(\pi A s)\f$
	    c0 = log(1 - tL) - log(M_PI * A * s);
	    /// - \f$c_1 = \theta_L - 1\f$
	    c1 = thetaL - 1;
	    /// - \f$c_2 = \log \frac{t_L \theta_L}{a} - (\theta_L - 1) \log a\f$
	    c2 = log(tL * thetaL / a) - (thetaL - 1.0)* log(a);
	}

    /// The location parameter is set just above the min age to push a bit more
    /// of the mass on the side above the min value.
    /// The scale is set to provide values close to the calibration point.

    virtual void InitialValue ( const FLOAT  maxAge )
	{
	    std::cauchy_distribution<FLOAT > dist(_opts._minAge * ( 1.0 + _opts._offset),
						  _opts._minAge / 100.0 );
	    std::function<FLOAT ()> distFn = std::bind(dist, std::ref(_repl->_statsObj->RandomGen()));
	    _age = DrawAge(distFn, maxAge, _opts);
	}

    virtual FLOAT  operator()   ( const FLOAT  age ) const
	{
	    FLOAT  v;

	    if ( age > _opts._minAge ) {
		auto z = (age - t0) / s;
		v = c0 - log(1 + pow(z,2));
	    }
	    else
		v = c2 + c1 * log(age);

	    return v;
	}

    FLOAT  t0;					  ///< Cauchy location
    FLOAT  s;					  ///< Cauchy scale
    FLOAT  c0;
    FLOAT  c1;
    FLOAT  c2;

};

// *****************************************************************************
/// Subclass for a upper bound only calibration

struct UpperBound : Calibration::Data {

    UpperBound( const Calibration::Opts & o )
	: Calibration::Data(o)
	{}

    UpperBound( const Calibration::Data & d,
		struct Replicate &        r )
	: Calibration::Data(d, r)
	{
	    const auto tR  = _opts._rightMass;
	    const auto b   = _opts._maxAge;

	    pInRange = log((1.0 - tR) / b);
	    thetaR   = (1 - tR) / (tR * b);
	    c1       = log(thetaR * tR) + thetaR * b;
	}

    /// The location parameter is set just below the min age to push a bit more
    /// of the mass on the side above the min value.
    /// The scale is set to provide values close to the calibration point.

    virtual void InitialValue ( const FLOAT  maxAge )
	{
	    std::cauchy_distribution<FLOAT > dist(_opts._maxAge * ( 1.0 - _opts._offset),
						  _opts._maxAge / 100.0 );
	    std::function<FLOAT ()> distFn = std::bind(dist, std::ref(_repl->_statsObj->RandomGen()));
	    _age = DrawAge(distFn, maxAge, _opts);
	}

    virtual FLOAT  operator()   ( const FLOAT  age ) const
	{
	    return age < _opts._maxAge
			 ? pInRange
			 : c1 - thetaR * age;
	};

    /// Constant probability returned when the age passed is less than the upper limit.
    /// \f$\log\frac{1-mass_R}{age_{max}}\f$
    FLOAT  pInRange;

    FLOAT  thetaR;				  ///< \f$\log\frac{1-mass_R}{mass_R age_{max}}\f$
    FLOAT  c1;					  ///< \f$\log(mass_R \theta_R) + \theta_R age_{max}\f$

};

// *****************************************************************************
/// Subclass for lower and upper bound calibration

struct LowerUpperBound : Calibration::Data {

    LowerUpperBound( const Calibration::Opts & o )
	: Calibration::Data(o)
	{}

    LowerUpperBound( const Calibration::Data & d,
		     struct Replicate &        r )
	: Calibration::Data(d, r)
	{
	    const auto tL = _opts._leftMass;
	    const auto tR = _opts._rightMass;
	    const auto a  = _opts._minAge;
	    const auto b  = _opts._maxAge;

	    FLOAT  c0            = (1.0 - tL - tR) / (b - a);
	    thetaR               = c0 / tR;
	    const auto thetaL    = thetaR * a;

	    pInRange = log(c0);

	    c1 = thetaL - 1.0;
	    c2 = log(tL * thetaL / a) + c1 * log(a);
	}

    virtual void InitialValue ( const FLOAT  maxAge )
	{
	    std::uniform_real_distribution<FLOAT > dist(_opts._minAge,
							std::min(maxAge, _opts._maxAge ));
	    _age = dist(_repl->_statsObj->RandomGen());
	}

    virtual FLOAT  operator()   ( const FLOAT  age ) const
	{
	    return (age < _opts._minAge)
		? c2 + c1 + log(age)
		: (age  <= _opts._maxAge)
  		    ? pInRange
		    : c1 - thetaR * age;
	}

    /// Constant probability returned when the age passed is within the bounds.
    /// \f$\log \frac{1 - mass_L - mass_R}{age_{max} - age_{min}}\f$
    FLOAT  pInRange;

    FLOAT  thetaR;				  ///< \f$\frac{1 - mass_L - mass_R}{mass_R ( age_{max} - age_{min})}\f$
    FLOAT  c1;					  ///< \f$\theta_L - 1\f$
    FLOAT  c2;					  ///< \f$log\frac{t_L \theta_L}{a} + c_1 \log a\f$

};

// *****************************************************************************
/// Subclass for a gamma distributed calibration

struct GammaDistributed : Calibration::Data {

    GammaDistributed( const Calibration::Opts & o )
	: Calibration::Data(o)
	{}

    GammaDistributed( const Calibration::Data & d,
		      struct Replicate &        r )
	: Calibration::Data(d, r)
	{
	    const auto a = _opts._alpha;
	    const auto b = _opts._beta;

	    c1 = - lgamma(a) - a * log(b) ;
	    c2 = a - 1.0;
	}

    /// Select an initial value close to the mean using a normal distribution for the
    /// initial value only.
    virtual void InitialValue ( const FLOAT  maxAge )
	{
	    FLOAT mu = _opts._alpha * _opts._beta;
	    std::normal_distribution<FLOAT > dist( mu,
						   mu / 100.0 );
	    std::function<FLOAT ()> distFn = std::bind(dist, std::ref(_repl->_statsObj->RandomGen()));
	    _age =  DrawAge(distFn, maxAge, _opts);
	}

    /// Return the log of the gamma value
    virtual FLOAT  operator()   ( const FLOAT  age ) const
	{
	    return  c1 + c2 * log(age) - age / _opts._beta;
	}

    FLOAT  c1;					  ///< \f$a \log(b) - \log \Gamma(a)\f$
    FLOAT  c2;					  ///< \f$a - 1.0\f$

};

/// *****************************************************************************
/// Subclass for a normally distributed calibration

struct NormallyDistributed : Calibration::Data {

    NormallyDistributed( const Calibration::Opts & o )
	: Calibration::Data(o)
	{}

    NormallyDistributed( const Calibration::Data & d,
			 struct Replicate &        r )
	: Calibration::Data(d, r)
	{
	    const auto v = _opts._sigma;

	    c1 = 2.0 * v;
	    c2 = log(1.0) - log(2.0 * v * M_PI) / 2.0;
	}

    /// Select an initial value close to the mean.
    virtual void InitialValue ( const FLOAT  maxAge )
	{
	    std::normal_distribution<FLOAT > dist(_opts._mu,
						  _opts._mu / 100.0);
	    std::function<FLOAT ()> distFn = std::bind(dist, std::ref(_repl->_statsObj->RandomGen()));
	    _age =  DrawAge(distFn, maxAge, _opts);
	}

    virtual FLOAT  operator()   ( const FLOAT  age ) const
	{
	    return  c2 - pow(age - _opts._mu, 2) / c1;
	}

    FLOAT  c1;					  ///< \f$2 \sigma^2\f$
    FLOAT  c2;					  ///< \f$log(1) - \frac{\log(2\sigma^2 \pi)}{2} + \frac{\mu^2}{2 \sigma^2}\f$

};

// *****************************************************************************

Calibration::Data *
Calibration::Data::Factory ( const Opts &  o )
{
    switch ( o._cType ) {

	case Options::CalType::LOWER_BOUND:
	    return new LowerBound(o);

	case Options::CalType::UPPER_BOUND:
	    return new UpperBound(o);

	case Options::CalType::LOWER_UPPER:
	    return new LowerUpperBound(o);

	case Options::CalType::GAMMA_DIST:
	    return new GammaDistributed(o);

	case Options::CalType::NORMAL_DIST:
	    return new NormallyDistributed(o);

	default:
	    assert(0 && "Unknown calibration type");

    }

    return nullptr;				  // Stupid microsoft compiler
}

// *****************************************************************************

Calibration::Data *
Calibration::Data::Replicate ( const Calibration::Data * d,
			       struct Replicate &        repl )
{

    /// - Update the calibration vector in the replicate.

    repl._calsIncluded[d->_opts._id] = true;

    /// - Create the appropriate type of calibration node.

    switch ( d->_opts._cType ) {

	case Options::CalType::LOWER_BOUND:
	    return new LowerBound(*d, repl);

	case Options::CalType::UPPER_BOUND:
	    return new UpperBound(*d, repl);

	case Options::CalType::LOWER_UPPER:
	    return new LowerUpperBound(*d, repl);

	case Options::CalType::GAMMA_DIST:
	    return new GammaDistributed(*d, repl);

	case Options::CalType::NORMAL_DIST:
	    return new NormallyDistributed(*d, repl);

	default:
	    assert(0 && "Unknown calibration type");

    }

    return nullptr;				  // Stupid microsoft compiler
}

// *****************************************************************************

std::string
Calibration::Data::str ( const std::string hdg )
    const
{
    std::stringstream ss;
    if ( hdg.size() ) ss << hdg << "<";

    ss << Dump::str(_age, "age") << ' '
       << _opts.str("opts");

    if ( hdg.size() ) ss << ">";
    return ss.str();
}

// *****************************************************************************
/// Constructor for the calibration option object.
/// @throw Except::BadOpt Invalid calibration type.
/// @throw Except::BadCalibrationOpt Invalid calibration option.

Calibration::Opts::Opts( const std::list<Taxa*>&              to,   ///< List of taxa objects
			 const std::vector<Options::CalOpt*>& opts, ///< Options
			 const std::string&                   l,    ///< Label for the calibration node
			 unsigned                             id )  ///< calibration id
    : _taxaObjs(to),
      _label(l),
      _id(id),
      _minAge(Calibration::minAge),
      _leftMass(0.025),
      _maxAge(Calibration::maxAge),
      _rightMass(0.025),
      _offset(0.05),
      _scale(1.0),
      _alpha(0.0),
      _beta(0.0),
      _mu(0.0),
      _sigma(0.0)
{

    bool calType = false;
    bool min = false;
    bool max = false;
    bool left = false;
    bool right = false;
    bool offset = false;
    bool scale = false;
    bool alpha = false;
    bool beta = false;
    bool mu = false;
    bool sigma = false;

    for ( auto p: opts )

	switch ( p->type ) {

	    case Options::CalOptType::Type:
		_cType = p->data.calType;
		calType = true;
		break;
	    case Options::CalOptType::MinAge:
		_minAge = p->data.doubleVal;
		min = true;
		break;
	    case Options::CalOptType::MaxAge:
		_maxAge = p->data.doubleVal;
		max = true;
		break;
  	    case Options::CalOptType::LeftMass:
		_leftMass = p->data.doubleVal;
		left = true;
		break;
	    case Options::CalOptType::RightMass:
		_rightMass = p->data.doubleVal;
		right = true;
		break;
	    case Options::CalOptType::Offset:
		_offset = p->data.doubleVal;
		offset = true;
		break;
	    case Options::CalOptType::Scale:
		_scale = p->data.doubleVal;
		scale = true;
		break;
	    case Options::CalOptType::Mu:
		_mu = p->data.doubleVal;
		mu = true;
		break;
	    case Options::CalOptType::Sigma:
		_sigma = p->data.doubleVal;
		sigma = true;
		break;
	    case Options::CalOptType::Alpha:
		_alpha = p->data.doubleVal;
		alpha = true;
		break;
	    case Options::CalOptType::Beta:
		_beta = p->data.doubleVal;
		beta = true;
		break;
	    default:
		throw Except::BadOpt(p->type);

	}

    /// - Validate the parameters

    if ( !calType )
	throw Except::BadCalibrationOpt("Calibration type not specified");

    switch ( _cType ) {

	case Options::CalType::LOWER_BOUND:
	    if ( alpha || beta || mu || sigma )
		throw Except::BadCalibrationOpt("Do not specify statistical parameters for a lower bound only calibration.");
	    if ( max )
		throw Except::BadCalibrationOpt("Do not specify maximum age for lower bound only calibration.");
	    if ( right )
		throw Except::BadCalibrationOpt("Do not specify mass to the right of an upper bound for lower bound only calibration.");
	    if ( !min )
		throw Except::BadCalibrationOpt("The minimum calibration age must be specified a lower bound only calibration.");
	    break;

	case Options::CalType::UPPER_BOUND:
	    if ( alpha || beta || mu || sigma || offset || scale )
		throw Except::BadCalibrationOpt("Do not specify statistical parameters for an upper bound only calibration.");
	    if ( min )
		throw Except::BadCalibrationOpt("Do not specify minimum age for upper bound only calibration.");
	    if ( left )
		throw Except::BadCalibrationOpt("Do not specify mass to the left of a lower bound for an upper bound only calibration.");
	    if ( !max )
		throw Except::BadCalibrationOpt("The maxiumum calibration age must be specified an upper bound only calibration.");
	    break;

	case Options::CalType::LOWER_UPPER:
	    if ( alpha || beta || mu || sigma || offset || scale )
		throw Except::BadCalibrationOpt("Do not specify statistical parameters for an upper bound only calibration.");
	    if ( !max || !min )
		throw Except::BadCalibrationOpt("Both minimum and maxiumum calibration ages must be specified on an lower/upper bound calibration.");
	    break;

	case Options::CalType::GAMMA_DIST:
	    if ( !alpha || !beta )
		throw Except::BadCalibrationOpt("The alpha and beta parameters must be specified for the gamma distribution");
	    if ( min || max || left || right || offset || scale || mu || sigma )
		throw Except::BadCalibrationOpt("Only the alpha and beta parameters may be specified for the gamma distribution");
	    break;

	case Options::CalType::NORMAL_DIST:
	    if ( !mu || !sigma )
		throw Except::BadCalibrationOpt("The mean and variance parameters must be specified for the normal distribution");
	    if ( min || max || left || right || offset || scale || alpha || beta )
		throw Except::BadCalibrationOpt("Only the mean and variance parameters may be specified for the normal distribution");
	    break;

	default:
	    throw Except::BadCalibrationOpt("Invalid calibration type");

    }

}

// *****************************************************************************
/// Output the calibration to the log

void
Calibration::Opts::Log( Logger & logger )         ///< Pointer to the logger instance
    const
{

    std::string descendents;
    for ( auto txp : _taxaObjs ) {
	if (!descendents.empty())
	    descendents += ", ";
	descendents += txp->_label.c_str();
    }

    logger.Log("%*c%04d: %s%sDescendents: %s",
	       logger.indent, ' ' ,
	       _id + 1,
	       _label.empty() ? "" : _label.c_str(),
	       _label.empty() ? "" : ", ",
	       descendents.c_str());

    std::string opts = "Type: " + CalibrationTypes[_cType];

    auto makeOpt = [] (const char * title, const FLOAT val) {
	std::stringstream ss;
	ss << title << ": " << val;
	return ss.str();
    };

    switch (_cType) {
	case Options::CalType::LOWER_BOUND:
	    opts += makeOpt(", Min Age", _minAge);
	    opts += makeOpt(", Left Mass", _leftMass);
	    opts += makeOpt(", Offset", _offset);
	    opts += makeOpt(", Scale", _scale);
	    break;

	case Options::CalType::UPPER_BOUND:
	    opts += makeOpt(", Max Age", _maxAge);
	    opts += makeOpt(", Right Mass", _rightMass);
	    break;

	case Options::CalType::LOWER_UPPER:
	    opts += makeOpt(", Min Age", _minAge);
	    opts += makeOpt(", Left Mass", _leftMass);
	    opts += makeOpt(", Max Age", _maxAge);
	    opts += makeOpt(", Right Mass", _rightMass);
	    break;

	case Options::CalType::GAMMA_DIST:
	    opts += makeOpt(", Alpha", _alpha);
	    opts += makeOpt(", Beta", _beta);
	    break;

	case Options::CalType::NORMAL_DIST:
	    opts += makeOpt(", Mean", _mu);
	    opts += makeOpt(", Variance", _sigma);
	    break;
    }

    logger.Log("%*c%s", logger.indent + 6, ' ', opts.c_str());

}

// *****************************************************************************

std::string
Calibration::Opts::str ( const std::string hdg )
    const
{
    std::stringstream ss;
    if ( hdg.size() ) ss << hdg << "<";

    ss << Dump::str(_label, "label") << ' '
       << Dump::str(_id, "id") << ' '
       << Dump::str(CalibrationTypes[_cType], "cType") << ' ';

    ss << Dump::str(_minAge, "minAge") << ' '
       << Dump::str(_maxAge, "maxAge") << ' '
       << Dump::str(_leftMass, "leftMass") << ' '
       << Dump::str(_rightMass, "rightMass") << ' '
       << Dump::str(_offset, "offset") << ' '
       << Dump::str(_scale, "scale") << ' '
       << Dump::str(_alpha, "alpha") << ' '
       << Dump::str(_beta, "beta") << ' '
       << Dump::str(_mu, "mu") << ' '
       << Dump::str(_sigma, "sigma") << ' ';

    ss << Taxa::str(_taxaObjs, "taxaObjs");

    if ( hdg.size() ) ss << ">";
    return ss.str();
}

// *****************************************************************************

std::string
Calibration::str ( const std::list<Calibration::Data*> & l,
		   const std::string                     hdg )
{
    std::stringstream ss;
    if ( hdg.size() ) ss << hdg << "<";

    for ( auto c : l )
        ss << Dump::pstr(c, "Calibration") << '\n';

    if ( hdg.size() ) ss << ">";
    return ss.str();
}
