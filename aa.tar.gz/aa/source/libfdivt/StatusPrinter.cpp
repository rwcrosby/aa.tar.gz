/// @file StatusPrinter.cpp
/// Definitions for the status printer methods.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include "Logger.h"
#include "StatusPrinter.h"

using namespace std;
using namespace std::chrono;

/// Print interval.
/// Maximum time in seconds between status lines.
static const duration<FLOAT > printPeriod (600);

/// Status line format
/// Iteration Percent Elapsed LnL Remaining
static const char * statusFormat("%7d %8.2f%% %3d:%02d:%02d %3d:%02d:%02d %14.3f %12.3f %5.1f%% %5.1f%% %5.1f%%");


/// milliseconds in a minute
static const int secondsInMinute = 1000 * 60;
/// milliseconds in an hour
static const int minutesInHour   = 60 * secondsInMinute;


// *****************************************************************************
/// Print the  status line.

/// @param gen Current mcmc generation
/// @param lnP Log of the posterior
/// @param lnL Log Likelihood
/// @param ageAccept Acceptance ratio for age proposals
/// @param rateAccept Acceptance ratio for rate proposals
/// @param otherAccept Acceptance ratio for nuisance parameter proposals
/// @param currPt Current time point
///

void
StatusPrinter::PrintLine ( unsigned                              gen,
			   FLOAT                                 lnP,
			   FLOAT                                 lnL,
			   FLOAT                                 ageAccept,
			   FLOAT                                 rateAccept,
			   FLOAT                                 otherAccept,
			   std::chrono::steady_clock::time_point currPt )
{

    auto elapsed   = duration_cast< duration<int, std::ratio<1,1000> > >
        (currPt - _startPt);
    auto remaining = duration_cast< duration<int, std::ratio<1,1000> > >
        (float(_nGen - gen) * (currPt - _startPt) / float(gen));

    auto eHr  = duration_cast<hours>   (elapsed);
    auto eMin = duration_cast<minutes> (elapsed % minutesInHour);
    auto eSec = duration_cast<seconds> (elapsed % secondsInMinute);

    auto rHr  = duration_cast<hours>   (remaining);
    auto rMin = duration_cast<minutes> (remaining % minutesInHour);
    auto rSec = duration_cast<seconds> (remaining % secondsInMinute);

    _logger.Log( statusFormat,
                 gen,
                 (float)gen/(float)_nGen * 100.0,
                 eHr.count(), eMin.count(), eSec.count(),
                 rHr.count(), rMin.count(), rSec.count(),
		 lnP,
		 lnL,
		 ageAccept * 100.0,
		 rateAccept * 100.0,
		 otherAccept * 100.0 );

}

// *****************************************************************************
/// Constructor for the status line printer.

/// Setup the timer

StatusPrinter::StatusPrinter( Logger &  lg,
                              unsigned  nGen )
    : _logger(lg),
      _nGen(nGen),
      _firstPeriod(true),
      _startPt(steady_clock::now())
{
    _logger.Log("          Percent   ------Time-------  --All Chains/Replicates---  -Acceptance Ratios-");
    _logger.Log("   Step  Complete   Elapsed Remaining  ln(Posterior)        ln(L)   Ages  Rates  Other");

}

// *****************************************************************************

void
StatusPrinter::operator()( unsigned gen,
			   FLOAT    lnP,
			   FLOAT    lnL,
			   FLOAT    ageAccept,
			   FLOAT    rateAccept,
			   FLOAT    otherAccept )
{

    gen++;                                    // Make it 1 relative

    steady_clock::time_point currPt = steady_clock::now();

    // If the number of generations requested is less than 100 just print the final line
    if ( _nGen < 100 ) {
        if ( gen == _nGen )
            PrintLine(gen, lnP, lnL, ageAccept, rateAccept, otherAccept, currPt);
        return;
    }

    // If we haven't printed the first line yet, just accumulate data
    if (_firstPeriod) {

        if ( !(gen % (_nGen / 100)) ) {
	    PrintLine(gen, lnP, lnL, ageAccept, rateAccept, otherAccept, currPt);
            _byPercent = true;
            _firstPeriod = false;
        }
        else {
            duration<FLOAT > sinceStart = duration_cast< duration<FLOAT > >(currPt - _startPt);

            if ( sinceStart > printPeriod ) {
		PrintLine(gen, lnP, lnL, ageAccept, rateAccept, otherAccept, currPt);
                _periodStartPt = currPt;
                _byPercent     = false;
                _firstPeriod   = false;
            }
        }

    }

    // We know if we're printing by percent or time...
    else {

        if (_byPercent) {
            if ( !(gen % (_nGen / 100) ) )
		PrintLine(gen, lnP, lnL, ageAccept, rateAccept, otherAccept, currPt);
        }
        else {
            duration<FLOAT > sinceLastPrint = duration_cast< duration<FLOAT > >(currPt - _periodStartPt);

            if ( sinceLastPrint > printPeriod ) {
		PrintLine(gen, lnP, lnL, ageAccept, rateAccept, otherAccept, currPt);
                _periodStartPt = currPt;
            }

        }

    }

}
