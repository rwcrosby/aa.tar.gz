/// @file EvoModel.cpp
/// Definitions for the base evolutionary model methods and functions.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include <iostream>
#include <iomanip>
#include <map>

#include "Config.h"
#include "DivTime.h"
#include "Dump.h"
#include "Except.h"
#include "EvoModel.h"
#include "EvoModelCpu.h"
#ifdef OPENCL
#include "EvoModelGpu.h"
#endif
#include "EvoModelParameters.h"
#include "Locus.h"
#include "Logger.h"
#include "MBUtils.h"
#include "Replicates.h"
#include "SequenceFactory.h"
#include "TransitionMatrix.h"
#include "StatsFn.h"

// *****************************************************************************
// Local function prototypes

static
void
FrequencyParmsCheck ( const std::string model,
                      DivTime&          dt );
static
void
FrequencyParmsLog   ( const DivTime&    dt );

static
void
KappaParmCheck      ( const std::string model,
		      DivTime&          dt );

static
void
KappaParmLog        ( const DivTime&    dt );

// *****************************************************************************
/// Map to generate descriptions for the evolutionary models

static std::map<Options::EvoModel, std::string> ModelNames = {
    {Options::EvoModel::JC69,  "JC69 - Jukes Cantor Basic Model"},
    {Options::EvoModel::K80,   "K80 - Kimura 1 Parameter Model"},
    {Options::EvoModel::F81,   "F81 - Felsenstein 1981 Model"},
    {Options::EvoModel::F84,   "F84 - Felsenstein 1984 Model"},
    {Options::EvoModel::HKY85, "HKY85 - Hasegawa-Kishino-Yano 1985 Model"},
    {Options::EvoModel::T92,   "T92 - Tamura 1992 Model"},
    {Options::EvoModel::TN93,  "TN93 - Tamura-Nei 1993 Model"},
    {Options::EvoModel::GTR,   "GTR - Generalized Time Reversable"},
};

// *****************************************************************************
/// Setup the Q rate matrix for the GTR model.

static
void
ComputeQMatrixGTR ( DirichletParameterSet * modelParms,
		    DirichletParameterSet * freqParms,
		    FLOAT  ** Q )
{
    const FLOAT  a = modelParms->_values[0];
    const FLOAT  b = modelParms->_values[1];
    const FLOAT  c = modelParms->_values[2];
    const FLOAT  d = modelParms->_values[3];
    const FLOAT  e = modelParms->_values[4];
    const FLOAT  f = modelParms->_values[5];

    const FLOAT  T = freqParms->_values[0];
    const FLOAT  C = freqParms->_values[1];
    const FLOAT  A = freqParms->_values[2];
    const FLOAT  G = freqParms->_values[3];

    Q[0][1] = a * C;
    Q[0][2] = b * A;
    Q[0][3] = c * G;
    Q[0][0] = - Q[0][1] - Q[0][2] - Q[0][3];

    Q[1][0] = a * T;
    Q[1][2] = d * A;
    Q[1][3] = e * G;
    Q[1][1] = - Q[1][0] - Q[1][2] - Q[1][3];

    Q[2][0] = b * T;
    Q[2][1] = d * C;
    Q[2][3] = f * G;
    Q[2][2] = - Q[2][0] - Q[2][1] - Q[2][3];

    Q[3][0] = c * T;
    Q[3][1] = e * C;
    Q[3][2] = f * A;
    Q[3][3] = - Q[3][0] - Q[3][1] - Q[3][2];
}

// *****************************************************************************
/// Mr Bayes uses a pointer array to FLOAT  array format for matricies.
/// This routine sets the first N members of the FLOAT  input vector to point to the
/// "rows" of the matrix in the following elements of the input vector.

inline
void
MakeMBMatrix( const int n,
              FLOAT *   m,
              FLOAT **  mb )
{
    for ( int i = 0; i < n; i++ )
        *mb++ = m + i * n;
}

// *****************************************************************************

EvoModel::EvoModel( EvoModelRoot &    parent,
                    Tree::LocusRoot & lRoot )
    : _repl(parent._repl),
      _parent(parent),
      _lRoot(lRoot),
      _alpha(nullptr)
{

    /// - Create and add the \f$\alpha\f$ parameter for the variation

    if ( GammaRates() )
        _alpha = new GCatAlphaParameter ( *this,
					  _repl._dt._eMGammaParms[0],
					  _repl._dt._eMGammaParms[1],
					  "Rate Categories Alpha",
					  "Rate_Cat_Alpha");
    parent._eModelList.push_back(this);
}

// *****************************************************************************

EvoModel::~EvoModel()
{
    delete _alpha;
}

// *****************************************************************************

std::string
EvoModel::str( const std::string hdg ) const
{

    std::stringstream ss;
    if ( GammaRates() )
	ss << Dump::str(*_alpha, " alpha")
	   << Dump::str(_rateVec, " rateVec");
    return ss.str();

}

// *****************************************************************************

void
EvoModel::UpdateAllTMatrixes()
{
    for ( auto tMat : _tMatrixList )
	UpdateTMatrix(tMat);
}

// *****************************************************************************
void
EvoModel::ComputeGTRLocusConstants ( DirichletParameterSet * modelParms,
				     DirichletParameterSet * freqParms,
				     FLOAT  *                cMat,
				     FLOAT  *                Wr )
{

    static const unsigned    N = 4;

    /// - Generate the Q rate matrix

    FLOAT   Q[N*N];                                // Rate matrix
    FLOAT * Qmb[N];                                // Vector of pointer to vectors
    MakeMBMatrix(N, Q, Qmb);                       // Convert to Mr. Bayes format
    ComputeQMatrixGTR(modelParms, freqParms, Qmb); // Get the rate matrix

    /// - Compute the eigen system using the current parameter values

    int    iWork[N];
    FLOAT  dWork[N];

    FLOAT    V[N*N];                              // Eigenvectors
    FLOAT *  Vmb[N];
    MakeMBMatrix(N,V, Vmb);
    FLOAT    Wi[N];                               // Imaginary part of the eigenvalues
    auto rc = MrBayes::EigensForRealMatrix (N, Qmb, Wr, Wi, Vmb, iWork, dWork );

    /// - Complex eigenvalues are not expected so throw an error if they are returned.

    if ( rc )
        throw Except::NumericError("Error in computation of eigen system");

    for ( unsigned i = 0; i < N; i++ )
        if ( !MrBayes::IsZero(Wi[i]) )
            throw Except::NumericError("Complex eigenvalues found");

    /// - Copy the Eigenvector matrix so the inversion doesn't destroy the original

    FLOAT   Vc[N*N];                             // Copy of the matrix
    FLOAT * Vcmb[N];
    MakeMBMatrix(N,Vc, Vcmb);
    memcpy(Vc, V, sizeof(FLOAT ) * N * N);

    /// - Compute the inverse of the eigen vector matrix

    FLOAT   Vi[N*N];                             // Eigenvector inverse
    FLOAT * Vimb[N];
    MakeMBMatrix(N,Vi, Vimb);                    // In Mr. Bayes format
    rc = MrBayes::InvertMatrix(N, Vcmb, dWork, iWork, Vimb);

    /// - Generate the constant multiplier matrix

    FLOAT  *v = cMat;
    for ( unsigned i = 0; i < N; i++ )
        for ( unsigned j = 0; j < N; j++ )
            for ( unsigned k = 0; k < N; k++ )
                *v++ = Vmb[i][k] * Vimb[k][j];

}

// *****************************************************************************
/// Create character frequency parameters.

DirichletParameterSet *
EvoModel::FrequencyParmsSetup ( EvoModel&        eModel,
				const FLOATVEC & initValues,
				const FLOATVEC & hyperParms )
{

    /// - Setup the headings for the trace file

    STRINGVEC hdgs;
    for ( auto ch : eModel._repl._dt._seqFactory->_alphabet )
	hdgs.emplace_back(1, ch);

    /// - Create the frequency parameters and set initial values

    DirichletParameterSet * dpsParms = new DirichletParameterSet( eModel,
								  initValues,
								  hyperParms,
								  "Freq",
								  hdgs );

    return dpsParms;

}

// *****************************************************************************

EvoModelRoot::EvoModelRoot ( Replicate&  repl,
			     Tree::Root& root )
    : _repl(repl),
      _root(root),
      _nGCat(_repl._dt._eMGammaCats),
      _n(_repl._dt._seqFactory->_alphabet.size())
{

    /// - Assure that we only handle nucleotides

    if ( _n != 4 )
        throw Except::ModelError("At this time only DNA is supported, the number of characters must equal 4");

}

// *****************************************************************************

void
EvoModelRoot::CheckParms( DivTime& dt )
{

    switch (dt._eModel) {

	case Options::EvoModel::JC69:
	    if ( dt._eMParms.size() )
		(*dt._logger)("Model parms specified for JC69 model - ignored");

	    if ( dt._eMFreqParms.size() )
		(*dt._logger)("Character frequency parms specified for JC69 model - ignored");

	    break;

	case Options::EvoModel::K80:
	    KappaParmCheck( "K80", dt);

	    if ( dt._eMFreqParms.size() )
		(*dt._logger)("Character frequency parms specified for JC69 model - ignored");

	    break;

	case Options::EvoModel::F81:
	    if ( dt._eMParms.size() )
		(*dt._logger)("Model parameters specified for F81 model - ignored");

	    FrequencyParmsCheck("F81", dt);
	    break;

	case Options::EvoModel::F84:
	    KappaParmCheck( "F84", dt);
	    FrequencyParmsCheck( "F84", dt);
	    break;

	case Options::EvoModel::HKY85:
	    KappaParmCheck( "HKY85", dt);
	    FrequencyParmsCheck( "HKY85", dt);
	    break;

	case Options::EvoModel::T92:
	    KappaParmCheck( "T92", dt);

	    if ( dt._eMFreqParms.size() != 0 &&
		 dt._eMFreqParms.size() != 2 )
		throw Except::ModelError("Either no GC frequency parameters or both alpha and beta are required for the T92 model");

	    break;

	case Options::EvoModel::TN93:
	    if ( dt._eMParms.size() == 0 )
		dt._eMParms = {1,1,1,1};
	    else if ( dt._eMParms.size() != 4 )
		throw Except::ModelError("Either no parameters or kappa1/kappa2  alpha and beta are required for the TN93 model");
	    else {
		if ( dt._eMParms[0] <= 0.0 || dt._eMParms[0] >= 100.0  )
		    throw Except::ModelError("Kappa1 alpha model parameter must be 0.0 < a < 100.0");
		if ( dt._eMParms[1] <= 0.0 )
		    throw Except::ModelError("Kappa1 beta model parameter must be > 0.0");
		if ( dt._eMParms[2] <= 0.0 || dt._eMParms[2] >= 100.0 )
		    throw Except::ModelError("Kappa2 alpha model parameter must be 0.0 < a < 100.0");
		if ( dt._eMParms[3] <= 0.0 )
		    throw Except::ModelError("Kappa2 beta model parameter must be > 0.0");
	    }

	    FrequencyParmsCheck( "TN93", dt);
	    break;

	case Options::EvoModel::GTR:
	    if ( dt._eMParms.size() == 0 )
		dt._eMParms = {1,1,1,1,1,1};
	    else if ( dt._eMParms.size() != 6 )
		throw Except::ModelError("Either no parameters or all 6 parameters are required for the GTR model");

	    FrequencyParmsCheck( "GTR", dt);
	    break;

	default:
	    std::stringstream ss;
	    ss << "Invalid model requested: "
	       << (unsigned char)dt._eModel;

	    throw Except::ModelError(ss.str());

    }

    EvoModelRoot::CheckParms_G(dt);

}

// *****************************************************************************

void
EvoModelRoot::CheckParms_G( DivTime& dt )
{

    if ( dt._eMGammaCats == 1 ) {
        if ( dt._eMGammaParms.size() != 0 )
            (*dt._logger)("Gamma alpha/beta specified for non-discrete gamma model - ignored");
        return;
    }

    if ( dt._eMGammaCats == 0 )
        dt._eMGammaCats = 4;

    if ( dt._eMGammaParms.size() == 0 )
        dt._eMGammaParms = {1,1};
    else if ( dt._eMGammaParms.size() != 2 )
        throw Except::ModelError("Gamma alpha and beta must both be specified");

}

// *****************************************************************************

void
EvoModelRoot::Default ( DivTime & dt)
{
    dt._eModel      = Options::EvoModel::JC69;
    dt._eMGammaCats = 1;
}

// *****************************************************************************

EvoModelRoot *
EvoModelRoot::Factory( Replicate &  repl,
		       Tree::Root & root )
{

#ifdef OPENCL
    if ( repl._gpuRepl )
	return EvoModelRootGpu::Factory(repl, root);
#endif

    return EvoModelRootCpu::Factory(repl, root);

}

// *****************************************************************************

void
EvoModelRoot::Log( const DivTime& dt )
{

    (*dt._logger)("%-40s: %s", "Evolutionary Model", ModelNames[dt._eModel].c_str());

    switch (dt._eModel) {

	case Options::EvoModel::JC69:
	    break;

	case Options::EvoModel::K80:
	    KappaParmLog(dt);
	    break;

	case Options::EvoModel::F81:
	    FrequencyParmsLog(dt);
	    break;

	case Options::EvoModel::F84:
	    KappaParmLog(dt);
	    FrequencyParmsLog(dt);
	    break;

	case Options::EvoModel::HKY85:
	    KappaParmLog(dt);
	    FrequencyParmsLog(dt);
	    break;

	case Options::EvoModel::T92:
	    KappaParmLog( dt);

	    (*dt._logger)("%*c%-s", Logger::indent, ' ', "GC Freq Hyperparameters");
	    if ( dt._eMFreqParms.size() == 0 )
		(*dt._logger)("%*c%s", Logger::indent * 2, ' ', "Set From Data");
	    else {
		(*dt._logger)("%*c%-*s: %g", Logger::indent * 2, ' ', Logger::hdgWidth - Logger::indent * 2, "Alpha", dt._eMFreqParms[0]);
		(*dt._logger)("%*c%-*s: %g", Logger::indent * 2, ' ', Logger::hdgWidth - Logger::indent * 2, "Beta",  dt._eMFreqParms[1]);
	    }
	    break;

	case Options::EvoModel::TN93:
	    (*dt._logger)("%*c%s", Logger::indent, ' ', "Kappa1 Hyperparameters");
	    (*dt._logger)("%*c%-*s: %g", Logger::indent * 2, ' ', Logger::hdgWidth - Logger::indent * 2, "Alpha", dt._eMParms[0]);
	    (*dt._logger)("%*c%-*s: %g", Logger::indent * 2, ' ', Logger::hdgWidth - Logger::indent * 2, "Beta",  dt._eMParms[1]);
	    (*dt._logger)("%*c%s", Logger::indent, ' ', "Kappa2 Hyperparameters");
	    (*dt._logger)("%*c%-*s: %g", Logger::indent * 2, ' ', Logger::hdgWidth - Logger::indent * 2, "Alpha", dt._eMParms[2]);
	    (*dt._logger)("%*c%-*s: %g", Logger::indent * 2, ' ', Logger::hdgWidth - Logger::indent * 2, "Beta",  dt._eMParms[3]);

	    FrequencyParmsLog( dt);
	    break;

	case Options::EvoModel::GTR:
	    (*dt._logger)("%*c%s", Logger::indent, ' ', "Model Hyperparameters");
	    (*dt._logger)("%*c%-*s: %g", Logger::indent * 2, ' ', Logger::hdgWidth - Logger::indent * 2, "Alpha", dt._eMParms[0]);
	    (*dt._logger)("%*c%-*s: %g", Logger::indent * 2, ' ', Logger::hdgWidth - Logger::indent * 2, "Beta", dt._eMParms[1]);
	    (*dt._logger)("%*c%-*s: %g", Logger::indent * 2, ' ', Logger::hdgWidth - Logger::indent * 2, "Gamma", dt._eMParms[2]);
	    (*dt._logger)("%*c%-*s: %g", Logger::indent * 2, ' ', Logger::hdgWidth - Logger::indent * 2, "Delta", dt._eMParms[3]);
	    (*dt._logger)("%*c%-*s: %g", Logger::indent * 2, ' ', Logger::hdgWidth - Logger::indent * 2, "Epsilon", dt._eMParms[4]);
	    (*dt._logger)("%*c%-*s: %g", Logger::indent * 2, ' ', Logger::hdgWidth - Logger::indent * 2, "Zeta", dt._eMParms[5]);

	    FrequencyParmsLog( dt);
	    break;

	default:
	    assert(0 && "Invalid Model");


    }

    EvoModelRoot::Log_G(dt);

}

// *****************************************************************************

void
EvoModelRoot::Log_G( const DivTime& dt )
{
    if ( dt._eMGammaCats > 1 ) {
        (*dt._logger)("%*cNumber of Discrete Gamma Categories  : %d", Logger::indent, ' ', dt._eMGammaCats);
        (*dt._logger)("%*cAlpha for Discrete Gamma          : %g", Logger::indent * 2, ' ', dt._eMGammaParms[0]);
        (*dt._logger)("%*cBeta for Discrete Gamma           : %g", Logger::indent * 2, ' ', dt._eMGammaParms[1]);
    }

}

// *****************************************************************************

std::string
EvoModelRoot::str( const std::string hdg )
    const
{
    std::stringstream ss;
    ss << Dump::str(_nGCat, "nGCat") << ' '
       << Dump::str(_n, "n");
    return ss.str();
}

// *****************************************************************************
/// Validate the frequency parameters

static
void
FrequencyParmsCheck ( const std::string model,
                      DivTime&          dt )
{

    if ( dt._eMFreqParms.size() == 0 )
	dt._eMFreqParms = {1,1,1,1};
    else if ( dt._eMFreqParms.size() != dt._seqFactory->_alphabet.size() )
        throw Except::ModelError("Either no frequencies or a frequency for each character state are required for the " + model + " model");

}

// *****************************************************************************
/// Log the frequency parameters

static
void
FrequencyParmsLog ( const DivTime& dt )
{

    (*dt._logger)("%*c%s", Logger::indent, ' ', "Character Frequency Hyperparameters");
    if ( dt._eMFreqParms.size() == 0 )
        (*dt._logger)("%*c%s", Logger::indent * 2, ' ', "Set From Data");
    else {
        unsigned i = 0;
        for ( auto f :  dt._eMFreqParms )
            (*dt._logger)( "%*c'%c'%*c: %f", Logger::indent * 2, ' ',
                           dt._seqFactory->_alphabet[i++],
                           Logger::hdgWidth - Logger::indent * 2 - 3, ' ', f );
    }

}

// *****************************************************************************
/// Check the kappa parameters

static
void
KappaParmCheck ( const std::string model,
                 DivTime&          dt )
{

    if ( dt._eMParms.size() == 0 )
        dt._eMParms = {1,1};
    else if ( dt._eMParms.size() != 2 )
        throw Except::ModelError("Either no parameters or both alpha and beta are required for the " + model + " model");
    else {
        if ( dt._eMParms[0] <= 0.0 || dt._eMParms[0] >= 100.0  )
            throw Except::ModelError("Alpha model parameter must be 0.0 < a < 100.0");
        if ( dt._eMParms[1] <= 0.0 )
            throw Except::ModelError("Beta model parameter must be greater than 0.0");
    }

}

// *****************************************************************************
/// Log the frequency parameters

static
void
KappaParmLog ( const DivTime& dt )
{
    (*dt._logger)("%*c%-s", Logger::indent, ' ', "Kappa Hyperparameters");
    (*dt._logger)("%*c%-*s: %g", Logger::indent * 2, ' ', Logger::hdgWidth - Logger::indent * 2, "Alpha", dt._eMParms[0]);
    (*dt._logger)("%*c%-*s: %g", Logger::indent * 2, ' ', Logger::hdgWidth - Logger::indent * 2, "Beta",  dt._eMParms[1]);
}
