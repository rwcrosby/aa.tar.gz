/// @file Parameter.cpp
/// Definitions for the parameter methods

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include <string>

#include "Parameter.h"
#include "Replicates.h"
#include "Tree.h"

// *****************************************************************************

namespace Dump {
    template<>
    std::string
    str( const Parameter & p,
	 const std::string hdg )
    {
	std::stringstream ss;
	ss << hdg << '<' << p.str() << '>';
	return ss.str();

    }

}

// *****************************************************************************

NuisanceParameter::NuisanceParameter ( Replicate &  repl,
				       Tree::Root & root )
    : Parameter(repl, root, ParmStats::NUISANCE),
      _prior(0.0),
      _oldPrior(0.0),
      _lnPN(root._lnPN)
{
}

// *****************************************************************************

void
NuisanceParameter::Accept()
{
    _repl._nuisanceAccepted++;
    Parameter::Accept();
}

// *****************************************************************************

void
NuisanceParameter::Reject()
{
    _repl._nuisanceRejected++;
    Parameter::Reject();
}

// *****************************************************************************

std::string
NuisanceParameter::str ()
    const
{
    std::stringstream ss;
    ss << Parameter::str() << ' '
       << Dump::str( _prior, _oldPrior ,"prior" ) << ' '
       << Dump::str( _lnPN, "lnPN" );
    return ss.str();
}
// *****************************************************************************

Parameter::Parameter( Replicate &    repl,
		      Tree::Root &   root,
		      const unsigned pType )
    : _id(repl._parmId++),
      _repl(repl),
      _root(root),
      _tInfo(nullptr),
      _pType(pType),
      _value(0.0),
      _oldValue(0.0)
{
    _repl._parmList.push_back(this);
    _repl._stats._parms[_pType]._n++;
}

// *****************************************************************************

FLOAT  Parameter::Sample()
{
    _tInfo->_sum += _value;
    return _value;
}

// *****************************************************************************

static const auto defaultDataSource = [] ( Tree::TraceInfo * ti ) { return ti->_parm->_value; };

void
Parameter::SetTraceInfo( Tree::TraceType   type,
			 Tree::DATASRC     dsource,
			 int               lId,
                         int               nId,
			 unsigned          idx,
                         const std::string label,
			 const std::string heading )
{

    std::stringstream ss;
    if ( lId >= 0 )
	ss << "L" << lId + 1 << '_';
    if ( nId >= 0 )
	ss << "N" << nId + 1 << '_';
    ss << heading;

    _tInfo = new Tree::TraceInfo ( _root, this, type, dsource, lId, nId, idx, label, ss.str());
    _root._traceList.push_back(_tInfo);
}

void
Parameter::SetTraceInfo( Tree::TraceType   type,
                         int               nId,
			 const std::string heading )
{
    SetTraceInfo ( type, defaultDataSource, -1, nId, 0, "", heading);
}

void
Parameter::SetTraceInfo( Tree::TraceType   type,
			 Tree::DATASRC     dsource,
			 int               lId,
			 unsigned          idx,
                         const std::string label,
			 const std::string heading )
{
    SetTraceInfo ( type, dsource, lId, -1, idx, label, heading);
}

void
Parameter::SetTraceInfo( Tree::TraceType   type,
			 int               lId,
                         const std::string label,
			 const std::string heading )
{
    SetTraceInfo ( type, defaultDataSource, lId, -1, 0, label, heading);
}

void
Parameter::SetTraceInfo( Tree::TraceType   type,
			 int               lId,
			 int               nId,
			 const std::string heading )
{
    SetTraceInfo ( type, defaultDataSource, lId, nId, 0, "", heading);
}

// *****************************************************************************

std::string
Parameter::str ()
    const
{
    std::stringstream ss;
    ss << Dump::str(typeid(*this).name()) << ' '
       << Dump::str(_id) << ' '
       << Dump::str(_value, _oldValue, "value");
    return ss.str();
}


// *****************************************************************************

void
Parameter::Accept()
{
    _repl.CommitProposal();
}

// *****************************************************************************

void
Parameter::Reject()
{
    _value = _oldValue;
    _repl.RollbackProposal();
}
