/// @file PAPI.cpp
/// Methods and helper classes in support of the
/// Papi performance library

// *************************************************************************

// Copyright© 2010-2012 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include <assert.h>
#include <papi.h>
#include <stdlib.h>
#include <iostream>
#include <iomanip>

#include "Except.h"
#include "Logger.h"
#include "PAPI.h"

/// Default set of PAPI Events to monitor.

static const std::vector<int> papiEvents = {
    PAPI_TOT_CYC,
    PAPI_TOT_INS,
};

/// Number of events

static const unsigned nEvents = sizeof(papiEvents) / sizeof(int);

/// Yes this is a global variable...groan.
/// It's needed by the function that returns the thread id.
/// This must be a function pointer as defined by the papi interface.

static PAPI* papiGlobal = nullptr;

// *****************************************************************************
/// Simple function to return the current thread id.

unsigned long
TnoFn ()
{
    return papiGlobal->_idMap.at(std::this_thread::get_id());
}

// *****************************************************************************
/// Generate an exception on a PAPI error

static
inline
void
ErrCheck ( int          rc,                       ///< PAPI return code
           const char * fn )                      ///< PAPI function called
{
    if ( rc != PAPI_OK )
        throw Except::PAPIError(fn, PAPI_strerror(rc));
}


// ****************************************************************************

PAPI::PAPI ( Logger & log)
    : _log(log)
{

    /// - Initialize the library.

    int rc = PAPI_library_init(PAPI_VER_CURRENT);
    if ( rc != PAPI_VER_CURRENT ) throw Except::PAPIError("PAPI_library_init",
							  std::to_string(rc).c_str());

    /// - Set parent thread id map entry.

    _idMap[std::this_thread::get_id()] = 0;

    /// - Initialize threading support

    papiGlobal = this;
    ErrCheck(PAPI_thread_init( TnoFn ), "PAPI_thread_init" );

    /// - Get the set of events to process, either the default or from the environment

    AddEvents();

}

// ****************************************************************************

PAPI::~PAPI ()
{

    for ( unsigned tno = 0; tno < _eventThreadTotals.size(); tno++ ) {

        _log.Log( "PAPI counters for thread %u", tno );

        for ( auto& event : _eventThreadTotals[tno] ) {

            PAPI_event_info_t info;
            ErrCheck( PAPI_get_event_info(event.first, &info),
                      "PAPI_get_event_info" );

        _log.Log("%*c%-*s: %-*s: %*ld",
                 Logger::indent, ' ',
                 14, info.symbol,
                 20, info.short_descr,
                 19, event.second );
        }

    }

    _log.Log( "PAPI counter totals" );
    for ( auto event : _events ) {
        try {

            PAPI_event_info_t info;
            ErrCheck( PAPI_get_event_info(event, &info),
                      "PAPI_get_event_info" );

            _log.Log("%*c%-*s: %-*s: %*ld",
                     Logger::indent, ' ',
                     14, info.symbol,
                     20, info.short_descr,
                     19, _eventTotals[event] );

        }
        catch (std::out_of_range e ) {
        }
    }

}

// ****************************************************************************

void
PAPI::AddEvents()
{

    char * envEvents = getenv("FDIVT_PAPI_EVENTS");

    if (envEvents ) {

	std::stringstream ss(envEvents);
	std::string eventName;
	while ( std::getline(ss, eventName, ',') ) {
	    int event;
	    ErrCheck(PAPI_event_name_to_code((char*)eventName.c_str(), &event),
		     "PAPI_event_name_to_code");
	    _events.push_back(event);
	}

    }

    else

	_events = papiEvents;

}

// *****************************************************************************

void
PAPI::AddThread( PAPIThread *    thread,
                 std::thread::id tid,
                 const unsigned  threadNo )
{

    std::unique_lock<std::mutex> lk(_mutex);

    _nThreads++;

    if ( _threads.size() <= threadNo ) {
        _threads.resize(threadNo + 1);
        _eventThreadTotals.resize(threadNo + 1);
    }
    _threads[threadNo] = thread;

    _idMap[tid] = threadNo;

}

// *****************************************************************************

void
PAPI::CopyThreadTotals( unsigned    threadNo,
                        INTVEC &    ids,
                        long long * ecounts)
{

    for ( unsigned i = 0; i < ids.size(); i++ ) {
        _eventThreadTotals[threadNo].emplace_back(ids[i], ecounts[i]);
        _eventTotals[ids[i]] += ecounts[i];
    }

}

// *****************************************************************************

void
PAPI::RemoveThread( std::thread::id tid,
                    const unsigned  threadNo )
{

    std::unique_lock<std::mutex> lk(_mutex);

    _threads[threadNo] = nullptr;
    _idMap.erase(tid);

}

// ****************************************************************************

PAPIThread::PAPIThread ( PAPI *         papi,
                         const unsigned threadNo )
    : _threadNo(threadNo), _eventSet(PAPI_NULL), _papi(*papi)
{

    ///< - Add the thread to the map and thread set in the parent object.

    _papi.AddThread( this,
                     std::this_thread::get_id(),
                     _threadNo );

    /// - Initialize PAPI for the thread.

    int rc = PAPI_register_thread();
    if ( rc != PAPI_OK ) {                        // Unwind PAPI state on error
        _papi.RemoveThread( std::this_thread::get_id(),
                            _threadNo );
        throw Except::PAPIError ( "PAPI_register_thread",
                                  PAPI_strerror(rc) );
    }

    /// - Create the PAPI event set.

    rc = PAPI_create_eventset(&_eventSet);
    if ( rc != PAPI_OK ) {                        // Unwind PAPI state on error
        PAPI_unregister_thread();
        _papi.RemoveThread( std::this_thread::get_id(),
                            _threadNo );
        throw Except::PAPIError ( "PAPI_create_eventset",
                                  PAPI_strerror(rc) );
    }

   /// - Add events for the thread.

    for ( auto event : papi->_events ) {

	int rc = PAPI_add_event(_eventSet, event);
	if ( rc == PAPI_ENOEVNT || rc == PAPI_ECNFLCT ) {
	    PAPI_event_info_t info;
	    ErrCheck( PAPI_get_event_info(event, &info),
		      "PAPI_get_event_info" );
	    papi->_log("Unable to add papi event %s, %d\n",  info.symbol, rc);
	    continue;
	}
	ErrCheck(rc, "PAPI_add_event");

	_eventIds.push_back(event);

    }

    /// - Start event recording.

    rc = PAPI_start(_eventSet);
    if ( rc != PAPI_OK ) {                        // Unwind PAPI state on error
        PAPI_cleanup_eventset(_eventSet);
        PAPI_destroy_eventset(&_eventSet);
        PAPI_unregister_thread();
        _papi.RemoveThread( std::this_thread::get_id(),
                            _threadNo );
        throw Except::PAPIError ( "PAPI_start",
                                  PAPI_strerror(rc) );
    }


}

// ****************************************************************************

PAPIThread::~PAPIThread ()
{

    long long ec[nEvents];

    /// - Stop recording

    ErrCheck( PAPI_stop(_eventSet, ec), "PAPI_stop" );

    /// - Copy to parent instance.

    _papi.CopyThreadTotals( _threadNo, _eventIds, ec);

    /// - Cleanup the interface.

    ErrCheck( PAPI_cleanup_eventset(_eventSet),  "PAPI_cleanup_eventset" );
    ErrCheck( PAPI_destroy_eventset(&_eventSet), "PAPI_destroy_eventset" );
    ErrCheck( PAPI_unregister_thread(),          "PAPI_unregister_thread" );

    /// - Remove mapping

    _papi.RemoveThread( std::this_thread::get_id(),
                        _threadNo );


}

#if 0

#endif
