/// @file PAPI.h
/// Interface to the papi performance library

// *************************************************************************

// Copyright© 2010-2012 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef PAPI_H
#define PAPI_H

#include <list>
#include <map>
#include <mutex>
#include <thread>

#include "Config.h"

class  Logger;
class  PAPI;

// ****************************************************************************
/// PAPI Per Thread Information.

class PAPIThread
{

    const unsigned              _threadNo;	  ///< My thread number
    int                         _eventSet;        ///< PAPI event set handle
    PAPI &                      _papi;            ///< Parent papi object

    INTVEC                      _eventIds;        ///< Set of PAPI event id's for this thread

    friend class PAPI;

public:

    /// Constructor to build the thread level object.
    /// @param papi Owning parent object
    /// @param threadNo My thread number
    /// @throw PAPIError Error returned from PAPI call.
    PAPIThread( PAPI *         papi,
                const unsigned threadNo );

    /// Delete the thread object accumulating the counters to the parent PAPI object.
    /// @throw PAPIError Error returned from PAPI call.

    ~PAPIThread();

};

// *****************************************************************************
/// Papi library interface

class PAPI {

    unsigned                   _nThreads;	  ///< Number of threads

    std::vector<int>           _events;		  ///< Set of papi events to use

    std::vector<PAPIThread*>   _threads;          ///< Thread information array
    std::map<std::thread::id,
             unsigned>        _idMap;             ///< Convert system to my id's

    std::map<int,
             long long>       _eventTotals;       ///< Map of event types to counts

    Logger &                  _log;               ///< Log to output to.

    std::mutex                _mutex;             ///< Protect updates to the maps

    std::vector< std::list<std::pair<int, long long >>>
                             _eventThreadTotals; /// - Totals for each thread

    /// Add newly created thread to appropriate lists.
    /// @param thread Thread block pointer.
    /// @param tid C++ thread identifier.
    /// @param threadNo My thread number
    void
    AddThread ( PAPIThread *    thread,
		std::thread::id tid,
		const unsigned  threadNo );

    /// Remove failed thread from the lists.
    /// @param tid C++ thread identifier
    /// @param threadNo My thread number
    void
    RemoveThread ( std::thread::id tid,
		   const unsigned  threadNo );

    /// Copy thread totals into master list.
    /// @param threadNo My thread number
    /// @param ids List of PAPI event id's
    /// @param ecounts Counters for the events
    void
    CopyThreadTotals ( unsigned    threadNo,
		       INTVEC &    ids,
		       long long * ecounts);

    void
    AddEvents();

public:

    /// Create the PAPI interface.
    /// @throw PAPIError Error returned from PAPI call.

    PAPI(Logger & log);                           ///< Logger to write the counters to.

    /// Destroy the interface logging the counters.
    /// @throw PAPIError Error returned from PAPI call.

    ~PAPI();

    friend class         PAPIThread;
    friend unsigned long TnoFn();

};

#endif // PAPI_H
