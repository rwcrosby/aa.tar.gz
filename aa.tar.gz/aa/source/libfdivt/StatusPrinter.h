/// @file StatusPrinter.h
/// Definition for the status line print routine

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _STATUSPRINTER_H_
#define _STATUSPRINTER_H_

#include <chrono>

class Logger;

/// Status line print routine.
/// Prints the status line either every 1% of the iterations or every
/// 10 minutes, whichever is smaller.

struct StatusPrinter {

    /// Create the status printer.
    /// Setup the timer and print headings.
    /// @param lg Logger instance to write to.
    /// @param nGen Total MCMC generations to be run.
    StatusPrinter ( Logger &  lg ,
                    unsigned  nGen );

    /// Operator to check for and possibly print the status line.
    /// Print the status line either every printPeriod or every 1 percent of the
    /// mcmc iterations.
    /// @param gen Current MCMC generation
    /// @param lnP Log of the posterior
    /// @param lnL Log of the likelihood
    /// @param ageAccept Percentante of age proposals accepted
    /// @param rateAccept Percentage of rate proposals accepted
    /// @param otherAccept Percentage of other proposals accepted
    void
    operator() ( unsigned gen,
		 FLOAT    lnP,
		 FLOAT    lnL,
		 FLOAT    ageAccept,
		 FLOAT    rateAccept,
		 FLOAT    otherAccept );

private:

    /// Print the  status line.
    /// @param gen Current mcmc generation
    /// @param lnL Log of the likelihood
    /// @param ageAccept Percentante of age proposals accepted
    /// @param rateAccept Percentage of rate proposals accepted
    /// @param otherAccept Percentage of other proposals accepted
    /// @param currPt Current time point.
    void
    PrintLine  ( unsigned gen,
		 FLOAT    lnP,
		 FLOAT    lnL,
		 FLOAT    ageAccept,
		 FLOAT    rateAccept,
		 FLOAT    otherAccept,
		 std::chrono::steady_clock::time_point currPt );

    Logger &       _logger;                       ///< Reference to the output logger

    const unsigned _nGen;                         ///< Total MCMC steps

    bool           _firstPeriod;                  ///< Still prior to first line print?
    bool           _byPercent;                    ///< Printing by percent or time?

    std::chrono::steady_clock::time_point _startPt;       ///< Instantion point
    std::chrono::steady_clock::time_point _periodStartPt; ///< Start of current output period

};

#endif // _STATUSPRINTER_H_
