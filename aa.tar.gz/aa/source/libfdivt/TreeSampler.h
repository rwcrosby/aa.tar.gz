/// @file TreeSampler.h
/// Declaration for the tree sampling routine

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _TREESAMPLER_H_
#define _TREESAMPLER_H_

struct DivTime;
class  Logger;
struct ReplicateVec;

// *************************************************************************
/// Sample the trees.
/// Trees for each MCMC run are output to separate files. The files are
/// formatted as a nexus file to allow labeling of the trees.

struct TreeSampler {

    TreeSampler (ReplicateVec & replVec);

    void operator() (unsigned gen);

    DivTime      & _dt;				  ///< Owning div time object
    ReplicateVec & _replVec;                      ///< Reference to the parent divergene time object
    Logger &       _logger;			  ///< Just for debugging stuff

};

#endif // _TREESAMPLER_H_
