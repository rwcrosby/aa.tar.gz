/// @file MBUtils.h
/// Utilities copied from Mr. Bayes 3.2 source.

/*
 *  MrBayes 3
 *
 *  (c) 2002-2013
 *
 *  John P. Huelsenbeck
 *  Dept. Integrative Biology
 *  University of California, Berkeley
 *  Berkeley, CA 94720-3140
 *  johnh@berkeley.edu
 *
 *  Fredrik Ronquist
 *  Swedish Museum of Natural History
 *  Box 50007
 *  SE-10405 Stockholm, SWEDEN
 *  fredrik.ronquist@nrm.se
 *
 *  With important contributions by
 *
 *  Paul van der Mark (paulvdm@sc.fsu.edu)
 *  Maxim Teslenko (maxim.teslenko@nrm.se)
 *
 *  and by many users (run 'acknowledgments' to see more info)
 *
 *  Additional (non-algorithmic) contributions by
 *  R. Crosby
 *  Texas A&M University,
 *  College Station, Texas
 *  Contact: R Crosby <rcrosby@tamu.edu>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details (www.gnu.org).
 *
 */

#ifndef __MBUTILS_H__
#define __MBUTILS_H__

#include <cmath>

#include "Config.h"

typedef FLOAT  MrBFlt;
typedef unsigned long BitsLong;

namespace MrBayes {

    const FLOAT  ETA = 1E-30;

    int EigensForRealMatrix (int dim, MrBFlt **a, MrBFlt *wr, MrBFlt *wi, MrBFlt **z, int *iv1, MrBFlt *fv1);
    int InvertMatrix        (int dim, MrBFlt **a, MrBFlt *col, int *indx, MrBFlt **aInv);

    inline
    bool
    IsZero( const FLOAT  x)
    {
        return std::abs(x) < ETA;
    }

}

#endif  /* __MBUTILS_H__ */
