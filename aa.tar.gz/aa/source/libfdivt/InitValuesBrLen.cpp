/// @file InitValuesBrLen.cpp
/// Definition of the methods in the branch length initial value routine

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include <limits>
#include <stack>
#include <unordered_map>
#include <unordered_set>

#include "AgePrior.h"
#include "Calibration.h"
#include "DivTime.h"
#include "Dump.h"
#include "EvoModel.h"
#include "Except.h"
#include "InitValuesBrLen.h"
#include "Likelihood.h"
#include "Logger.h"
#include "Parameter.h"
#include "RatesParameters.h"
#include "RatesPrior.h"
#include "Replicates.h"
#include "StatsFn.h"
#include "Taxa.h"
#include "TransitionMatrix.h"
#include "Tree.h"

// *****************************************************************************
/// Vertex information used in the initial value setting

struct VInfo {

    VInfo()
        : _min(Calibration::minAge),
	  _avgDistToNow(0.0)
        {}

    bool MinSet()
        {
            return _min != Calibration::minAge;
        }

    FLOAT          _min;                          ///< Minimun age for node
    Tree::Position _minPos;			  ///< Node that set the minimum
    FLOAT          _avgDistToNow;                 ///< Average total branch length to age zero.

};

namespace Dump {

    template<>
    std::string
    str( const VInfo & vi,
	 const std::string hdg )
    {
	std::stringstream ss;
	if ( hdg.size() ) ss << hdg << "<";

	ss << Dump::str(vi._min, "min") << ' '
	   << vi._minPos.str("minPos") << ' '
	   << Dump::str(vi._avgDistToNow, "avgDistToNow");

	if ( hdg.size() ) ss << '>';
	return ss.str();
    }

}

// *****************************************************************************

/// Map for min/max values
typedef std::unordered_map<Tree::Position,
			   VInfo,
			   Tree::PositionHash> VINFOMAP;

/// Map for visited nodes
typedef std::unordered_set<Tree::Node *> NODESET;

// *****************************************************************************
/// Entries in the max age stacks

struct MaxStack {

    MaxStack( FLOAT                  age,
	      const Tree::Position & tPos )
	: _max(age),
	  _tPos(tPos)
	{}

    MaxStack( const MaxStack & mStack )
	: _max(mStack._max),
	  _tPos(mStack._tPos)
	{}

    FLOAT          _max;		          ///< Max value
    Tree::Position _tPos;	                  ///< Where the max was found

};

// *****************************************************************************
/// DFS object for the first pass.

struct Pass1DFS : Tree::Dfs {

    Pass1DFS( Replicate & repl,
              VINFOMAP &  viMap )
        : _repl(repl),
          _viMap(viMap)
        {}

    virtual RC InnerBegin( const Tree::Position & tPos );
    virtual RC InnerEnd  ( const Tree::Position & tPos );
    virtual RC RootBegin ( Tree::Root & root );
    virtual RC RootEnd   ( Tree::Root & root );

    FLOAT      OldestChild ( const Tree::Position & tPos,
                             Tree::Position & cPos ) const;

    Replicate &          _repl;		          ///< Parent replicate
    VINFOMAP &           _viMap;                  ///< Map for node information
    std::stack<MaxStack> _maxStack;               ///< Stack of max values

};

// *****************************************************************************
/// DFS object for the second pass.

struct Pass2DFS : Tree::Dfs {

    Pass2DFS( Replicate & repl,
              VINFOMAP &  viMap )
        : _repl(repl),
          _viMap(viMap)
        {}

    virtual RC InnerBegin( const Tree::Position & tPos );
    virtual RC InnerEnd  ( const Tree::Position & tPos );
    virtual RC Leaf      ( const Tree::Position & tPos );
    virtual RC RootBegin ( Tree::Root & root );
    virtual RC RootEnd   ( Tree::Root & root );

    Replicate &          _repl;		          ///< Parent replicate
    VINFOMAP &           _viMap;                  ///< Map for node information
    std::stack<MaxStack> _maxStack;               ///< Stack of max values

};

// *****************************************************************************
/// DFS object for the third pass setting the evolutionary model and
/// transition matrices.

struct Pass3DFS : ReplicateDfs {

    Pass3DFS( Replicate & repl )
	: _repl(repl)
	{}

    virtual RC InnerBegin( const Tree::Position & tPos );
    virtual RC Leaf      ( const Tree::Position & tPos )
	{
	    return InnerBegin(tPos);
	}

    Replicate &          _repl;		          ///< Parent replicate

};

// *****************************************************************************
// Check a map and generate an abort if not found.

static VInfo&
MapCheck (VINFOMAP &            m,
	  const Tree::Position& k)
{
    try {
        return m.at(k);
    }
    catch ( std::out_of_range e ) {
        assert(0 && "Missing vertex info map entry");
        throw;
    }
}

// *****************************************************************************
/// Return the average age for the set of calibrations.

static
FLOAT
AgeFromCalibrations ( std::list<Calibration::Data*> & calList )
{

    FLOAT  tt = 0.0;
    for ( auto cal : calList)
        tt += cal->_age;

    return tt/FLOAT (calList.size());
}

// *****************************************************************************
/// Find the average branch length to the present

static
FLOAT
AveDistToNow ( const Tree::Position & tPos,
	       VINFOMAP &             viMap    )
{

    FLOAT  sumBrLen = 0.0;

    for ( auto cPair : tPos._node->_children ) {
        Tree::Position childPos(cPair.first, cPair.second[tPos._treeIdx]);
	if ( childPos.IsInner() ) {
	    auto & mm = MapCheck(viMap, childPos);
	    sumBrLen += childPos.BrLen() + mm._avgDistToNow;
	}
	else
	    sumBrLen += childPos.BrLen();
    }

    return sumBrLen / FLOAT (tPos._node->_children.size());

}

// *****************************************************************************
/// Calculate the rate for a specific locus data block

static
FLOAT
CalculateRateAtLocus( const Tree::LocusNode * const parentLN,
                      const Tree::Position &        tPos,
                      const FLOAT                   myTime )
{

    /// - Get the time at the parent node

    FLOAT  parentTime = (*parentLN->_ageParmToUse)();

    /// - No time at parent, oh well

    if ( parentTime == 0.0 )
        return 0.0;

    Tree::Position parentPos = parentLN->_tNode
        ? Tree::Position(parentLN->_tNode)
        : Tree::Position(parentLN->_lRoot._root);

    /// - Get the total branch length and return the rate.

    Tree::Path path(parentPos, tPos );
    return path.BrLen() / (parentTime - myTime);

}

// *****************************************************************************

void
InitValuesBrLen::operator()( Replicate & repl )
{
    LOGENTER(_logger, repl._id, Dump::ptr(&repl, "repl"));

    /// - Map to save ages for each inner node

    VINFOMAP viMap;

    /// - First pass,
    ///   - Set hyperparameters on rates
    ///   - Set calibration initial values
    ///   - Set min and max values when possible

    Pass1DFS p1DFS(repl, viMap);
    for ( auto & root : repl )
        p1DFS(root);

    /// - Second pass
    ///   - Set times when descenting
    ///   - Set rates when ascending

    LOGDEBUG(_logger, repl._id, "Starting Pass 2");

    Pass2DFS p2DFS(repl, viMap);
    for ( auto & root : repl )
        p2DFS(root);

    /// - Third pass
    ///   - Set branch lengths in the transition matrixes

    LOGDEBUG(_logger, repl._id, "Starting Pass 3");

    Pass3DFS p3DFS(repl);
    p3DFS(repl);

    /// - Set the priors for the rate hyperparameters

    Rates::InitialParmPriors(repl);

    /// - Set the rates priors

    LOGDEBUG(_logger, repl._id, "Set rate priors");

    for ( auto & root : repl )
	for ( auto & lRoot : root._locusVec ) {
	    lRoot._rLnPR->InitialValues();
	    root._lnPR += (*lRoot._rLnPR)();
	}

    /// - Set the ages priors

    LOGDEBUG(_logger, repl._id, "Set age priors");

    for ( auto & root : repl )
	root._lnPA->InitialValues();

    /// - Compute the initial log likelihood

    LOGDEBUG(_logger, repl._id, "Set likelihood");

    for ( auto & root : repl )
	root._lkh->Compute();

    repl.CommitProposal();

    LOGEXIT(_logger, repl._id, Dump::ptr(&repl, "repl"));
}

// *****************************************************************************

Tree::Dfs::RC
Pass1DFS::InnerBegin( const Tree::Position & tPos )
{

    REPRENTER(Dump::str(tPos,"tPos"));

    auto & tNode   = tPos._node->_treeVec[tPos._treeIdx];

    /// - If a calibration on this node calculate it's age

    if ( tNode._calList.size() ) {

        /// - Get initial values for the calibrations restricting to
        ///   any max age already specified

        for ( auto cal : tNode._calList )
            cal->InitialValue( _maxStack.top()._max );

        /// - Set the time for the node

	FLOAT  age = AgeFromCalibrations(tNode._calList);
	(*tNode._ageParm)(age);
        _maxStack.emplace(age, tPos);

	REPRDEBUG(Dump::str(age,"age"),
		  Dump::str(_maxStack.top()._max,"max"));

    }
    else
        _maxStack.emplace( _maxStack.top() );

    _viMap.emplace( tPos, VInfo());

    REPREXIT(Dump::str(tPos,"tPos"));
    return CONTINUE;
}

// *****************************************************************************

Tree::Dfs::RC
Pass1DFS::InnerEnd( const Tree::Position & tPos )
{
    REPRENTER(Dump::str(tPos,"tPos"));
    auto & vi  = MapCheck(_viMap, tPos);          // Get map entry for this node
    auto & tn = tPos.AsTNode();

    if ( (*tn._ageParm)() ) {                     // If a calibration here, use it as the min
	vi._min = (*tn._ageParm)();
	vi._minPos = tPos;
    }
    else
	vi._min = OldestChild(tPos, vi._minPos);    // Find the oldest child age for the node

    vi._avgDistToNow = AveDistToNow(tPos, _viMap);  // Get average branch length to the present

    _maxStack.pop();

    REPREXIT(Dump::str(vi,"vi"));
    return CONTINUE;
}

// *****************************************************************************
/// Find the oldest possible age of any child of the node passed.

FLOAT
Pass1DFS::OldestChild ( const Tree::Position & tPos,
                        Tree::Position &       cPos ) const
{

    /// - Loop through the children looking for the oldest

    FLOAT  minAge = 0.0;

    for ( auto cPair : tPos._node->_children ) {

        Tree::Position childPos(cPair.first, cPair.second[tPos._treeIdx]);

        if ( childPos.IsLeaf() )
            continue;

        auto & mm(MapCheck(_viMap, childPos));

        if ( mm._min > minAge ) {
            minAge = mm._min;
	    cPos = mm._minPos;
	}

    }

    return minAge;

}

// *****************************************************************************

Tree::Dfs::RC
Pass1DFS::RootBegin( Tree::Root & root )
{
    REPRENTER(Dump::ptr(&root,"Root"),
	      Dump::str(root._label,"Label"));

    FLOAT          age(Calibration::maxAge);
    Tree::Position tPos(&root, 0);

    /// - If a calibration on this root calculate the root age

    if ( root._calList.size() ) {

        /// - Get initial values for the calibrations with no restriction
        ///   saving the oldest value.

        for ( auto & cal : root._calList )
            cal->InitialValue(Calibration::maxAge);

        /// - Set the time and age for the root

	FLOAT  age = AgeFromCalibrations(root._calList);
	(*root._ageParm)(age);

	REPRDEBUG(Dump::str(age,"age"));

    }

    _maxStack.emplace(age, tPos);

    _viMap.emplace( tPos, VInfo() );

    REPREXIT(Dump::ptr(&root,"Root"));
    return CONTINUE;
}

// *****************************************************************************

Tree::Dfs::RC
Pass1DFS::RootEnd( Tree::Root & root )
{
    REPRENTER(Dump::ptr(&root,"Root"),
	      Dump::str(root._label,"Label"));

    Tree::Position rPos(&root, 0);

    /// - Set the distance and min even if we have a root age so the rate calculations will work.

    auto &  vi  = MapCheck(_viMap, rPos);              // Get map entry for this node

    vi._min          = OldestChild(rPos, vi._minPos);  // Find oldest possible age for the root
    vi._avgDistToNow = AveDistToNow(rPos, _viMap);     // Set the average branch length to present

    _maxStack.pop();

    REPREXIT(Dump::str(vi, "vi"));
    return CONTINUE;
}

// *****************************************************************************

Tree::Dfs::RC
Pass2DFS::InnerBegin( const Tree::Position & tPos )
{
    REPRENTER(Dump::str(tPos,"tPos"));

    auto & vi = MapCheck(_viMap, tPos);	    // Get map entry for this node
    auto & tn = tPos.AsTNode();

    /// - If we already have an age at this node, just push that as the max

    if ( (*tn._ageParm)() )
	_maxStack.emplace( (*tn._ageParm)(), tPos );

    /// - If the max is set we can compute the age of this node.
    ///   Calculation is depending on whether we also have a minimun age.

    else if ( _maxStack.top()._max != Calibration::maxAge ) {

	FLOAT  age;

	if ( vi.MinSet() ) {
	    Tree::Path downPath(tPos, vi._minPos);
	    Tree::Path fullPath(_maxStack.top()._tPos, vi._minPos);
	    age = (downPath.BrLen() / fullPath.BrLen() ) * fullPath.DeltaAge() + vi._min;

	    REPRDEBUG( Dump::str(age,"Min set: age"),
		       Dump::str(vi,"vi"),
		       Dump::str(downPath.BrLen(),"downPath.BrLen"),
		       Dump::str(fullPath.BrLen(),"fullPath.BrLen"),
		       Dump::str(fullPath.DeltaAge(),"fullPath.DeltaAge") );

	}
	else {
	    Tree::Path upPath(_maxStack.top()._tPos, tPos);
	    age = _maxStack.top()._max -
		   ( ( upPath.BrLen() / ( upPath.BrLen() + vi._avgDistToNow  ) ) * _maxStack.top()._max);

	    REPRDEBUG(Dump::str(age,"Min not set: age"),
		      Dump::str(vi, "vi"),
		      Dump::str(_maxStack.top()._max,"max"),
		      Dump::str(upPath.BrLen(),"upPath.BrLen"));

	}

	if ( vi._min >= _maxStack.top()._tPos.Age() )
	{
	    std::stringstream ss;

	    ss << "Illogical dates for inner node in range ("
	       << vi._min
	       << ", "
	       << _maxStack.top()._tPos.Age()
	       << ") for tree "
	       << tPos.GetRoot()._label;

	    _repl._logger(ss.str().c_str());
	    // throw Except::NumericError(ss.str());

	}

	try {
	age = _repl._statsObj->DrawNormal( age,
                                           (_maxStack.top()._tPos.Age() - vi._min) / 6,
                                           vi._min,
                                           _maxStack.top()._tPos.Age() );
	}
	catch (Except::NumericError e) {
	    std::string s = e.what();
	    // throw Except::NumericError(s + " in tree " + tPos.GetRoot()._label);
	    std::string msg = s + " in tree " + tPos.GetRoot()._label;
	    _repl._logger(msg.c_str());
	    age = vi._min;
	}

	(*tn._ageParm)(age);
	_maxStack.emplace(age, tPos);

	REPRDEBUG(Dump::str(age,"age"));

    }

    else
	_maxStack.emplace(_maxStack.top());

    REPREXIT(Dump::str(tPos,"tPos"));
    return CONTINUE;
}

// *****************************************************************************

Tree::Dfs::RC
Pass2DFS::InnerEnd( const Tree::Position & tPos )
{
    REPRENTER(Dump::str(tPos,"tPos"));

    /// - If not the global clock set the rates

    if ( _repl._cModel != Options::ClockModel::GLOBAL ) {

        /// - Loop through the loci setting the rates

        auto & tn = tPos.AsTNode();

        FLOAT  myTime = (*tn._ageParm)();

        for ( auto & l : tn._locusVec )
            if ( !l._missing && l._rateParm ) {
		/// @todo fix the rate calculation
                FLOAT  rate = CalculateRateAtLocus(l._parent, tPos, myTime);
		try {
		    (*l._rateParm)( _repl._statsObj->DrawNormal ( rate,
								  rate / 30.0,
								  Calibration::minAge,
								  Calibration::maxAge ) );
		}
		catch ( Except::NumericError e ) {
		    std::string s = e.what();
		    _repl._logger("Inner end rate, %f", rate);
		    (*l._rateParm)(.1);
		    // throw Except::NumericError(s + " Inner End Rate");
		}
            }

    }

    _maxStack.pop();

    REPREXIT(Dump::str(tPos,"tPos"));
    return CONTINUE;
}

// *****************************************************************************

Tree::Dfs::RC
Pass2DFS::Leaf( const Tree::Position & tPos )
{
    REPRENTER(Dump::str(tPos,"tPos"),
	      Dump::str(tPos._node->_taxa->_label,"Taxa"));

    /// - If not the global clock set the rates

    if ( _repl._cModel != Options::ClockModel::GLOBAL ) {

        /// - Loop through the loci setting the rates

        for ( auto & l : tPos.AsTNode()._locusVec )
            if ( !l._missing && l._rateParm) {
                FLOAT  rate = CalculateRateAtLocus(l._parent, tPos, 0.0);
		try {
		    (*l._rateParm)( _repl._statsObj->DrawNormal ( rate,
								  rate / 30.0,
								  Calibration::minAge,
								  Calibration::maxAge ) );
		}
		catch ( Except::NumericError e ) {
		    std::string s = e.what();
		    throw Except::NumericError(s + " Leaf rate");
		}
            }

    }

    REPREXIT(Dump::str(tPos,"tPos"),
	     Dump::str(tPos._node->_taxa->_label,"Taxa"));
    return CONTINUE;
}

// *****************************************************************************
/// Set the root age if needed.

/// @throw NoCalibrations No calibrations found for tree.

Tree::Dfs::RC
Pass2DFS::RootBegin( Tree::Root & root )
{
    REPRENTER(Dump::ptr(&root,"Root"),
	      Dump::str(root._label,"Label"));

    FLOAT              age(0.0);

    /// - If se already have an age for the root, just use it

    if ( (*root._ageParm)() )

        age = (*root._ageParm)();

    else {

        Tree::Position tPos(&root, 0);
        auto &         vi (MapCheck(_viMap, tPos));	    // Get map entry for this node

        /// - If no minimum is set at this point there were no calibrations
        ///   found anywhere in the tree. This isn't allowed at this time.

        if ( !vi.MinSet() )
            throw Except::NoCalibrations(root._label);

        /// - No root age: compute based on rate to calibration point

        Tree::Path downPath(tPos, vi._minPos);

        age = (vi._avgDistToNow * vi._min) / fabs(vi._avgDistToNow - downPath.BrLen());

	REPRDEBUG( Dump::str(age,"age"),
		   Dump::str(downPath.BrLen(),"brLen"),
		   Dump::str(vi, "vi"));

	try {
	    age = _repl._statsObj->DrawNormal( age,
					       age / 30.0,
					       vi._min,
					       Calibration::maxAge );
	}
	catch ( Except::NumericError e ) {
	    std::string s = e.what();
	    throw Except::NumericError(s + " Root age");
	}

	(*root._ageParm)(age);

    }

    /// - Push either the max or a real root date

    _maxStack.emplace( age, root );

    REPREXIT(Dump::str(age,"age"));
    return CONTINUE;
}

// *****************************************************************************
/// Set the rates at the root only for the global clock model.

Tree::Dfs::RC
Pass2DFS::RootEnd( Tree::Root & root )
{
    REPRENTER(Dump::ptr(&root,"Root"),
	      Dump::str(root._label,"Label"));

    for ( auto & l : root._locusVec )

        if ( l._rateParm ) {

            Tree::Position tPos (&root, 0);
            auto &         mm   (MapCheck(_viMap, tPos));
            FLOAT          rate (mm._avgDistToNow / (*root._ageParm)());
	    try {
		(*l._rateParm)( _repl._statsObj->DrawNormal ( rate,
							      rate / 30.0,
							      Calibration::minAge,
							      Calibration::maxAge ) );
	    }
	    catch ( Except::NumericError e ) {
		std::string s = e.what();
		throw Except::NumericError(s + " Root end rate");
	    }
        }

    _maxStack.pop();

    REPREXIT(Dump::ptr(&root,"Root"));

    return CONTINUE;
}

// *****************************************************************************

ReplicateDfs::RC
Pass3DFS::InnerBegin( const Tree::Position & tPos )
{
    REPRENTER(Dump::str(tPos,"tPos"));

    /// - Loop through all the locus blocks for all trees setting initial distances.

    for ( auto & tNode : tPos._node->_treeVec ) {

        for ( auto & lNode : tNode._locusVec ) {

            /// - If this node is not in the gene tree or it's the gene tree parent,
            ///   don't generate a transition matrix.

            if ( lNode._missing || !lNode._parent )
                continue;

	    /// - Get the rate and time values for this node.

            FLOAT  rate = (*lNode._rateParmToUse)();
            FLOAT  time = (*lNode._parent->_ageParmToUse)() -
		          ( lNode.IsLeaf() ? 0.0 :  (*tNode._ageParm)() );

            /// - Set the initial distance here but don't compute the
            ///   matrix since this needs to be done through UpdateTransitionMatricies
            ///   for the GTR model.

            lNode._tMatrix->_dist = time * rate;

        }

    }

    REPREXIT(Dump::str(tPos,"tPos"));
    return CONTINUE;
}
