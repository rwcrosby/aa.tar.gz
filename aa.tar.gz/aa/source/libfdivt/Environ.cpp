/// @file Environ.cpp
/// Definitions for the environmental functions

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University, 
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifdef __linux__
#include <unistd.h>
#elif __APPLE__
#include <unistd.h>
#elif _WIN32
#include <windows.h>
#else
#error Platform not detected
#endif

#include "Environ.h"

// *****************************************************************************
/// Return the number of cores available on the system

unsigned
Environ::Cores( void )	   
{
    
#ifdef __linux__
    return sysconf(_SC_NPROCESSORS_ONLN);
#elif __APPLE__
    return sysconf(_SC_NPROCESSORS_ONLN);
#elif _WIN32
    SYSTEM_INFO sysinfo;
    GetSystemInfo( &sysinfo );
    return sysinfo.dwNumberOfProcessors;
#endif
    
}
