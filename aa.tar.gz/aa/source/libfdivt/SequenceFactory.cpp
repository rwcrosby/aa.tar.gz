/// @file SequenceFactory.cpp
/// Definition of the sequence factory methods.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include "Except.h"
#include "Locus.h"
#include "Sequence.h"
#include "SequenceFactory.h"

// *****************************************************************************
/// Make a sequence object.

/// Create the sequence object validating the set of characters as well
/// as determining if the data is empty.

/// @throw Except::InvalidSeqCh Invalid character in sequence.
/// @throw Except::InvalidSeqLength All sequence for locus must be same length
/// @throw Except::MissingSeq All of the sequence data is missing.

/// @param seqIn Input sequence as a string
/// @param taxa  Associate to this taxa
/// @param locus Associate to this locus


Sequence *
SequenceFactory::MakeSequence( const std::string  seqIn,
			       Taxa &             taxa,
			       Locus &            locus )
{

    // Determine if the sequence is empty (zero length or all missing or gaps)
    if ( seqIn.length() == 0 )
	// || seqIn.find_first_not_of(both) == std::string::npos)
	throw Except::MissingSeq();

    if ( locus._seqLen == 0)	{		  // Set length on first sequence
	locus._seqLen = seqIn.length();
	locus._charCnts.resize(_alphabet.length() + 2);
    }
    else if ( locus._seqLen != seqIn.length() )	  // All others must be same length
	throw Except::InvalidSeqLength(locus._seqLen, seqIn.length());

    auto* seq = new Sequence(taxa, locus, seqIn);
    seq->reserve(locus._seqLen);

    // Process through the sequence generating the sequence vector
    for ( const char & c : seqIn ) {

	auto pos = _alphabet.find_first_of(c);
	if ( pos == std::string::npos ) {		  // Not found
	    if ( c == _gapCh ) {
		seq->push_back(_alphabet.length());
		locus._charCnts[_alphabet.length()]++;
	    }
	    else if ( c == _missingCh ) {
		seq->push_back(_alphabet.length());
		locus._charCnts[_alphabet.length() + 1]++;
	    }
	    else
		throw Except::InvalidSeqCh(c);
	}
	else {
	    seq->push_back(pos);
	    locus._charCnts[pos]++;
            locus._totalChars++;
	}

    }

    return seq;

}
