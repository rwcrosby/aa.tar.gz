/// @file StatsFn.cpp
/// Definitions of the various statistical functions. Mostly copied from Yang (PAML 4.8).

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include <cassert>
#include <cmath>
#include <sstream>

#include "Except.h"
#include "StatsFn.h"

// *****************************************************************************

static long   Factorial       ( int    n );
static double IncompleteGamma ( double x,
                                double alpha,
                                double ln_gamma_alpha );

static double LnGamma         ( double x );
static double QuantileChi2    ( double prob,
                                double v );
static double QuantileNormal  ( double prob );

// *****************************************************************************

/// Maximum number of attempts to get an draw in the specified range.
static const unsigned max_tries = 100;

/// Value to compare against for size
static const double  small(1e-6 );

// *****************************************************************************

static
inline
double
QuantileGamma( double  prob, double  alpha,double  beta)
{
    return QuantileChi2(prob,2.0*(alpha))/(2.0*(beta));
}

// *****************************************************************************
/// Draw from a distribution constraining the result to a range

static
FLOAT
ConstrainedDraw ( std::function<FLOAT ()> & distFn,
		  const FLOAT               min,
		  const FLOAT               max )
{

    /// - Loop drawing random values from the distribution until
    ///   we get one in the range (or spend too long at it...

    for ( unsigned i = 0; i < max_tries; i++ ) {

        double  draw =  distFn();

        if ( min < draw && draw < max )
            return draw;

    }

    std::stringstream ss;

    ss << "Unable to obtain random draw in range ("
       << min
       << ", "
       << max
       << ")";

    throw Except::NumericError(ss.str());

}

// *****************************************************************************
/// Namespace for the statistical functions that don't require random numbers

namespace StatsFn {

    // *************************************************************************

    FLOAT
    DiscreteGamma( FLOAT    alpha,
                   unsigned nCat,
                   FLOAT    rateVec[] )
    {

#ifdef _WIN32
        double  * wa = new double [nCat];
#else
        double  wa[nCat];
#endif

        double  lnga1 (LnGamma(alpha+1));
        double  mean  (1.0);

        for ( unsigned i = 0; i < nCat - 1; i++ ) {
            /// - Find the cutting points (see eq 9 in Yang 1994).
            wa[i] = QuantileGamma( ( i + 1.0 ) / nCat, alpha, alpha);
            /// - Get the mean rate for the interval (see eq 10 in Yang 1994).
            wa[i] = IncompleteGamma(wa[i] * alpha, alpha + 1, lnga1);
        }

        rateVec[0] = wa[0] * mean * nCat;

        for ( unsigned i = 1; i < nCat-1; i++ )
            rateVec[i] = (wa[i] - wa[i-1]) * mean * nCat;

        rateVec[nCat-1] = (1-wa[nCat-2]) * mean * nCat;

        return 1.0 / double (nCat);

#ifdef _WIN32
        delete[] wa;
#endif
    }

    // *************************************************************************
    /// Return the PDF value using the
    /// \f$\frac{1}{\Gamma(\alpha) \beta^\alpha} x^{\alpha-1} e^{-\frac{x}{\beta}}\f$
    /// parameterization.
    /// @param x Value to obtain PDF for
    /// @param alpha \f$\alpha\f$ parameter
    /// @param beta \f$\beta\f$ parameter

    double  GammaPDF( double  x,
                      double  alpha,
                      double  beta )
    {
        if (x<=0 || alpha<=0 || beta<=0)
            throw Except::NumericError("Gamma PDF: Value(s) out of range");

        if (alpha > 100)
            throw Except::NumericError("Gamma PDF: alpha too large");

	return 1.0 / (tgamma(alpha) * pow(beta, alpha)) * pow(x, alpha - 1.0) * exp(-x/beta);
    }

}

// *****************************************************************************

StatsObj::StatsObj( const FLOAT seed )
    : _randomGen(seed),
      _uniformDist(0.0, 1.0),
      _normalDist(0.0,1.0),
      _stdNormal(std::bind( _normalDist, std::ref(_randomGen))),
      _uniform01(std::bind( _uniformDist, std::ref(_randomGen)))
{
}

// *****************************************************************************
/// This returns a variate from the 1:1 mixture of two normals
/// N(-m, 1-m^2) and N(m, 1-m^2), which has mean 0 and variance 1.
/// The value m = 0.94 is useful for generating MCMC proposals

FLOAT
StatsObj::DrawNormalMix (FLOAT  m)
{
    FLOAT z = m + DrawStdNormal() * sqrt( 1 - m*m );
    return DrawUniform() < 0.5 ? -z : z;
}

// *****************************************************************************
/// Return a random draw from the specified gamma distribution

FLOAT
StatsObj::DrawGamma ( const FLOAT  alpha,
                      const FLOAT  beta,
                      const FLOAT  min,
                      const FLOAT  max )
{
    std::gamma_distribution<FLOAT > dist(alpha, beta);
    std::function<FLOAT ()>         distFn = std::bind(dist, std::ref(_randomGen));
    return ConstrainedDraw(distFn, min, max);
}

// *****************************************************************************
/// Return a random draw from the specified normal distribution.

FLOAT
StatsObj::DrawNormal ( const FLOAT  mu,
                       const FLOAT  sigma,
                       const FLOAT  min,
                       const FLOAT  max )
{

    FLOAT mean;

    /// @todo Figure out how to setup the initial values better

    if (min <= mu && mu <= max)
	mean = mu;
    else if (mu < min)
	mean = min;
    else
	mean = max;

    std::normal_distribution<FLOAT > dist(mean, sigma);
    std::function<FLOAT ()>         distFn = std::bind(dist, std::ref(_randomGen));
    return ConstrainedDraw(distFn, min, max);

}

// *****************************************************************************

static
long
Factorial (int n)
{
    assert(n <= 11 && "Factorial > 11");

    long f = 1;
    for (int i = 2; i <= n; i++)
        f *= i;

    return f;
}

// *****************************************************************************

static
double
IncompleteGamma (double  x,
                 double  alpha,
                 double  ln_gamma_alpha)
{
/* returns the incomplete gamma ratio I(x,alpha) where x is the upper
           limit of the integration and alpha is the shape parameter.
   returns (-1) if in error
   ln_gamma_alpha = ln(Gamma(alpha)), is almost redundant.
   (1) series expansion,     if (alpha>x || x<=1)
   (2) continued fraction,   otherwise
   RATNEST FORTRAN by
   Bhattacharjee GP (1970) The incomplete gamma integral.  Applied Statistics,
   19: 285-287 (AS32)
*/
   int i;
   double  p=alpha, g=ln_gamma_alpha;
   double  accurate=1e-10, overflow=1e60;
   double  factor, gin=0, rn=0, a=0,b=0,an=0,dif=0, term=0, pn[6];

   if (x==0) return (0);
   if (x<0 || p<=0) return (-1);

   factor=exp(p*log(x)-x-g);
   if (x>1 && x>=p) goto l30;
   /* (1) series expansion */
   gin=1;  term=1;  rn=p;
 l20:
   rn++;
   term *= x/rn;   gin += term;
   if (term > accurate) goto l20;
   gin *= factor/p;
   goto l50;
 l30:
   /* (2) continued fraction */
   a = 1-p;   b = a+x+1;  term = 0;
   pn[0] = 1;  pn[1] = x;  pn[2] = x+1;  pn[3] = x*b;
   gin = pn[2]/pn[3];
 l32:
   a++;
   b += 2;
   term++;
   an = a*term;
   for (i=0; i<2; i++)
      pn[i+4] = b*pn[i+2] - an*pn[i];
   if (pn[5] == 0) goto l35;
   rn = pn[4]/pn[5];
   dif = fabs(gin-rn);
   if (dif > accurate) goto l34;
   if (dif <= accurate*rn) goto l42;
 l34:
   gin = rn;
 l35:
   for (i=0; i<4; i++) pn[i] = pn[i+2];
   if (fabs(pn[4]) < overflow) goto l32;
   for (i=0; i<4; i++) pn[i] /= overflow;
   goto l32;
 l42:
   gin = 1-factor*gin;

 l50:
   return (gin);
}

// *****************************************************************************

static
double
LnGamma (double  x)
{
/* returns ln(gamma(x)) for x>0, accurate to 10 decimal places.
   Stirling's formula is used for the central polynomial part of the procedure.

   Pike MC & Hill ID (1966) Algorithm 291: Logarithm of the gamma function.
   Communications of the Association for Computing Machinery, 9:684
*/
    double  lng;
    int nx=(int)x;

    if ( (double )nx == x && nx >= 0 && nx <= 11 )

        lng = log( (double )Factorial(nx-1) );

    else {

        assert ( x > 0 && "LnGamma not implemented for x <= 0");

        double  f    = 0.0;
        double  fneg = 0.0;

        if ( x < 7 ) {
            f = 1;
            double  z = x-1;
            while ( ++ z < 7 )
                f *= z;
            x = z;
            f = -log(f);
        }

        double  z =  1 / (x * x);

        lng = fneg + f +
            (x - 0.5) * log(x) - x +
            .918938533204673 +
            (((-.000595238095238 * z + .000793650793651) * z - .002777777777778) * z + .083333333333333) / x;
    }

    return  lng;

}

// *****************************************************************************

static
double
QuantileChi2 (double  prob,
              double  v)
{
/* returns z so that Prob{x<z}=prob where x is Chi2 distributed with df=v
   returns -1 if in error.   0.000002<prob<0.999998
   RATNEST FORTRAN by
       Best DJ & Roberts DE (1975) The percentage points of the
       Chi2 distribution.  Applied Statistics 24: 385-388.  (AS91)
   Converted into C by Ziheng Yang, Oct. 1993.
*/
   double e=.5e-6, aa=.6931471805, p=prob;
   double a=0,q=0,p1=0,p2=0,t=0,x=0,b=0,s1,s2,s3,s4,s5,s6;

   if ( p < small )
       return 0.0;
   if ( p > 1 - small )
       return 9999.0;

   assert( v > 0 && "Degrees of freedom must be positive");

   double g  = LnGamma (v/2);
   double xx = v/2;
   double c  = xx-1;
   double ch = 0.0;
   if (v >= -1.24*log(p)) goto l1;

   ch = pow((p*xx*exp(g+xx*aa)), 1/xx);
   if (ch-e<0)
       return ch;
   goto l4;
l1:
   if (v>.32) goto l3;
   ch=0.4;
   a=log(1-p);
l2:
   q=ch;  p1=1+ch*(4.67+ch);
   p2=ch*(6.73+ch*(6.66+ch));
   t=-0.5+(4.67+2*ch)/p1 - (6.73+ch*(13.32+3*ch))/p2;
   ch-=(1-exp(a+g+.5*ch+c*aa)*p2/p1)/t;
   if (fabs(q/ch-1)-.01 <= 0) goto l4;
   else                       goto l2;

l3:
   x = QuantileNormal(p);
   p1 = 0.222222/v;
   ch = v*pow((x*sqrt(p1)+1-p1), 3.0);
   if (ch>2.2*v+6)
      ch = -2*(log(1-p)-c*log(.5*ch)+g);
l4:
   q  = ch;
   p1 = .5*ch;
   if ((t=IncompleteGamma (p1, xx, g))<0)
       assert(0 && "IncompleteGamma");
   p2 = p-t;
   t  = p2*exp(xx*aa+g+p1-c*log(ch));
   b  = t/ch;
   a  = 0.5*t-b*c;

   s1 = (210+a*(140+a*(105+a*(84+a*(70+60*a))))) / 420;
   s2 = (420+a*(735+a*(966+a*(1141+1278*a))))/2520;
   s3 = (210+a*(462+a*(707+932*a)))/2520;
   s4 = (252+a*(672+1182*a)+c*(294+a*(889+1740*a)))/5040;
   s5 = (84+264*a+c*(175+606*a))/2520;
   s6 = (120+c*(346+127*c))/5040;
   ch += t*(1+0.5*t*s1-b*c*(s1-b*(s2-b*(s3-b*(s4-b*(s5-b*s6))))));
   if (fabs(q/ch-1) > e) goto l4;

   return ch;
}

// *****************************************************************************

static
double
QuantileNormal (double  prob)
{
/* returns z so that Prob{x<z}=prob where x ~ N(0,1) and (1e-12)<prob<1-(1e-12)
   returns (-9999) if in error
   Odeh RE & Evans JO (1974) The percentage points of the normal distribution.
   Applied Statistics 22: 96-97 (AS70)

   Newer methods:
   Wichura MJ (1988) Algorithm AS 241: the percentage points of the
   normal distribution.  37: 477-484.
   Beasley JD & Springer SG  (1977).  Algorithm AS 111: the percentage
   points of the normal distribution.  26: 118-121.
*/

    const double  a0 = -0.322232431088;
    const double  a1 = -1.0;
    const double  a2 = -0.342242088547;
    const double  a3 = -0.0204231210245;
    const double  a4 = -0.453642210148e-4;
    const double  b0 = 0.0993484626060;
    const double  b1 = 0.588581570495;
    const double  b2 = 0.531103462366;
    const double  b3 = 0.103537752850;
    const double  b4 = 0.0038560700634;

    double  z = 9999.0;

    double  p1 = prob <0.5 ? prob : 1.0 - prob;

    if ( p1 < small )
        z = 999.0;
    else {
        double  y = sqrt (log(1/(p1*p1)));
        z = y + ((((y*a4+a3)*y+a2)*y+a1)*y+a0) / ((((y*b4+b3)*y+b2)*y+b1)*y+b0);
    }
    return prob < 0.5 ? -z : z;
}
