/// @file RatesPrior.cpp
/// Definitions for the various rate priors.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#define _USE_MATH_DEFINES

#include "Parameter.h"
#include "RatesPrior.h"
#include "Replicates.h"
#include "Tree.h"

// *****************************************************************************
/// Rates prior for the correlated clock model at a gene tree node.

struct NodeCorrelated : RatesPriorNode
{

    NodeCorrelated ( Replicate &       repl,
		     Tree::LocusNode & lNode,
		     RatesPriorRoot &  pRoot )
	: RatesPriorNode(repl, lNode, pRoot),
	  _lnR(0.0),
	  _oldLnR(0.0),
	  _cLnPRy1(0.0),
	  _oldCLnPRy1(0.0),
	  _cLnPRy2(0.0),
	  _oldCLnPRy2(0.0),
	  _cLnPR1(0.0),
	  _oldCLnPR1(0.0),
	  _cLnPR2(0.0),
	  _oldCLnPR2(0.0),
	  _cLnPR3(0.0),
	  _oldCLnPR3(0.0),
	  _cLnPR4(0.0),
	  _oldCLnPR4(0.0)
	{}

    /// Compute the prior when the rate at the node is changed.
    virtual
    void
    NewRate()
	{
	    _lnR = log( (*_lNode._rateParmToUse)() );
	}

    /// Compute both the constants and the prior logging the transaction.
    virtual
    void
    ComputeAll()
	{
	    REPRENTER(Dump::pstr(this,"this"));
	    _repl.LogRollback(this);
	    _oldCLnPRy1 = _cLnPRy1;
	    _oldCLnPRy2 = _cLnPRy2;
	    _oldCLnPR1  = _cLnPR1;
	    _oldCLnPR2  = _cLnPR2;
	    _oldCLnPR3  = _cLnPR3;
	    _oldCLnPR4  = _cLnPR4;
	    _oldLnR     = _lnR;
	    Prior::Save();

	    Constants();
	    Prior();
	}

    /// Compute and log only the prior.
    virtual
    void
    ComputePrior()
	{
	    _repl.LogRollback(this);
	    _oldLnR = _lnR;
	    Prior::Save();

	    Prior();
	}

    /// Rollback both constants and prior
    void
    RollbackAll()
	{
	    _cLnPRy1 = _oldCLnPRy1;
	    _cLnPRy2 = _oldCLnPRy2;
	    _cLnPR1  = _oldCLnPR1;
	    _cLnPR2  = _oldCLnPR2;
	    _cLnPR3  = _oldCLnPR3;
	    _cLnPR4  = _oldCLnPR4;
	    RollbackPrior();
	}

    /// Rollback only the prior.
    void
    RollbackPrior()
	{
	    _lnR     = _oldLnR;
	    Prior::Rollback();
	}

    /// Output debugging string for the node
    std::string
    str()
	const
	{
	    std::stringstream ss;
	    ss << Prior::str() << ' '
	       << Dump::str(_lnR, _oldLnR, "lnR") << ' '
	       << Dump::str(_cLnPRy1, _oldCLnPRy1, "cLnPRy1") << ' '
	       << Dump::str(_cLnPRy2, _oldCLnPRy2, "cLnPRy2") << ' '
	       << Dump::str(_cLnPR1, _oldCLnPR1, "cLnPR1") << ' '
	       << Dump::str(_cLnPR2, _oldCLnPR2, "cLnPR2") << ' '
	       << Dump::str(_cLnPR3, _oldCLnPR3, "cLnPR3") << ' '
	       << Dump::str(_cLnPR4, _oldCLnPR4, "cLnPR4");
	    return ss.str();
	}

    /// Log of the rate at this node
    FLOAT  _lnR;
    FLOAT  _oldLnR;

private:

    /// Compute just the constants.
    void Constants();

    /// Compute just the prior.
    void Prior();

    /// Constants used for the rates prior under the correlated model.
    /// see Rannala & Yang 2007 for notation.

    /// \f$\displaystyle ( t_A + t_1) \frac{\sigma^2}{2}\f$
    FLOAT  _cLnPRy1;
    FLOAT  _oldCLnPRy1;

    /// \f$\displaystyle ( t_A + t_2) \frac{\sigma^2}{2}\f$
    FLOAT  _cLnPRy2;
    FLOAT  _oldCLnPRy2;

    /// \f$\displaystyle \frac{\log \left( det(\mathbf{T})\left(\sigma^2\right)^2\right)}{2}\f$
    FLOAT  _cLnPR1;
    FLOAT  _oldCLnPR1;

    /// \f$\displaystyle \frac{\mathbf{T}^{-1}_{0,0}}{2 \sigma^2}\f$
    FLOAT  _cLnPR2;
    FLOAT  _oldCLnPR2;

    /// \f$\displaystyle \frac{\mathbf{T}^{-1}_{0,1}}{\sigma^2}\f$
    FLOAT  _cLnPR3;
    FLOAT  _oldCLnPR3;

    /// \f$\displaystyle \frac{\mathbf{T}^{-1}_{1,1}}{2\sigma^2}\f$
    FLOAT  _cLnPR4;
    FLOAT  _oldCLnPR4;

};

/// Compute the prior at a gene inner node

struct NodeCorrelatedInner : NodeCorrelated {
    NodeCorrelatedInner ( Replicate &       repl,
			  Tree::LocusNode & lNode,
			  RatesPriorRoot &  pRoot )
	: NodeCorrelated(repl, lNode, pRoot)
	{}

    virtual void ComputeAll()
	{
	    _rollbackFn = &NodeCorrelated::RollbackAll;
	    NodeCorrelated::ComputeAll();
	}

    virtual void ComputePrior()
	{
	    _rollbackFn = &NodeCorrelated::RollbackPrior;
	    NodeCorrelated::ComputePrior();
	}

    virtual void NewAge ()
	{
	    _pRoot.LogRollback();
	    ComputeAll();
	    auto parentLnPR = static_cast<NodeCorrelated*>(_lNode._parent->_lnPR);
	    parentLnPR->ComputeAll();
	}

    virtual void NewRate ()
	{
	    _pRoot.LogRollback();
	    NodeCorrelated::NewRate();
	    ComputePrior();
	    auto parentLnPR = static_cast<NodeCorrelated*>(_lNode._parent->_lnPR);
	    parentLnPR->ComputePrior();
	}

    virtual void Rollback()
	{
	    (this->*_rollbackFn)();
	}

    /// Function pointer to either rollback all or rollback prior method
    void (NodeCorrelated::* _rollbackFn)();

};

/// Compute the prior at a gene leaf node

struct NodeCorrelatedLeaf : NodeCorrelated {
    NodeCorrelatedLeaf ( Replicate &       repl,
			 Tree::LocusNode & lNode,
			 RatesPriorRoot &  pRoot )
	: NodeCorrelated(repl, lNode, pRoot)
	{}

    virtual void NewRate ()
	{
	    _pRoot.LogRollback();
	    auto parentLnPR = static_cast<NodeCorrelated*>(_lNode._parent->_lnPR);
	    parentLnPR->ComputePrior();
	}

};

/// Compute the prior at a gene tree root

struct NodeCorrelatedRoot : NodeCorrelated {
    NodeCorrelatedRoot ( Replicate &       repl,
			 Tree::LocusNode & lNode,
			 RatesPriorRoot &  pRoot )
	: NodeCorrelated(repl, lNode, pRoot)
	{}

    virtual void NewAge()
	{
	    REPRENTER(Dump::ptr(&_lNode, "lNode"));
	    _pRoot.LogRollback();
	    ComputeAll();
	}

    virtual void Rollback()
	{
	    RollbackAll();
	}
};

/// Rates prior for the correlated clock model for a gene tree.

struct RootCorrelated : RatesPriorRoot
{

    RootCorrelated ( Replicate &       repl,
		     Tree::LocusRoot & lRoot )
	: RatesPriorRoot(repl, lRoot)
	{}

    virtual void InitialValues ();
    virtual void NewMean       ();
    virtual void NewVariance   ();

    /// Rollback the overall gene tree prior value.
    virtual void Rollback()
	{
	    Prior::Rollback();
	}

};

// *****************************************************************************
/// Rates prior for the global clock model, gene tree node.
/// Really just a placeholder. Should never be called since there aren't any
/// rate parameters for the  molecular clock model but the code is simpler if
/// this is just an empty skeleton.

struct NodeGlobal : RatesPriorNode
{

    NodeGlobal ( Replicate &       repl,
		 Tree::LocusNode & lNode,
		 RatesPriorRoot &  pRoot )
	: RatesPriorNode(repl, lNode, pRoot)
	{}

};

/// Rates prior for the global clock model, gene tree root.
/// Really just a placeholder. Should never be called since there aren't any
/// rate parameters for the  molecular clock model but the code is simpler if
/// this is just an empty skeleton.

struct RootGlobal : RatesPriorRoot
{

    RootGlobal ( Replicate &       repl,
		 Tree::LocusRoot & lRoot )
	: RatesPriorRoot(repl, lRoot)
	{}

    virtual void InitialValues () {}
    virtual void NewMean       () {}
    virtual void NewVariance   () {}

};

// *****************************************************************************
/// Rates prior for the independent clock model, gene tree node.

struct NodeIndependent : RatesPriorNode
{

    NodeIndependent ( Replicate &       repl,
		      Tree::LocusNode & lNode,
		      RatesPriorRoot &  pRoot )
	: RatesPriorNode(repl, lNode, pRoot)
	{}

    virtual void NewRate ();

};

/// Rates prior for the independent clock model at a gene tree root.

struct RootIndependent : RatesPriorRoot
{

    RootIndependent ( Replicate &       repl,
		      Tree::LocusRoot & lRoot )
	: RatesPriorRoot(repl, lRoot),
	  _c3(0.0),
	  _lnMu(0.0)
	{}

    virtual void InitialValues ();
    virtual void NewMean       ()  { InitialValues(); }
    virtual void NewVariance   ()  { InitialValues(); }

    virtual void   Rollback()
	{
	    _c3   = _oldC3;
	    _lnMu = _oldLnMu;
	    Prior::Rollback();
	}

    /// Constant based only on the parameter values.
    FLOAT             _c3;
    FLOAT             _oldC3;

    /// Log of the mean used as a constant in the per node calculations.
    FLOAT             _lnMu;
    FLOAT             _oldLnMu;

};

// *****************************************************************************
/// Helper function for casts

inline
NodeCorrelated *
AsNodeCorrelated( Prior * p)
{
    return static_cast<NodeCorrelated*>(p);
}

// *****************************************************************************

void
NodeCorrelated::Constants ()
{
    REPRENTER(Dump::ptr(this), Dump::ptr(&_lNode,"lNode"));
    FLOAT  a  = (*_lNode._ageParmToUse)();
    FLOAT  a1 = _lNode._children[0]->_tNode->IsLeaf()
	? 0.0
	: (*_lNode._children[0]->_ageParmToUse)();
    FLOAT  a2 = _lNode._children[1]->_tNode->IsLeaf()
	? 0.0
	: (*_lNode._children[1]->_ageParmToUse)();

    FLOAT  ss = (*_lNode._lRoot._ratesVarParm)();

    FLOAT  tA  = ! _lNode._parent
	         ? 0.0
	         : ( ( (*_lNode._parent->_ageParmToUse)() - (*_lNode._ageParmToUse)() ) / 2.0 );
    FLOAT  t1 = ( a - a1 ) / 2.0;
    FLOAT  t2 = ( a - a2 ) / 2.0;

    FLOAT  detT = t1 * t2 + tA * (t1 + t2);

    REPRDEBUG( Dump::str(a,"a"),
	       Dump::str(a1,"a1"),
	       Dump::str(a2,"a2"),
	       Dump::str(ss,"ss"),
	       Dump::str(tA,"tA"),
	       Dump::str(t1,"t1"),
	       Dump::str(t2,"t2"),
	       Dump::str(detT,"detT") );

    _cLnPRy1 = (tA + t1) * ss / 2.0;
    _cLnPRy2 = (tA + t2) * ss / 2.0;

    _cLnPR1  = log( detT * pow(ss,2) ) / 2.0 - log ( 2.0 * M_PI) / 2.0 ;

    _cLnPR2  = ( tA + t2) / (2.0 * ss * detT) ;
    _cLnPR3  = - tA  / (ss * detT);
    _cLnPR4  = ( tA + t1) / (2.0 * ss * detT);
    REPREXIT(Dump::pstr(this));
}

// *****************************************************************************

void
NodeCorrelated::Prior ()
{
    REPRENTER(Dump::ptr(this));

    /// - Get the child rates (logs)

    FLOAT  lnR1 = AsNodeCorrelated(_lNode._children[0]->_lnPR)->_lnR;
    FLOAT  lnR2 = AsNodeCorrelated(_lNode._children[1]->_lnPR)->_lnR;

    /// - Compute the y values for each of the children

    FLOAT  y1 = lnR1 - _lnR + _cLnPRy1;
    FLOAT  y2 = lnR2 - _lnR + _cLnPRy2;

    /// - Compute the value of the prior at a node as <br>
    ///   \f$\displaystyle c_1 + c_2 y^2_1 + c_3 y_1 y_2 + c_4 y_2^2 + \log{r_1} + \log{r_2} \f$

    _value = _cLnPR1 -
	     _cLnPR2 * y1 * y1 -
	     _cLnPR3 * y1 * y2 -
	     _cLnPR4 * y2 * y2 +
	     lnR1 + lnR2;

    /// - Adjust the overall gene tree prior value

    _pRoot.UpdatePrior(_value - _oldValue);

    REPREXIT(str(),
	     Dump::str(lnR1,"lnR1"),
	     Dump::str(lnR2,"lnR2"),
	     Dump::str(y1,"y1"),
	     Dump::str(y2,"y2"));
}

// *****************************************************************************

void
NodeIndependent::NewRate ()
{

    _repl.LogRollback(this);

    RootIndependent & pRoot = static_cast<RootIndependent&>(_pRoot);

    FLOAT  lnR = log( (*_lNode._rateParmToUse)() );
    FLOAT  lnDiff = (lnR - pRoot._lnMu);

    /// - Compute the value of the prior at a node as <br>
    /// \f$\displaystyle -\left( c3 + \log{r} + \frac{(r - \mu)^2}{2 \sigma^2} + \frac{r - \mu}{2}\right)\f$

    _value = pRoot._c3 - lnR - lnDiff * lnDiff / (2.0 * (*_lNode._lRoot._ratesVarParm)()) - lnDiff / 2.0;

    /// - Adjust the overall gene tree prior value

    _pRoot.LogRollback();
    _pRoot.UpdatePrior(_value - _oldValue);

}

// *****************************************************************************

RatesPriorNode *
RatesPriorNode::Factory( Replicate &       repl,
			 Tree::LocusNode & lNode )
{

    RatesPriorNode * prior = nullptr;

    switch (repl._cModel ) {

        case Options::ClockModel::GLOBAL:
	    prior = new NodeGlobal ( repl, lNode, *lNode._lRoot._rLnPR );
	    break;

        case Options::ClockModel::INDEPENDENT:
	    prior = new NodeIndependent ( repl, lNode, *lNode._lRoot._rLnPR );
	    break;

        case Options::ClockModel::CORRELATED:
	    if ( lNode.IsRoot() )
		prior = new NodeCorrelatedRoot  ( repl, lNode, *lNode._lRoot._rLnPR );
	    else if ( lNode.IsInner() )
		prior = new NodeCorrelatedInner ( repl, lNode, *lNode._lRoot._rLnPR );
	    else
		prior = new NodeCorrelatedLeaf  ( repl, lNode, *lNode._lRoot._rLnPR );
	    break;

        default:
	    assert(0 && "Invalid clock model");

    }

    return prior;

}

// *****************************************************************************

RatesPriorRoot *
RatesPriorRoot::Factory( Replicate &       repl,
			 Tree::LocusRoot & lRoot )
{

    RatesPriorRoot * prior = nullptr;

    switch (repl._cModel ) {

        case Options::ClockModel::GLOBAL:
	    prior = new RootGlobal ( repl, lRoot );
	    break;

        case Options::ClockModel::INDEPENDENT:
	    prior = new RootIndependent ( repl, lRoot );
	    break;

        case Options::ClockModel::CORRELATED:
	    prior = new RootCorrelated ( repl, lRoot );
	    break;

        default:
	    assert(0 && "Invalid clock model");

    }

    return prior;

}

// *****************************************************************************

void
RatesPriorRoot::LogRollback ()
{
    _repl.LogRollback(this);
    Save();
}

// *****************************************************************************

void
RootCorrelated::InitialValues ()
{
    REPRENTER(Dump::str(_value, _oldValue,"value"));

    /// - Traverse the gene tree computing the prior

    struct Dfs : Tree::LocusDfs {

	virtual
	RC
	InnerBegin ( Tree::LocusNode & lNode )
	    {
		AsNodeCorrelated(lNode._lnPR)->_lnR = log( (*lNode._rateParmToUse)() );
		return CONTINUE;
	    }

	virtual
	RC
	InnerEnd ( Tree::LocusNode & lNode )
	    {
		AsNodeCorrelated(lNode._lnPR)->ComputeAll();
		return CONTINUE;
	    }

	virtual
	RC
	Leaf ( Tree::LocusNode & lNode )
	    {
		return InnerBegin(lNode);
	    }

	virtual
	RC
	RootBegin ( Tree::LocusNode & lNode )
	    {
		AsNodeCorrelated(lNode._lnPR)->_lnR = log((*lNode._lRoot._ratesMeanParm)());
		return CONTINUE;
	    }

	virtual
	RC
	RootEnd ( Tree::LocusNode & lNode )
	    {
		return InnerEnd(lNode);
	    }

    } dfs;
    dfs(_lRoot);

    REPREXIT(Dump::str(_value, _oldValue,"value"));
}

// *****************************************************************************

void
RootCorrelated::NewMean ()
{
    _repl.LogRollback(this);
    _oldValue = _value;

    /// - Traverse the gene tree computing the prior

    struct Dfs : Tree::LocusDfs {

	virtual RC InnerEnd ( Tree::LocusNode & lNode )
	    {
		AsNodeCorrelated(lNode._lnPR)->ComputePrior();
		return CONTINUE;
	    }

	virtual RC RootEnd ( Tree::LocusNode & lNode )
	    {
		return InnerEnd(lNode);
	    }

    } dfs;
    dfs(_lRoot);
}

// *****************************************************************************

void
RootCorrelated::NewVariance ()
{
    _repl.LogRollback(this);
    _oldValue = _value;

    /// - Traverse the gene tree computing the prior

    struct Dfs : Tree::LocusDfs {

	virtual RC InnerEnd ( Tree::LocusNode & lNode )
	    {
		AsNodeCorrelated(lNode._lnPR)->ComputeAll();
		return CONTINUE;
	    }

	virtual RC RootEnd ( Tree::LocusNode & lNode )
	    {
		return InnerEnd(lNode);
	    }

    } dfs;
    dfs(_lRoot);
}

// *****************************************************************************

void
RootIndependent::InitialValues ()
{
    /// - Compute initial values of the constants.<br>
    ///   \f$\displaystyle c3 = \frac{\log \sigma^2}{2} + \frac{\log 2 \pi}{2} + \frac{\sigma^2}{2}\f$

    _c3   = ( log( (*_lRoot._ratesVarParm)() ) - log ( 2.0 * M_PI ) - (*_lRoot._ratesVarParm)() ) /2;
    _lnMu = log( (*_lRoot._ratesMeanParm)() );

    /// - Traverse the gene tree computing the prior

    struct Dfs : Tree::LocusDfs {

	virtual RC InnerBegin ( Tree::LocusNode & lNode )
	    {
		lNode._lnPR->NewRate();
		return CONTINUE;
	    }

	virtual RC Leaf ( Tree::LocusNode & lNode )
	    {
		return InnerBegin(lNode);
	    }

    } dfs;
    dfs(_lRoot);

}
