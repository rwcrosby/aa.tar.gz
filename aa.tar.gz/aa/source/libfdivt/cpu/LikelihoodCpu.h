/// @file LikelihoodCpu.h
/// Declarations for the cpu based likelihood algorithm methods.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _LIKELIHOODCPU_H_
#define _LIKELIHOODCPU_H_

struct Replicate;

namespace Tree {
    struct LocusNode;
    struct LocusRoot;
    struct Position;
    struct Root;
}

namespace LikelihoodCpu {

    /// Create a likelihood object at a species tree root.
    Likelihood *
    Factory ( Replicate &  repl,
	      Tree::Root & root );

    /// Create a likelihood object at a gene tree root.
    Likelihood *
    Factory ( Replicate &       repl,
	      Tree::LocusRoot & lRoot );

    /// Create a likelihood object at a species tree node.
    Likelihood *
    Factory ( Replicate &          repl,
	      const Tree::Position tPos );

    /// Create a likelihood object at a gene tree node.
    Likelihood *
    Factory ( Replicate &       repl,
	      Tree::LocusNode & lNode );

}

#endif // _LIKELIHOODCPU_H_
