/// @file TransitionMatrixCpu.cpp
/// Definitions for the cpu version of the transition matrix.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include <sstream>

#include "Dump.h"
#include "EvoModel.h"
#include "Replicates.h"
#include "TransitionMatrixCpu.h"

// *****************************************************************************

TransitionMatrixCpu::TransitionMatrixCpu( const unsigned n,
					  const unsigned nGCat,
					  EvoModel &     parent)
    : TransitionMatrix(n, nGCat, parent)
{
    _matrix    = new FLOAT [ _nGCat * (_n + 1) * _n ];
    _oldMatrix = new FLOAT [ _nGCat * (_n + 1) * _n ];

    auto m = _matrix;
    auto o = _oldMatrix;

    for ( unsigned gCat = 0; gCat < _nGCat; gCat++ )
        for ( unsigned row = 0; row < _n + 1; row++ )
            for ( unsigned col = 0; col < _n; col++ )

                if ( row == _n ) {
                    *m++ = 1.0;
                    *o++ = 1.0;
                }
                else {
                    *m++ = 0.0;
                    *o++ = 0.0;
                }
}

// *****************************************************************************

TransitionMatrixCpu::~TransitionMatrixCpu()
{
    delete[] _matrix;
    delete[] _oldMatrix;
}

// *****************************************************************************

static
std::string
tmat_string( const unsigned n,
             const unsigned nGCat,
             const FLOAT  * copy1,
             const FLOAT  * copy2 )
{
    std::string str;
    for ( unsigned gcat = 0; gcat < nGCat; gcat++ ) {
	std::string mstr;
	for ( unsigned i = 0; i < n + 1; i++ )
	    mstr += Dump::str(copy1, copy2, n) + '\n';
	str += Dump::indent_heading ( mstr, Dump::vector_heading(gcat, "gCat") ) + '\n';
    }

    return str;
}

// *****************************************************************************

std::string
TransitionMatrixCpu::str( const std::string hdg ) const
{
    std::stringstream ss;
    ss << TransitionMatrix::str(hdg) << ' '
       << Dump::ptr(_matrix, _oldMatrix, "matrix") << '\n'
       << Dump::indent(tmat_string(_n, _nGCat, _matrix, _oldMatrix));
    return ss.str();
}
