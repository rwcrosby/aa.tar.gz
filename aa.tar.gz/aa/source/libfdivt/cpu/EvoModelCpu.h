/// @file EvoModelCpu.h
/// Declarations of the evolutionary model classes for the cpu based algorithm.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _EVOMODELCPU_H_
#define _EVOMODELCPU_H_

#include "EvoModel.h"

struct Replicate;

namespace Tree {
    struct LocusRoot;
    struct Root;
}

/// Container for the cpu factory method.

struct EvoModelRootCpu : EvoModelRoot {

    EvoModelRootCpu ( Replicate &  repl,
		      Tree::Root & root )
	: EvoModelRoot ( repl, root )
	{}

    /// Create a gene tree evolutionary model instance.
    /// @param lRoot Gene tree root
    /// @returns Pointer to created model instance
    virtual
    EvoModel *
    Factory ( Tree::LocusRoot & lRoot );

   /// Create a species tree evolutionary model instance.
    /// @param repl Replicate owning the model.
    /// @param root Species tree root
    /// @returns Pointer to created model instance
    static
    EvoModelRoot *
    Factory ( Replicate &  repl,
	      Tree::Root & root );

};

#endif // _EVOMODELCPU_H_
