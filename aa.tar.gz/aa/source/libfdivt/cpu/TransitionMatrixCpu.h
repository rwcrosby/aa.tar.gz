/// @file TransitionMatrixCpu.h
/// Declaration of the cpu version of the transition matrix

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _TRANSITIONMATRIXCPU_H_
#define _TRANSITIONMATRIXCPU_H_

#include "TransitionMatrix.h"

// *****************************************************************************
/// Transition matrix for the cpu base algorithm.
/// Actual matrix is dimensionsed (N+1) x N x NGCat.
/// The additional row exists to provide values for the missing data value (1.0).

struct TransitionMatrixCpu : TransitionMatrix {

    /// Constructor used by the model's MakeTransitionMatrix method.
    /// @param n Matrix size (nxn).
    /// @param nGCat Number of gamma categories (1 for non-gamma models).
    /// @param parent Owning evolutionary model instance.
    TransitionMatrixCpu( const unsigned n,
			 const unsigned nGCat,
			 EvoModel &     parent);

    virtual ~TransitionMatrixCpu();

    virtual void Rollback()
	{
	    TransitionMatrix::Rollback();
            SwapMatrix();
	}

    /// Save state and log for rollback
    virtual
    void
    Save()
	{
	    TransitionMatrix::Save();
	    SwapMatrix();
	}

    /// Output the dump string for the model.
    /// @param hdg Heading to prepend to the dump string
    virtual std::string str ( const std::string hdg = "") const;

    /// Swap the working matrix back
    void SwapMatrix()
        {
            FLOAT * t = _matrix;
            _matrix    = _oldMatrix;
            _oldMatrix = t;
        }

    FLOAT *       _matrix;                        ///< The actual matrixes ( (n+1) x n x nGCat)
    FLOAT *       _oldMatrix;                     ///< Prior value of matrixes

};


#endif // _TRANSITIONMATRIXCPU_H_
