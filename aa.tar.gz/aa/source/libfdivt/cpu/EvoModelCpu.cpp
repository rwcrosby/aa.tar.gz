/// @file EvoModelCpu.cpp
/// Definitions for the evolutionary model methods for the cpu algorithm

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include <iostream>

#include "DivTime.h"
#include "Dump.h"
#include "Locus.h"
#include "EvoModel.h"
#include "EvoModelCpu.h"
#include "EvoModelParameters.h"
#include "Replicates.h"
#include "SequenceFactory.h"
#include "TransitionMatrixCpu.h"
#include "Tree.h"

// *****************************************************************************

static
void
ComputeMatrixJC69 ( FLOAT *       matrix,
		    const FLOAT   brLen );
static
void
ComputeMatrixK80  ( FLOAT *       matrix,
		    const FLOAT   brLen,
		    const FLOAT   kappa1 );

static
void
ComputeMatrixTN93 ( FLOAT            matrix[],
		    const FLOAT      brLen,
		    const FLOAT      kappa1,
		    const FLOAT      kappa2,
		    const FLOATVEC & freqParms );

static
void
ComputeMatrixGTR( FLOAT       matrix[],
		  const FLOAT dist,
		  FLOAT *     c,
		  FLOAT *     Wr );

// *****************************************************************************
/// Subclass of the base evolutionary mode for the CPU base algorithm.

struct EvoModelCpuImpl : EvoModel {

    EvoModelCpuImpl ( EvoModelRoot &   parent,
		      Tree::LocusRoot& lRoot )
	: EvoModel( parent, lRoot)
	{}

    /// Factory to build a transition matrix based on an evolutionary model.
    /// Does not populate the matrix.
    virtual
    TransitionMatrix *
    MakeTransitionMatrix ();

    virtual
    void
    UpdateTMatrix ( TransitionMatrix * tMat,
		    const FLOAT       dist )
	{
	    tMat->Save();
	    tMat->_dist = dist;
	    ComputeTMatrix(static_cast<TransitionMatrixCpu*>(tMat));
	}

    virtual
    void
    UpdateTMatrix ( TransitionMatrix * tMat )
	{
	    tMat->Save();
	    ComputeTMatrix(static_cast<TransitionMatrixCpu*>(tMat));
	}

    /// Compute the values in a transition matrix.
    /// Works across gamma rate categories.
    /// Swaps matricies prior
    virtual
    void
    ComputeTMatrix ( TransitionMatrixCpu * tMat ) = 0;

};

// *************************************************************************
/// Model subclass for the Jukes-Cantor model

struct JC69 : EvoModelCpuImpl {

    JC69 ( EvoModelRoot &    parent,
	   Tree::LocusRoot & lRoot )
	: EvoModelCpuImpl(parent, lRoot),
	  _charFreqs(_parent._n, 1.0/FLOAT (_parent._n))
	{}

    virtual
    const
    FLOATVEC &
    CharFreq () const
	{
	    return _charFreqs;
	}

    /// Compute the values in a transition matrix
    virtual
    void
    ComputeTMatrix ( TransitionMatrixCpu * tMat )
	{
	    ComputeMatrixJC69 ( tMat->_matrix,
				tMat->_dist );
	}

    /// Output the dump string for the model
    virtual
    std::string
    str ( const std::string hdg = "") const;

    /// The set of constant character frequencies
    FLOATVEC _charFreqs;

};

/// Model subclass for the Jukes-Cantor model with gamma rate categories

struct JC69_G : JC69 {

    JC69_G ( EvoModelRoot &    parent,
	     Tree::LocusRoot & lRoot )
	: JC69(parent, lRoot)
	{}

    /// Update all gamma rate categories for a matrix
    virtual
    void
    ComputeTMatrix ( TransitionMatrixCpu * tMat )
	{
	    for ( unsigned i = 0; i < _parent._nGCat; i++ )
		ComputeMatrixJC69 ( tMat->_matrix + 4 * (4 + 1) * i,
				    tMat->_dist * _rateVec[i] );
	}

};

// *************************************************************************
/// Model subclass for the Kimura 1980 two parameter model.

struct K80 : EvoModelCpuImpl {

    K80 ( EvoModelRoot &    parent,
	  Tree::LocusRoot & lRoot );

    virtual
    ~K80()
	{
	    delete _kappa;
	}

    virtual
    const
    FLOATVEC &
    CharFreq () const
	{
	    return _charFreqs;
	}

    /// Update a transition matrix instance
    virtual
    void
    ComputeTMatrix ( TransitionMatrixCpu * tMat )
	{
	    ComputeMatrixK80 ( tMat->_matrix,
			       tMat->_dist,
			       (*_kappa)() );
	}

    /// Output the dump string for the model.
    virtual
    std::string
    str ( const std::string hdg = "") const;

    /// The \f$\kappa\f$ model parameter.
    Parameter * _kappa;

    /// The set of constant character frequencies
    FLOATVEC    _charFreqs;

};

/// Model subclass for the Kimura model with gamma rate categories

struct K80_G : K80 {

    K80_G ( EvoModelRoot &    parent,
	    Tree::LocusRoot & lRoot )
	: K80(parent, lRoot)
	{}

    /// Update all gamma rate categories for a matrix
    virtual
    void
    ComputeTMatrix ( TransitionMatrixCpu * tMat )
	{
	    for ( unsigned i = 0; i < _parent._nGCat; i++ )
		ComputeMatrixK80( tMat->_matrix + 4 * (4 + 1) * i,
				  tMat->_dist * _rateVec[i],
				  (*_kappa)() );
	}

};

// *************************************************************************
/// Model subclass for Felsenstein 1981 model

struct F81 : EvoModelCpuImpl {

    F81 ( EvoModelRoot &    parent,
	  Tree::LocusRoot & lRoot );

    virtual
    ~F81()
	{
	    delete _freqParms;
	}

    virtual
    const
    FLOATVEC &
    CharFreq () const
	{
	    return _freqParms->_values;
	}

    /// Update a transition matrix instance
    virtual
    void
    ComputeTMatrix ( TransitionMatrixCpu * tMat )
	{
	    ComputeMatrixTN93 ( tMat->_matrix,
				tMat->_dist,
				1.0,
				1.0,
				_freqParms->_values );
	}

    /// Output the dump string for the model
    virtual
    std::string
    str ( const std::string hdg = "") const;

    DirichletParameterSet * _freqParms;

};

/// Model subclass for the Felsenstein 1981 model with gamma rate categories

struct F81_G : F81 {

    F81_G ( EvoModelRoot &    parent,
	    Tree::LocusRoot & lRoot )
	: F81(parent, lRoot)
	{}

    /// Update all gamma rate categories for a matrix
    virtual
    void
    ComputeTMatrix ( TransitionMatrixCpu * tMat )
	{
	    for ( unsigned i = 0; i < _parent._nGCat; i++ )
		ComputeMatrixTN93 ( tMat->_matrix + 4 * (4 + 1) * i,
				    tMat->_dist * _rateVec[i],
				    1.0,
				    1.0,
				    _freqParms->_values );
	}

};

// *************************************************************************
/// Model subclass for Felsenstein 1984 model

struct F84 : EvoModelCpuImpl {

    F84 ( EvoModelRoot &    parent,
	  Tree::LocusRoot & lRoot );

    virtual
    ~F84()
	{
	    delete _kappa;
	    delete _freqParms;
	}

    virtual
    const
    FLOATVEC &
    CharFreq () const
	{
	    return _freqParms->_values;
	}

    /// Update a transition matrix instance
    virtual
    void
    ComputeTMatrix ( TransitionMatrixCpu * tMat )
	{
	    auto & parms = _freqParms->_values;
	    ComputeMatrixTN93 ( tMat->_matrix,
			       tMat->_dist,
			       1.0 + (*_kappa)()/(parms[0] + parms[1]),
			       1.0 + (*_kappa)()/(1.0 - parms[0] - parms[1]),
			       _freqParms->_values );
	}

    /// Output the dump string for the model
    virtual
    std::string
    str  ( const std::string hdg = "") const;

    Parameter *             _kappa;
    DirichletParameterSet * _freqParms;

};

/// Model subclass for the Felsenstein 1984 model with gamma rate categories

struct F84_G : F84 {

    F84_G ( EvoModelRoot &    parent,
	    Tree::LocusRoot & lRoot )
	: F84(parent, lRoot)
	{}

    /// Update all gamma rate categories for a matrix
    virtual
    void
    ComputeTMatrix ( TransitionMatrixCpu * tMat )
	{
	    auto & parms = _freqParms->_values;
	    for ( unsigned i = 0; i < _parent._nGCat; i++ )
		ComputeMatrixTN93 ( tMat->_matrix + 4 * (4 + 1) * i,
				   tMat->_dist * _rateVec[i],
				   1.0 + (*_kappa)()/(parms[0] + parms[1]),
				   1.0 + (*_kappa)()/(1.0 - parms[0] - parms[1]),
				   _freqParms->_values );
	}

};

// *************************************************************************
/// Model subclass for HKY 1985 model

struct HKY85 : EvoModelCpuImpl {

    HKY85 ( EvoModelRoot &    parent,
	    Tree::LocusRoot & lRoot );

    virtual
    ~HKY85()
	{
	    delete _kappa;
	    delete _freqParms;
	}

    virtual
    const
    FLOATVEC &
    CharFreq () const
	{
	    return _freqParms->_values;
	}

    /// Update a transition matrix instance
    virtual
    void
    ComputeTMatrix ( TransitionMatrixCpu * tMat )
	{
	    ComputeMatrixTN93 ( tMat->_matrix,
			       tMat->_dist,
			       (*_kappa)(),
			       (*_kappa)(),
			       _freqParms->_values );
	}

    /// Output the dump string for the model
    virtual
    std::string
    str  ( const std::string hdg = "") const;

    Parameter *             _kappa;
    DirichletParameterSet * _freqParms;

};

/// Model subclass for the HKY 1985 model with gamma rate categories

struct HKY85_G : HKY85 {

    HKY85_G ( EvoModelRoot &    parent,
	      Tree::LocusRoot & lRoot )
	: HKY85(parent, lRoot)
	{}

    /// Update all gamma rate categories for a matrix
    virtual
    void
    ComputeTMatrix ( TransitionMatrixCpu * tMat )
	{
	    for ( unsigned i = 0; i < _parent._nGCat; i++ )
		ComputeMatrixTN93( tMat->_matrix + 4 * (4 + 1) * i,
				   tMat->_dist * _rateVec[i],
				   (*_kappa)(),
				   (*_kappa)(),
				   _freqParms->_values );
	}

};

// *************************************************************************

struct T92 : EvoModelCpuImpl {

    T92 ( EvoModelRoot &    parent,
	  Tree::LocusRoot & lRoot );

    virtual
    ~T92()
	{
	    delete _kappa;
	    delete _gcFreq;
	}

    virtual
    const
    FLOATVEC &
    CharFreq () const
	{
	    return _charFreqs;
	}

    /// Update a transition matrix instance
    virtual
    void
    ComputeTMatrix ( TransitionMatrixCpu * tMat )
	{
	    ComputeMatrixTN93 ( tMat->_matrix,
				tMat->_dist,
				(*_kappa)(),
				(*_kappa)(),
				{ (1 - (*_gcFreq)()) / 2,
				  (*_gcFreq)() / 2,
				  (1 - (*_gcFreq)()) / 2,
				  (*_gcFreq)() / 2 } );
	}

    /// Output the dump string for the model
    virtual
    std::string
    str  ( const std::string hdg = "") const;

    Parameter * _kappa;
    Parameter * _gcFreq;

    /// The set of constant character frequencies
    FLOATVEC    _charFreqs;

};

/// Model subclass for the HKY 1985 model with gamma rate categories

struct T92_G : T92 {

    T92_G ( EvoModelRoot &    parent,
	    Tree::LocusRoot & lRoot )
	: T92(parent, lRoot)
	{}

    /// Update all gamma rate categories for a matrix
    virtual
    void
    ComputeTMatrix ( TransitionMatrixCpu * tMat )
	{
	    for ( unsigned i = 0; i < _parent._nGCat; i++ )
		ComputeMatrixTN93 ( tMat->_matrix + 4 * (4 + 1) * i,
				    tMat->_dist * _rateVec[i],
				    (*_kappa)(),
				    (*_kappa)(),
				    { (1 - (*_gcFreq)()) / 2,
				      (*_gcFreq)() / 2,
				      (1 - (*_gcFreq)()) / 2,
				      (*_gcFreq)() / 2 } );
	}

};

// *************************************************************************

struct TN93 : EvoModelCpuImpl {

    TN93 (EvoModelRoot &    parent,
	  Tree::LocusRoot & lRoot );

    virtual
    ~TN93()
	{
	    delete _kappa1;
	    delete _kappa2;
	    delete _freqParms;
	}

    virtual
    const
    FLOATVEC &
    CharFreq () const
	{
	    return _freqParms->_values;
	}

    /// Update a transition matrix instance
    virtual
    void
    ComputeTMatrix ( TransitionMatrixCpu * tMat )
	{
	    ComputeMatrixTN93 ( tMat->_matrix,
				tMat->_dist,
				(*_kappa1)(),
				(*_kappa2)(),
				_freqParms->_values );
	}

    /// Output the dump string for the model
    virtual
    std::string
    str  ( const std::string hdg = "") const;

    Parameter *             _kappa1;
    Parameter *             _kappa2;
    DirichletParameterSet * _freqParms;

};

/// Model subclass for the HKY 1985 model with gamma rate categories

struct TN93_G : TN93 {

    TN93_G ( EvoModelRoot &    parent,
	     Tree::LocusRoot & lRoot )
	: TN93(parent, lRoot)
	{}
    /// Update all gamma rate categories for a matrix

    virtual
    void
    ComputeTMatrix ( TransitionMatrixCpu * tMat )
	{
	    for ( unsigned i = 0; i < _parent._nGCat; i++ )
		ComputeMatrixTN93( tMat->_matrix + 4 * (4 + 1) * i,
				   tMat->_dist * _rateVec[i],
				   (*_kappa1)(),
				   (*_kappa2)(),
				   _freqParms->_values );
	}

};

// *************************************************************************
/// Model subclass for the generalized time reversable model.

struct GTR : EvoModelCpuImpl {

    GTR ( EvoModelRoot &    parent,
	  Tree::LocusRoot & lRoot );

    virtual
    ~GTR()
	{
	    delete _modelParms;
	    delete _freqParms;
	}

    virtual
    const
    FLOATVEC &
    CharFreq () const
	{
	    return _freqParms->_values;
	}

    /// Update a transition matrix instance
    virtual
    void
    ComputeTMatrix ( TransitionMatrixCpu * tMat )
	{
	    ComputeMatrixGTR ( tMat->_matrix,
			       tMat->_dist,
			       _cMat,
			       _Wr );
	}

    /// Update all transition matricies recomputing the eigenvectors and values.
    virtual
    void
    UpdateAllTMatrixes ();

    /// Output the dump string for the model
    virtual
    std::string
    str  ( const std::string hdg = "") const;

    /// Matrix dimension
    static const unsigned    N = 4;

    DirichletParameterSet *  _modelParms;
    DirichletParameterSet *  _freqParms;

    /// The multiplier matrix.
    /// The matrix is defined here so it's addressable wherever needed.
    FLOAT                   _cMat[N*N*N];

    /// The eigenvalues (real only).
    FLOAT                   _Wr[N];

};

/// Model subclass for the generalized time reversable model with gamma rate categories.

struct GTR_G : GTR {

    GTR_G ( EvoModelRoot &    parent,
	    Tree::LocusRoot & lRoot )
	: GTR(parent, lRoot)
	{}

    /// Update all gamma rate categories for a matrix
    virtual
    void
    ComputeTMatrix ( TransitionMatrixCpu * tMat )
	{
	    for ( unsigned i = 0; i < _parent._nGCat; i++ )
		ComputeMatrixGTR( tMat->_matrix + 4 * (4 + 1) * i,
				  tMat->_dist * _rateVec[i],
				  _cMat,
				  _Wr );
	}

};

// *****************************************************************************
/// Transition matrix computation for the JC69 model
/// From Yang (Paml v4.8)

static
void
ComputeMatrixJC69 ( FLOAT            matrix[],
		    const FLOAT      brLen )
{

    FLOAT term1 = exp( -4.0 * brLen );

    matrix[0]  =
                 matrix[5]  =
                              matrix[10] =
                                           matrix[15] =
                                               0.25 * ( 1.0  + 3.0 * term1);
                 matrix[1]  =  matrix[2] =  matrix[3] =
    matrix[4]  =               matrix[6] =  matrix[7] =
    matrix[8]  = matrix[9] =               matrix[11]  =
    matrix[12] = matrix[13] = matrix[14] =
                                               0.25 * ( 1.0  - term1);

}

// *****************************************************************************
/// Transition matrix computation for the K80 model
/// From Yang (Paml v4.8)

static
void
ComputeMatrixK80 ( FLOAT            matrix[],
		   const FLOAT      brLen,
		   const FLOAT      kappa )
{

    const FLOAT term1  = exp( - ( 4.0 * brLen )/ ( 2.0 + kappa ));
    const FLOAT term2  = exp( - ( 2.0 * brLen * ( 1.0 + kappa )  ) / ( 2.0 + kappa ) );

    const FLOAT pdiag  = 0.25 * ( 1.0  + term1 + 2.0 * term2);
    const FLOAT ratio  = 0.25 * ( 1.0  + term1 - 2.0 * term2);
    const FLOAT transv = 0.25 - 0.25 * term1;

    matrix[0]   = pdiag;
    matrix[1]   = ratio;
    matrix[2]   = transv;
    matrix[3]   = transv;

    matrix[4]   = ratio;
    matrix[5]   = pdiag;
    matrix[6]   = transv;
    matrix[7]   = transv;

    matrix[8]   = transv;
    matrix[9]   = transv;
    matrix[10]  = pdiag;
    matrix[11]  = ratio;

    matrix[12]  = transv;
    matrix[13]  = transv;
    matrix[14]  = ratio;
    matrix[15]  = pdiag;

}

// *****************************************************************************
/// Transition matrix computation for the F81 to TN93 models.
/// From Yang (Paml v4.8)

static
void
ComputeMatrixTN93 ( FLOAT            matrix[],
		    const FLOAT      brLen,
		    const FLOAT      kappa1,
		    const FLOAT      kappa2,
		    const FLOATVEC & freqParms )
{

    if ( debugSet )
	assert ( freqParms.size() == 4 && "Bad frequence parms vector");

    FLOAT T = freqParms[0];
    FLOAT C = freqParms[1];
    FLOAT A = freqParms[2];
    FLOAT G = freqParms[3];

    FLOAT Y = T + C;
    FLOAT R = A + G;

    FLOAT mr = 1/( 2*T*C*kappa1 + 2*A*G*kappa2 + 2*Y*R );

    FLOAT a1t = brLen * mr * kappa1;
    FLOAT a2t = brLen * mr * kappa2;
    FLOAT bt  = brLen * mr;

    FLOAT e1 = exp(-bt);
    FLOAT e2 = exp(-(R*a2t + Y*bt));
    FLOAT e3 = exp(-(Y*a1t + R*bt));

    matrix[0*4+0] = T + R*T/Y*e1 + C/Y*e3;
    matrix[0*4+1] = C + R*C/Y*e1 - C/Y*e3;
    matrix[0*4+2] = A*(1-e1);
    matrix[0*4+3] = G*(1-e1);

    matrix[1*4+0] = T + R*T/Y*e1 - T/Y*e3;
    matrix[1*4+1] = C + R*C/Y*e1 + T/Y*e3;
    matrix[1*4+2] = A*(1 - e1);
    matrix[1*4+3] = G*(1 - e1);

    matrix[2*4+0] = T*(1 - e1);
    matrix[2*4+1] = C*(1 - e1);
    matrix[2*4+2] = A + Y*A/R*e1 + G/R*e2;
    matrix[2*4+3] = G + Y*G/R*e1 - G/R*e2;

    matrix[3*4+0] = T*(1 - e1);
    matrix[3*4+1] = C*(1 - e1);
    matrix[3*4+2] = A + Y*A/R*e1 - A/R*e2;
    matrix[3*4+3] = G + Y*G/R*e1 + A/R*e2;

}

// *****************************************************************************

void
ComputeMatrixGTR( FLOAT       matrix[],
		  const FLOAT brLen,
		  FLOAT *     c,
		  FLOAT *     Wr )
{

    FLOAT eExp[GTR::N];

    for ( unsigned i = 0; i < GTR::N; i++ )
        eExp[i] = exp ( *Wr++ * brLen );

    for ( unsigned i = 0; i < GTR::N; i++ )
        for ( unsigned j = 0; j < GTR::N; j++ ) {
            FLOAT sum = 0.0;
            for ( unsigned k = 0; k < GTR::N; k++ )
                sum += *c++ * eExp[k];
            *matrix++ = (sum < 0.0) ? 0.0 : sum;
        }

}

// *****************************************************************************

TransitionMatrix *
EvoModelCpuImpl::MakeTransitionMatrix ()
{
    auto tm = new TransitionMatrixCpu(_parent._n, _parent._nGCat, *this);
    _tMatrixList.push_back(tm);
    return tm;
}

// *****************************************************************************
/// Static method to build a species tree instance.

EvoModelRoot *
EvoModelRootCpu::Factory ( Replicate &  repl,
			   Tree::Root & root )
{
    return new EvoModelRootCpu(repl, root);
}

// *****************************************************************************

EvoModel *
EvoModelRootCpu::Factory ( Tree::LocusRoot & lRoot )
{
    auto & dt = _repl._dt;

    EvoModel * em = nullptr;

    switch (dt._eModel) {

    case Options::EvoModel::JC69:
        em = ( dt._eMGammaCats == 1 )
            ? new JC69( *this, lRoot )
            : new JC69_G( *this, lRoot );
        break;

    case Options::EvoModel::K80:
        em = ( dt._eMGammaCats == 1 )
            ? new K80( *this, lRoot )
            : new K80_G( *this, lRoot );
        break;

    case Options::EvoModel::F81:
        em = ( dt._eMGammaCats == 1 )
            ? new F81( *this, lRoot )
            : new F81_G( *this, lRoot );
        break;

    case Options::EvoModel::F84:
        em = ( dt._eMGammaCats == 1 )
            ? new F84( *this, lRoot )
            : new F84_G( *this, lRoot );
        break;

    case Options::EvoModel::HKY85:
        em = ( dt._eMGammaCats == 1 )
            ? new HKY85( *this, lRoot )
            : new HKY85_G( *this, lRoot );
        break;

    case Options::EvoModel::T92:
        em = ( dt._eMGammaCats == 1 )
            ? new T92( *this, lRoot )
            : new T92_G( *this, lRoot );
        break;

    case Options::EvoModel::TN93:
        em = ( dt._eMGammaCats == 1 )
            ? new TN93( *this, lRoot )
            : new TN93_G( *this, lRoot );
        break;

    case Options::EvoModel::GTR:
        em = ( dt._eMGammaCats == 1 )
            ? new GTR( *this, lRoot )
            : new GTR_G( *this, lRoot );
        break;

    default:
        assert(0 && "Invalid Model");

    }

    return em;

}

// *****************************************************************************
/// Output the dump string representation of the model.

std::string
JC69::str(const std::string hdg) const
{
    return (hdg.length() ? hdg : "") +
	"<JC69 " +
	EvoModel::str() +
	'>';
}

// *****************************************************************************

K80::K80( EvoModelRoot &    parent,
	  Tree::LocusRoot & lRoot )
    : EvoModelCpuImpl(parent, lRoot),
      _charFreqs(_parent._n, 1.0/FLOAT (_parent._n))
      {

    /// - Create and add the transition/transversion ratio parameter.

    _kappa = new GammaParameter( *this,
				 _repl._dt._eMParms[0],
				 _repl._dt._eMParms[1],
				 "Kappa" );

}

// *****************************************************************************
/// Output the dump string representation of the model.

std::string
K80::str(const std::string hdg) const
{
    std::stringstream ss;
    if ( hdg.size() ) ss << hdg << "<";

    ss << "K80 "
       << Dump::pstr(_kappa, "kappa")
       << EvoModel::str();

    if ( hdg.size() ) ss << ">";
    return ss.str();
}

// *****************************************************************************

F81::F81( EvoModelRoot &    parent,
	  Tree::LocusRoot & lRoot )
    : EvoModelCpuImpl(parent, lRoot)
{
    _freqParms = EvoModel::FrequencyParmsSetup( *this,
						lRoot._locus._charPct,
						_repl._dt._eMFreqParms );
}

// *****************************************************************************
/// Output the dump string representation of the model.

std::string
F81::str(const std::string hdg) const
{
    std::stringstream ss;
    if ( hdg.size() ) ss << hdg << "<";

    ss << "F81 "
       << Dump::pstr(_freqParms, "freqParms") << ' '
       << EvoModel::str();

    if ( hdg.size() ) ss << ">";
    return ss.str();
}

// *****************************************************************************

F84::F84( EvoModelRoot &    parent,
	  Tree::LocusRoot & lRoot )
    : EvoModelCpuImpl(parent, lRoot)
{

    /// - Create and add the transition/transversion ratio parameter.

    _kappa = new GammaParameter ( *this,
				  _repl._dt._eMParms[0],
				  _repl._dt._eMParms[1],
				  "Kappa" );

    /// - Create the character frequency parms

    _freqParms = EvoModel::FrequencyParmsSetup( *this,
						lRoot._locus._charPct,
						_repl._dt._eMFreqParms );

}

// *****************************************************************************
/// Output the dump string representation of the model.

std::string
F84::str ( const std::string hdg ) const
{
    std::stringstream ss;
    if ( hdg.size() ) ss << hdg << "<";

    ss << "F81 "
       << Dump::pstr(_kappa, "kappa") << ' '
       << Dump::pstr(_freqParms, "freqParms") << ' '
       << EvoModel::str();

    if ( hdg.size() ) ss << ">";
    return ss.str();
}

// *****************************************************************************

HKY85::HKY85( EvoModelRoot &    parent,
	      Tree::LocusRoot & lRoot )
    : EvoModelCpuImpl(parent, lRoot)
{

    /// - Create and add the transition/transversion ratio parameter.

    _kappa = new GammaParameter ( *this, _repl._dt._eMParms[0], _repl._dt._eMParms[1], "Kappa" );

    /// - Create the character frequency parms

    _freqParms = EvoModel::FrequencyParmsSetup( *this,
						lRoot._locus._charPct,
						_repl._dt._eMFreqParms );
}

// *****************************************************************************

std::string
HKY85::str  ( const std::string hdg ) const
{
    std::stringstream ss;
    if ( hdg.size() ) ss << hdg << "<";

    ss << "HKY85 "
       << Dump::pstr(_kappa, "kappa") << ' '
       << Dump::pstr(_freqParms, "freqParms") << ' '
       << EvoModel::str();

    if ( hdg.size() ) ss << ">";
    return ss.str();
}

// *****************************************************************************

T92::T92( EvoModelRoot &    parent,
	  Tree::LocusRoot & lRoot )
    : EvoModelCpuImpl(parent, lRoot),
      _charFreqs(_parent._n, 1.0/FLOAT (_parent._n))

{

    const DivTime& dt = _repl._dt;

    /// - Create and add the transition/transversion ratio parameter.

    _kappa = new GammaParameter ( *this, dt._eMParms[0], dt._eMParms[1], "Kappa" );

    /// - If the frequencies are not specified, use the values from the locus

    FLOATVEC gcParms;

    if ( dt._eMFreqParms.size() == 2 )
        gcParms =  dt._eMFreqParms;
    else {
        if ( auto idx = dt._seqFactory->_alphabet.find('G') == std::string::npos )
            throw Except::ModelError("No 'G' value in alphabet, required for T92 model");
        else
            gcParms.push_back(lRoot._locus._charPct[idx]);
        if ( auto idx = dt._seqFactory->_alphabet.find('C') == std::string::npos )
            throw Except::ModelError("No 'C' value in alphabet, required for T92 model");
        else
            gcParms.push_back(lRoot._locus._charPct[idx]);
    }

    _gcFreq = new GammaParameter ( *this, gcParms[0], gcParms[1], "Freq GC", "Freq_GC" );

}

// *****************************************************************************
/// Output the dump string representation of the model.

std::string
T92::str( const std::string hdg ) const
{
    std::stringstream ss;
    if ( hdg.size() ) ss << hdg << "<";

    ss << "T92 "
       << Dump::pstr(_kappa, "kappa") << ' '
       << Dump::pstr(_gcFreq, "gcFreq") << ' '
       << EvoModel::str();

    if ( hdg.size() ) ss << ">";
    return ss.str();
}

// *****************************************************************************

TN93::TN93( EvoModelRoot &    parent,
	    Tree::LocusRoot & lRoot )
    : EvoModelCpuImpl(parent, lRoot)
{

    /// - Create and add the transition/transversion ratio parametera.

    _kappa1 = new GammaParameter ( *this, _repl._dt._eMParms[0], _repl._dt._eMParms[1], "Kappa_1", "Kappa 1");
    _kappa2 = new GammaParameter ( *this, _repl._dt._eMParms[2], _repl._dt._eMParms[3], "Kappa_2", "Kappa 2");

    /// - Create the character frequency parms

    _freqParms = EvoModel::FrequencyParmsSetup( *this,
						lRoot._locus._charPct,
						_repl._dt._eMFreqParms );

}

// *****************************************************************************

std::string
TN93::str( const std::string hdg ) const
{
    std::stringstream ss;
    if ( hdg.size() ) ss << hdg << "<";

    ss << "TN93 "
       << Dump::pstr(_kappa1, "kappa1") << ' '
       << Dump::pstr(_kappa2, "kappa2") << ' '
       << Dump::pstr(_freqParms, "freqParms") << ' '
       << EvoModel::str();

    if ( hdg.size() ) ss << ">";
    return ss.str();
}

// *****************************************************************************

GTR::GTR( EvoModelRoot &    parent,
	  Tree::LocusRoot & lRoot )
    : EvoModelCpuImpl(parent, lRoot)
{

    /// - Setup the headings for the trace file

    STRINGVEC hdgs;
    for ( unsigned i = 1; i <= _repl._dt._eMParms.size(); i++ )
	hdgs.emplace_back("GTR_" + std::to_string(i));

    /// - Create the model parameters setting initial values.

    _modelParms = new DirichletParameterSet(*this,
					    _repl._dt._eMParms,
					    "GTR",
					    {"Alpha", "Beta", "Gamma", "Delta", "Epsilon", "Zeta"});

    /// - Create the character frequency parms

    _freqParms = EvoModel::FrequencyParmsSetup( *this,
						lRoot._locus._charPct,
						_repl._dt._eMFreqParms) ;

}

// *****************************************************************************
/// The various matricies and vectors that don't need to persist are allocated on
/// the stack. This shouldn't be a problem (total memory is about 736 bytes)
/// particularly since the routine isn't is in a recursive stack frame.
/// There is some impediance matching required to make the code from Mr. Bayes work here.

void
GTR::UpdateAllTMatrixes()
{

    /// - Compute the eigenvalues and multipler matrix.

    EvoModel::ComputeGTRLocusConstants ( _modelParms, _freqParms, _cMat, _Wr );

    /// - Finally do the actual matrix updates

    EvoModel::UpdateAllTMatrixes();

}

// *****************************************************************************

std::string
GTR::str( const std::string hdg ) const
{
    std::stringstream ss;
    if ( hdg.size() ) ss << hdg << "<";

    ss << "GTR "
       << Dump::pstr(_modelParms, "modelParms") << ' '
       << Dump::pstr(_freqParms, "freqParms") << ' '
       << EvoModel::str();

    if ( hdg.size() ) ss << ">";
    return ss.str();
}
