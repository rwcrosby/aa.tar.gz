/// @file LikelihoodCpu.cpp
/// Definitions for the cpu based likelihood algorithm

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include <iostream>
#include <iomanip>

#include "Dump.h"
#include "EvoModel.h"
#include "Likelihood.h"
#include "LikelihoodCpu.h"
#include "Locus.h"
#include "Replicates.h"
#include "TransitionMatrixCpu.h"
#include "Tree.h"

// *****************************************************************************

struct CpuLocusNode;
struct CpuLocusRoot;

void
SwapVec( FLOAT * & a,
	 FLOAT * & b );

// *****************************************************************************
/// Likelihood object at a gene tree node.
/// The is where the heavy lifting occurs.

struct CpuLocusNode : Likelihood {

    /// Function type definition for the computational modules.
    typedef void (*ComputeNodeVec) ( CpuLocusNode * lkh  );

    CpuLocusNode(Replicate &       repl,
		 Tree::LocusNode & lNode );

    virtual
    ~CpuLocusNode();

    virtual
    FLOAT
    Compute();

    virtual
    void
    Rollback()
	{
	    Likelihood::Rollback();
	    SwapVec( _baseVec, _oldBaseVec );
	    if ( _swappedLeft )
		SwapVec( _lhsVec, _oldLhsVec );
	    if ( _swappedRight )
		SwapVec( _rhsVec, _oldRhsVec );
	}

    virtual
    std::string
    str ( const std::string hdg = "")
	const;

    void
    UpdateBaseVecs();

    void
    UpdateBaseVecLeft();

    void
    UpdateBaseVecRight();

    Tree::LocusNode &           _lNode;           ///< Owning locus node
    const Tree::LocusRoot &     _lRoot;           ///< Owning gene tree
    const EvoModel &            _eModel;	  ///< Associated evolutionary model

    const unsigned              _n;               ///< Number of sequence bases
    const unsigned              _nGCat;           ///< Number of gamma rate catetories

    const Tree::SITEVEC *       _mySiteVec;       ///< This nodes site vector.

    /// Gene tree root likelihood instance.
    CpuLocusRoot *              _lkhLRoot;

    /// Address of the current left child transition matrix instance.
    const TransitionMatrixCpu * _lhTMatrix;

    /// Left child likelihood module.
    const CpuLocusNode *        _lhLkh;

    /// Address of the current right child transition matrix instance.
    const TransitionMatrixCpu * _rhTMatrix;

    /// Left child likelihood module.
    const CpuLocusNode *        _rhLkh;

    FLOAT *                    _baseVec;         ///< Vector of probabilities by base and gamma class
    FLOAT *                    _oldBaseVec;      ///< To facilitate proposition rollback

    /// Vector for the left child containing the sums of the products of the transition
    /// matrixes and base vectors. Used in cases where only one branch is changed and the
    /// other can use precomputed values (e.g. rate proposals recomputing the likelihood from
    /// the node containing the new rate to the root),
    FLOAT *                    _lhsVec;
    FLOAT *                    _oldLhsVec;
    bool                        _swappedLeft;

    /// Vector for the right child containing the sums of the products of the transition
    /// matrixes and base vectors. Used in cases where only one branch is changed and the
    /// other can use precomputed values (e.g. rate proposals recomputing the likelihood from
    /// the node containing the new rate to the root),
    FLOAT *                    _rhsVec;
    FLOAT *                    _oldRhsVec;
    bool                        _swappedRight;

    /// Function computes the base vector at the node using both
    /// left and right children.
    ComputeNodeVec              _compBaseVec;

    /// Function computes the base vector when only this branches
    /// left child has changed.
    ComputeNodeVec              _compBaseVecLeft;

    /// Function computes the base vector when only this branches
    /// right child has changed.
    ComputeNodeVec              _compBaseVecRight;

};

// *****************************************************************************
/// Likelihood object at a gene tree root

struct CpuLocusRoot : Likelihood {

    /// Function type definition for the likelihood routine.
    typedef FLOAT (*ComputeLogLikelihood)( const CpuLocusNode * lkh ,
					   const FLOATVEC &     basePct );

    CpuLocusRoot(Replicate &       repl,
		 Tree::LocusRoot & lRoot );

    virtual
    FLOAT
    Compute();

    FLOAT
    UpdateValue();

    Tree::LocusRoot &           _lRoot;

    const EvoModel &            _eModel;

    /// Function compute the loglikelihood value at the node
    ComputeLogLikelihood        _compLogLkh;

};

// *****************************************************************************
/// Likelihood object at a species tree root

struct CpuRoot : Likelihood {

    CpuRoot( Replicate &  repl,
	     Tree::Root & root )
	: Likelihood(repl),
	  _root(root)
	{}

    virtual
    FLOAT
    operator()();

    virtual
    FLOAT
    Compute();

    Tree::Root & _root;

};

// *****************************************************************************
/// Likelihood object at a species tree node

struct CpuTreeNode : Likelihood {

    CpuTreeNode(Replicate &          repl,
		const Tree::Position tPos )
	: Likelihood(repl),
	  _tPos(std::move(tPos))
	{}

    virtual
    FLOAT
    Compute();

    const Tree::Position _tPos;

};

// *****************************************************************************
/// Template to generate the various base vector computation functions at the nodes.
/// This depends on the optimizer to generate clean code for the various cases.
/// For example, "if (0) whatever;" should be optimized out.
/// @tparam LINNER Set to true if the left child is an inner node, false if it's a leaf.
/// @tparam RINNER Set to true if the right child is an inner node, false if it's a leaf.
/// @tparam N4 Set to true if this for the 4 nucleotide DNA case.
/// @tparam GAMMA Set to true if this will handle discrete gamma rate classes.
/// @tparam NGCAT4 Set to true the number of discrete gamma rate classes is 4 (the default).
/// @tparam LCONST Set to true if lhs is considered constant (inner nodes only).
/// @tparam RCONST Set to true if rhs is considered constant (inner nodes only).
/// @param lkh Likelihood functor for the current node.

template< bool LINNER,
	  bool RINNER,
	  bool N4,
	  bool GAMMA,
	  bool NGCAT4,
	  bool LCONST = false,
	  bool RCONST = false >
void
ComputeNodeVec( CpuLocusNode * lkh )
{
    FLOAT *        bv      = lkh->_baseVec;

    const unsigned nCodes  = N4 ? 4 : lkh->_n;
    const unsigned nGCat   = GAMMA ? (NGCAT4 ? 4 : lkh->_nGCat) : 1;

    const unsigned tmSize  = nCodes * (nCodes + 1);
    const unsigned bvSize  = nCodes;

    FLOAT*         rhsCVec = lkh->_rhsVec;
    FLOAT*         lhsCVec = lkh->_lhsVec;

    for ( auto & site : *lkh->_mySiteVec ) {

	const FLOAT* lhsTMat  = lkh->_lhTMatrix->_matrix;
	const FLOAT* lhsBVec;

	if ( LINNER && !LCONST )
	    lhsBVec = lkh->_lhLkh->_baseVec + site._lhs * nGCat * nCodes;

	const FLOAT* rhsTMat  = lkh->_rhTMatrix->_matrix;
	const FLOAT* rhsBVec;

	if ( RINNER && !RCONST )
	    rhsBVec = lkh->_rhLkh->_baseVec + site._rhs * nGCat * nCodes;

	for ( unsigned c = 0; c < nGCat; c++ ) {

	    const FLOAT* lm;
	    if ( LINNER )
		lm = lhsTMat;
	    else
		lm = lhsTMat + site._lhs * nCodes;

	    const FLOAT* rm;
	    if ( RINNER )
		rm = rhsTMat;
	    else
		rm = rhsTMat + site._rhs * nCodes;

	    for ( unsigned i = 0; i < nCodes; i++) {

		FLOAT lhs;

		if ( !LINNER )
		    lhs = *lm++;
		else if ( LCONST )
		    lhs = *lhsCVec++;
		else {
		    lhs = 0.0;
		    const FLOAT * bvwork = lhsBVec;
		    for ( unsigned j = 0; j < nCodes; j++ )
			lhs += (*bvwork++) * (*lm++);
		    *lhsCVec++ = lhs;
		}

		FLOAT rhs;

		if ( !RINNER )
		    rhs = *rm++;
		else if ( RCONST )
		    rhs = *rhsCVec++;
		else {
		    rhs = 0.0;
		    const FLOAT * bvwork = rhsBVec;
		    for ( unsigned j = 0; j < nCodes; j++ )
			rhs += (*bvwork++) * (*rm++);
		    *rhsCVec++ = rhs;
		}

		*bv++ = lhs * rhs;

	    }

	    if ( LINNER && !LCONST )
		lhsBVec += bvSize;

	    lhsTMat += tmSize;

	    if ( RINNER && !RCONST )
		rhsBVec += bvSize;

	    rhsTMat += tmSize;

	}
    }
}

// *****************************************************************************
/// Key to the base vector computation function lookup map

struct BvKey {
    const bool _leftIsInner;                      ///< Is the left child an inner node
    const bool _rightIsInner;                     ///< Is the right child an inner node
    const bool _nIs4;                             ///< Is this DNA codes?
    const bool _gamma;                            ///< Is this using the discrete gamma model
    const bool _nGCatIs4;                         ///< Is the number of discrete categories 4?

    BvKey( const bool leftIsInner,
           const bool rightIsInner,
           const bool nIs4,
           const bool gamma,
           const bool nGCatIs4 )
        : _leftIsInner   (leftIsInner),
          _rightIsInner  (rightIsInner),
          _nIs4          (nIs4),
          _gamma         (gamma),
          _nGCatIs4      (nGCatIs4)
        {}

    bool operator<(const BvKey & rhs) const
        {
            return std::tie (_leftIsInner, _rightIsInner, _nIs4, _gamma, _nGCatIs4) <
                   std::tie (rhs._leftIsInner, rhs._rightIsInner, rhs._nIs4, rhs._gamma, rhs._nGCatIs4);
        }

};

/// Entry in the base vector computation lookup map

struct BvEntry {

    CpuLocusNode::ComputeNodeVec _fullFn;         ///< Function to compute the full node base vec
    CpuLocusNode::ComputeNodeVec _leftPartialFn;  ///< Function to compute assuming the right child is unchanged
    CpuLocusNode::ComputeNodeVec _rightPartialFn; ///< Function to compute assuming the left child is unchanged

    BvEntry(CpuLocusNode::ComputeNodeVec fullFn,
            CpuLocusNode::ComputeNodeVec leftPartialFn,
            CpuLocusNode::ComputeNodeVec rightPartialFn)
        : _fullFn(fullFn),
          _leftPartialFn(leftPartialFn),
          _rightPartialFn(rightPartialFn)
        {}

};

/// Helper to generate map entries

#define MAPENTRY(li, ri, n4, g, g4) { {li, ri, n4, g, g4},                            \
                                      { ComputeNodeVec<li, ri, n4, g, g4>,            \
                                        ComputeNodeVec<li, ri, n4, g, g4, li, false>, \
                                        ComputeNodeVec<li, ri, n4, g, g4, false, ri> } }

/// Initialization of the function lookup map

static const std::map<const BvKey, const BvEntry> bvMap
{
    //        left   right  n=4    gamma  gcat=4

    // Leaf leaf models
    MAPENTRY( false, false, false, false, false),
    MAPENTRY( false, false, false, true,  false),
    MAPENTRY( false, false, false, true,  true ),
    MAPENTRY( false, false, true,  false, false),
    MAPENTRY( false, false, true,  true,  false),
    MAPENTRY( false, false, true,  true,  true ),

    // Leaf inner models
    MAPENTRY( false, true,  false, false, false),
    MAPENTRY( false, true,  false, true,  false),
    MAPENTRY( false, true,  false, true,  true ),
    MAPENTRY( false, true,  true,  false, false),
    MAPENTRY( false, true,  true,  true,  false),
    MAPENTRY( false, true,  true,  true,  true ),

    // Inner leaf models
    MAPENTRY( true,  false, false, false, false),
    MAPENTRY( true,  false, false, true,  false),
    MAPENTRY( true,  false, false, true,  true ),
    MAPENTRY( true,  false, true,  false, false),
    MAPENTRY( true,  false, true,  true,  false),
    MAPENTRY( true,  false, true,  true,  true ),

    // Inner inner models
    MAPENTRY( true,  true , false, false, false),
    MAPENTRY( true,  true , false, true,  false),
    MAPENTRY( true,  true , false, true,  true ),
    MAPENTRY( true,  true , true,  false, false),
    MAPENTRY( true,  true , true,  true,  false),
    MAPENTRY( true,  true , true,  true,  true )

};

// *****************************************************************************
/// Template to generate the various log likelihood functions at the nodes.
/// This depends on the optimizer to generate clean code for the various cases.
/// For example, "if (0) whatever;" should be optimized out.
/// @tparam N4 Set to true if this for the 4 nucleotide DNA case.
/// @tparam GAMMA Set to true if this will handle discrete gamma rate classes.
/// @tparam NGCAT4 Set to true the number of discrete gamma rate classes is 4 (the default).
/// @param lkh Likelihood instance for the current node.
/// @param charFreq Vector of character frequencies to factor in.
/// @return Log likelihood at the node.

template< bool N4,
	  bool GAMMA,
	  bool NGCAT4 >
FLOAT
ComputeLogLikelihood( const CpuLocusNode * lkh,
		      const FLOATVEC &     charFreq )
{
    FLOAT *        bv     = lkh->_baseVec;

    const unsigned nCodes = N4 ? 4 : lkh->_n;
    const unsigned nGCat  = GAMMA ? (NGCAT4 ? 4 : lkh->_nGCat) : 1;

    FLOAT value = 0.0;

    for ( auto & site : *lkh->_mySiteVec ) {

	FLOAT baseSum  = 0.0;
	auto *catMeans = lkh->_eModel._rateVec.data();

	for ( unsigned c = 0; c < nGCat; c++ ) {

	    FLOAT catSum = 0.0;

	    const FLOAT * bp = charFreq.data();

	    for ( unsigned i = 0; i < nCodes; i++ )
		catSum += (*bv++) * (*bp++);

	    if (GAMMA)
		baseSum += catSum * (*catMeans++);
	    else
		baseSum += catSum;

	}

	value += FLOAT(site._count) * log(baseSum);

    }

    return value;

}

// *****************************************************************************
/// Key to the log likelihood computation function lookup map

struct LlKey {
    const bool _nIs4;                             ///< Is this DNA codes?
    const bool _gamma;                            ///< Is this using the discrete gamma model
    const bool _nGCatIs4;                         ///< Is the number of discrete categories 4?

    LlKey( const bool nIs4,
           const bool gamma,
           const bool nGCatIs4 )
        : _nIs4          (nIs4),
          _gamma         (gamma),
          _nGCatIs4      (nGCatIs4)
        {}

    bool operator<(const LlKey & rhs) const
        {
            return std::tie (_nIs4, _gamma, _nGCatIs4) <
                   std::tie (rhs._nIs4, rhs._gamma, rhs._nGCatIs4);
        }

};

/// Helper to generate map entries

#define LLENTRY(n4, g, g4) { {n4, g, g4},  ComputeLogLikelihood<n4, g, g4> }

/// Initialization of the function lookup map

static const std::map<const LlKey, CpuLocusRoot::ComputeLogLikelihood> llMap
{
    //        n=4    gamma  gcat=4
    LLENTRY( false, false, false),
    LLENTRY( false, true,  false),
    LLENTRY( false, true,  true ),
    LLENTRY( true,  false, false),
    LLENTRY( true,  true,  false),
    LLENTRY( true,  true,  true )
};

// *****************************************************************************

inline
void
SwapVec( FLOAT * & a,
	 FLOAT * & b )
{
    FLOAT * t;
    t = a;
    a = b;
    b = t;
}

// *****************************************************************************

inline
void
UpdateChildTMatrixes ( Tree::LocusNode & lNode )
{

    for ( auto lChild : lNode._children )
	lChild->UpdateTMatrix();

}

// *****************************************************************************

inline
CpuLocusRoot *
LocusRootLkh(const Tree::LocusRoot & lRoot)
{
    return static_cast<CpuLocusRoot *>(lRoot._lkh);
}

// *****************************************************************************

inline
CpuLocusNode *
LocusNodeLkh(const Tree::LocusRoot & lRoot)
{

    return static_cast<CpuLocusNode *>(static_cast<const Tree::LocusNode &>(lRoot)._lkh);
}

// *****************************************************************************

inline
CpuLocusNode *
LocusNodeLkh(const Tree::LocusNode & lNode)
{
    return static_cast<CpuLocusNode *>(lNode._lkh);
}

// *****************************************************************************

inline
CpuLocusRoot *
LocusRootLkh(const Tree::LocusNode & lNode)
{
    return LocusRootLkh(lNode._lRoot);
}

// *****************************************************************************

Likelihood *
LikelihoodCpu::Factory ( Replicate &  repl,
			 Tree::Root & root )
{
    return new CpuRoot (repl, root);
}

// *****************************************************************************

Likelihood *
LikelihoodCpu::Factory ( Replicate &       repl,
			 Tree::LocusRoot & lRoot )
{
    return new CpuLocusRoot (repl, lRoot);
}

// *****************************************************************************
/// Updates value at gene and species tree roots

Likelihood *
LikelihoodCpu::Factory ( Replicate &          repl,
			 const Tree::Position tPos )
{
    return new CpuTreeNode (repl, tPos);
}

// *****************************************************************************

Likelihood *
LikelihoodCpu::Factory ( Replicate &       repl,
			 Tree::LocusNode & lNode )
{
    return new CpuLocusNode (repl, lNode);
}

// *****************************************************************************
/// Create and setup a locus node instance.

CpuLocusNode::CpuLocusNode(Replicate &       repl,
			   Tree::LocusNode & lNode )
    : Likelihood(repl),
      _lNode(lNode),
      _lRoot(lNode._lRoot),
      _eModel(*_lRoot._eModel),
      _n(_eModel._parent._n),
      _nGCat(_eModel._parent._nGCat),
      _mySiteVec(lNode._siteVec),
      _lkhLRoot(LocusRootLkh(_lRoot))
{
    if ( lNode.IsLeaf() ) {
	_lhTMatrix        = nullptr;
	_rhTMatrix        = nullptr;
	_lhLkh            = nullptr;
	_rhLkh            = nullptr;
	_compBaseVec      = nullptr;
	_compBaseVecLeft  = nullptr;
	_compBaseVecRight = nullptr;
	_baseVec          = nullptr;
	_oldBaseVec       = nullptr;
	_lhsVec           = nullptr;
	_rhsVec           = nullptr;
	_oldLhsVec        = nullptr;
	_oldRhsVec        = nullptr;
    }
    else {
	_lhTMatrix = static_cast<TransitionMatrixCpu*>(lNode._children[0]->_tMatrix);
	_rhTMatrix = static_cast<TransitionMatrixCpu*>(lNode._children[1]->_tMatrix);
	_lhLkh     = LocusNodeLkh(*lNode._children[0]);
	_rhLkh     = LocusNodeLkh(*lNode._children[1]);

	auto & bve = bvMap.at( { lNode._children[0]->IsInner(),
		    lNode._children[1]-> IsInner(),
		    _n == 4,
		    _eModel.GammaRates(),
		    _nGCat == 4 } );

	_compBaseVec      = bve._fullFn;
	_compBaseVecLeft  = bve._leftPartialFn;
	_compBaseVecRight = bve._rightPartialFn;

	const unsigned vlen = _mySiteVec->size() * _n * _nGCat;

	_baseVec    = new FLOAT[vlen];
	_oldBaseVec = new FLOAT[vlen];
	_lhsVec     = new FLOAT[vlen];
	_rhsVec     = new FLOAT[vlen];
	_oldLhsVec  = new FLOAT[vlen];
	_oldRhsVec  = new FLOAT[vlen];

	for ( unsigned i = 0; i < vlen; i++ ) {
	    _baseVec[i] = 0.0;
	    _oldBaseVec[i] = 0.0;
	}

    }

}

// *****************************************************************************
/// Delete the working vectors

CpuLocusNode::~CpuLocusNode()
{
    delete[] _baseVec;
    delete[] _oldBaseVec;
    delete[] _lhsVec;
    delete[] _rhsVec;
    delete[] _oldLhsVec;
    delete[] _oldRhsVec;
}

// *****************************************************************************
/// Compute the likelihood for a changed locus node.
/// Used for rate proposals.

FLOAT
CpuLocusNode::Compute()
{
    REPRENTER( Dump::ptr(this) );

    /// - Update the current transition matrix.

    _lNode.UpdateTMatrix();

    /// - Update base vectors to the root

    bool isLeftChild = _lNode._isLeftChild;
    for ( auto lp = _lNode._parent; lp; lp = lp->_parent ) {
	auto lkhLp = LocusNodeLkh(*lp);
	if ( isLeftChild )
	    lkhLp->UpdateBaseVecLeft();
	else
	    lkhLp->UpdateBaseVecRight();
	isLeftChild = lp->_isLeftChild;
    }

    /// - Compute the overall log likelihood for the gene tree

    _lkhLRoot->UpdateValue();

    auto ratio = _lkhLRoot->_value - _lkhLRoot->_oldValue;
    REPREXIT ( Dump::ptr(this),
	       Dump::str(_lkhLRoot->_value, "lRootLnL"),
	       Dump::str(_lkhLRoot->_oldValue, "oldLRootLnL"),
	       Dump::str(ratio, "ratio") );
    return ratio;
}

// *****************************************************************************

std::string
CpuLocusNode::str( const std::string hdg ) const
{
    std::stringstream ss;
    if ( hdg.size() ) ss << hdg << "<";

    ss << Dump::ptr(this) << ' '
       << Dump::str(std::string(typeid(*this).name())) << ' '
       << Dump::str(_n, "n") << ' '
       << Dump::str(_nGCat, "nGCat") << ' '
       << Dump::ptr(&_mySiteVec, "mySiteVec") << ' '
       << Dump::ptr(&_lhTMatrix, "lhTMatrix") << ' '
       << Dump::ptr(_lhLkh, "lhLkhFn") << ' '
       << Dump::ptr(&_rhTMatrix, "rhTMatrix") << ' '
       << Dump::ptr(_rhLkh, "rhLkhFn");

    std::stringstream bvss;

    if ( _mySiteVec ) {

	if ( _mySiteVec->size() )
	    ss << '\n';

	auto copy1 = _baseVec;
	auto copy2 = _oldBaseVec;

	for ( unsigned site = 0; site < _mySiteVec->size(); site++ ) {

	    std::string sstr;

	    for ( unsigned gcat = 0; gcat < _nGCat; gcat++ )
		sstr += Dump::indent_heading ( Dump::str(copy1, copy2, _n) + '\n',
					       Dump::vector_heading(gcat, "gCat") ) + '\n';

	    bvss << Dump::indent_heading ( sstr, Dump::vector_heading(site, "site", 3) ) + '\n';

	}


    } else
	ss << '\n';

    if ( hdg.size() ) bvss << '>';
    return ss.str() + Dump::indent(bvss.str());
}

// *****************************************************************************
/// Update base vectors at the node logging the operation
/// The nodes base vector as well as the left and right child intermediate vectors
/// are logged.

void
CpuLocusNode::UpdateBaseVecs()
{
    REPRENTER( Dump::ptr(this) );
    _repl.LogRollback(this);
    SwapVec( _baseVec, _oldBaseVec );
    SwapVec( _lhsVec, _oldLhsVec );
    SwapVec( _rhsVec, _oldRhsVec );
    _swappedRight = true;
    _swappedLeft = true;

    _compBaseVec(this);

    REPREXIT( Dump::ptr(this) );
}

// *****************************************************************************
/// Update the base vec and the left intermediate vec

void
CpuLocusNode::UpdateBaseVecLeft()
{
    REPRENTER( Dump::ptr(this) );
    _repl.LogRollback(this);
    SwapVec( _baseVec, _oldBaseVec );
    SwapVec( _lhsVec, _oldLhsVec );
    _swappedRight = false;
    _swappedLeft = true;

    _compBaseVecLeft(this);

    REPREXIT( Dump::ptr(this) );
}

// *****************************************************************************
/// Update the base vec and the right intermediate vec

void
CpuLocusNode::UpdateBaseVecRight()
{
    REPRENTER( Dump::ptr(this) );
    _repl.LogRollback(this);
    SwapVec( _baseVec, _oldBaseVec );
    SwapVec( _rhsVec, _oldRhsVec );
    _swappedRight = true;
    _swappedLeft = false;

    _compBaseVecRight(this);

    REPREXIT( Dump::ptr(this) );
}

// *****************************************************************************

CpuLocusRoot::CpuLocusRoot(Replicate &       repl,
			   Tree::LocusRoot & lRoot )
    : Likelihood(repl),
      _lRoot(lRoot),
      _eModel(*_lRoot._eModel)
{
    _compLogLkh = llMap.at ( { _eModel._parent._n == 4,
		               _eModel.GammaRates(),
		               _eModel._parent._nGCat == 4 } );
}

// *****************************************************************************
/// Compute the likelihood value for the gene tree.
/// Used with nuisance parameter proposals.
/// Depends on UpdateValue to log the operation.

FLOAT
CpuLocusRoot::Compute()
{
    REPRENTER( Dump::ptr(this) );

    /// - Update the transition matrixes assuming a parameter change.

    _lRoot._eModel->UpdateAllTMatrixes();

    /// - Traverse the gene tree computing the likelihood vectors

    struct LocusDfs : Tree::LocusDfs {

        RC InnerEnd ( Tree::LocusNode & lNode )
            {
                LocusNodeLkh(lNode)->UpdateBaseVecs();
                return CONTINUE;
            }

        RC RootEnd  ( Tree::LocusNode & lNode )
            {

		return lNode._missing ? CONTINUE : InnerEnd(lNode);
            }

    } dfs;
    dfs(_lRoot);

    UpdateValue();

    REPREXIT( Dump::ptr(this),
	      Dump::str(_value, "value"),
	      Dump::str(_oldValue, "oldValue") );
    return _value - _oldValue;
}

// *****************************************************************************
/// Update the likelihood value at the root logging the operation.
/// @return New value for the gene tree likelihood.

FLOAT
CpuLocusRoot::UpdateValue()
{
    _repl.LogRollback(this);
    Save();

    _value = _compLogLkh(LocusNodeLkh(*_lRoot._trueRoot), _eModel.CharFreq());

    return _value;
}

// *****************************************************************************
/// Compute the value for all the gene trees.
/// Used during initial value computations. Distances have been set in advance.
/// Logging not important.

FLOAT
CpuRoot::Compute()
{
    REPRENTER(Dump::ptr(this));

    _value = 0.0;

    for ( auto & lRoot : _root._locusVec ) {

	/// - Update the transition matricies for the gene tree.

	lRoot._eModel->UpdateAllTMatrixes();

	/// - Traverse the gene tree computing the likelihood vectors

	struct LocusDfs : Tree::LocusDfs {

	    RC InnerEnd ( Tree::LocusNode & lNode )
		{
		    LocusNodeLkh(lNode)->_compBaseVec(LocusNodeLkh(lNode));
		    return CONTINUE;
		}

	    RC RootEnd  ( Tree::LocusNode & lNode )
		{
		    return InnerEnd(lNode);
		}

	} dfs;
	dfs(lRoot);

	auto lkhLRoot = LocusRootLkh(lRoot);
	auto lkhLNode = LocusNodeLkh(*lRoot._trueRoot);

	lkhLRoot->_value  = lkhLRoot->_compLogLkh(lkhLNode, lRoot._eModel->CharFreq());
	_value += lkhLRoot->_value;
	REPRDEBUG(Dump::str(lRoot._locus._id,"locus._id"),
		  Dump::str(lkhLRoot->_value,"lkhLRoot._value"));

    }

    REPREXIT(Dump::ptr(this),
	     Dump::str(_value, "value"));
    return _value;
}

// *****************************************************************************
/// Compute and return the value of the likelihood for the species tree.
/// Sums across all the gene trees.
/// Not logged.

FLOAT
CpuRoot::operator()()
{
    REPRENTER(Dump::ptr(this));

    _value = 0.0;
    for ( auto & lRoot : _root._locusVec )
	_value += (*lRoot._lkh)();

    REPREXIT(Dump::ptr(this),
	     Dump::str(_value, "value"));
    return _value;
}

// *****************************************************************************
/// Compute the likelihood across all gene trees at a particular species tree node.
/// Used with age parameter proposals.
/// @return Prior ratio summed over all gene trees.

FLOAT
CpuTreeNode::Compute()
{
    REPRENTER(Dump::ptr(this));

    FLOAT priorRatio = 0.0;

    if ( _tPos.IsRoot() ) {

	/// - If a root node, process the list of non-missing locus roots.

	auto & lVec = _tPos.AsRoot()._locusVec;

	for ( auto & lRoot : lVec )

	    if ( !lRoot._missing ) {

		auto lkhLRoot = LocusRootLkh(lRoot);
		auto lkhLNode = LocusNodeLkh(lRoot);

		/// - Update the children's transition matrixies.

		UpdateChildTMatrixes(lRoot);

		/// - Update this node's base vector

		lkhLNode->UpdateBaseVecs();

		/// - Compute the overall log likelihood for the gene tree

		lkhLRoot->UpdateValue();
		priorRatio += lkhLRoot->_value - lkhLRoot->_oldValue;

		REPRDEBUG("Root Likelihood",
			  Dump::str(lkhLRoot->_value, "value"),
			  Dump::str(lkhLRoot->_oldValue, "oldValue") );

	    }

    }
    else {

	/// - If an inner node, process the list of non-missing locus nodes.

	auto & lVec = _tPos.AsTNode()._locusVec;

	for ( auto & lNode : lVec )

	    if ( !lNode._missing ) {

		auto lkhLRoot = LocusRootLkh(lNode._lRoot);
		auto lkhLNode = LocusNodeLkh(lNode);

		/// - Update this node's as well as it's children's transition matrixies.

		lNode.UpdateTMatrix();
		UpdateChildTMatrixes(lNode);

		/// - Update this node's base vector

		lkhLNode->UpdateBaseVecs();

		/// - Update base vectors to the root

		bool isLeftChild = lNode._isLeftChild;
		for ( auto lp = lNode._parent; lp; lp = lp->_parent ) {
		    auto lkhLp = static_cast<CpuLocusNode*>(lp->_lkh);
		    if ( isLeftChild )
			lkhLp->UpdateBaseVecLeft();
		    else
			lkhLp->UpdateBaseVecRight();
		    isLeftChild = lp->_isLeftChild;
		}

		/// - Compute the overall log likelihood for the gene tree

		lkhLRoot->UpdateValue();
		priorRatio += lkhLRoot->_value - lkhLRoot->_oldValue;

	    }

    }

    REPREXIT( Dump::ptr(this),
	      Dump::str(priorRatio, "priorRatio") );
    return priorRatio;

}
