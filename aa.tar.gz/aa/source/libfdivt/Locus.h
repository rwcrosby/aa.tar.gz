/// @file Locus.h
/// Declaration of the locus object

// *************************************************************************
// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _LOCUS_H_
#define _LOCUS_H_

#include "Config.h"

class  Logger;
struct Sequence;
struct SequenceFactory;

// *****************************************************************************
/// Declaration of the class for a locus.
/// An instance of this object is created for each locus loaded.

struct Locus {

    Locus(const std::string       label,
	  const unsigned          id,
          const SequenceFactory & seqFac)
	: _label(label),
	  _id(id),
          _seqFac(seqFac),
	  _seqLen(0),
          _uniquePatterns(0),
          _invariantCols(0),
          _missingDataCols(0),
          _allMissingCols(0),
          _totalChars(0),
          _totalAllChars(0)
	{};

    /// Add the sequence to the list for this locus
    void                    AddSequence ( Sequence * seq ); ///< Pointer to the sequence object

    /// Dump info for the locus to the logger.
    void                    Log( Logger & logger ) const;

    /// Compute the various metrics for the locus
    void                    ComputeStatistics();

    const std::string       _label;               ///< Name to associate with the locus
    const unsigned          _id;                  ///< Ordinal index for this locus
    const SequenceFactory & _seqFac;              ///< To get alphabet and such

    unsigned                _seqLen;		  ///< Length of the sequence for this locus
    std::vector<Sequence *> _seqVec;		  ///< Set of sequences for the locus, indexed by taxa id

    unsigned                _uniquePatterns;      ///< Number of unique (not missing) column patters
    unsigned                _invariantCols;       ///< Columns with invariant patterns (not missing)
    unsigned                _missingDataCols;     ///< Columns with missing data
    unsigned                _allMissingCols;      ///< Columns with only missing data
    unsigned                _totalChars;          ///< Total valid characters
    unsigned                _totalAllChars;       ///< Total chars (incl missing/gap)

    UINTVEC                 _charCnts;		  ///< Count of occurances of each char in alphabet
    FLOATVEC                _charPct;		  ///< Percentages of occurance for each char

};

#endif // _LOCUS_H_
