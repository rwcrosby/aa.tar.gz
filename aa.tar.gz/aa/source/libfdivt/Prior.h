/// @file Prior.h
/// Definition of the base class for the rate and age priors.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _PRIOR_H_
#define _PRIOR_H_

#include "Config.h"
#include "ITransaction.h"

struct Replicate;

// *****************************************************************************
/// Pure virtual base class for the rates priors.

struct Prior : ITransaction {

    Prior( Replicate & repl )
	: _value(0.0),
	  _oldValue(0.0),
	  _repl(repl)
	{}

    /// Return the value of the prior for this gene tree.
    /// All values are the logs of the actual prior values.
    virtual
    FLOAT
    operator() ()
	const
	{
	    return _value;
	}

    /// Empty commit, only overridden if needed
    virtual
    void
    Commit()
	{}

    /// Return the prior ratio for a inflight proposal
    virtual
    FLOAT
    PriorRatio ()
	const
	{
	    return _value - _oldValue;
	}

    /// Restore old value of the parameter.
    virtual
    void
    Rollback ()
	{
	    _value = _oldValue;
	}

    /// Save the value of the prior in case of rollback
    virtual
    void
    Save ()
	{
	    _oldValue = _value;
	}

    virtual
    std::string
    str()
	const;

    FLOAT             _value;			  ///< Value of the prior
    FLOAT             _oldValue;		  ///< Saved for rollback

protected:

    Replicate &       _repl;			  ///< Owning replicate

};


#endif // _PRIOR_H_
