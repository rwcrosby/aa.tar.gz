/// @file Likelihood.h
/// Base class for the likelihood computational algorithms

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _LIKELIHOOD_H_
#define _LIKELIHOOD_H_

#include <string>

#include "ITransaction.h"

class  Logger;
struct Replicate;

namespace Tree {
    struct LocusNode;
    struct LocusRoot;
    struct Position;
    struct Root;
}

// *****************************************************************************
/// Base class for the likelihood computational algorithms

struct Likelihood : ITransaction {

    /// Just setup the control fields.
    Likelihood( Replicate & repl );

    // Required for the virtual function machinery.
    virtual
    ~Likelihood()
	{};

    /// Return the likelihood value at the node.
    /// Only really defined for tree and locus roots, otherwise zero will be returned.
    virtual
    FLOAT
    operator()()
	{
	    return _value;
	}

    /// Empty commit method.
    /// Overridden in the gpu methods.
    virtual
    void
    Commit()
	{}

    /// Compute the likelihood updating the gene and species tree values.
    /// @return Tree likelihood for instance at the species tree root, likelihood ratio for all
    ///         other instance.
    virtual
    FLOAT
    Compute() = 0;

    /// Get rid of any data loaded prior to dumping.
    /// Used by the GPU routines to clear data pulled down from the gpu.
    virtual
    void
    DisposeData ()
	{};

    /// Create a likelihood object at a species tree root.
    /// Proxies to either the cpu or gpu versions.
    static
    Likelihood *
    Factory ( Replicate &  repl,
	      Tree::Root & root );

    /// Create a likelihood object at a gene tree root.
    /// Proxies to either the cpu or gpu versions.
    static
    Likelihood *
    Factory ( Replicate &       repl,
	      Tree::LocusRoot & lRoot );

    /// Create a likelihood object at a species tree node.
    /// Proxies to either the cpu or gpu versions.
    static
    Likelihood *
    Factory ( Replicate &          repl,
	      const Tree::Position tPos );

    /// Create a likelihood object at a gene tree node.
    /// Proxies to either the cpu or gpu versions.
    static
    Likelihood *
    Factory ( Replicate &       repl,
	      Tree::LocusNode & lNode );

    /// Load any data required prior to dumping objects.
    /// Used by the GPU routines to pull data down from the gpu.
    virtual
    void
    GetData ()
	{};

    /// Generate the dump string for the object.
    virtual
    std::string
    str ( const std::string hdg = "")
	const;

    /// Do anything require at the end of replication after all object have been constructed.
    /// Currently only used by the species tree root in GPU mode to allocate device memory.
    virtual
    void
    ReplRootEnd()
	{}

    /// Reset the likelihood at this node.
    virtual
    void
    Rollback()
	{
	    _value = _oldValue;
	}

    FLOAT       _value;				  ///< Log likelihood value
    FLOAT       _oldValue;                        ///< Saved likelihood value

    Replicate & _repl;                            ///< Parent replicate

protected:

    /// Setup for rollback.
    void
    Save()
	{
	    _oldValue = _value;
	}

    Logger &    _logger;                          ///< Logger to output to

};

#endif // _LIKELIHOOD_H_
