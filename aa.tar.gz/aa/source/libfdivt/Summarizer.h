/// @file Summarizer.h
/// Summarize trace file output and generate final trees and parameter summaries.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _SUMMARIZER_H_
#define _SUMMARIZER_H_

struct OutputManager;
struct ThreadSet;
struct ReplicateVec;

// *****************************************************************************
/// Do the summarization and output the ending files.
/// @param tSet Set of threads to use for generating summaries
/// @param replVec Replicate vector to process
/// @param oMgr Output manager to use for the otuput

void
Summarizer(ThreadSet &     tSet,
	   ReplicateVec &  replVec,
	   OutputManager & oMgr );

#endif // _SUMMARIZER_H_
