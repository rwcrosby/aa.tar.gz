/// @file EvoModelGpuImpl.h
/// Declarations of the gpu implemention of the evolutionary model.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _EVOMODELGPUIMPL_H_
#define _EVOMODELGPUIMPL_H_

#include <cassert>

#include "EvoModel.h"
#include "GpuInterfaceImpl.h"

struct EvoModelRoot;
struct Replicate;
struct TransitionMatrix;
struct TransitionMatrixGpu;

namespace Tree {
    struct Root;
    struct LocusRoot;
}

// *****************************************************************************
/// Subclass of the base evolutionary model for a gene tree.

struct EMGpuImpl : EvoModel {

    EMGpuImpl ( EvoModelRoot &   parent,
		Tree::LocusRoot& lRoot )
	: EvoModel( parent, lRoot),
	  _which(false),
	  _idx1(0),
	  _idx2(0)
	{}

    /// Return the index for the inactive locus block
    inline
    unsigned
    Index2Update()
	{
	    return _which ? _idx2 : _idx1;
	}

    /// Return the index for the active locus block to use for calculations
    inline
    unsigned
    Index2Use()
	{
	    return _which ? _idx1 : _idx2;
	}

    /// Factory to build a transition matrix based on an evolutionary model.
    /// Does not populate the matrix.
    virtual
    TransitionMatrix *
    MakeTransitionMatrix ();

    /// Return model specific dump information
    virtual
    std::string
    ModelStr()
	const = 0;

    /// Do model specific initializations of the locus block
    /// This piece does the common gamma rates blocks
    /// @param lBlk Pointer to the first slot for data
    /// @returns Updated slot pointer
    virtual
    cl_float *
    PopulateLocusBlock( cl_float * lBlk);

    /// Rollback the index
    virtual
    void
    Rollback()
	{
	    EvoModel::Rollback();
	    SwapCopy();
	}

    /// Output the dump string for the instance
    virtual
    std::string
    str ( const std::string hdg = "")
	const;

    /// Swap the copy in use
    inline
    void
    SwapCopy()
	{
	    _which = !_which;
	}

    /// Update all transition matrixes for the gene tree.
    /// Used for gene tree level changes like gamma categories
    void
    UpdateAllTMatrixes();

    /// Push the entry for this matrix onto the
    virtual
    void
    UpdateTMatrix ( TransitionMatrix * tMat,
		    const FLOAT        dist );

    /// Shouldn't use this one
    virtual
    void
    UpdateTMatrix ( TransitionMatrix * tMat )
    	{
	    assert(0 && "Attempting to call Gpu UpdateTMatrix");
	}

    bool     _which;				  ///< Which locus block is current?

    /// Since the locus blocks are a collection of floats, the indicies are
    /// to the appropriate float, not set of floats.

    unsigned _idx1;				  ///< Index to first block copy
    unsigned _idx2;				  ///< Index to second block copy

};

// *****************************************************************************
/// Root Object for the gpu implementation.
/// An instance exists at each species tree root.
/// Subclassed for the individual models.

struct EMRGpuImpl : EvoModelRoot {

    EMRGpuImpl ( Replicate &  repl,
		 Tree::Root & root,
		 const char * name );

    virtual
    ~EMRGpuImpl();

    /// Clear data pulled from the GPU.
    virtual
    void
    DisposeData ()
	{
	    delete _tmData;
	    _tmData = nullptr;
	}

    /// Do an updates queued in the pos vector
    cl_event
    DoUpdates();

    /// Pull the data from the GPU for dumping.
    virtual
    void
    GetData ();

    /// Setup to queue tm update requests to the pos vector
    void
    InitForUpdates()
	{
	    _posUpdList.clear();
	};

    /// Return the number of floats in a locus block
    virtual
    unsigned
    LocusBlockSize()
	const = 0;

    /// Return model specific dump information
    virtual
    std::string
    ModelStr()
	const = 0;

    /// Complete the initialization of the instance at the end of replication.
    virtual
    void
    ReplRootEnd();

    /// Output the dump string for the instance
    virtual
    std::string
    str ( const std::string hdg = "")
	const;

    /// Do an update of all the transition matrixes for this species tree
    virtual
    void
    UpdateAllTMatrixes ();

    GpuReplicateImpl &  _gpuRepl;		  ///< Replicates gpu interface
    GpuInterfaceImpl &  _gpuIntf;		  ///< GLobal gpu interface

    cl_kernel           _kernel; 		  ///< OpenCL kernel to update TM's
    cl_event            _event;			  ///< Event to wait for tm update completion

    /// Entries in the transition matrix and position vectors.
    /// The value reflects the number of transition matrixes created,
    /// the opencl allocation is double this for the two copies of each matrix.
    unsigned            _vecSize;

    const unsigned      _tmAlloc;		  ///< Size in bytes of a transition matrix
    unsigned            _tmVecAlloc;		  ///< Byte size of TM vector
    cl_mem              _tmVecBuf;		  ///< OpenCL object for TM vector

    unsigned            _posVecAlloc;		  ///< Byte size of position vector
    cl_mem              _posVecBuf;		  ///< OpenCL object for position vector

    std::list<TransitionMatrixGpu*> _posUpdList;  ///< List of matrixes to update this time.

    unsigned            _locusVecAlloc; 	  ///< Byte size of the gamma rates vector
    cl_mem              _locusVecBuf;		  ///< OpenCL object for gamma rates vector

    cl_float *          _tmData;		  ///< Transition matrix data from the gpu.

};

// *****************************************************************************

inline
EMGpuImpl *
GpuImpl (EvoModel * em)
{
    return static_cast<EMGpuImpl *>(em);
}

inline
EMGpuImpl &
GpuImpl (EvoModel & em)
{
    return static_cast<EMGpuImpl &>(em);
}

inline
EMRGpuImpl *
GpuImpl (EvoModelRoot * em)
{
    return static_cast<EMRGpuImpl *>(em);
}

inline
EMRGpuImpl &
GpuImpl (EvoModelRoot & em)
{
    return static_cast<EMRGpuImpl &>(em);
}

#endif // _EVOMODELGPUIMPL_H_
