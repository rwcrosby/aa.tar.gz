/// @file GpuInterfaceImpl.h
/// Definition of the GPU implementation

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _GPUINTERFACEIMPL_H_
#define _GPUINTERFACEIMPL_H_

#include <iostream>

#ifdef __APPLE__
#include <OpenCL/cl.h>
#else
#include <CL/cl.h>
#endif

#include "Except.h"
#include "GpuInterface.h"

// *****************************************************************************
/// A list of events...

typedef std::vector<cl_event> EVENTLIST;

// *****************************************************************************
/// Dump specializations for opencl objects.

namespace Dump {

    std::string
    str( cl_command_queue q,
	 std::string      hdg = "" );

    std::string
    str( cl_kernel   k,
	 std::string hdg = "" );

    std::string
    str( cl_event    e,
	 std::string hdg = "" );

    std::string
    str( cl_mem      m,
	 std::string hdg = "" );

}

// *****************************************************************************
/// Implementation of the GPU interface

struct GpuInterfaceImpl : GpuInterface {

    GpuInterfaceImpl( Logger & logger );

    virtual
    ~GpuInterfaceImpl();

    /// Build a single program
    cl_program
    BuildProgram ( const std::string & pgm,
		   const DefineList    defs );

    /// Build the GPU programs for the evolutionary models and likelihood
    /// @param log Logger instance to output to.
    /// @param defs List of key/values pairs to define to the build
    virtual
    void
    BuildPrograms ( Logger &         log,
		    const DefineList defs );

    /// Return a textual string for an opencl return code.
    static
    const char *
    CLErrString(cl_int err);

    /// Create a buffer object of the requested size
    /// @param flags Flags to pass to clCreateBuffer
    /// @param alloc Allocation in bytes
    /// @return OpenCL memory object handle
    cl_mem
    CreateBuffer ( cl_mem_flags flags,
		   size_t       alloc );

    /// Carve out a subbuffer from a larger buffer.
    /// @param buf Buffer to allocate from
    /// @param offset Offset within the buffer
    /// @param alloc Byte size to allocate
    /// @param flags Allocation flags
    /// @return Memory object for the sub allocation
    static
    cl_mem
    CreateSubBuffer ( cl_mem       buf,
		      unsigned     offset,
		      size_t       alloc,
		      cl_mem_flags flags = CL_MEM_READ_WRITE );

    /// Check error codes and throw an error
    static
    inline
    void
    ErrorChk( cl_int status,
	      std::string e )
	{
	    if ( status != CL_SUCCESS )
		throw Except::GpuError( e, CLErrString(status) );
	}

    /// Get the next device in order.
    /// Provides a round-robin allocation of the devices.
    cl_device_id
    GetNextDevice()
	{
	    auto dev = _devices[_nextDevice++];
	    if ( _nextDevice >= _nDevices )
		_nextDevice = 0;
	    return dev;
	}

    /// Create a kernel
    static
    cl_kernel
    GetKernel ( cl_program   pgm,
		const char * name );

    /// Output information about the interface
    virtual
    void
    Log()
	const;

    /// Return the number of work groups required (assuming a work group size
    /// equal to the maximum) for the number of work items specified.
    inline
    unsigned
    NumWorkGroups ( const unsigned nWorkItems )
	{
	    return (nWorkItems - 1) / _maxWorkGroupSize + 1;
	}

    /// Set a memory object as a kernel argument.
    static
    inline
    void
    SetKernelArg ( cl_kernel    kernel,
		   unsigned     argNo,
		   const cl_mem arg )
	{
	    cl_int status = clSetKernelArg ( kernel,
					     argNo,
					     sizeof(cl_mem),
					     &arg );
	    GpuInterfaceImpl::ErrorChk(status,  "Failure to set memory object kernel argument");
	}

    /// Set a integer as a kernel argument.
    static
    inline
    void
    SetKernelArg ( cl_kernel    kernel,
		   unsigned     argNo,
		   const cl_int arg )
	{
	    cl_int status = clSetKernelArg ( kernel,
					     argNo,
					     sizeof(cl_int),
					     &arg );
	    GpuInterfaceImpl::ErrorChk(status,  "Failure to set integer kernel argument");
	}

    /// Create a local buffer of specified size
    static
    inline
    void
    SetKernelArgLocal ( cl_kernel    kernel,
			unsigned     argNo,
			const size_t size )
	{
	    cl_int status = clSetKernelArg ( kernel,
					     argNo,
					     size,
					     0 );
	    GpuInterfaceImpl::ErrorChk(status,  "Failure to set local buffer kernel argument");
	}

    /// Wait for a vector of events to complete
    static
    inline
    void
    WaitForEvents ( std::vector<cl_event> e)
	{
	    WaitForEvents(e.size(), e.data());
	}

    /// Wait for an array of events to complete
    static
    inline
    void
    WaitForEvents ( const unsigned count,
		    cl_event *     events )
	{
	    cl_int status = clWaitForEvents( count, events );
	    GpuInterfaceImpl::ErrorChk(status,  "Wait for events failed" );
	}

    cl_uint          _nPlatforms;		  ///< Number of platforms found
    cl_platform_id * _platforms;		  ///< List of platform id's
    unsigned         _platform2Use;		  ///< Index of the platform selected for use.

    cl_uint          _nDevices;			  ///< Number of devices found
    cl_device_id *   _devices;			  ///< List of devices found
    unsigned         _nextDevice;		  ///< Round robin allocator for command queues

    size_t           _maxWorkGroupSize;		  ///< Maximun work group size allowed

    cl_context       _context;			  ///< OpenCL context

    cl_program       _emProgram;		  ///< GPU program for evolutionary models
    cl_program       _lkhProgram;		  ///< GPU program for likelihood

};

// *****************************************************************************
/// Implementation of the per-replicate gpu interface

struct GpuReplicateImpl : GpuReplicate {

    GpuReplicateImpl( Replicate &        repl,
		      GpuInterfaceImpl & gpuIntf );

    virtual ~GpuReplicateImpl()
	{
	    if ( _cQueue )        clReleaseCommandQueue ( _cQueue );
	    if ( _lkhLeafLeaf )   clReleaseKernel ( _lkhLeafLeaf );
	    if ( _lkhLeafInner )  clReleaseKernel ( _lkhLeafInner );
	    if ( _lkhInnerLeaf )  clReleaseKernel ( _lkhInnerLeaf );
	    if ( _lkhInnerInner ) clReleaseKernel ( _lkhInnerInner );
	    if ( _lnLKernel )     clReleaseKernel ( _lnLKernel );
	    if ( _reduceKernel )  clReleaseKernel ( _reduceKernel );
	}

    /// Wait for queue to empty
    void
    Finish()
	{
	    cl_int status = clFinish ( _cQueue );
	    GpuInterfaceImpl::ErrorChk(status,  "Failure finishing commands");
	}

    /// Map a buffer into host memory waiting for completion
    /// @param buf OpenCL memory object
    /// @param alloc Size in bytes of area to map
    /// @param offset Offset from start of memory object to map
    /// @return Pointer to mapped memory
    void *
    MapBuffer ( cl_mem buf,
		size_t alloc,
		size_t offset = 0);

    /// Queue a kernel for execution with specified work group size.
    inline
    cl_event
    QueueKernel ( cl_kernel         kernel,
		  size_t            width,
		  size_t            workGroupSize,
		  size_t            offset,
		  const EVENTLIST & events )
	{
	    cl_event event;
	    cl_int status = clEnqueueNDRangeKernel ( _cQueue,
						     kernel,
						     1,
						     offset ? &offset : nullptr,
						     &width,
						     workGroupSize ? &workGroupSize : nullptr,
						     events.size(),
						     events.size() ? events.data() : nullptr,
						     &event );
	    GpuInterfaceImpl::ErrorChk(status,  "Failure queueing OpenCl kernel");
	    return event;
	}

    /// Queue a kernel for execution.
    inline
    cl_event
    QueueKernel ( cl_kernel         kernel,
		  size_t            width,
		  const EVENTLIST & events)
	{
	    return QueueKernel(kernel, width, 0, 0, events );
	}

    /// Queue a buffer read
    inline
    cl_event
    QueueRead ( cl_mem           buf,		  ///< OpenCL Memory object to read
		size_t           offset,	  ///< Offset with block to start read
		size_t           len,		  ///< Length to read
		void *            mem,		  ///< Where to put data
		const EVENTLIST & events)	  ///< Vector of events to wait on
	{
	    cl_event event;
	    cl_int status = clEnqueueReadBuffer ( _cQueue,
						  buf,
						  CL_FALSE,
						  offset,
						  len,
						  mem,
						  events.size(),
						  events.size() ? events.data() : nullptr,
						  &event );
	    GpuInterfaceImpl::ErrorChk(status,  "Failure queueing OpenCL buffer read");
	    return event;
	}

    /// Read a buffer back from the gpu waiting for completion.
    /// @param buf OpenCL Buffer object
    /// @param mem Pointer to area to recieve data
    /// @param len Length of data to read
    void
    ReadWait ( cl_mem buf,
	       void * mem,
	       size_t len );

    /// Queue the unmap of a buffer
    /// @return Event to wait on
	cl_event
	UnmapBuffer ( cl_mem buf,
		      void * mem );

    GpuInterfaceImpl & _gpuIntf;

    cl_command_queue   _cQueue;

    cl_kernel          _lkhLeafLeaf;
    cl_kernel          _lkhLeafInner;
    cl_kernel          _lkhInnerLeaf;
    cl_kernel          _lkhInnerInner;

    cl_kernel          _lnLKernel;                ///< Kernel to use with site log likelihood computation
    cl_kernel          _reduceKernel;	          ///< Kernel to use with likelihood summation

};

#endif // _GPUINTERFACEIMPL_H_
