/// @file LikelihoodGpuImpl.h
/// Declarations for the GPU likelihood objects and functions.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _LIKELIHOODGPUIMPL_H_
#define _LIKELIHOODGPUIMPL_H_

#include "GpuInterfaceImpl.h"
#include "Likelihood.h"
#include "Tree.h"

struct EvoModel;
struct EMRGpuImpl;
struct LkhGpuRoot;
struct LkhGpuLocusRoot;
struct Replicate;
struct TransitionMatrixGpu;

// *****************************************************************************
// Structure of the GPU site vector entries.

struct SitePosEntry {
    cl_int lhsIdx;
    cl_int rhsIdx;
};

// *****************************************************************************
/// Likelihood object at a species tree node

struct LkhGpuTreeNode : Likelihood {

    LkhGpuTreeNode( Replicate &          repl,
		    const Tree::Position tPos )
	: Likelihood(repl),
	  _tPos(std::move(tPos)),
	  _eModel(*GpuImpl(tPos.GetRoot()._eModel))
	{}

    virtual
    FLOAT
    Compute();

    const Tree::Position _tPos;
    EMRGpuImpl &         _eModel;		  ///< Evolutionary model at the root

};

// *****************************************************************************
/// likelihood object at a species tree root
/// Responsible for allocating the GPU memory for the transition matrixes.

struct LkhGpuRoot : Likelihood {

    LkhGpuRoot( Replicate &  repl,
		Tree::Root & root );

    virtual
    ~LkhGpuRoot()
	{
	    if ( _siteBuf )  clReleaseMemObject(_siteBuf);
	    if ( _bvBuf )    clReleaseMemObject(_bvBuf);
	    if ( _countBuf ) clReleaseMemObject(_countBuf);
	    if ( _cFreqBuf ) clReleaseMemObject(_cFreqBuf);
	    DisposeData();
	}

    /// Compute and return the value of the likelihood for the species tree.
    /// Sums across all the gene trees.
    /// Not logged.
    virtual
    FLOAT
    operator()();

    /// Compute the likelihood at the species tree root returning the value.
    virtual
    FLOAT
    Compute();

    /// Clear data pulled from the GPU.
    virtual
    void
    DisposeData ()
	{
	    delete[] _bvData;
	    delete[] _siteData;
	    delete[] _countData;
	    delete[] _cFreqData;
	    _bvData = nullptr;
	    _siteData = nullptr;
	    _countData = nullptr;
	    _cFreqData = nullptr;
	}

    /// Pull the data from the GPU for dumping.
    virtual
    void
    GetData ();

    /// Allocate the necessary device memory objects and populate as required.
    virtual
    void
    ReplRootEnd();

    /// Output dump string for the instance.
    virtual
    std::string
    str ( const std::string hdg = "" )
	const;

    /// Return the existing vector size then update it.
    unsigned
    UpdateVecSize( unsigned nvs )
	{
	    auto vs = _vecSize;
	    _vecSize += nvs;
	    return vs;
	}

    GpuReplicateImpl &        _gpuRepl;		  ///< Replicates gpu interface
    GpuInterfaceImpl &        _gpuIntf;		  ///< GLobal gpu interface

    Tree::Root &              _root;	          ///< Associated species tree
    EMRGpuImpl &              _eModel;		  ///< Evolutionary model at the root

    unsigned                  _vecSize;	          ///< Entries in site and base vectors
    unsigned                  _lRootVecSize;	  ///< Number of entries in root site vector

    unsigned                  _siteAlloc;	  ///< Byte size of site vector
    cl_mem                    _siteBuf;		  ///< Memory object for the site vector

    unsigned                  _bvEntrySize;	  ///< Number of floats in a base vector entry
    unsigned                  _bvAlloc;	          ///< Byte size of vector of base vectors
    cl_mem                    _bvBuf;		  ///< Memory object for the vector of base vectors

    unsigned                  _countAlloc;	  ///< Byte size of count vector
    cl_mem                    _countBuf;	  ///< Vector of counts at the sites.

    unsigned                  _cFreqAlloc;	  ///< Byte size of character frequency vector
    cl_mem                    _cFreqBuf;	  ///< Vector of character frequencies by locus

    cl_float *                _bvData;		  ///< Base vector data from the gpu
    SitePosEntry *            _siteData;	  ///< Site data from the gpu
    cl_float *                _countData;	  ///< Count data from the gpu.
    cl_float *                _cFreqData;	  ///< Character frequency data from the gpu.

};

// *****************************************************************************
/// Likelihood object at a gene tree node.
/// The is where the heavy lifting occurs.

struct LkhGpuLocusNode : Likelihood {

    LkhGpuLocusNode ( Replicate &       repl,
		      Tree::LocusNode & lNode );

    /// Return the index of the inactive base vecrtor
    inline
    unsigned
    Index2Update()
	{
	    return _which ? _idx1 : _idx2;
	}

    /// Return the index of the active base vector
    inline
    unsigned
    Index2Use()
	{
	    return _which ? _idx2 : _idx1;
	}

    virtual
    FLOAT
    Compute();

    /// To silence warnings.
    virtual
    void
    ReplRootEnd()
	{}

    /// Perform final initialization at end of replication.
    void
    ReplRootEnd ( SitePosEntry * vec );

    /// Rollback the index
    virtual
    void
    Rollback()
	{
	    Likelihood::Rollback();
	    SwapCopy();
	}

    /// Output dump string for the instance.
    virtual
    std::string
    str ( const std::string hdg = "" )
    	const;

    /// Swap the copy in use
    inline
    void
    SwapCopy()
	{
	    _which = !_which;
	}

    /// Queue the update to the base vector
    cl_event
    UpdateBaseVec ( EVENTLIST & events );

    Tree::LocusNode &     _lNode;		  ///< Owning locus node
    LkhGpuRoot &          _lkhRoot;		  ///< Likelihood controller for the species tree
    LkhGpuLocusRoot &     _lkhLRoot;		  ///< Likelihood controller for the gene tree

    cl_kernel             _kernel;		  ///< OpenCL kernel to use with this node.
    cl_event              _event;		  ///< OpenCL event for the kernel

    bool                  _which;		  ///< Which copy of the base vector to update

    unsigned	          _idx1;		  ///< Index to first block copy and site vector
    unsigned	          _idx2;		  ///< Index to second block copy

    TransitionMatrixGpu * _lhTMatrix;	          ///< Left child transition matrix
    TransitionMatrixGpu * _rhTMatrix;	          ///< Right child transition matrix

    LkhGpuLocusNode *     _lhLkh;	          ///< Left child likelihood node
    LkhGpuLocusNode *     _rhLkh;	          ///< Right child likelihood node

};

// *****************************************************************************
/// Likelihood object at a gene tree root

struct LkhGpuLocusRoot : Likelihood {

    LkhGpuLocusRoot( Replicate &       repl,
		     Tree::LocusRoot & lRoot );

    virtual
    ~LkhGpuLocusRoot()
	{
	    if (_rBuf1)        clReleaseMemObject(_rBuf1);
	    if (_rBuf2)        clReleaseMemObject(_rBuf2);
	}

    /// Compute the likelihood over a gene tree.
    /// @return Likelihood value (not ratio) for the gene tree.
    virtual
    FLOAT
    Compute();

    /// To silence warnings.
    virtual
    void
    ReplRootEnd()
	{}

    /// Perform final initialization at end of replication.
    void
    ReplRootEnd ( float *    cVec,
		  unsigned & cIdx,
		  float *    fVec,
		  unsigned & fIdx );

    /// Output dump string for the instance.
    virtual
    std::string
    str ( const std::string hdg = "" )
	const;

    /// Update the log likelihood for the gene tree
    cl_event
    UpdateValue( const EVENTLIST & events );

    Tree::LocusRoot &           _lRoot;		  ///< Associated locus root
    EMGpuImpl &                 _eMLRoot;	  ///< Associated gene tree evolutionary model
    LkhGpuRoot &                _lkhRoot;	  ///< Likelihood controller for the gene tree

    unsigned                    _countIdx;	  ///< Index into count buffer for this locus
    unsigned                    _countSize;	  ///< Entries in this count buffer segment
    unsigned                    _cFreqIdx;	  // < Index into character freq buffer for this locus

    cl_mem                      _rBuf1;		  ///< First reduction buffer
    unsigned                    _rBuf1Alloc;	  ///< Byte allocation for buffer 1
    unsigned                    _rBuf1Size;	  ///< Number of entries in buffer 1
    cl_mem                      _rBuf2;		  ///< Second reduction buffer
    unsigned                    _rBuf2Alloc;	  ///< Byte allocation for buffer 2
    unsigned                    _rBuf2Size;	  ///< Number of entries in buffer 2

    cl_event                    _event;		  ///< Final event for likelihood calculations.

    cl_float                    _lnL;		  ///< Likelihood value pulled from gpu

};

#endif // _LIKELIHOODGPUIMPL_H_
