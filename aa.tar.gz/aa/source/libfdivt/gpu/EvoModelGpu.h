/// @file EvoModelGpu.h
/// Declarations of the evolutionary model classes for the gpu based algorithm.
/// This header is used as the external interface for the gpu algorithm
/// evolutionary model code. The gpu specific code is in EvoModelGpuImpl.h.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _EVOMODELGPU_H_
#define _EVOMODELGPU_H_

struct EvoModelRoot;
struct Replicate;

namespace Tree {
    struct Root;
}

// *****************************************************************************
/// Container for the gpu factory method.

namespace EvoModelRootGpu {

    /// Create an evolutionary model instance.
    /// @param repl Replicate owning the model.
    /// @param root Species tree root
    /// @returns Pointer to created model instance
    EvoModelRoot *
    Factory ( Replicate &  repl,
	      Tree::Root & root );

}

#endif // _EVOMODELGPU_H_
