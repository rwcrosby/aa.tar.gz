/// @file EvoModelGpu.cpp
/// Definitions for the evolutionary model methods for the cpu algorithm

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include <iostream>

#include "DivTime.h"
#include "Dump.h"
#include "EvoModel.h"
#include "EvoModelGpu.h"
#include "EvoModelGpuImpl.h"
#include "EvoModelParameters.h"
#include "GpuInterfaceImpl.h"
#include "Locus.h"
#include "Replicates.h"
#include "SequenceFactory.h"
#include "TransitionMatrixGpu.h"
#include "Tree.h"

// *****************************************************************************
/// Definition of a position entry.
/// These structures are used to transition matrix work items onto the
/// gamma rate and matrix vectors.

struct PosEntry {
    cl_int    tmVecIdx;	                          ///< Index into the transition matrix vector
    cl_int    locusIdx;	                          ///< Index into locus dependent parameters
    cl_float  brLen;				  ///< Branch length to use
};

// *****************************************************************************
/// Subclass for the gene tree JC69 model

struct EMGpuJC69 : EMGpuImpl {

    EMGpuJC69 ( EvoModelRoot &   parent,
		Tree::LocusRoot& lRoot )
	: EMGpuImpl( parent, lRoot ),
	  _charFreqs(_parent._n, 1.0/FLOAT (_parent._n))
	{}

    virtual
    const
    FLOATVEC &
    CharFreq () const
	{
	    return _charFreqs;
	}

    virtual
    std::string
    ModelStr()
	const
	{
	    return "JC69";
	}

    /// The set of constant character frequencies
    FLOATVEC _charFreqs;

};

struct EMRGpuJC69 : EMRGpuImpl {

    EMRGpuJC69( Replicate &  repl,
		Tree::Root & root )
	: EMRGpuImpl ( repl, root, "TmJC69" )
	{};

    EvoModel *
    Factory( Tree::LocusRoot & lRoot )
	{
	    return new EMGpuJC69(*this, lRoot);
	}

    virtual
    unsigned
    LocusBlockSize()
	const
	{
	    return _nGCat;
	}

    virtual
    std::string
    ModelStr()
	const
	{
	    return "JC69";
	}

};

// *****************************************************************************
/// Subclass for the gene tree K80 model

struct EMGpuK80 : EMGpuImpl {

    EMGpuK80 ( EvoModelRoot &   parent,
	       Tree::LocusRoot& lRoot )
	: EMGpuImpl( parent, lRoot),
	  _charFreqs(_parent._n, 1.0/FLOAT (_parent._n))
	{
	    _kappa = new GammaParameter( *this,
					 _repl._dt._eMParms[0],
					 _repl._dt._eMParms[1],
					 "Kappa" );
	}

    virtual
    ~EMGpuK80()
	{
	    delete _kappa;
	}

    virtual
    const
    FLOATVEC &
    CharFreq () const
	{
	    return _charFreqs;
	}

    virtual
    std::string
    ModelStr()
	const
	{
	    std::stringstream ss;
	    ss <<  "K80 "
	       << Dump::pstr(_kappa, "kappa");
	    return ss.str();
	}

    /// Set the kappa value in the locus block
    virtual
    cl_float *
    PopulateLocusBlock (cl_float * lBlk)
	{
	    lBlk = EMGpuImpl::PopulateLocusBlock(lBlk);
	    *lBlk++ = (*_kappa)();
	    return lBlk;
	}

    Parameter * _kappa;

    /// The set of constant character frequencies
    FLOATVEC _charFreqs;

};

struct EMRGpuK80 : EMRGpuImpl {

    EMRGpuK80( Replicate &  repl,
	       Tree::Root & root )
	: EMRGpuImpl ( repl, root, "TmK80" )
	{}

    EvoModel *
    Factory( Tree::LocusRoot & lRoot )
	{
	    return new EMGpuK80(*this, lRoot);
	}

    virtual
    unsigned
    LocusBlockSize()
	const
	{
	    return _nGCat + 1;
	}

    virtual
    std::string
    ModelStr()
	const
	{
	    return "K80";
	}

};

// *****************************************************************************
/// Model subclass for Felsenstein 1981 model

struct EMGpuF81 : EMGpuImpl {

    EMGpuF81 ( EvoModelRoot &   parent,
		Tree::LocusRoot& lRoot )
	: EMGpuImpl( parent, lRoot)
	{
	    _freqParms = EvoModel::FrequencyParmsSetup( *this,
							lRoot._locus._charPct,
							_repl._dt._eMFreqParms );
	}

    virtual
    ~EMGpuF81()
	{
	    delete _freqParms;
	}

    virtual
    const
    FLOATVEC &
    CharFreq () const
	{
	    return _freqParms->_values;
	}

    virtual
    std::string
    ModelStr()
	const
	{
	    std::stringstream ss;
	    ss <<  "F81 "
	       << Dump::pstr(_freqParms, "freqparms");
	    return ss.str();
	}

    /// Set the Freq and kappa (constant) values in the locus block
    virtual
    cl_float *
    PopulateLocusBlock (cl_float * lBlk)
	{
	    lBlk = EMGpuImpl::PopulateLocusBlock(lBlk);
	    *lBlk++ = 1.0;
	    *lBlk++ = 1.0;
	    for ( auto v : _freqParms->_values )
		*lBlk++ = v;
	    return lBlk;
	}

    DirichletParameterSet * _freqParms;

};

struct EMRGpuF81 : EMRGpuImpl {

    EMRGpuF81( Replicate &  repl,
		Tree::Root & root )
	: EMRGpuImpl ( repl, root, "TmTN93" )
	{}

    EvoModel *
    Factory( Tree::LocusRoot & lRoot )
	{
	    return new EMGpuF81(*this, lRoot);
	}

    virtual
    unsigned
    LocusBlockSize()
	const
	{
	    return _nGCat + 2 + _n;
	}

    virtual
    std::string
    ModelStr()
	const
	{
	    return "F81";
	}

};

// *****************************************************************************
/// Model subclass for Felsenstein 1984 model

struct EMGpuF84 : EMGpuImpl {

    EMGpuF84 ( EvoModelRoot &   parent,
		Tree::LocusRoot& lRoot )
	: EMGpuImpl( parent, lRoot)
	{
	    auto & dt = _repl._dt;
	    _kappa = new GammaParameter ( *this, _repl._dt._eMParms[0], _repl._dt._eMParms[1], "Kappa");
	    _freqParms = EvoModel::FrequencyParmsSetup( *this, lRoot._locus._charPct, dt._eMFreqParms );
	}

    virtual
    ~EMGpuF84()
	{
	    delete _kappa;
	    delete _freqParms;
	}

    virtual
    const
    FLOATVEC &
    CharFreq () const
	{
	    return _freqParms->_values;
	}

    virtual
    std::string
    ModelStr()
	const
	{
	    std::stringstream ss;
	    ss <<  "F84 "
	       << Dump::pstr(_kappa, "kappa") << ' '
	       << Dump::pstr(_freqParms, "freqparms");
	    return ss.str();
	}

    /// Set the kappa value in the locus block
    virtual
    cl_float *
    PopulateLocusBlock (cl_float * lBlk)
	{
	    lBlk = EMGpuImpl::PopulateLocusBlock(lBlk);

	    auto & parms = _freqParms->_values;

	    *lBlk++ = 1.0 + (*_kappa)()/(parms[0] + parms[1]);
	    *lBlk++ = 1.0 + (*_kappa)()/(1.0 - parms[0] - parms[1]);

	    for ( auto v : _freqParms->_values )
		*lBlk++ = v;

	    return lBlk;
	}

    Parameter *             _kappa;
    DirichletParameterSet * _freqParms;

};

struct EMRGpuF84 : EMRGpuImpl {

    EMRGpuF84( Replicate &  repl,
		Tree::Root & root )
	: EMRGpuImpl ( repl, root, "TmTN93" )
	{}

    EvoModel *
    Factory( Tree::LocusRoot & lRoot )
	{
	    return new EMGpuF84(*this, lRoot);
	}

    virtual
    unsigned
    LocusBlockSize()
	const
	{
	    return _nGCat + 2 + _n;
	}

    virtual
    std::string
    ModelStr()
	const
	{
	    return "F84";
	}

};

// *****************************************************************************
/// Model subclass for HKY 1985 model

struct EMGpuHKY85 : EMGpuImpl {

    EMGpuHKY85 ( EvoModelRoot &   parent,
		Tree::LocusRoot& lRoot )
	: EMGpuImpl( parent, lRoot)
	{
	    auto & dt = _repl._dt;
	    _kappa = new GammaParameter ( *this, dt._eMParms[0], dt._eMParms[1], "Kappa");
	    _freqParms = EvoModel::FrequencyParmsSetup( *this, lRoot._locus._charPct, dt._eMFreqParms );
	}

    virtual
    ~EMGpuHKY85()
	{
	    delete _kappa;
	    delete _freqParms;
	}

    virtual
    const
    FLOATVEC &
    CharFreq () const
	{
	    return _freqParms->_values;
	}

    virtual
    std::string
    ModelStr()
	const
	{
	    std::stringstream ss;
	    ss <<  "HKY85 "
	       << Dump::pstr(_kappa, "kappa") << ' '
	       << Dump::pstr(_freqParms, "freqparms");
	    return ss.str();
	}

    /// Set the kappa value in the locus block
    virtual
    cl_float *
    PopulateLocusBlock (cl_float * lBlk)
	{
	    lBlk = EMGpuImpl::PopulateLocusBlock(lBlk);

	    *lBlk++ = (*_kappa)();
	    *lBlk++ = (*_kappa)();

	    for ( auto v : _freqParms->_values )
		*lBlk++ = v;

	    return lBlk;
	}

    Parameter *             _kappa;
    DirichletParameterSet * _freqParms;

};

struct EMRGpuHKY85 : EMRGpuImpl {

    EMRGpuHKY85( Replicate &  repl,
		Tree::Root & root )
	: EMRGpuImpl ( repl, root, "TmTN93" )
	{}

    EvoModel *
    Factory( Tree::LocusRoot & lRoot )
	{
	    return new EMGpuHKY85(*this, lRoot);
	}

    virtual
    unsigned
    LocusBlockSize()
	const
	{
	    return _nGCat + 2 + _n;
	}

    virtual
    std::string
    ModelStr()
	const
	{
	    return "HKY85";
	}

};

// *****************************************************************************
/// Subclass for the gene tree T92 model

struct EMGpuT92 : EMGpuImpl {

    EMGpuT92 ( EvoModelRoot &   parent,
	       Tree::LocusRoot& lRoot )
	: EMGpuImpl( parent, lRoot),
	  _charFreqs(_parent._n, 1.0/FLOAT (_parent._n))
	{
	    auto & dt = _repl._dt;
	    _kappa = new GammaParameter ( *this, dt._eMParms[0], dt._eMParms[1], "Kappa");

	    /// - If the frequencies are not specified, use the values from the locus

	    FLOATVEC gcParms;

	    if ( dt._eMFreqParms.size() == 2 )
		gcParms =  dt._eMFreqParms;
	    else {
		if ( auto idx = dt._seqFactory->_alphabet.find('G') == std::string::npos )
		    throw Except::ModelError("No 'G' value in alphabet, required for T92 model");
		else
		    gcParms.push_back(lRoot._locus._charPct[idx]);
		if ( auto idx = dt._seqFactory->_alphabet.find('C') == std::string::npos )
		    throw Except::ModelError("No 'C' value in alphabet, required for T92 model");
		else
		    gcParms.push_back(lRoot._locus._charPct[idx]);
	    }

	    _gcFreq = new GammaParameter ( *this, gcParms[0], gcParms[1], "Freq GC", "Freq_GC" );

	}

    virtual
    ~EMGpuT92()
	{
	    delete _kappa;
	    delete _gcFreq;
	}

    virtual
    const
    FLOATVEC &
    CharFreq () const
	{
	    return _charFreqs;
	}

    virtual
    std::string
    ModelStr()
	const
	{
	    std::stringstream ss;
	    ss <<  "T92 "
	       << Dump::pstr(_kappa, "kappa") << ' '
	       << Dump::pstr(_gcFreq, "gcFreq");
	    return ss.str();
	}

    /// Set the kappa value in the locus block
    virtual
    cl_float *
    PopulateLocusBlock (cl_float * lBlk)
	{
	    lBlk = EMGpuImpl::PopulateLocusBlock(lBlk);

	    *lBlk++ = (*_kappa)();
	    *lBlk++ = (*_kappa)();

	    *lBlk++ = (1 - (*_gcFreq)()) / 2;
	    *lBlk++ = (*_gcFreq)() / 2;
	    *lBlk++ = (1 - (*_gcFreq)()) / 2;
	    *lBlk++ = (*_gcFreq)() / 2 ;

	    return lBlk;
	}

    Parameter *             _kappa;
    Parameter *             _gcFreq;

    /// The set of constant character frequencies
    FLOATVEC _charFreqs;

};

struct EMRGpuT92 : EMRGpuImpl {

    EMRGpuT92( Replicate &  repl,
		Tree::Root & root )
	: EMRGpuImpl ( repl, root, "TmTN93" )
	{}

    EvoModel *
    Factory( Tree::LocusRoot & lRoot )
	{
	    return new EMGpuT92(*this, lRoot);
	}

    virtual
    unsigned
    LocusBlockSize()
	const
	{
	    return _nGCat + 2 + _n;
	}

    virtual
    std::string
    ModelStr()
	const
	{
	    return "T92";
	}

};

// *****************************************************************************
/// Subclass for the gene tree TN93 model

struct EMGpuTN93 : EMGpuImpl {

    EMGpuTN93 ( EvoModelRoot &   parent,
		Tree::LocusRoot& lRoot )
	: EMGpuImpl( parent, lRoot)
	{
	    _kappa1 = new GammaParameter ( *this,
					   _repl._dt._eMParms[0],
					   _repl._dt._eMParms[1],
					   "Kappa_1",
					   "Kappa 1");
	    _kappa2 = new GammaParameter ( *this,
					   _repl._dt._eMParms[2],
					   _repl._dt._eMParms[3],
					   "Kappa_2",
					   "Kappa 2");
	    _freqParms = EvoModel::FrequencyParmsSetup( *this,
							lRoot._locus._charPct,
							_repl._dt._eMFreqParms );
	}

    virtual
    ~EMGpuTN93()
	{
	    delete _kappa1;
	    delete _kappa2;
	    delete _freqParms;
	}

    virtual
    const
    FLOATVEC &
    CharFreq () const
	{
	    return _freqParms->_values;
	}

    virtual
    std::string
    ModelStr()
	const
	{
	    std::stringstream ss;
	    ss <<  "TN93 "
	       << Dump::pstr(_kappa1, "kappa1") << ' '
	       << Dump::pstr(_kappa2, "kappa2") << ' '
	       << Dump::pstr(_freqParms, "freqparms");
	    return ss.str();
	}

    /// Set the kappa value in the locus block
    virtual
    cl_float *
    PopulateLocusBlock (cl_float * lBlk)
	{
	    lBlk = EMGpuImpl::PopulateLocusBlock(lBlk);
	    *lBlk++ = (*_kappa1)();
	    *lBlk++ = (*_kappa2)();
	    for ( auto v : _freqParms->_values )
		*lBlk++ = v;
	    return lBlk;
	}

    Parameter *             _kappa1;
    Parameter *             _kappa2;
    DirichletParameterSet * _freqParms;

};

struct EMRGpuTN93 : EMRGpuImpl {

    EMRGpuTN93( Replicate &  repl,
		Tree::Root & root )
	: EMRGpuImpl ( repl, root, "TmTN93" )
	{}

    EvoModel *
    Factory( Tree::LocusRoot & lRoot )
	{
	    return new EMGpuTN93(*this, lRoot);
	}

    virtual
    unsigned
    LocusBlockSize()
	const
	{
	    return _nGCat + 2 + _n;
	}

    virtual
    std::string
    ModelStr()
	const
	{
	    return "TN93";
	}

};

// *****************************************************************************
/// Subclass for the gene tree GTR model

struct EMGpuGTR : EMGpuImpl {

    EMGpuGTR ( EvoModelRoot &   parent,
	       Tree::LocusRoot& lRoot );

    virtual
    ~EMGpuGTR()
	{
	    delete _modelParms;
	    delete _freqParms;
	}

    virtual
    const
    FLOATVEC &
    CharFreq () const
	{
	    return _freqParms->_values;
	}

    virtual
    std::string
    ModelStr()
	const
	{
	    std::stringstream ss;
	    ss << "GTR" << ' '
	       << Dump::pstr(_modelParms, "modelParms") << ' '
	       << Dump::pstr(_freqParms, "freqParms");
	    return ss.str();
	}

    /// Set the kappa value in the locus block
    virtual
    cl_float *
    PopulateLocusBlock (cl_float * lBlk);

    /// Matrix dimension
    static const unsigned    N = 4;

    DirichletParameterSet *  _modelParms;
    DirichletParameterSet *  _freqParms;

    /// The multiplier matrix.
    /// The matrix is defined here so it's addressable wherever needed.
    FLOAT                    _cMat[N*N*N];

    /// The eigenvalues (real only).
    FLOAT                    _Wr[N];

};

struct EMRGpuGTR : EMRGpuImpl {

    EMRGpuGTR( Replicate &  repl,
		Tree::Root & root )
	: EMRGpuImpl ( repl, root, "TmGTR" )
	{}

    EvoModel *
    Factory( Tree::LocusRoot & lRoot )
	{
	    return new EMGpuGTR(*this, lRoot);
	}

    virtual
    unsigned
    LocusBlockSize()
	const
	{
	    return _nGCat + _n * _n * _n + _n;
	}

    virtual
    std::string
    ModelStr()
	const
	{
	    return "GTR";
	}

};

// *****************************************************************************

TransitionMatrix *
EMGpuImpl::MakeTransitionMatrix ()
{
    auto tm = new TransitionMatrixGpu(_parent._n,
				      _parent._nGCat,
				      *this);
    _tMatrixList.push_back(tm);
    GpuImpl(_parent)._vecSize++;
    return tm;
}

// *****************************************************************************

cl_float *
EMGpuImpl::PopulateLocusBlock( cl_float * lBlk )
{
    if ( !_rateVec.size() )
	*lBlk++ = 1.0;
    else
	for ( auto gRate : _rateVec )
	    *lBlk++ = gRate;
    return lBlk;
}

// *****************************************************************************

std::string
EMGpuImpl::str( const std::string hdg )
    const
{
    std::stringstream ss;
    if ( hdg.size() ) ss << hdg << '<';

    ss << ModelStr() << ' '
       << EvoModel::str() << ' '
       << Dump::str(_which, "which") << ' '
       << Dump::str(_idx1, "idx1") << ' '
       << Dump::str(_idx2, "idx2");

    if ( hdg.size() ) ss << '>';
    return ss.str();
}

// *****************************************************************************

void
EMGpuImpl::UpdateAllTMatrixes()
{
    REPRENTER(Dump::ptr(this));

    EVENTLIST events;
    auto & eMRoot = GpuImpl(_parent);

    /// - Update the locus block for this gene tree

    auto buf = (float*)eMRoot._gpuRepl.MapBuffer( eMRoot._tmVecBuf,
						  eMRoot.LocusBlockSize() * sizeof(cl_float),
						  Index2Update() * sizeof(cl_float));

    PopulateLocusBlock(buf);

    events.push_back( eMRoot._gpuRepl.UnmapBuffer(eMRoot._tmVecBuf, buf ) );

    /// - Setup the position vector for this gene tree only.

    PosEntry * pev = (PosEntry *)eMRoot._gpuRepl.MapBuffer(eMRoot._posVecBuf,
							   eMRoot._posVecAlloc );

    PosEntry * pe = pev;
    for ( auto tm : _tMatrixList ) {
	auto tmGpu =  static_cast<TransitionMatrixGpu*>(tm);

	pe->tmVecIdx = tmGpu->Index2Update();
	tmGpu->SwapCopy();
	tmGpu->Save();

	pe->locusIdx = Index2Update();

	pe->brLen    = tmGpu->_dist;

	pe++;
    }

    /// - Setup to use the now updated copy

    SwapCopy();
    _repl.LogRollback(this);

    events.push_back( eMRoot._gpuRepl.UnmapBuffer(eMRoot._posVecBuf, pev ) );

    /// - Queue the kernel to build the transition matricies.

    eMRoot._event = eMRoot._gpuRepl.QueueKernel(eMRoot._kernel,
						_tMatrixList.size(),
						events);

    REPREXIT(Dump::ptr(this));
}

// *****************************************************************************
///Push this entry onto the update list and setup for rollback

void
EMGpuImpl::UpdateTMatrix ( TransitionMatrix * tMat,
			   const FLOAT        dist )
{
    REPRDEBUG(Dump::ptr(this),
	      Dump::ptr(tMat,"tMat"),
	      Dump::str(dist,"dist"));

    GpuImpl(_parent)._posUpdList.push_back(GpuImpl(tMat));
}

// *****************************************************************************

EMRGpuImpl::EMRGpuImpl ( Replicate &  repl,
			 Tree::Root & root,
			 const char * name )
    : EvoModelRoot ( repl, root ),
      _gpuRepl(*static_cast<GpuReplicateImpl*>(repl._gpuRepl)),
      _gpuIntf(_gpuRepl._gpuIntf),
      _kernel(GpuInterfaceImpl::GetKernel(_gpuIntf._emProgram, name)),
      _vecSize(0),
      _tmAlloc(_nGCat * (_n + 1) * _n * sizeof(float)),
      _tmVecAlloc(0),
      _tmVecBuf(nullptr),
      _posVecAlloc(0),
      _posVecBuf(nullptr),
      _locusVecAlloc(0),
      _locusVecBuf(nullptr),
      _tmData(nullptr)
{
}

// *****************************************************************************

EMRGpuImpl::~EMRGpuImpl ()
{
    if ( _kernel )	clReleaseKernel (_kernel);
    if ( _tmVecBuf )	clReleaseMemObject (_tmVecBuf);
    if ( _posVecBuf )   clReleaseMemObject (_posVecBuf);
    if ( _locusVecBuf ) clReleaseMemObject (_locusVecBuf);
    delete _tmData;
}

// *****************************************************************************

cl_event
EMRGpuImpl::DoUpdates ()
{
    REPRENTER ( Dump::ptr(this),
		Dump::str((unsigned)_posUpdList.size(),"posListSize"));

    /// - Map enough of the pos vector for the updates in the list

    auto len = _posUpdList.size() * sizeof(PosEntry);

    PosEntry * pev = (PosEntry*)_gpuRepl.MapBuffer( _posVecBuf, len );

    /// - Create the pos entries

    PosEntry * pe = pev;
    for ( auto tm : _posUpdList ) {

	pe->tmVecIdx = tm->Index2Update();
	tm->SwapCopy();
	tm->Save();

	pe->locusIdx = GpuImpl(tm->_parent).Index2Use();

	pe->brLen    = tm->_dist;

	pe++;
    }

    cl_event event = _gpuRepl.UnmapBuffer(_posVecBuf, pev );

    /// - Queue the kernel to build the transition matricies.

    REPREXIT ( Dump::ptr(this) );
    _event =  _gpuRepl.QueueKernel( _kernel,
				    _posUpdList.size(),
				    { event } );

    return _event;

}

// *****************************************************************************
/// Read back the computed transition matrix set.

void
EMRGpuImpl::GetData ()
{
    _tmData = new float[_tmVecAlloc / sizeof(cl_float)] ;
    _gpuRepl.ReadWait(_tmVecBuf, _tmData, _tmVecAlloc);
}

// *****************************************************************************
/// Create the OpenCL objects for the evolutionary model.

void
EMRGpuImpl::ReplRootEnd()
{
    REPRENTER(Dump::ptr(this),
	      Dump::str((unsigned)_eModelList.size(),"eModelList.size"),
	      Dump::str(LocusBlockSize(),"LocusBlockSize")
	);

    /// - Allocate, populate and set the transition matrix vector as a kernel parameter.
    ///   Enough space is allocated for two copies of each TM

    _tmVecAlloc = _vecSize * _tmAlloc * 2;
    _tmVecBuf = _gpuIntf.CreateBuffer( CL_MEM_READ_WRITE | CL_MEM_ALLOC_HOST_PTR,
				       _tmVecAlloc );

    auto buf = (float*)_gpuRepl.MapBuffer( _tmVecBuf, _tmVecAlloc );

    for (auto fp1 = buf; fp1 < buf + _tmVecAlloc / sizeof(float); )
	*fp1++ = 1.0;

    auto event = _gpuRepl.UnmapBuffer(_tmVecBuf, buf );

    GpuInterfaceImpl::SetKernelArg ( _kernel,  0, _tmVecBuf );

    /// - Create the locus vector buffer (2 copies for each locus) and set as an argument

    _locusVecAlloc = _eModelList.size() * LocusBlockSize() * sizeof(cl_float) * 2;
    _locusVecBuf   = _gpuIntf.CreateBuffer( CL_MEM_READ_ONLY | CL_MEM_ALLOC_HOST_PTR,
					    _locusVecAlloc );

    GpuInterfaceImpl::SetKernelArg ( _kernel,  1, _locusVecBuf );

    /// - Create the position vector buffer and set it's argument
    ///   In theory this should be read only but that puts it in the constant memory
    ///   space on the device and it just isn't big enough...

    _posVecAlloc = _vecSize * sizeof(PosEntry);
    _posVecBuf   = _gpuIntf.CreateBuffer ( CL_MEM_READ_WRITE | CL_MEM_ALLOC_HOST_PTR,
					   _posVecAlloc );

    GpuInterfaceImpl::SetKernelArg ( _kernel,  2, _posVecBuf );

    /// - Loop throught all the gene tree evolutionary models setting
    /// locus block and transition matrix indicies.

    unsigned lbIdx = 0;
    unsigned tmIdx = 0;
    for ( auto eModel : _eModelList  ) {

	auto em = GpuImpl(eModel);
	em->_idx1 = lbIdx;
	em->_idx2 = em->_idx1 +  _eModelList.size();
	lbIdx++;

	for ( auto tMat : eModel->_tMatrixList ) {
	    auto tm = GpuImpl(tMat);
	    tm->_idx1 = tmIdx++;
	    tm->_idx2 = tm->_idx1 + _vecSize;
	}

	REPRDEBUG(Dump::str(em->_idx1, "idx1"),
		  Dump::str(em->_idx2, "idx2"),
		  Dump::pstr(em,"em")
	    );

    }

    /// - Wait for completion of the memory transfer

    GpuInterfaceImpl::WaitForEvents( { event } );

    REPREXIT( Dump::ptr(this) );
}

// *****************************************************************************

void
EMRGpuImpl::UpdateAllTMatrixes ()
{
    REPRENTER(Dump::ptr(this));

    EVENTLIST events;

    /// - Populate the position vector for the whole species tree.

    PosEntry * pev = (PosEntry*)_gpuRepl.MapBuffer(_posVecBuf, _posVecAlloc );

    PosEntry * pe = pev;
    for ( auto & lRoot : _root._locusVec  ) {

	auto em = GpuImpl(lRoot._eModel);

	for ( auto tm : em->_tMatrixList ) {
	    auto tmGpu =  GpuImpl(tm);

	    pe->tmVecIdx = tmGpu->Index2Update();
	    tmGpu->SwapCopy();

	    pe->locusIdx = em->Index2Update();

	    pe->brLen	 = tmGpu->_dist;
	    pe++;
	}

	em->SwapCopy();

    }

    if (debugSet)
	for ( auto p = pev; p < pe; p++ )
	    REPRDEBUG(Dump::str(p->tmVecIdx,"tmVecIdx"),
		      Dump::str(p->locusIdx,"locusIdx"),
		      Dump::str(p->brLen, "brLen"));


    events.push_back( _gpuRepl.UnmapBuffer(_posVecBuf, pev ) );

    /// - Populate and upload the locus vector
    ///   The gamma rates are copied here the rest is delegated to the locus instance

    cl_float * lVec = (cl_float*)_gpuRepl.MapBuffer(_locusVecBuf, _locusVecAlloc );

    cl_float * lBlk = lVec;
    for ( auto & lRoot : _root._locusVec )
	lBlk = GpuImpl(lRoot._eModel)->PopulateLocusBlock(lBlk);

    if (debugSet)
	for ( auto p = lVec; p < lBlk; p += LocusBlockSize() )
	    for ( unsigned i = 0; i < LocusBlockSize(); i++ )
		REPRDEBUG(Dump::str(i,"i"), Dump::ptr(p,"p"),Dump::str(p[i],"Locus block data"))

    events.push_back( _gpuRepl.UnmapBuffer(_locusVecBuf, lVec ) );

    _event = _gpuRepl.QueueKernel(_kernel, _vecSize, events);

    REPREXIT(Dump::ptr(this));
}

// *****************************************************************************

std::string
EMRGpuImpl::str( const std::string hdg )
    const
{
    std::stringstream ss;
    if ( hdg.size() ) ss << hdg << "<";

    ss << ModelStr() << ' '
       << EvoModelRoot::str() << ' '
       << Dump::ptr(_kernel, "kernel") << ' '
       << Dump::str(_vecSize, "vecSize") << ' '
       << Dump::str(_tmAlloc, "tmAlloc") << ' '
       << Dump::str(_tmVecAlloc, "tmVecAlloc") << ' '
       << Dump::str(_tmVecBuf, "tmVecBuf") << ' '
       << Dump::str(_posVecAlloc, "posVecAlloc") << ' '
       << Dump::ptr(_posVecBuf, "posVecBuf") << ' '
       << Dump::str(_locusVecAlloc, "locusVecAlloc") << ' '
       << Dump::ptr(_locusVecBuf, "locusVecBuf");

    if ( _tmData && _vecSize < 1000 ) {

	ss << '\n';

	auto data1 = _tmData;
	auto data2 = _tmData + _tmAlloc * _vecSize / sizeof(cl_float);

	for ( unsigned vec = 0; vec < _vecSize; vec++ ) {

	    std::string vstr;

	    for ( unsigned gcat = 0; gcat < _nGCat; gcat++ ) {
		std::string mstr;
		for ( unsigned i = 0; i < _n + 1; i++ )
		    mstr += Dump::str(data1, data2, _n) + '\n';
		vstr += Dump::indent_heading ( mstr, Dump::vector_heading(gcat, "gCat") ) + '\n';
	    }

	    ss << Dump::indent_heading ( vstr, Dump::vector_heading(vec, "vec", 3) ) + '\n';

	}

    }

    auto s = Dump::rtrim(ss.str());
    if ( hdg.size() ) s += ">";
    return s;
}

// *****************************************************************************

EMGpuGTR::EMGpuGTR ( EvoModelRoot &   parent,
		     Tree::LocusRoot& lRoot )
    : EMGpuImpl( parent, lRoot)
{
    REPRENTER(Dump::ptr(this));

    /// - Setup the headings for the trace file

    STRINGVEC hdgs;
    for ( unsigned i = 1; i <= _repl._dt._eMParms.size(); i++ )
	hdgs.emplace_back("GTR_" + std::to_string(i));

    /// - Create the model parameters setting initial values.

    _modelParms = new DirichletParameterSet(*this,
					    _repl._dt._eMParms,
					    "GTR",
					    {"Alpha", "Beta", "Gamma", "Delta", "Epsilon", "Zeta"});

    /// - Create the character frequency parms

    _freqParms = EvoModel::FrequencyParmsSetup( *this,
						lRoot._locus._charPct,
						_repl._dt._eMFreqParms) ;

    REPREXIT(Dump::ptr(this));
}

// *****************************************************************************

cl_float *
EMGpuGTR::PopulateLocusBlock( cl_float * lBlk)
{
    REPRENTER(Dump::ptr(this),
	      Dump::ptr(lBlk,"lBlk"));

    lBlk = EMGpuImpl::PopulateLocusBlock(lBlk);

    EvoModel::ComputeGTRLocusConstants(_modelParms,
				       _freqParms,
				       _cMat,
				       _Wr );

    /// - Set the parameter for the multipler matrix vector

    const unsigned cMatESize = N * N * N;
    for ( unsigned i = 0; i < cMatESize; i++ )
	*lBlk++ = _cMat[i];

    /// - Set the parameter for the eigenvalues vector

    for ( unsigned i = 0; i < EMGpuGTR::N; i++ )
	*lBlk++ = _Wr[i];

    REPREXIT(Dump::ptr(this),
	     Dump::ptr(lBlk,"lBlk"));
    return lBlk;
}

// *****************************************************************************

EvoModelRoot *
EvoModelRootGpu::Factory( Replicate &  repl,
			  Tree::Root & root )
{

    EvoModelRoot * em = nullptr;

    switch (repl._dt._eModel) {

	case Options::EvoModel::JC69:
	    em = new EMRGpuJC69(repl, root);
	    break;

	case Options::EvoModel::K80:
	    em = new EMRGpuK80(repl, root);
	    break;

	case Options::EvoModel::F81:
	    em = new EMRGpuF81(repl, root);
	    break;

	case Options::EvoModel::F84:
	    em = new EMRGpuF84(repl, root);
	    break;

	case Options::EvoModel::HKY85:
	    em = new EMRGpuHKY85(repl, root);
	    break;

	case Options::EvoModel::T92:
	    em = new EMRGpuT92(repl, root);
	    break;

	case Options::EvoModel::TN93:
	    em = new EMRGpuTN93(repl, root);
	    break;

	case Options::EvoModel::GTR:
	    em = new EMRGpuGTR(repl, root);
	    break;

	default:
	    assert(0 && "Invalid Model");

    }

    return em;
}
