/// @file GpuInterface.h
/// Declaration for the GPU capabilities/interface class

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _GPUINTERFACE_H_
#define _GPUINTERFACE_H_

#include <list>

struct DivTime;
class  Logger;
struct Replicate;

// *****************************************************************************
/// GPU interface class for the library.
/// A single instance of this class will be created.

struct GpuInterface {

    /// - Type of the list of program defines
    typedef std::list<std::pair<std::string, std::string>> DefineList;

    /// Initialize the instance.
    GpuInterface ( Logger & logger )
	: _logger(logger)
	{}

    /// Close down the opencl interface
    virtual
    ~GpuInterface()
	{}

    /// Build the GPU programs for the evolutionary models and likelihood
    /// @param log Logger instance to output to
    /// @param defs List of key/values pairs to define to the build
    virtual
    void
    BuildPrograms ( Logger &         log,
		    const DefineList defs ) = 0;

    /// Output information about the interface
    virtual
    void
    Log()
	const = 0;

    /// Construct an interface.
    /// Get platform and device id's from opencl and setup the context to use.
    /// @param dt Parent divergence time object to get options.
    /// @return Pointer to the GPU interface
    /// @throw Except::GpuError If an error was returned from opencl.
    /// @throw Except::NoGpus If no actual GPU's were found.
    static
    GpuInterface *
    Factory(DivTime & dt);

    Logger & _logger;

};

// *****************************************************************************
/// GPU interface class for an individual replicate.
/// Owns the command queue for the devices

struct GpuReplicate {

    GpuReplicate( Replicate & repl )
	: _repl(repl)
	{}

    virtual
    ~GpuReplicate()
	{}

    /// Construct an interface.
    /// Setup the command queue
    /// @param repl Parent replicate
    /// @param gpuIntf Controlling GPU interface
    /// @return Pointer to the GPU replicate interface
    /// @throw Except::GpuError If an error was returned from opencl.
    static
    GpuReplicate *
    Factory( Replicate &    repl,
	     GpuInterface * gpuIntf );

    Replicate &    _repl;

};


#endif // _GPUINTERFACE_H_
