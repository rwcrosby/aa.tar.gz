/// @file TransitionMatrixGpu.h
/// Declaration of the gpu version of the transition matrix

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _TRANSITIONMATRIXGPU_H_
#define _TRANSITIONMATRIXGPU_H_

#include "GpuInterfaceImpl.h"
#include "TransitionMatrix.h"

// *****************************************************************************
/// Transition matrix for the gpu base algorithm.
/// The actual matrixes are on the gpu in a vector for the tree.
/// Two copies of each TM are allocated. One is current and the other the prior
/// value. Selection occurs through the use of the _which member.

struct TransitionMatrixGpu : TransitionMatrix {

    /// Constructor used by the model's MakeTransitionMatrix method.
    /// @param n Matrix size (nxn).
    /// @param nGCat Number of gamma categories (1 for non-gamma models).
    /// @param parent Owning evolutionary model instance.
    TransitionMatrixGpu( const unsigned n,
			 const unsigned nGCat,
			 EvoModel &     parent )
	: TransitionMatrix(n, nGCat, parent),
	  _which(false),
	  _idx1(0),
	  _idx2(0)
	{}

    virtual
    ~TransitionMatrixGpu()
	{}

    /// Return the index for the inactive matrix copy
    inline
    unsigned
    Index2Update()
	const
	{
	    return _which ? _idx2 : _idx1;
	}

    /// Return the index for the matrix copy to use for calculations
    inline
    unsigned
    Index2Use()
	const
	{
	    return _which ? _idx1 : _idx2;
	}


    /// Rollback the index
    virtual
    void
    Rollback()
	{
	    TransitionMatrix::Rollback();
	    SwapCopy();
	}

    /// Setup for commit or rollback
    virtual
    void
    Save();

    /// Just dump the local fields for the transition matrix
    virtual
    std::string
    str( const std::string hdg = "" )
	const;

    /// Output the dump string for the set of transition matricies
    /// found in memory.
    /// @param nGCat Number of gamma rate categories
    /// @param n Number of code values
    /// @param data Pointer to the data block from the gpu
    /// @param tmVecSize number of transition matrixes
    /// @param hdg Heading to prepend to the dump string
    static
    std::string
    str ( unsigned          nGCat,
	  unsigned          n,
	  cl_float *        data,
	  unsigned          tmVecSize,
	  const std::string hdg = "" );

    /// Swap the copy in use
    inline
    void
    SwapCopy()
	{
	    _which = !_which;
	}

    /// Update the matrix with a new distance value.
    /// @param newDist New value of time * rate.
    virtual
    void
    Update ( const FLOAT  newDist )
	{}

    bool           _which;			  ///< Which of the two copies is in use
    unsigned       _idx1;			  ///< Index for copy 1 of the tm
    unsigned       _idx2;			  ///< Index for copy 2 of the tm

};

// *****************************************************************************

inline
TransitionMatrixGpu *
GpuImpl(TransitionMatrix * tm)
{
    return static_cast<TransitionMatrixGpu*>(tm);
}

inline
TransitionMatrixGpu &
GpuImpl(TransitionMatrix &tm)
{
    return static_cast<TransitionMatrixGpu &>(tm);
}

#endif // _TRANSITIONMATRIXCPU_H_
