/// @file GpuInterface.cpp
/// Definitions for the GPU interface methods

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include <cassert>

#include "Config.h"
#include "Dump.h"
#include "DivTime.h"
#include "EvoModelGpu.h"
#include "Except.h"
#include "GpuInterfaceImpl.h"
#include "LikelihoodGpu.h"
#include "Logger.h"
#include "Replicates.h"

// *****************************************************************************

GpuInterface *
GpuInterface::Factory( DivTime & dt )
{
//    throw Except::NoGpus("Testing");

    return new GpuInterfaceImpl(*dt._logger);
}

// *****************************************************************************
/// Initialize the opencl interface.
/// @throw Except::GpuException Error in the GPU interface
/// @throw Except::NoGpus No GPU devices found.

GpuInterfaceImpl::GpuInterfaceImpl( Logger & logger)
    : GpuInterface(logger),
      _platforms(nullptr),
      _devices(nullptr),
      _nextDevice(0),
      _context(nullptr)
{
    _logger.DebugStd("Enter", 0, __FILE__, __LINE__, FUNCNAME);

    /// - Get the platform id's

    cl_int status = clGetPlatformIDs(0,
				     NULL,
				     &_nPlatforms);
    GpuInterfaceImpl::ErrorChk(status,  "Unable to query the number of platforms" );

    _platforms = new cl_platform_id[_nPlatforms];
    status = clGetPlatformIDs(_nPlatforms,
			      _platforms,
			      NULL);
    GpuInterfaceImpl::ErrorChk(status,  "Unable to enumerate the platforms" );

    /// - Select the first platform that supports the full profile, if none - error

    for ( _platform2Use = 0; _platform2Use < _nPlatforms; _platform2Use++ ) {

	size_t size;
	char buf[80];
	status = clGetPlatformInfo(_platforms[_platform2Use], CL_PLATFORM_PROFILE, sizeof(buf), buf, &size);
	if (status != CL_SUCCESS) {
	    std::stringstream ss;
	    ss << "Unable to get platform "
	       << _platforms[_platform2Use]
	       << " profile";
	    throw Except::GpuError( ss.str(), GpuInterfaceImpl::CLErrString(status) );
	}
	if ( size > sizeof(buf) ) {
	    std::stringstream ss;
	    ss << "Platform  "
	       << _platforms[_platform2Use]
	       << " profile too long for buffer";
	    throw Except::GpuError(ss.str());
	}

	if ( !strcmp("FULL_PROFILE", buf ) )
	     break;

    }

    if ( _platform2Use >= _nPlatforms )
	throw Except::NoGpus("No platforms supporting the full profile were found");

    /// @todo Verify the required version number -

    /// - Get device id's for all Gpu's.

    status = clGetDeviceIDs( _platforms[0],
			     CL_DEVICE_TYPE_GPU,
			     0,
			     NULL,
			     &_nDevices);
    if ( status != CL_SUCCESS) {
	std::stringstream ss;
	ss << "Unable to query the number of devices on platform["
	   << _platforms[0]
	   << "]";
	throw Except::GpuError(ss.str(), GpuInterfaceImpl::CLErrString(status) );
    }
    if ( _nDevices < 1 )
	throw Except::NoGpus( "No GPU devices found" );

    _devices = new cl_device_id[_nDevices];
    status = clGetDeviceIDs( _platforms[0],
			     CL_DEVICE_TYPE_GPU,
			     _nDevices,
			     _devices,
			     NULL);
    if ( status != CL_SUCCESS) {
	std::stringstream ss;
	ss << "Unable to enumerate the devices on platform["
	   << _platforms[0]
	   << "]";
	throw Except::GpuError(ss.str(), GpuInterfaceImpl::CLErrString(status) );
    }

    /// - We assume any and all devices are homogeneous in their characteristics.
    ///   Given that, get the max work group size for the first device.

    status = clGetDeviceInfo ( _devices[0],
			       CL_DEVICE_MAX_WORK_GROUP_SIZE,
			       sizeof(size_t),
			       &_maxWorkGroupSize,
			       0 );
    GpuInterfaceImpl::ErrorChk(status,  "Unable to get device info" );

    /// - Create the context.

    cl_context_properties contextProperties[] =
    {
        CL_CONTEXT_PLATFORM, (cl_context_properties)_platforms[_platform2Use],
        0
    };

    _context = clCreateContext( contextProperties,
				_nDevices,
				_devices,
				NULL,
				NULL,
				&status);
    GpuInterfaceImpl::ErrorChk(status,  "Unable to create context" );

    _logger.DebugStd("Exit", 0, __FILE__, __LINE__, FUNCNAME);
}

// *****************************************************************************
/// Close down the opencl interface

GpuInterfaceImpl::~GpuInterfaceImpl()
{
    clReleaseContext(_context);
    delete[] _platforms;
    delete[] _devices;
}

// *****************************************************************************

cl_program
GpuInterfaceImpl::BuildProgram ( const std::string & pgm,
				 const DefineList    defList )
{
    _logger.DebugStd("Enter", 0, __FILE__, __LINE__, FUNCNAME);

    /// Create the program object

    cl_int status;
    const char * pgmPtr = pgm.c_str();
    cl_program program = clCreateProgramWithSource ( _context,
						     1,
						     &pgmPtr,
						     0,
						     &status );
    GpuInterfaceImpl::ErrorChk(status,  "Unable to create program from source" );

    /// Setup the compile options
    std::stringstream ss;
    // ss << "-Werror -cl-std=CL1.1 ";
    ss << "-cl-std=CL1.1 ";
    ss << "-I" << gpudir << ' ';
    for ( auto & p : defList )
	ss << "-D" << p.first << '=' << p.second << ' ';

    _logger.Debug("Build options: %s", ss.str().c_str());

    /// Build the program

    status = clBuildProgram ( program,
			      _nDevices,
			      _devices,
			      ss.str().c_str(),
			      0,
			      0);

    /// Handle build failures

    if ( status == CL_BUILD_PROGRAM_FAILURE ) {

        // Get the build log and output
	size_t logSize;
        status = clGetProgramBuildInfo( program,
				        _devices[0],
				        CL_PROGRAM_BUILD_LOG,
				        0,
				        0,
				        &logSize );
	GpuInterfaceImpl::ErrorChk(status,  "Unable to get build log size" );

        auto programLog = new char[logSize + 1];
        status = clGetProgramBuildInfo ( program,
					 _devices[0],
					 CL_PROGRAM_BUILD_LOG,
					 logSize + 1,
					 programLog,
					 0);
	GpuInterfaceImpl::ErrorChk(status,  "Unable to get build log" );

	_logger("OpenCL Build Failure:");
	_logger(programLog);

	delete[] programLog;

	throw Except::GpuError("Build failure",
			       GpuInterfaceImpl::CLErrString(CL_BUILD_PROGRAM_FAILURE));

    }
    else
	GpuInterfaceImpl::ErrorChk(status,  "Other build failure" );

    _logger.DebugStd("Exit", 0, __FILE__, __LINE__, FUNCNAME);
    return program;
}

// *****************************************************************************

void
GpuInterfaceImpl::BuildPrograms ( Logger &         log,
				  const DefineList defs )
{

    log("");
    const char * emSrc;
    const char * lkhSrc;

    if ( getenv("FDIVT_KSRC") ) {
	emSrc = R"PGM(
              #include "EvoModelKernels.cl"
              )PGM";
	lkhSrc = R"PGM(
              #include "LikelihoodKernels.cl"
              )PGM";
	log("Included source for GPU Programs at runtime");
    }
    else {
	emSrc =
              #include "EvoModelKernels.h"
              ;
	lkhSrc =
              #include "LikelihoodKernels.h"
              ;
	log.Debug("GpuInterfaceImpl::BuildPrograms: Imbedded Source");
    }

    _emProgram = BuildProgram( emSrc, defs );
    log("Built Evolutionary Model GPU Programs");

    _lkhProgram = BuildProgram( lkhSrc, defs );
    log("Built Likelihood GPU Programs");

}

// *****************************************************************************
/// Generate a textual error for a opencl error code.

const char *
GpuInterfaceImpl::CLErrString(cl_int err){
    switch(err){
	case 0:   return "CL_SUCCESS";
	case -1:  return "CL_DEVICE_NOT_FOUND";
	case -2:  return "CL_DEVICE_NOT_AVAILABLE";
	case -3:  return "CL_COMPILER_NOT_AVAILABLE";
	case -4:  return "CL_MEM_OBJECT_ALLOCATION_FAILURE";
	case -5:  return "CL_OUT_OF_RESOURCES";
	case -6:  return "CL_OUT_OF_HOST_MEMORY";
	case -7:  return "CL_PROFILING_INFO_NOT_AVAILABLE";
	case -8:  return "CL_MEM_COPY_OVERLAP";
	case -9:  return "CL_IMAGE_FORMAT_MISMATCH";
	case -10: return "CL_IMAGE_FORMAT_NOT_SUPPORTED";
	case -11: return "CL_BUILD_PROGRAM_FAILURE";
	case -12: return "CL_MAP_FAILURE";

	case -30: return "CL_INVALID_VALUE";
	case -31: return "CL_INVALID_DEVICE_TYPE";
	case -32: return "CL_INVALID_PLATFORM";
	case -33: return "CL_INVALID_DEVICE";
	case -34: return "CL_INVALID_CONTEXT";
	case -35: return "CL_INVALID_QUEUE_PROPERTIES";
	case -36: return "CL_INVALID_COMMAND_QUEUE";
	case -37: return "CL_INVALID_HOST_PTR";
	case -38: return "CL_INVALID_MEM_OBJECT";
	case -39: return "CL_INVALID_IMAGE_FORMAT_DESCRIPTOR";
	case -40: return "CL_INVALID_IMAGE_SIZE";
	case -41: return "CL_INVALID_SAMPLER";
	case -42: return "CL_INVALID_BINARY";
	case -43: return "CL_INVALID_BUILD_OPTIONS";
	case -44: return "CL_INVALID_PROGRAM";
	case -45: return "CL_INVALID_PROGRAM_EXECUTABLE";
	case -46: return "CL_INVALID_KERNEL_NAME";
	case -47: return "CL_INVALID_KERNEL_DEFINITION";
	case -48: return "CL_INVALID_KERNEL";
	case -49: return "CL_INVALID_ARG_INDEX";
	case -50: return "CL_INVALID_ARG_VALUE";
	case -51: return "CL_INVALID_ARG_SIZE";
	case -52: return "CL_INVALID_KERNEL_ARGS";
	case -53: return "CL_INVALID_WORK_DIMENSION";
	case -54: return "CL_INVALID_WORK_GROUP_SIZE";
	case -55: return "CL_INVALID_WORK_ITEM_SIZE";
	case -56: return "CL_INVALID_GLOBAL_OFFSET";
	case -57: return "CL_INVALID_EVENT_WAIT_LIST";
	case -58: return "CL_INVALID_EVENT";
	case -59: return "CL_INVALID_OPERATION";
	case -60: return "CL_INVALID_GL_OBJECT";
	case -61: return "CL_INVALID_BUFFER_SIZE";
	case -62: return "CL_INVALID_MIP_LEVEL";
	case -63: return "CL_INVALID_GLOBAL_WORK_SIZE";
	default: return "Unknown OpenCL error";
    }
}

// *****************************************************************************

cl_mem
GpuInterfaceImpl::CreateBuffer ( cl_mem_flags flags,
				 size_t       alloc )
{
    cl_int status;
    cl_mem buf = clCreateBuffer ( _context,
				  flags,
				  alloc,
				  nullptr,
				  &status );
    GpuInterfaceImpl::ErrorChk(status,  "Unable to allocate buffer" );
    return buf;
}

// *****************************************************************************

cl_mem
GpuInterfaceImpl::CreateSubBuffer ( cl_mem       buf,
				    unsigned     offset,
				    size_t       alloc,
				    cl_mem_flags flags )
{
    cl_buffer_region bufInfo;
    bufInfo.origin = offset;
    bufInfo.size   = alloc;
    cl_int status;
    cl_mem subBuf = clCreateSubBuffer ( buf,
					flags,
					CL_BUFFER_CREATE_TYPE_REGION,
					&bufInfo,
					&status );
    GpuInterfaceImpl::ErrorChk(status,  "Failure to create sub-buffer" );
    return subBuf;
}

// *****************************************************************************

cl_kernel
GpuInterfaceImpl::GetKernel ( cl_program   pgm,
			      const char * name )
{
    cl_int status;
    cl_kernel kernel = clCreateKernel ( pgm,
					name,
					&status );
    GpuInterfaceImpl::ErrorChk(status,  std::string("Unable to create GPUkernel:") + name);
    return kernel;
}

// *****************************************************************************

void
GpuInterfaceImpl::Log()
    const
{

    _logger("");
    _logger("GPU Devices:");

    for ( unsigned i = 0; i < _nDevices; i++ ) {
	char   buf[80];
	size_t size;
	cl_int status = clGetDeviceInfo(_devices[i], CL_DEVICE_NAME, sizeof(buf), buf, &size);
	if (status != CL_SUCCESS)
	    continue;

	_logger("Device %d: %s", i + 1, buf);

    }

}

// *****************************************************************************

GpuReplicate *
GpuReplicate::Factory( Replicate &    repl,
		       GpuInterface * gpuIntf )
{
    return new GpuReplicateImpl( repl, static_cast<GpuInterfaceImpl&>(*gpuIntf) );
}

// *****************************************************************************

GpuReplicateImpl::GpuReplicateImpl( Replicate &        repl,
				    GpuInterfaceImpl & gpuIntf )
    : GpuReplicate(repl),
      _gpuIntf(gpuIntf),
      _cQueue(nullptr)
{
    REPRENTER(Dump::ptr(this));

    /// - Create the command queue

    cl_int status;
    _cQueue = clCreateCommandQueue ( _gpuIntf._context,
				     _gpuIntf.GetNextDevice(),
#ifdef __APPLE__
				     0,
#else
				     CL_QUEUE_OUT_OF_ORDER_EXEC_MODE_ENABLE,
#endif
				     &status );
    if (status != CL_SUCCESS)
	throw Except::GpuError("Unable to obtain command queue",
			       GpuInterfaceImpl::CLErrString(status));

    /// - Create the kernels

    _lkhLeafLeaf   = GpuInterfaceImpl::GetKernel(gpuIntf._lkhProgram, "LeafLeaf");
    _lkhLeafInner  = GpuInterfaceImpl::GetKernel(gpuIntf._lkhProgram, "LeafInner");
    _lkhInnerLeaf  = GpuInterfaceImpl::GetKernel(gpuIntf._lkhProgram, "InnerLeaf");
    _lkhInnerInner = GpuInterfaceImpl::GetKernel(gpuIntf._lkhProgram, "InnerInner");
    _lnLKernel     = GpuInterfaceImpl::GetKernel(gpuIntf._lkhProgram, "LnL");
    _reduceKernel  = GpuInterfaceImpl::GetKernel(gpuIntf._lkhProgram, "Reduce");

    REPREXIT(Dump::str(_cQueue, "cQueue"))

}

// *****************************************************************************

void *
GpuReplicateImpl::MapBuffer ( cl_mem buf,
			      size_t alloc,
			      size_t offset )
{
    cl_int status;
    void * mem = clEnqueueMapBuffer ( _cQueue,
				      buf,
				      CL_TRUE,
				      CL_MAP_WRITE,
				      offset,
				      alloc,
				      0,
				      nullptr,
				      nullptr,
				      &status );
    GpuInterfaceImpl::ErrorChk(status,  "Unable to map buffer" );
    return mem;
}

// *****************************************************************************

void
GpuReplicateImpl::ReadWait ( cl_mem buf,
			     void * mem,
			     size_t len )
{
    cl_int status = clEnqueueReadBuffer ( _cQueue,
					  buf,
					  CL_TRUE,
					  0,
					  len,
					  mem,
					  0,
					  NULL,
					  NULL );

    GpuInterfaceImpl::ErrorChk(status,  "Unable to read data" );
}

// *****************************************************************************

cl_event
GpuReplicateImpl::UnmapBuffer ( cl_mem buf,
				void * mem )
{
    cl_event event;
    cl_int status = clEnqueueUnmapMemObject ( _cQueue,
					      buf,
					      mem,
					      0,
					      nullptr,
					      &event );
    GpuInterfaceImpl::ErrorChk(status,  "Unable to unmap buffer" );
    return event;
}

// *****************************************************************************

std::string
Dump::str( cl_command_queue q,
	   std::string      hdg )
{
    std::stringstream ss;
    if ( hdg.size() ) ss << hdg << "<";

    cl_context                  ctx;
    cl_device_id                dev;
    cl_uint                     refc;
    cl_command_queue_properties prop;

    assert( clGetCommandQueueInfo(q, CL_QUEUE_CONTEXT, sizeof(ctx), &ctx, 0) == CL_SUCCESS );
    assert( clGetCommandQueueInfo(q, CL_QUEUE_DEVICE, sizeof(dev), &dev, 0) == CL_SUCCESS );
    assert( clGetCommandQueueInfo(q, CL_QUEUE_REFERENCE_COUNT, sizeof(refc), &refc, 0) == CL_SUCCESS );
    assert( clGetCommandQueueInfo(q, CL_QUEUE_PROPERTIES, sizeof(prop), &prop, 0) == CL_SUCCESS );

    ss << Dump::ptr(q) << ' '
       << Dump::ptr(ctx, "Context") << ' '
       << Dump::ptr(dev, "Device") << ' '
       << Dump::str(refc,"RefCount") << ' '
       << Dump::str((unsigned)prop,"Properties");

    if ( hdg.size() ) ss << ">";
    return ss.str();
}
// *****************************************************************************

std::string
Dump::str( cl_event    e,
	   std::string hdg )
{
    std::stringstream ss;
    if ( hdg.size() ) ss << hdg << "<";

    cl_command_queue cq;
    cl_context       ctx;
    cl_command_type  ctyp;
    cl_int           cstat;
    cl_uint          crefc;

    assert( clGetEventInfo(e,  CL_EVENT_COMMAND_QUEUE, sizeof(cl_command_queue), &cq, 0) == CL_SUCCESS );
    assert( clGetEventInfo(e,  CL_EVENT_CONTEXT, sizeof(cl_context), &ctx, 0) == CL_SUCCESS );
    assert( clGetEventInfo(e,  CL_EVENT_COMMAND_TYPE, sizeof(cl_command_type), &ctyp, 0) == CL_SUCCESS );
    assert( clGetEventInfo(e,  CL_EVENT_COMMAND_EXECUTION_STATUS, sizeof(cl_int), &cstat, 0) == CL_SUCCESS );
    assert( clGetEventInfo(e,  CL_EVENT_REFERENCE_COUNT, sizeof(cl_int), &crefc, 0) == CL_SUCCESS );

    ss << Dump::ptr(e) << ' '
       << Dump::ptr(cq, "Queue") << ' '
       << Dump::ptr(ctx, "Context") << ' '
       << Dump::str(ctyp, "Type") << ' '
       << Dump::str(cstat, "Status") << ' '
       << Dump::str(crefc,"RefCount");

    if ( hdg.size() ) ss << ">";
    return ss.str();
}

// *****************************************************************************

std::string
Dump::str( cl_kernel   k,
	   std::string hdg )
{
    std::stringstream ss;
    if ( hdg.size() ) ss << hdg << "<";

    cl_program       pgm;
    cl_context       ctx;
    char             fName[1024];
    cl_uint          nargs;
    cl_uint          refc;

    assert( clGetKernelInfo(k, CL_KERNEL_FUNCTION_NAME, sizeof(fName), fName, 0) == CL_SUCCESS );
    assert( clGetKernelInfo(k, CL_KERNEL_NUM_ARGS, sizeof(nargs), &nargs, 0) == CL_SUCCESS );
    assert( clGetKernelInfo(k, CL_KERNEL_REFERENCE_COUNT, sizeof(refc), &refc, 0) == CL_SUCCESS );
    assert( clGetKernelInfo(k, CL_KERNEL_CONTEXT, sizeof(ctx), &ctx, 0) == CL_SUCCESS );
    assert( clGetKernelInfo(k, CL_KERNEL_PROGRAM, sizeof(pgm), &pgm, 0) == CL_SUCCESS );

    ss << Dump::ptr(k) << ' '
       << Dump::str(std::string(fName), "FunctionName") << ' '
       << Dump::ptr(ctx, "Context") << ' '
       << Dump::ptr(pgm, "Program") << ' '
       << Dump::str(nargs, "NArgs") << ' '
       << Dump::str(refc,"RefCount");

    if ( hdg.size() ) ss << ">";
    return ss.str();
}

// *****************************************************************************

std::string
Dump::str( cl_mem           m,
	   std::string      hdg )
{
    std::stringstream ss;
    if ( hdg.size() ) ss << hdg << "<";

    cl_mem_object_type oType;
    cl_mem_flags       flags;
    cl_context         ctx;
    cl_mem             mem;
    size_t             offset;
    size_t             size;


    assert( clGetMemObjectInfo (m, CL_MEM_TYPE, sizeof(oType), &oType, 0) == CL_SUCCESS );
    assert( clGetMemObjectInfo (m, CL_MEM_FLAGS, sizeof(flags), &flags, 0) == CL_SUCCESS );
    assert( clGetMemObjectInfo (m, CL_MEM_CONTEXT, sizeof(ctx), &ctx, 0) == CL_SUCCESS );
    assert( clGetMemObjectInfo (m, CL_MEM_ASSOCIATED_MEMOBJECT, sizeof(mem), &mem, 0) == CL_SUCCESS );
    assert( clGetMemObjectInfo (m, CL_MEM_OFFSET, sizeof(offset), &offset, 0) == CL_SUCCESS );
    assert( clGetMemObjectInfo (m, CL_MEM_SIZE, sizeof(size), &size, 0) == CL_SUCCESS );

    std::stringstream oinfo;

    oinfo << Dump::ptr(mem) << '/' << offset << '/' << size;

    ss << Dump::ptr(m) << ' '
       << Dump::str(oinfo.str(), "AssocObj") << ' '
       << Dump::str((unsigned)flags,"Flags") << ' '
       << Dump::ptr(ctx, "Context");

    if ( hdg.size() ) ss << ">";
    return ss.str();
}
