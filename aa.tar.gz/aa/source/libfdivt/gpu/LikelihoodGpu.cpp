/// @file LikelihoodGpu.cpp
/// Definitions for the gpu based likelihood algorithm

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include "DivTime.h"
#include "Dump.h"
#include "EvoModelGpuImpl.h"
#include "GpuInterfaceImpl.h"
#include "LikelihoodGpu.h"
#include "LikelihoodGpuImpl.h"
#include "Locus.h"
#include "Replicates.h"
#include "SequenceFactory.h"
#include "TransitionMatrixGpu.h"
#include "Tree.h"

// *****************************************************************************
/// Traveral subclass to compute the likelihood at a locus

struct LkhGpuLocusDfs : Tree::LocusDfs {

    LkhGpuLocusDfs  ( LkhGpuRoot &  lkhRoot )
	: _repl(lkhRoot._repl),
	  _lkhRoot(lkhRoot)
	{}

    virtual RC InnerEnd ( Tree::LocusNode & lNode );
    virtual RC RootEnd  ( Tree::LocusNode & lNode );

    Replicate &       _repl;
    LkhGpuRoot &      _lkhRoot;

};

// *****************************************************************************

inline
LkhGpuLocusNode *
LocusNodeLkh (const Tree::LocusNode & lNode)
{
    return static_cast<LkhGpuLocusNode *>(lNode._lkh);
}

inline
LkhGpuLocusRoot *
LocusRootLkh ( const Tree::LocusNode & lNode)
{
    return static_cast<LkhGpuLocusRoot *>(lNode._lRoot._lkh);
}

inline
LkhGpuLocusRoot *
LocusRootLkh ( const Tree::LocusRoot & lRoot)
{
    return static_cast<LkhGpuLocusRoot *>(lRoot._lkh);
}

inline
unsigned
RoundUp ( const unsigned n,
	  const unsigned upTo )
{
    return ( (n - 1) / upTo + 1 ) * upTo;
}

// *****************************************************************************
/// Generate the kernel name depending on whether the left or right children
/// are present.

static
cl_kernel
LkhLocusNodeKernel(const LkhGpuLocusNode & lkh)
{
    if ( lkh._lhLkh->_lNode.IsLeaf() &&  lkh._rhLkh->_lNode.IsLeaf())
	return lkh._lkhRoot._gpuRepl._lkhLeafLeaf;

    if ( lkh._lhLkh->_lNode.IsLeaf() )
	return lkh._lkhRoot._gpuRepl._lkhLeafInner;

    if ( lkh._rhLkh->_lNode.IsLeaf() )
	return lkh._lkhRoot._gpuRepl._lkhInnerLeaf;

    return lkh._lkhRoot._gpuRepl._lkhInnerInner;
}

// *****************************************************************************

Likelihood *
LikelihoodGpu::Factory ( Replicate &  repl,
			 Tree::Root & root )
{
    return new LkhGpuRoot (repl, root);
}

// *****************************************************************************

Likelihood *
LikelihoodGpu::Factory ( Replicate &       repl,
			 Tree::LocusRoot & lRoot )
{
    return new LkhGpuLocusRoot (repl, lRoot);
}

// *****************************************************************************
/// Updates value at gene and species tree roots

Likelihood *
LikelihoodGpu::Factory ( Replicate &          repl,
			 const Tree::Position tPos )
{
    return new LkhGpuTreeNode (repl, tPos);
}

// *****************************************************************************

Likelihood *
LikelihoodGpu::Factory ( Replicate &       repl,
			 Tree::LocusNode & lNode )
{
    return new LkhGpuLocusNode (repl, lNode);
}

// *****************************************************************************
/// Start up the kernel for this node with dependencies on it's children's kernels.

Tree::LocusDfs::RC
LkhGpuLocusDfs::InnerEnd( Tree::LocusNode & lNode )
{
    auto * lkh = LocusNodeLkh(lNode);

    /// - Setup the event list either the children of this node if they are inner nodes
    ///   or the transition matrix updates.

    EVENTLIST events;

    for ( auto lnp : lNode._children )
	if ( !lnp->IsLeaf() )
	    events.push_back( LocusNodeLkh(*lnp)->_event );

    if ( events.size() < 2 )
	events.push_back(_lkhRoot._eModel._event);

    lkh->UpdateBaseVec(events);

    return CONTINUE;
}

// *****************************************************************************
/// Process as a regular inner node but then do the reduction.

Tree::LocusDfs::RC
LkhGpuLocusDfs::RootEnd( Tree::LocusNode & lNode )
{
    REPRENTER(Dump::ptr(this));

    /// - Do normal node processing for the root.

    InnerEnd(lNode);

    /// - Compute the -log likekihood at the site

    auto lkhLRoot = LocusRootLkh(lNode);
    lkhLRoot->_event = lkhLRoot->UpdateValue( { LocusNodeLkh(lNode)->_event } );

    REPREXIT(Dump::ptr(this));
    return CONTINUE;
}

// *****************************************************************************
/// Create and setup a locus node instance.

LkhGpuLocusNode::LkhGpuLocusNode( Replicate &       repl,
				  Tree::LocusNode & lNode )
    : Likelihood(repl),
      _lNode(lNode),
      _lkhRoot(*static_cast<LkhGpuRoot*>(_lNode._lRoot._root._lkh)),
      _lkhLRoot(*static_cast<LkhGpuLocusRoot*>(_lNode._lRoot._lkh)),
      _kernel(nullptr),
      _which(false),
      _idx1(_lkhRoot.UpdateVecSize(lNode._siteVec ? _lNode._siteVec->size() : 0)),
      _idx2(0)
{

    if ( _lNode.IsRoot() )
	_lkhRoot._lRootVecSize += _lNode._siteVec->size();

    if ( _lNode.IsLeaf() ) {
	_lhTMatrix = nullptr;
	_rhTMatrix = nullptr;
	_lhLkh     = nullptr;
	_rhLkh     = nullptr;
    }
    else {
	_lhTMatrix = static_cast<TransitionMatrixGpu*>(_lNode._children[0]->_tMatrix);
	_rhTMatrix = static_cast<TransitionMatrixGpu*>(_lNode._children[1]->_tMatrix);
	_lhLkh     = LocusNodeLkh(*_lNode._children[0]);
	_rhLkh     = LocusNodeLkh(*_lNode._children[1]);
    }

}

// *****************************************************************************

FLOAT
LkhGpuLocusNode::Compute ()
{

    REPRENTER ( Dump::ptr(this) );

    /// - Update the current transition matrix.

    auto & emr = _lkhRoot._eModel;
    emr.InitForUpdates();

    _lNode.UpdateTMatrix();

    EVENTLIST events = { emr.DoUpdates() };

    /// - Update base vectors to the root

    for ( auto lp = _lNode._parent; lp; lp = lp->_parent )
	events = { LocusNodeLkh(*lp)->UpdateBaseVec(events) };

    /// - Compute the overall log likelihood for the gene tree

    events = { _lkhLRoot.UpdateValue(events) };

    /// - Wait on the likelihood to complete

    GpuInterfaceImpl::WaitForEvents(events);

    /// - Copy the log likelihood to the locus value

    _lkhLRoot._value = _lkhLRoot._lnL;

    auto ratio = _lkhLRoot._value - _lkhLRoot._oldValue;
    REPREXIT ( Dump::ptr(this),
	       Dump::str(_lkhLRoot._value, "lRootLnL"),
	       Dump::str(_lkhLRoot._oldValue, "oldLRootLnL"),
	       Dump::str(ratio, "ratio") );
    return ratio;
}

// *****************************************************************************
/// Complete initialization of the locus node.

void
LkhGpuLocusNode::ReplRootEnd ( SitePosEntry * sVec )
{
    REPRENTER ( Dump::ptr(this) );

    _idx2 = _idx1 + _lkhRoot._vecSize;

    _kernel  = LkhLocusNodeKernel(*this);

    auto sv = sVec + _idx1;

    for ( auto & site : *_lNode._siteVec ) {
	sv->lhsIdx = site._lhs;
	sv->rhsIdx = site._rhs;
	sv++;
    }

    REPREXIT ( Dump::ptr(this) );
}

// *****************************************************************************

std::string
LkhGpuLocusNode::str ( const std::string hdg )
    const
{
    std::stringstream ss;
    if ( hdg.size() ) ss << hdg << "<";

    ss << Likelihood::str() << ' '
       << Dump::ptr(_kernel ,"kernel") << ' '
       << Dump::str(_which, "which") << ' '
       << Dump::str(_idx1, "idx1") << ' '
       << Dump::str(_idx2, "idx2");

    if ( hdg.size() ) ss << '>';
    return ss.str();
}

// *****************************************************************************

cl_event
LkhGpuLocusNode::UpdateBaseVec ( EVENTLIST & events )
{
    /// - Setup the kernel arguments

    REPRENTER(Dump::ptr(this),
	      Dump::ptr(_kernel, "kernel"),
	      Dump::str(_idx1, "idx1"),
	      Dump::str(_idx2, "idx2"),
	      Dump::str(_lkhRoot._bvBuf, "baseVec"),
	      Dump::str(_lkhRoot._eModel._tmVecBuf, "tmVecBuf"),
	      Dump::str(Index2Update(), "bvIdx2Upd"),
	      Dump::str(_lhTMatrix->Index2Use(), "lhTMIdx"),
	      Dump::str(_rhTMatrix->Index2Use(), "rhTMIdx") );

    unsigned argNo = 0;
    GpuInterfaceImpl::SetKernelArg ( _kernel, argNo++, _lkhRoot._siteBuf);
    GpuInterfaceImpl::SetKernelArg ( _kernel, argNo++, _lkhRoot._bvBuf);
    GpuInterfaceImpl::SetKernelArg ( _kernel, argNo++, _lkhRoot._eModel._tmVecBuf);
    GpuInterfaceImpl::SetKernelArg ( _kernel, argNo++, _idx1);
    GpuInterfaceImpl::SetKernelArg ( _kernel, argNo++, Index2Update());
    GpuInterfaceImpl::SetKernelArg ( _kernel, argNo++, _lhTMatrix->Index2Use());
    GpuInterfaceImpl::SetKernelArg ( _kernel, argNo++, _rhTMatrix->Index2Use());

    if ( !_lhLkh->_lNode.IsLeaf() )
	GpuInterfaceImpl::SetKernelArg ( _kernel, argNo++, _lhLkh->Index2Use());
    if ( !_rhLkh->_lNode.IsLeaf() )
	GpuInterfaceImpl::SetKernelArg ( _kernel, argNo++, _rhLkh->Index2Use());

    _event =  _lkhRoot._gpuRepl.QueueKernel( _kernel, _lNode._siteVec->size(), events );

    /// - Flip the which indicator on this node so the copy we just updated will be
    ///   used as we traverse up the tree.

    SwapCopy();

    _repl.LogRollback(this);

    REPREXIT( Dump::ptr(this),
	      Dump::ptr(_event,"myEvent"),
	      Dump::str(argNo, "argNo") );

    return _event;

}

// *****************************************************************************

LkhGpuLocusRoot::LkhGpuLocusRoot(Replicate &       repl,
				 Tree::LocusRoot & lRoot )
    : Likelihood(repl),
      _lRoot(lRoot),
      _eMLRoot(*static_cast<EMGpuImpl*>(_lRoot._eModel)),
      _lkhRoot(*static_cast<LkhGpuRoot*>(_lRoot._root._lkh)),
      _rBuf1(nullptr),
      _rBuf1Alloc(0),
      _rBuf1Size(0),
      _rBuf2(nullptr),
      _rBuf2Alloc(0),
      _rBuf2Size(0)
{
}

// *****************************************************************************
/// Compute the likelihood across a gene tree.
/// Used after update of the per gene tree nuisance parameters.

FLOAT
LkhGpuLocusRoot::Compute()
{
    REPRENTER(Dump::ptr(this));

    /// - Compute all the transition matricies

    _eMLRoot.UpdateAllTMatrixes();

    /// - Compute the likelihood by traversing each gene tree starting kernels
    ///   for each inner node and the final kernel for the overall likelihood.

    LkhGpuLocusDfs dfs(_lkhRoot);
    dfs (_lRoot);

    /// - Wait on the likelihood to complete

    GpuInterfaceImpl::WaitForEvents({_event});

    /// - Copy the log likelihood to the locus value

    _value = _lnL;

    auto ratio = _value - _oldValue;
    REPREXIT(Dump::ptr(this),
	     Dump::str(_value, "value"),
	     Dump::str(_oldValue, "oldValue"),
	     Dump::str(ratio, "ratio"));
    return ratio;
}

// *****************************************************************************
/// Complete initialization of the locus node.

void
LkhGpuLocusRoot::ReplRootEnd ( float *    cVec,
			       unsigned & cIdx,
			       float *    fVec,
			       unsigned & fIdx )
{
    REPRENTER ( Dump::ptr(this),
		Dump::str(cIdx, "cIdx"),
		Dump::str(fIdx, "fIdx") );
    auto & gpuIntf = _lkhRoot._gpuIntf;
    auto & gpuRepl = _lkhRoot._gpuRepl;

    /// - Populate the buffer for the site counts.

    _countSize = _lRoot._trueRoot->_siteVec->size();
    _countIdx  = cIdx;

    for ( auto & site : *_lRoot._trueRoot->_siteVec )
	cVec[cIdx++] = site._count;

    /// - Populate the buffer for the character frequencies.

    _cFreqIdx          = fIdx;

    for ( auto v : _lRoot._eModel->CharFreq() )
	fVec[fIdx++] = v;

    /// - Allocate the reduction buffers and initialize to zero.  The first buffer is
    ///   sized to the number of sites (rounded up to a multiple of 2) and the second to
    ///   the number of workgroups required. Both are rounded up to the next multiple
    //    of the max work group size.

    if ( _countSize < gpuIntf._maxWorkGroupSize ) {
	_rBuf1Size = pow(2,ceil(log2(_countSize)));
	_rBuf2Size = 1;
    }
    else  {
	_rBuf1Size  = RoundUp(_countSize, gpuIntf._maxWorkGroupSize);

	if ( gpuIntf.NumWorkGroups(_rBuf1Size/2) < gpuIntf._maxWorkGroupSize )
	    _rBuf2Size = gpuIntf.NumWorkGroups(_rBuf1Size / 2);
	else
	    _rBuf2Size = RoundUp(gpuIntf.NumWorkGroups(_countSize),
				 gpuIntf._maxWorkGroupSize );
    }

    _rBuf1Alloc = _rBuf1Size * sizeof(cl_float);
    _rBuf1      = gpuIntf.CreateBuffer( CL_MEM_READ_WRITE, _rBuf1Alloc );

    auto buf1 = (cl_float*)gpuRepl.MapBuffer( _rBuf1, _rBuf1Alloc );
    for ( unsigned i = 0; i < _rBuf1Size; i++ )
	buf1[i] = 0.0;

    _rBuf2Alloc = _rBuf2Size * sizeof(cl_float);
    _rBuf2      = gpuIntf.CreateBuffer( CL_MEM_READ_WRITE, _rBuf2Alloc );

    auto buf2  = (cl_float*)gpuRepl.MapBuffer( _rBuf2, _rBuf2Alloc );
    for ( unsigned i = 0; i < _rBuf2Size; i++ )
	buf2[i] = 0.0;

    /// - Wait for the reduction buffers to upload.

    GpuInterfaceImpl::WaitForEvents( { gpuRepl.UnmapBuffer ( _rBuf1, buf1 ),
		                       gpuRepl.UnmapBuffer ( _rBuf2, buf2 ) } );

    REPREXIT ( Dump::ptr(this),
	       Dump::str(_countSize,"countSize"),
	       Dump::str(_rBuf1Size,"rBuf1Size"),
	       Dump::str(_rBuf1Alloc,"rBuf1Alloc"),
	       Dump::str(_rBuf2Size,"rBuf2Size"),
	       Dump::str(_rBuf2Alloc,"rBuf2Alloc"));
}

// *****************************************************************************

std::string
LkhGpuLocusRoot::str ( const std::string hdg )
    const
{
    std::stringstream ss;
    if ( hdg.size() ) ss << hdg << "<";

    ss << Likelihood::str() << ' '
       << Dump::ptr(_rBuf1 ,"rBuf1") << ' '
       << Dump::str(_rBuf1Alloc, "rBuf1Alloc") << ' '
       << Dump::str(_rBuf1Size, "rBuf1Size") << ' '
       << Dump::ptr(_rBuf2 ,"rBuf2") << ' '
       << Dump::str(_rBuf2Alloc, "rBuf2Alloc") << ' '
       << Dump::str(_rBuf2Size, "rBuf2Size") << '\n';

    std::vector<cl_float> rVec1;
    rVec1.resize(_rBuf1Size);
    _lkhRoot._gpuRepl.ReadWait(_rBuf1, rVec1.data(), _rBuf1Alloc);

    ss << Dump::indent(Dump::str(rVec1, "rBuf1")) << '\n';

    std::vector<cl_float> rVec2;
    rVec2.resize(_rBuf2Size);
    _lkhRoot._gpuRepl.ReadWait(_rBuf2, rVec2.data(), _rBuf2Alloc);

    ss << Dump::indent(Dump::str(rVec2, "rBuf2"));

    if ( hdg.size() ) ss << '>';
    return ss.str();
}

// *****************************************************************************

cl_event
LkhGpuLocusRoot::UpdateValue( const EVENTLIST & events )
{
    /// - Compute the -log likekihood at the site

    auto & lkhLNode = *LocusNodeLkh(*_lRoot._trueRoot);
    auto & gpuIntf  = _lkhRoot._gpuIntf;
    auto & gpuRepl  = _lkhRoot._gpuRepl;

    REPRENTER(Dump::ptr(this),
	      Dump::str((unsigned)lkhLNode._lNode._siteVec->size(),"siteVec.size"),
	      Dump::pstr(&lkhLNode,"lkhLNode"),
	      Dump::str(_countSize,"countSize")
	);

    GpuInterfaceImpl::SetKernelArg ( gpuRepl._lnLKernel, 0, _rBuf1 );
    GpuInterfaceImpl::SetKernelArg ( gpuRepl._lnLKernel, 1, _lkhRoot._countBuf );
    GpuInterfaceImpl::SetKernelArg ( gpuRepl._lnLKernel, 2, _countIdx );
    GpuInterfaceImpl::SetKernelArg ( gpuRepl._lnLKernel, 3, _lkhRoot._cFreqBuf );
    GpuInterfaceImpl::SetKernelArg ( gpuRepl._lnLKernel, 4, _cFreqIdx );
    GpuInterfaceImpl::SetKernelArg ( gpuRepl._lnLKernel, 5, _lkhRoot._bvBuf );
    GpuInterfaceImpl::SetKernelArg ( gpuRepl._lnLKernel, 6, lkhLNode.Index2Use() );

    cl_event event = gpuRepl.QueueKernel ( gpuRepl._lnLKernel,
					   _countSize,
					   events );

    /// - Perform multi-stage reduction for all genes

    cl_mem b1 = _rBuf1;
    cl_mem b2 = _rBuf2;

    unsigned nWorkItems = _rBuf1Size >> 1;

    for ( unsigned nWorkGroups = gpuIntf.NumWorkGroups(nWorkItems);
	  nWorkItems > 1;
	  nWorkGroups = gpuIntf.NumWorkGroups(nWorkItems) ) {

	REPRDEBUG(Dump::str(nWorkItems,"nWorkItems"),
		  Dump::str(nWorkGroups,"nWorkGroups"),
		  Dump::str((unsigned)gpuIntf._maxWorkGroupSize,"maxWorkGroupSize")
	    );

	GpuInterfaceImpl::SetKernelArg ( gpuRepl._reduceKernel, 0, b1 );
	GpuInterfaceImpl::SetKernelArg ( gpuRepl._reduceKernel, 1, b2 );
	GpuInterfaceImpl::SetKernelArgLocal ( gpuRepl._reduceKernel,
					      2,
					      gpuIntf._maxWorkGroupSize * sizeof(float) );

	/// - If less than a single workgroups items, just use that as the size.
	///   else round up to the workgroup multiple.

	unsigned nToQueue;
	unsigned workGroupSize;
	if ( nWorkItems < gpuIntf._maxWorkGroupSize ) {
	    nToQueue = nWorkItems;
	    workGroupSize = nToQueue;
	}
	else{
	    nToQueue = RoundUp ( nWorkItems, gpuIntf._maxWorkGroupSize );
	    workGroupSize = gpuIntf._maxWorkGroupSize;
	}

	REPRDEBUG(Dump::str(nToQueue,"nToQueue"));

	event = gpuRepl.QueueKernel ( gpuRepl._reduceKernel,
				      nToQueue,
				      workGroupSize,
				      0,
				      { event } );

	auto temp = b1;
	b1 = b2;
	b2 = temp;

	nWorkItems = nWorkGroups;

    }


    /// - Get the locus data off the gpu setting the final event in the instance.
    ///   It's pulled off to a seperate area then moved into the value since the
    ///   data types may be different sizes.

    _event = gpuRepl.QueueRead ( b1, 0, sizeof(cl_float), &_lnL, { event } );

    REPREXIT(Dump::ptr(this));
    return _event;
}

// *****************************************************************************

LkhGpuRoot::LkhGpuRoot( Replicate &  repl,
			Tree::Root & root )
    : Likelihood(repl),
      _gpuRepl(*static_cast<GpuReplicateImpl*>(repl._gpuRepl)),
      _gpuIntf(_gpuRepl._gpuIntf),
      _root(root),
      _eModel(*static_cast<EMRGpuImpl*>(root._eModel)),
      _vecSize(0),
      _lRootVecSize(0),
      _siteAlloc(0),
      _siteBuf(nullptr),
      _bvEntrySize(0),
      _bvAlloc(0),
      _bvBuf(nullptr),
      _countAlloc(0),
      _countBuf(nullptr),
      _cFreqAlloc(0),
      _cFreqBuf(nullptr),
      _bvData(nullptr),
      _siteData(nullptr),
      _countData(nullptr),
      _cFreqData(nullptr)
{
}

// *****************************************************************************
/// Compute the likelihood across a species tree.
/// Used for setting initial values.

FLOAT
LkhGpuRoot::Compute()
{
    REPRENTER(Dump::ptr(this));

    /// - Compute all the transition matricies

    _eModel.UpdateAllTMatrixes();

    /// - Compute the likelihood by traversing each gene tree starting kernels
    ///   for each inner node and the final kernel for the overall likelihood.

    LkhGpuLocusDfs dfs(*this);
    for ( auto & lRoot : _root._locusVec )
	dfs (lRoot);

    /// - Wait on all the likelihoods to complete

    std::vector<cl_event> events;
    events.reserve(_root._locusVec.size());
    for ( auto & lRoot : _root._locusVec )
	events.push_back(LocusRootLkh(lRoot)->_event);
    GpuInterfaceImpl::WaitForEvents(events);

    /// - Copy the log likelihoods to the locus values and sum

    _value = 0.0;
    for ( auto & lRoot : _root._locusVec ) {
	auto & lkhLRoot = *LocusRootLkh(lRoot);
	lkhLRoot._value = lkhLRoot._lnL;
	_value += lkhLRoot._value;
	REPRDEBUG(Dump::str(lRoot._locus._id,"locus._id"),
		  Dump::str(lkhLRoot._countSize,"countSize"),
		  Dump::str(lkhLRoot._value,"lkhLRoot._value"));
    }

    REPREXIT(Dump::ptr(this),
	     Dump::str(_value, "value"));
    return _value;
}

// *****************************************************************************
/// Read back the computed data.

void
LkhGpuRoot::GetData ()
{

    _siteData = new SitePosEntry[_siteAlloc / sizeof(SitePosEntry)];
    _gpuRepl.ReadWait(_siteBuf, _siteData, _siteAlloc);

    _bvData = new float[_bvAlloc / sizeof(cl_float)];
    _gpuRepl.ReadWait(_bvBuf, _bvData, _bvAlloc);

    _countData = new float[_countAlloc / sizeof(cl_float)];
    _gpuRepl.ReadWait(_countBuf, _countData, _countAlloc);

    _cFreqData = new float[_cFreqAlloc / sizeof(cl_float)];
    _gpuRepl.ReadWait(_cFreqBuf, _cFreqData, _cFreqAlloc);

}

// *****************************************************************************

void
LkhGpuRoot::ReplRootEnd()
{
    REPRENTER(Dump::ptr(this));

    /// - Allocate and map the site vector.
    ///   In theory this should be read only but there isn't enough space in the
    ///   constant area for a reasonably sized buffer

    _siteAlloc = _vecSize * sizeof(SitePosEntry);
    _siteBuf   = _gpuIntf.CreateBuffer( CL_MEM_READ_WRITE | CL_MEM_ALLOC_HOST_PTR,
					_siteAlloc );
    SitePosEntry * siteVec = (SitePosEntry*)_gpuRepl.MapBuffer( _siteBuf, _siteAlloc );

    REPRDEBUG ( Dump::ptr(_siteBuf, "siteBuf"),
		Dump::str(_siteAlloc, "siteAlloc") );

    /// - Allocate two copies of the base vectors.

    _bvEntrySize = _eModel._nGCat * _eModel._n;
    _bvAlloc     = _vecSize * _bvEntrySize * 2 * sizeof(cl_float);
    _bvBuf       = _gpuIntf.CreateBuffer( CL_MEM_READ_WRITE, _bvAlloc );

    REPRDEBUG ( Dump::str(_bvEntrySize, "bvEntrySize"),
		Dump::str(_bvAlloc, "bvAlloc"),
		Dump::str(_bvBuf, "bvBuf") );


    /// - Set the base vectors to a constant so I can see what's been changed...

    cl_float * bVec = (cl_float*)_gpuRepl.MapBuffer( _bvBuf, _bvAlloc );

    for ( auto pv = bVec; pv < bVec + _bvAlloc/ sizeof(cl_float); pv++ )
	*pv = 3.141592;

    /// - Allocate the count vector.
    ///   In theory this should be read only but there isn't enough space in the
    ///   constant area for a reasonably sized buffer

    _countAlloc = _lRootVecSize * sizeof(cl_float);
    _countBuf   = _gpuIntf.CreateBuffer( CL_MEM_READ_WRITE | CL_MEM_ALLOC_HOST_PTR,
					 _countAlloc );
    cl_float * countVec = (cl_float*)_gpuRepl.MapBuffer( _countBuf, _countAlloc );

    REPRDEBUG ( Dump::ptr(_countBuf, "countBuf"),
		Dump::str(_countAlloc, "countAlloc") );

    /// - Setup the character frequency buffer

    _cFreqAlloc = _root._locusVec.size() * _eModel._n * sizeof(cl_float);
    _cFreqBuf   = _gpuIntf.CreateBuffer( CL_MEM_READ_ONLY | CL_MEM_ALLOC_HOST_PTR,
					 _cFreqAlloc );
    cl_float * cFreqVec = (cl_float*)_gpuRepl.MapBuffer( _cFreqBuf, _cFreqAlloc );

    REPRDEBUG ( Dump::ptr(_cFreqBuf, "cFreqBuf"),
		Dump::str(_cFreqAlloc, "cFreqAlloc") );

    /// - Loop throught the loci setting up each tree

    cl_float *     cVec = countVec;
    unsigned       cIdx = 0;
    cl_float *     fVec = cFreqVec;
    unsigned       fIdx = 0;

    for ( auto & lRoot : _root._locusVec ) {

	struct LocusDfs : Tree::LocusDfs {

	    LocusDfs ( SitePosEntry *   sVec,
		       cl_float     * & cVec,
		       unsigned     &   cIdx,
		       cl_float     * & fVec,
		       unsigned     &   fIdx )
		: _sVec(sVec),
		  _cVec(cVec),
		  _cIdx(cIdx),
		  _fVec(fVec),
		  _fIdx(fIdx)
		{}

	    RC InnerEnd ( Tree::LocusNode & lNode )
		{
		    LocusNodeLkh(lNode)->ReplRootEnd( _sVec);
		    return CONTINUE;
		}

	    RC RootEnd ( Tree::LocusNode & lNode )
		{
		    LocusRootLkh(lNode)->ReplRootEnd( _cVec, _cIdx, _fVec, _fIdx );
		    return InnerEnd(lNode);
		}

	    SitePosEntry * _sVec;
	    cl_float * &   _cVec;
	    unsigned &     _cIdx;
	    cl_float * &   _fVec;
	    unsigned &     _fIdx;

	} dfs(siteVec, cVec, cIdx, fVec, fIdx);

	dfs(lRoot);

    }

    /// - Unmap the vectors

    std::vector<cl_event> events = { _gpuRepl.UnmapBuffer ( _siteBuf, siteVec ),
				     _gpuRepl.UnmapBuffer ( _bvBuf, bVec ),
				     _gpuRepl.UnmapBuffer ( _countBuf, countVec ),
				     _gpuRepl.UnmapBuffer ( _cFreqBuf, cFreqVec ) };

    /// - Wait for all uploads to complete

    GpuInterfaceImpl::WaitForEvents(events);

    REPREXIT(Dump::ptr(this));
}

// *****************************************************************************

std::string
LkhGpuRoot::str ( const std::string hdg )
    const
{
    std::stringstream ss;
    if ( hdg.size() ) ss << hdg << "<";

    ss << Likelihood::str() << ' '
       << Dump::str(_vecSize, "vecSize") << ' '
       << Dump::str(_lRootVecSize, "lRootVecSize") << ' '
       << Dump::str(_siteAlloc, "siteAlloc") << ' '
       << Dump::str(_siteBuf ,"siteBuf") << ' '
       << Dump::str(_bvEntrySize ,"bvEntrySize") << ' '
       << Dump::str(_bvAlloc ,"bvAlloc") << ' '
       << Dump::str(_bvBuf ,"bvBuf") << ' '
       << Dump::str(_countAlloc ,"countAlloc") << ' '
       << Dump::ptr(_countBuf ,"countBuf") << ' '
       << Dump::str(_cFreqAlloc ,"cFreqAlloc") << ' '
       << Dump::ptr(_cFreqBuf ,"cFreqBuf") << '\n';

    if ( _siteData && _vecSize < 1000 ) {
	std::stringstream sitess;
	for ( unsigned site = 0; site < _vecSize; site++ )
	    sitess << Dump::str(site, "site") << ' '
		   << Dump::str(_siteData[site].lhsIdx, "lhs") << ' '
		   << Dump::str(_siteData[site].rhsIdx, "rhs") << '\n';
	ss << Dump::indent(Dump::indent_heading ( sitess.str(), "siteData" )) << '\n';
    }

    if ( _bvData && _vecSize < 1000 ) {
	std::string bvss;

	auto copy1 = _bvData;
	auto copy2 = _bvData + _vecSize * _bvEntrySize;

	for ( unsigned site = 0; site < _vecSize; site++ ) {

	    std::string sstr;

	    for ( unsigned gcat = 0; gcat < _eModel._nGCat; gcat++ )
		sstr += Dump::indent_heading ( Dump::str(copy1, copy2, _eModel._n) + '\n',
					       Dump::vector_heading(gcat, "gCat") ) + '\n';

	    bvss += Dump::indent_heading ( sstr, Dump::vector_heading(site, "site", 3) ) + '\n';

	}

	ss << Dump::indent(Dump::indent_heading ( bvss, "BaseVec" )) << '\n';

    }

    if ( _countData ) {
	std::stringstream countss;
	countss << '<' << std::setprecision(6);
	for ( unsigned i = 0; i < _countAlloc / sizeof(cl_float); i++ ) {
	    if ( i != 0 ) countss << ',';
	    countss << _countData[i];
	}
	countss << '>';
	ss << Dump::indent(Dump::indent_heading ( countss.str(), "countData" )) << '\n';
    }

    if ( _cFreqData ) {
	std::stringstream freqss;

	auto cd = _cFreqData;

	for ( unsigned i = 0; i < _root._locusVec.size(); i++ ) {
	    freqss << Dump::str(i) << ' '
		   << std::setprecision(6);
	    for ( unsigned j = 0; j < _eModel._n; j++ ) {
		if ( j != 0 ) freqss << ',';
		freqss << *cd++;
	    }
	    freqss << '\n';
	}

	ss << Dump::indent(Dump::indent_heading ( freqss.str(), "cFreqData" )) << '\n';
    }

    std::string str = Dump::rtrim(ss.str());

    if ( hdg.size() ) str += '>';
    return str;
}

// *****************************************************************************

FLOAT
LkhGpuRoot::operator()()
{
    REPRENTER(Dump::ptr(this));

    /// - Pull the likelihood values off the gpu and sum
    ///   or should be just return the value in the instance?

    REPREXIT(Dump::ptr(this),
	     Dump::str(_value, "value"));
    return _value;
}


// *****************************************************************************

inline
void
UpdateChildTMatrixes ( Tree::LocusNode & lNode )
{
    for ( auto lChild : lNode._children )
	lChild->UpdateTMatrix();
}

FLOAT
LkhGpuTreeNode::Compute ()
{

    REPRENTER ( Dump::ptr(this) );

    _eModel.InitForUpdates();

    EVENTLIST locusEvents;

    /// - For root nodes just update the child transtition matrixes and compute
    ///   the base vector at the root.

    if ( _tPos.IsRoot() ) {

	auto & lVec = _tPos.AsRoot()._locusVec;

	for ( auto & lRoot : lVec )

	    if ( !lRoot._missing )
		UpdateChildTMatrixes(lRoot);

	/// - Empty update list - do nothing...

	if ( !_eModel._posUpdList.size() )
	    return 1.0;

	EVENTLIST events = { _eModel.DoUpdates() };

	for ( auto & lRoot : lVec )

	    if ( !lRoot._missing ) {

		/// - Update the root's base vector

		events = { LocusNodeLkh(lRoot)->UpdateBaseVec(events) };

		/// - Compute the overall log likelihood for the gene tree

		locusEvents.push_back(LocusRootLkh(lRoot)->UpdateValue(events));
	    }

    }

    /// - For other inner nodes, update the child and current nodes transition matrixes
    ///   and compute the base vectors up to the root.

    else {

	auto & lVec = _tPos.AsTNode()._locusVec;

	for ( auto & lNode : lVec )

	    if ( !lNode._missing ) {
		lNode.UpdateTMatrix();
		UpdateChildTMatrixes(lNode);
	    }

	/// - Empty update list - do nothing...

	if ( !_eModel._posUpdList.size() )
	    return 1.0;

	EVENTLIST events = { _eModel.DoUpdates() };

	for ( auto & lNode : lVec )

	    if ( !lNode._missing ) {

		/// - Update this node's base vector

		events = { LocusNodeLkh(lNode)->UpdateBaseVec(events) };

		/// - Update base vectors to the root

		for ( auto lp = lNode._parent; lp; lp = lp->_parent )
		    events = { LocusNodeLkh(*lp)->UpdateBaseVec(events) };

		/// - Compute the overall log likelihood for the gene tree

		locusEvents.push_back( LocusRootLkh(lNode._lRoot)->UpdateValue(events) );

	    }

    }

    FLOAT priorRatio = 0.0;

    /// - Copy the log likelihoods to the locus values and sum the ratios

    for ( auto & lRoot : _tPos.GetRoot()._locusVec ) {
	auto & lkhLRoot = *LocusRootLkh(lRoot);
	lkhLRoot._value = lkhLRoot._lnL;
	priorRatio += lkhLRoot._value - lkhLRoot._oldValue;
    }

    REPREXIT( Dump::ptr(this),
	      Dump::str(priorRatio, "priorRatio") );
    return priorRatio;
}
