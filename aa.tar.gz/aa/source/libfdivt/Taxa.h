/// @file Taxa.h
/// Declaration of the taxa object

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _TAXA_H_
#define _TAXA_H_

#include <string>
#include <list>
#include <vector>

class  Logger;
struct Sequence;
struct SequenceFactory;

// *****************************************************************************
/// Declaration of the taxa object.
/// An instance of this object is created for each taxa loaded

struct Taxa {

    /// Constructor for the taxa object.
    Taxa( const std::string label,	          ///< Text label to associate with the taxa.
          const unsigned    id )                  ///< Numeric id to use with the taxa.
        : _label(label),
          _id(id)
        {
        }

    ~Taxa();

    /// Add the sequence to the slot for the associated locus
    /// @param seq Pointer to the sequence object
    void
    AddSequence ( Sequence * seq );

    /// Dump info for the taxa to the logger.
    void
    Log( Logger &                logger,
	 const SequenceFactory & seqFactory ) const;

    /// Dump string for the taxa
    std::string
    str ( const std::string hdg = "" ) const;

    // *************************************************************************

    const std::string            _label;	  ///< Name to associate with the taxa
    const unsigned               _id;		  ///< Ordinal taxa id

    /// Vector of sequences by locus.
    /// The vector length is set by the total number of loci.
    /// Each entry may be null (no sequence for the locus.
    std::vector<Sequence *>      _seqVec;

    /// Generate the dump string for a list of pointers to these.
    static
    std::string
    str ( const std::list<Taxa *> & l,
	  const std::string         hdg = "" );

};

#endif // _TAXA_H_
