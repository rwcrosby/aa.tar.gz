/// @file EvoModelParameters.h
/// Devlarations for the parameters associated with the evolutionary models.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _EVOMODELPARAMETERS_H_
#define _EVOMODELPARAMETERS_H_

#include "Config.h"
#include "Parameter.h"

struct EvoModel;

namespace Tree {
    struct LocusRoot;
}

// *****************************************************************************
/// Base class the the evolutionary model parameter classes.

struct EvoModelParameter : NuisanceParameter {

protected:

    EvoModelParameter( EvoModel & eModel );

    /// Add the parameter to the replicate and update statistics
    void
    Add2Repl();

    virtual
    void
    Rollback()
	{
	    NuisanceParameter::Rollback();
	}

    virtual
    std::string
    str()
	const;

    EvoModel &        _eModel;
    Tree::LocusRoot & _lRoot;

};

// *****************************************************************************
/// Set of parameters with a dirichlet prior.

struct DirichletParameterSet : EvoModelParameter {

    /// Create a parameter set with the initial values specified.
    DirichletParameterSet( EvoModel&         eModel,       ///< Evolutionary model instance for this parameter
			   const FLOATVEC &  initValues,   ///< Initial values for the parameter set
			   const FLOATVEC &  hyperParms,   ///< Distriburion hyperparameters
			   const std::string hdgPrefix,	   ///< Use as prefix for the heading
			   const STRINGVEC   hdgVec        ///< Parameter headings for trace
                      );

    /// Create a parameter set with the initial value set as fractions of the
    /// number of parameters (e.g. 1/6 for GTR model parms).
    DirichletParameterSet( EvoModel&         eModel,       ///< Evolutionary model instance for this parameter
			   const FLOATVEC &  hyperParms,   ///< Distriburion hyperparameters
			   const std::string hdgPrefix,	   ///< Use as prefix for the heading
			   const STRINGVEC   hdgVec)       ///< Parameter headings for trace
	: DirichletParameterSet(eModel,
				FLOATVEC(hyperParms.size(), 1.0 / FLOAT (hyperParms.size())),
				hyperParms,
				hdgPrefix,
				hdgVec)
	{}

    virtual
    void
    Commit();

    virtual
    FLOAT
    Propose ();

    virtual
    void
    Rollback();

    virtual
    std::string
    str ()
	const;

    const FLOATVEC & _hyperParms;                 ///< Hyperparameters for the distribution

    FLOATVEC         _values;	                  ///< The actual parameter values
    FLOATVEC         _oldValues;                  ///< Saved value of the parameters for rollback

};

// *****************************************************************************
/// Evolutionary model parameter with a gamma prior.

struct GammaParameter : EvoModelParameter {

    GammaParameter( EvoModel  &    eModel,        ///< Evolutionary model instance for this parameter
                    const FLOAT    alpha,         ///< Alpha hyperparameter for the gamma distribution.
                    const FLOAT    beta,          ///< Beta hyperparameter for the gamma distribution.
		    const char *   label,         ///< Parameter label for trace
		    const char *   hdg            ///< Parameter heading for trace
                  );

    GammaParameter( EvoModel  &    eModel,        ///< Evolutionary model instance for this parameter
                    const FLOAT    alpha,         ///< Alpha hyperparameter for the gamma distribution.
                    const FLOAT    beta,          ///< Beta hyperparameter for the gamma distribution.
		    const char *   label          ///< Parameter label and heading for trace
                  )
	: GammaParameter(eModel, alpha, beta, label, label)
	{};

    virtual
    void
    Commit();

    virtual
    FLOAT
    Propose ();

    virtual
    void
    Rollback();

protected:

    const FLOAT  _alpha;                          ///< Alpha parameter to the gamma distribution
    const FLOAT  _beta;                           ///< Beta parameter to the gamma distribution

};

// *****************************************************************************
/// Gamma parameters for the discrete rate categories.

struct GCatAlphaParameter : GammaParameter {

    GCatAlphaParameter( EvoModel  &    eModel,        ///< Evolutionary model instance for this parameter
			const FLOAT    alpha,         ///< Alpha hyperparameter for the gamma distribution.
			const FLOAT    beta,          ///< Beta hyperparameter for the gamma distribution.
			const char *   label,         ///< Parameter label for trace
			const char *   hdg            ///< Parameter heading for trace
	);

    GCatAlphaParameter( EvoModel  &    eModel,        ///< Evolutionary model instance for this parameter
			const FLOAT    alpha,         ///< Alpha hyperparameter for the gamma distribution.
			const FLOAT    beta,          ///< Beta hyperparameter for the gamma distribution.
			const char *   label          ///< Parameter label and heading for trace
	)
	: GCatAlphaParameter(eModel, alpha, beta, label, label)
	{};

    virtual
    FLOAT
    Propose ();

    virtual
    void
    Rollback();

    FLOATVEC & _rateVec;                          ///< Table of gamma rates by category

};

#endif // _EVOMODELPARAMETERS_H_
