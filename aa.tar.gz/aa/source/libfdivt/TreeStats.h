/// @file TreeStats.h
/// Tree Statistics object definition.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _TREESTATS_H_
#define _TREESTATS_H_

#include <list>

#include "LogStats.h"

// *****************************************************************************
/// Tree Statistics structure

struct TreeStats : public LogStats {

    // Counters for performance information
    unsigned                          _nRoots;	    ///< Trees built
    unsigned                          _nInner;	    ///< Total inner nodes
    unsigned                          _nLeaves;	    ///< Total leaf

    unsigned                          _longTreeVec; ///< Longest tree vector

    unsigned                          _rootMem;     ///< Root block memory
    unsigned                          _innerMem;    ///< Inner node memory
    unsigned                          _leafMem;     ///< Leaf node memory
    unsigned                          _treeMem;     ///< Tree block memory
    unsigned                          _locusMem;    ///< Locus block memory
    unsigned                          _siteMem;     ///< Site vector memory

    /// Construct a new statistics instance.
    TreeStats(Logger & log)                         ///< Logger instance pointer
        : LogStats(log, "Tree Statistics"),
          _nRoots(0),
          _nInner(0),
          _nLeaves(0),
          _longTreeVec(0),
          _rootMem(0),
          _innerMem(0),
          _leafMem(0),
          _treeMem(0),
          _locusMem(0),
          _siteMem(0)
        {
        }

    virtual ~TreeStats() {}

    /// Output statistics to the log
    virtual void Log()
        {
            unsigned totalMem = _rootMem + _innerMem + _leafMem + _treeMem + _locusMem + _siteMem;

            STATSLIST _statsList {
                STATSITEM ("Trees",                &_nRoots),
                STATSITEM ("Inner Nodes",          &_nInner),
                STATSITEM ("Leaf Nodes",           &_nLeaves),
                STATSITEM ("Longest Tree Vector",  &_longTreeVec),
                STATSITEM ("Root Node Memory",     &_rootMem),
                STATSITEM ("Inner Node Memory",    &_innerMem),
                STATSITEM ("Leaf Node Memory",     &_leafMem),
                STATSITEM ("Tree Vector Memory",   &_treeMem),
                STATSITEM ("Locus Vector Memory",  &_locusMem),
                STATSITEM ("Site Vector Memory",   &_siteMem),
                STATSITEM ("Total Memory",         &totalMem),
            };

            _DoLogging(_statsList);
        }

};

#endif // _TREESTATS_H_
