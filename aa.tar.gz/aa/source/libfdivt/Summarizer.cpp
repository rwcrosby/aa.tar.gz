/// @file Summarizer.cpp
/// Definition of the run summarizer.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include <fstream>
#include <iostream>

#include "Except.h"
#include "OutputManager.h"
#include "Parameter.h"
#include "Replicates.h"
#include "Task.h"
#include "ThreadSet.h"
#include "Tree.h"

// *****************************************************************************
/// Task to create the summary for a specific tree.

struct TreeSummaryTask : Task {

    TreeSummaryTask ( Replicate & repl,
		      Tree::Root & root,
		      IOutputFile * finalTreeFile,
		      IOutputFile * detailFile )
	: _repl(repl),
	  _root(root),
	  _tFile(finalTreeFile),
	  _dFile(detailFile)
	{}

    virtual void operator()( const unsigned tno );

    Replicate &   _repl;
    Tree::Root &  _root;
    IOutputFile * _tFile;
    IOutputFile * _dFile;

};

// *****************************************************************************

void
Summarizer(ThreadSet &     tSet,
	   ReplicateVec &  replVec,
	   OutputManager & oMgr)
{

    /// - Create the task list

    Task::PtrList tasks;

    for ( auto & repl : replVec )
	for ( auto & root : repl )
	    tasks.push_back(new TreeSummaryTask(repl,
						root,
						root._finalTreeFile,
						root._detailFile ) );

    /// - Process the tasks creating the summaries in parallel

    tSet(tasks);

    /// - Delete the workers - apologies to V.I. Lenin

    for ( auto t : tasks )
	delete t;

}

// *****************************************************************************
/// Extract a stream entry adding to the set of parameters.

std::istream & operator>> ( std::istream &    is,
			    Tree::TraceInfo & ti )
{
    FLOAT  v;
    is >> v;
    ti._values->push_back(v);
    ti._sum += v;
    return is;
}

// *****************************************************************************

void
TreeSummaryTask::operator()( const unsigned id)
{

    unsigned nSamples = _root._sampleFile->NSamples();

    /// - Create the values vectors in the trace info blocks

    for ( auto ti : _root._traceList ) {
	ti->_values = new FLOATVEC;
	ti->_values->reserve(nSamples);
    }

    /// - Load the trace file data.

    _root._traceFile->Close();

    {
	std::ifstream sIn(_root._traceFile->Filename());
	if ( sIn.fail() )
	    throw Except::IOError("re-opening",
				  _root._traceFile->Filename(),
				  strerror(errno) );

	for ( std::string line; std::getline(sIn, line); ) {
	    unsigned gen;
	    std::istringstream is(line);
	    is >> gen;
	    for ( auto ti : _root._traceList )
		is >> *ti;
	}

    }

    /// - Compute the summary statics

    for ( auto ti : _root._traceList )
	ti->ComputeStats();

    /// - Delete the trace info value vectors

    for ( auto ti : _root._traceList ) {
	delete ti->_values;
	ti->_values = nullptr;
    }

    /// - Write the tree and report

    (*_tFile)();
    (*_dFile)();


}
