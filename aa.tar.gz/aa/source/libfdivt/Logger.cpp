/// @file Logger.cpp
/// Declarations for the logging methods

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include <clocale>
#include <cstdarg>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <stdexcept>

#ifdef _WIN32
#include <io.h>
#define DUP _dup
#define FDOPEN _fdopen
#else
#include <unistd.h>
#define DUP dup
#define FDOPEN fdopen
#endif


#include "Except.h"
#include "Logger.h"
#include "ILogSink.h"

using namespace std;

/// Namespace for the logging destination objects

namespace LogDest {

    // *****************************************************************************
    /// Base class for the log destination objects

    class Base {

    public:
	Base() {};
	virtual ~Base() {};

	virtual void Write(const char * buffer) = 0;
        virtual void Flush(void)
            {};

    };

    // *************************************************************************
    /// File pointer as a destination

    class FilePointer : public Base {

    protected:
	FILE * fp;

    public:
	FilePointer() {};
	FilePointer( FILE * p )
	    : fp(p) {};

	virtual ~FilePointer()
	    {
		if (fp)
		    fflush(fp);
	    };

	virtual void Write(const char * buffer)
	    {
		fputs(buffer, fp);
	    };

	virtual void Flush(void)
	    {
		fflush(fp);
	    };

    };

    // *************************************************************************
    /// File number as a destination

    class FileNumber : public FilePointer {

    public:
	FileNumber() {};
	FileNumber( const unsigned fno )
	    {
		auto nfno = DUP(fno);
		fp = FDOPEN(nfno, "w");
		if (!fp)
		    throw Except::BadOptValue("LogFile", "Unable to open log file");
	    };

	virtual ~FileNumber()
	    {
		fclose(fp);
		fp = nullptr;
	    };

    };

    // *************************************************************************
    /// Named file as a destination

    class FileName : public FilePointer {

    public:
	FileName(char * fn)
	    {
		fp = fopen(fn, "w");
		if (!fp)
		    throw Except::BadOptValue("LogFile", "Unable to open log file");
	    };

	virtual ~FileName()
	    {
		fclose(fp);
		fp = nullptr;
	    };

    };

    // *************************************************************************
    /// Log Sink Object as a destination

    class LogSink : public Base {

	ILogSink* sink;

    public:
	LogSink(ILogSink * s)
	    : sink(s)
	    {
		this->sink->Open();
	    };

	virtual ~LogSink()
	    {
		this->sink->Close();
	    };

	virtual void Write(const char * buffer)
	    {
		this->sink->Log(buffer);
	    };

    };

} // End LogDest Namespace

// *****************************************************************************

Logger::Logger()
    : _bufferSize(1024)
{
    _buffer = new char[_bufferSize];

    setlocale(LC_NUMERIC, "");
}

// *****************************************************************************
/// Destructor for the logger.


Logger::~Logger()
{

    /// Delete the log sink objects.

    for ( auto dest : _destinations ) delete dest;

    delete[] _buffer;

}

// *****************************************************************************

void
Logger::AddDestination(FILE * fp)		  ///< File pointer to add
{
    _destinations.push_back(new LogDest::FilePointer(fp));
}

// *****************************************************************************

void
Logger::AddDestination(const unsigned fno)	  ///< Add a file number to output to
{
    _destinations.push_back(new LogDest::FileNumber(fno));
}

// *****************************************************************************

void
Logger::AddDestination(char * fn)	      ///< File name to manage
{
    _destinations.push_back(new LogDest::FileName(fn));
}

// *****************************************************************************

void
Logger::AddDestination(ILogSink * sink)      ///< Log sink object
{
    _destinations.push_back(new LogDest::LogSink(sink));
}

// *****************************************************************************

void
Logger::operator()(const char * format,	          ///< printf format string.
                   ... )                          ///< Variables to be formatted into the output
{

    unique_lock<std::mutex> lk(_mutex);

    /// - Attempt to generate the output reallocating the buffer if needed.

    while (1) {

	va_list args;
	va_start (args, format);

	int needed = vsnprintf (_buffer, _bufferSize, format, args);
        if ( needed >= _bufferSize ) {
            delete[] _buffer;
            _bufferSize = needed + 2;
            _buffer = new char[_bufferSize];
        }
        else if ( needed == -1 ) {
            delete[] _buffer;
            _bufferSize = _bufferSize * 2;
            _buffer = new char[_bufferSize];
        }
        else
            break;
    }

    size_t len = strlen(_buffer);
    _buffer[len++] = '\n';
    _buffer[len] = '\0';

    for ( auto dest : _destinations ) {
        dest->Write(_buffer);
        dest->Flush();
    }

}

// *****************************************************************************

static const char* debugFmt = "/%u/%s/%s/%s/%u/ %s";

#ifdef _WIN32
#define DELIM '\\'
#else
#define DELIM '/'
#endif

void
Logger::DebugStdLine ( const std::string              type,
		       const unsigned                 id,
		       const std::string              file,
		       const unsigned                 line,
		       const std::string              func,
		       const std::vector<std::string> strs )
{

    /// - Strip any leading path information from the file name

    auto pos = file.rfind(DELIM);
    std::string fn = (pos == std::string::npos)
	? file
	: file.substr(pos + 1);

    /// - Reduce the function name to just class::method

    auto endname = func.rfind('(');
    std::string name = (endname == std::string::npos)
	? func
	: func.substr(0, endname);
    auto startname = name.rfind(' ');
    name = (startname == std::string::npos)
	? name
	: name.substr(startname + 1);

    /// - Build the output string as the concatenation of the variable strings passed.

    ostringstream ss;
    for ( auto it = strs.begin(); it != strs.end(); it++ ) {
	if ( it != strs.begin() )
	    ss << ' ';
	ss << *it;
    }

    (*this)(debugFmt, id, type.c_str(), name.c_str(), fn.c_str(), line, ss.str().c_str());

}
