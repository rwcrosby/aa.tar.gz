/// @file Likelihood.cpp
/// Definitions for the likilihood base class methods

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include "Dump.h"
#include "Likelihood.h"
#include "LikelihoodCpu.h"
#ifdef OPENCL
#include "LikelihoodGpu.h"
#endif
#include "Replicates.h"
#include "Tree.h"

// *****************************************************************************
/// Simple constructor defined here so the replicate header is's needed in the
/// .h file.

Likelihood::Likelihood( Replicate & repl )
    : _value(0.0),
      _repl(repl),
      _logger(_repl._logger)
{
}

// *****************************************************************************

std::string
Likelihood::str( const std::string hdg )
    const
{
    std::stringstream ss;
    if ( hdg.size() ) ss << hdg << '<';

    ss << Dump::str(_value, "lnL");

    if ( hdg.size() ) ss << '>';
    return ss.str();
}

// *****************************************************************************

Likelihood *
Likelihood::Factory ( Replicate &  repl,
		      Tree::Root & root )
{
#ifdef OPENCL
    if ( repl._gpuRepl )
	return LikelihoodGpu::Factory ( repl, root );
#endif

    return LikelihoodCpu::Factory ( repl, root );
}

// *****************************************************************************

Likelihood *
Likelihood::Factory ( Replicate &       repl,
		      Tree::LocusRoot & lRoot )
{
#ifdef OPENCL
    if ( repl._gpuRepl )
	return LikelihoodGpu::Factory ( repl, lRoot );
#endif

    return LikelihoodCpu::Factory ( repl, lRoot );
}

// *****************************************************************************

Likelihood *
Likelihood::Factory ( Replicate &          repl,
		      const Tree::Position tPos )
{
#ifdef OPENCL
    if ( repl._gpuRepl )
	return LikelihoodGpu::Factory ( repl, tPos );
#endif

    return LikelihoodCpu::Factory ( repl, tPos );
}

// *****************************************************************************

Likelihood *
Likelihood::Factory ( Replicate &       repl,
		      Tree::LocusNode & lNode )
{
#ifdef OPENCL
    if ( repl._gpuRepl )
	return LikelihoodGpu::Factory ( repl, lNode );
#endif

    return LikelihoodCpu::Factory ( repl, lNode );
}
