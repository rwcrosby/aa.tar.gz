/// @file Replicates.h
/// Declarations for the replicate  and list of replicates

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _REPLICATES_H_
#define _REPLICATES_H_

#include <algorithm>
#include <cassert>
#include <memory>
#include <random>

#include "Dump.h"
#include "Options.h"
#include "ParmStats.h"

class  DagFactory;
struct DagStats;
struct DivTime;
struct ITransaction;
struct GpuInterface;
struct GpuReplicate;
struct Likelihood;
struct Parameter;
struct StatsObj;

namespace Tree {
    struct Position;
    struct Root;
    struct Vertex;
}

// *****************************************************************************
/// Define the standard debugging output macros for any object with a _repl reference

#define REPRENTER(...) LOGENTER(_repl._logger, _repl._id, __VA_ARGS__);
#define REPRDEBUG(...) LOGDEBUG(_repl._logger, _repl._id, __VA_ARGS__);
#define REPREXIT(...)  LOGEXIT(_repl._logger, _repl._id, __VA_ARGS__);

/// Define the standard debugging output macros for any object with a _repl pointer

#define REPPENTER(...) LOGENTER(*_repl._logger, _repl._id, __VA_ARGS__);
#define REPPDEBUG(...) LOGDEBUG(*_repl._logger, _repl._id, __VA_ARGS__);
#define REPPEXIT(...)  LOGEXIT(*_repl._logger, _repl._id, __VA_ARGS__);

// *****************************************************************************
/// A single replicate.
/// Subclass of the list of roots in the dag

struct Replicate : std::vector<Tree::Root> {

    /// Copy constructor of a sort.
    /// Copies the Dag portion building the parameter list.
    /// Builds the evolutionary model, likelihood model and parameters
    /// that are specific to the replicate.
    Replicate( const unsigned id,                 ///< Replicate number.
	       unsigned &     nodeId,             ///< Counter to generate unique node id's
	       unsigned &     parmId,             ///< Counter to generate unique parameter id's
	       DivTime &      dt,	          ///< Parent divergence time instance
	       ParmStats &    stats,		  ///< Statistics recorder.
	       Logger &       logger,		  ///< Logger to output to
	       GpuInterface * gpuIntf		  ///< GPU interface or null if none
             );

    /// Destructor to clean up things.
    /// Most of this is automatic with the exception of the likelihood algorithm.
    ~Replicate();

    /// Commit a proposal when accepted
    inline
    void
    CommitProposal   ()
        {
	    if ( _commitLog.size() )
		DoCommit();
	    _rollbackLog.clear();
        }

    /// Return a random draw from a gamma distribution.
    /// Value is constrained by the min and max values passed.
    FLOAT
    DrawGamma ( const FLOAT  alpha,
		const FLOAT  beta,
		const FLOAT  min,
		const FLOAT  max );

    /// Return a random draw from a gamma distribution
    /// Value is constrained by the min and max values passed.
    FLOAT
    DrawNormal ( const FLOAT  mu,
		 const FLOAT  sigma,
		 const FLOAT  min,
		 const FLOAT  max );

    /// Add an object to the set of items to rollback in the case of
    /// a rejected proposal.
    inline
    void
    LogCommit ( ITransaction * cObj )             ///< Commit object to add to list
        {
	    LOGDEBUG(_logger, _id, Dump::ptr(cObj));
            _commitLog.push_back(cObj);
        }

    /// Add an object to the set of items to rollback in the case of
    /// a rejected proposal.
    inline
    void
    LogRollback ( ITransaction * rbObj )          ///< Rollback object to add to list
        {
	    LOGDEBUG(_logger, _id, Dump::ptr(rbObj));
            _rollbackLog.push_back(rbObj);
        }

    /// Rollback the objects on a rejected proposal
    inline
    void
    RollbackProposal ()
	{
	    if ( _rollbackLog.size() )
		DoRollback();
	    _commitLog.clear();

	}

    const DivTime &             _dt;                ///< Owning divergence time object 
    Logger &                    _logger;	    ///< Logger to output to
    ParmStats &                 _stats;		    ///< Container for parameter statistics
    const unsigned              _id;		    ///< Replicate number

    GpuReplicate *              _gpuRepl;	    ///< Null if no GPU support

    const Options::ClockModel   _cModel;            ///< Global, independent or correlated

    unsigned                    _ageAccepted;       ///< Accepted age proposals
    unsigned                    _rateAccepted;      ///< Accepted rate proposals
    unsigned                    _nuisanceAccepted;  ///< Accepted other proposals

    unsigned                    _ageRejected;       ///< Rejected age  proposals
    unsigned                    _rateRejected;      ///< Rejected rate  proposals
    unsigned                    _nuisanceRejected;  ///< Rejected nusiance proposals

    StatsObj *                  _statsObj;          ///< Random statistical functions

    unsigned &                  _nodeId;	    ///< Unique id used to generate Tree::Node id's
    unsigned &                  _parmId;	    ///< Unique id used to generate Parameter id's

    /// List of parameters for this replicate.
    /// Note this list doesn't own the memory for the parameters. That is the
    /// responsibility of the original container for the parameter
    /// (e.g. an evolutionary model instance).
    std::list<Parameter*>       _parmList;

    /// Vector used as a transaction queue to contain the objects that will be
    /// rolled back in the case of a rejected proposal.
    std::vector<ITransaction *> _rollbackLog;

    /// Vector used as a transaction queue to contain the objects that will be
    /// rolled forward in the case of an accepted proposal.
    std::vector<ITransaction *> _commitLog;

    /// Probability of a given calibration being included in this replicate.
    /// The first replicate will always be 100%. Subsequent replicates will
    /// have the value from DivTime.
    const FLOAT                 _calProb;

    /// Bit vector indicating which calibrations are included in this replicate.
    /// Corresponds to the Calibration::Opt._id values
    std::vector<bool>           _calsIncluded;

    const bool                  _commonRates;	    ///< Use the common rates multi-tree model
    const bool                  _commonAges;	    ///< Use the common ages multi-tree model

private:

    /// Create the trace blocks for the non-parameter items.
    void
    AddTraceBlocks(Tree::Root & root);

    /// Actually do the commit
    void
    DoCommit();

    /// Actually do the rollback
    void
    DoRollback();

};

// *****************************************************************************
/// Expansion on the base tree traversal routine to process all nodes of a replicate.
/// All trees are traversed in order. Each node is presented to the absract methods
/// only the first time it's seen.

struct ReplicateDfs {

    enum RC {
	/// Continue processing normally.
	CONTINUE,
	/// Discontinue downward traversal but continue overall procesing.
	STOPDOWN,
	/// Cancel DFS completely
	CANCEL
    };

    /// Hit an inner node for the first time on the way down the tree.
    /// @param tPos Current tree position
    /// @return Continuation status.
    virtual RC InnerBegin ( const Tree::Position & tPos )
	{
	    return CONTINUE;
	}

    /// After processing all children before popping.
    /// @param tPos Current tree position
    /// @return Continuation status.
    virtual RC InnerEnd   ( const Tree::Position & tPos )
	{
	    return CONTINUE;
	}

    /// Hit a leaf.
    /// @param tPos Current tree position
    /// @return Continuation status.
    virtual RC Leaf       ( const Tree::Position & tPos )
	{
	    return CONTINUE;
	}

    /// Hit the root node for the first time on the way down the tree.
    /// @param root Current tree position
    /// @return Continuation status.
    virtual RC RootBegin ( Tree::Root & root )
	{
	    return CONTINUE;
	}

    /// After processing all children before ending.
    /// @param root Current tree position
    /// @return Continuation status.
    virtual RC RootEnd   ( Tree::Root & root )
	{
	    return CONTINUE;
	}

    /// Perform the search
    /// @param repl Replicate to process
    virtual void operator()(Replicate & repl);

    /// Perform the search
    /// @param repl Replicate to process
    virtual void operator()(Replicate * repl)
	{
	    (*this)(*repl);
	}

};

// *****************************************************************************
/// The vector of replicates.
/// Elements in the vector correspond to the set of replicates (MCMC chains or
/// jackknife replicates).

struct ReplicateVec : public std::vector<Replicate> {

    /// Create the set of replicates from the current dag.
    /// @param dt Owning divergence time instance
    /// @param gpuIntf GPU interface object
    ReplicateVec( DivTime &      dt,
		  GpuInterface * gpuIntf );

    virtual ~ReplicateVec();

    DivTime &   _dt;			          ///< Owning div time object
    Logger &    _logger;                          ///< Logger to output to.
    ParmStats * _stats;                           ///< Stats on the parameters.

};

// *****************************************************************************
/// Create a parameter object adding it to the appropriate lists.

template<typename    ParmType,
	 typename... CArgs>
ParmType *
MakeParameter ( Replicate &     repl,
		ParmStats::Type st,
		CArgs ...       cArgs )
{

    ParmType * parm = new ParmType(repl, cArgs...);
    repl._parmList.push_back(parm);

    repl._stats._parms[(unsigned)st]._n++;
    repl._stats._parms[(unsigned)st]._mem += sizeof(ParmType);

    return parm;

}

#endif // _REPLICATES_H_
