/// @file AgePrior.h
/// Declarations for the prior of node ages.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _AGEPRIOR_H_
#define _AGEPRIOR_H_

#include "Prior.h"

struct Parameter;

namespace Tree {
    struct Position;
    struct Root;
}

// *****************************************************************************
/// Superclass for the prior of rates at the root of a species tree.

struct AgePriorRoot : Prior {

    AgePriorRoot( Replicate  & repl )
	: Prior(repl)
	{}

    virtual ~AgePriorRoot()
	{}

    /// Compute the prior for a species tree assuming no saved values.
    /// Intended for setting the initial values on the tree.
    virtual void InitialValues () = 0;

    /// Compute the prior for the species tree when the root age changes.
    virtual void NewAge () = 0;

    /// Update the log prior value by the amount passed.
    /// @param delta Change in the log of the prior
    virtual void UpdatePrior ( FLOAT delta )
	{
	    _value += delta;
	}

    /// Factory to create the appropriate prior module.
    /// @return Pointer to prior module created.
    /// @param repl Reference to owning replicate.
    /// @param root Reference to the species tree root for this prior.
    static AgePriorRoot * Factory  ( Replicate &  repl,
				     Tree::Root & root );

};

// *****************************************************************************
/// Pure virtual base class for the age prior at a tree node.

struct AgePriorNode : Prior {

    AgePriorNode( Replicate & repl )
	: Prior(repl)
	{}

    virtual ~AgePriorNode()
	{}

    /// Compute at a specific tree node when an age changes.
    /// Update the value of the overall tree prior in the root.
    virtual void NewAge () = 0;

    /// Factory to create the appropriate prior module.
    /// @return Pointer to prior module created.
    /// @param repl Reference to owning replicate.
    /// @param tPos Position in the species tree
    /// @param ageParm Reference to owning age parameter.
    static AgePriorNode * Factory  ( Replicate &            repl,
				     const Tree::Position & tPos,
				     Parameter &            ageParm );

};

#endif // _AGEPRIOR_H_
