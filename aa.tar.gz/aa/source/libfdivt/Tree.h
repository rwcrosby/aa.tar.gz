/// @file Tree.h
/// Structures associated with the trees in both the factory and the replicates.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _TREE_H_
#define _TREE_H_

#include <cassert>
#include <list>
#include <map>

#include "Config.h"

struct AgePriorRoot;
struct EvoModel;
struct EvoModelRoot;
struct Locus;
struct Likelihood;
class  Logger;
struct IOutputFile;
struct Parameter;
struct RatesPriorRoot;
struct RatesPriorNode;
struct Replicate;
struct Taxa;
struct TransitionMatrix;

namespace Calibration {
    struct Data;
}

namespace Tree {

    struct Dfs;
    struct Init;
    struct LocusDfs;
    struct LocusNode;
    struct LocusRoot;
    struct Node;
    struct Path;
    struct Position;
    struct PositionHash;
    struct Root;
    struct Site;
    struct TraceInfo;
    enum class TraceType  : unsigned char;
    struct TreeNode;

    typedef FLOAT  (*DATASRC) ( TraceInfo * ti );

    typedef std::vector<LocusNode>     LNODEVEC;
    typedef std::vector<LocusNode *>   LNODEPVEC;
    typedef std::vector<Node *>        NODEPVEC;
    typedef std::vector<LocusNode>     LNODEVEC;
    typedef std::vector<LocusNode *>   LNODEPVEC;
    typedef std::vector<Site>          SITEVEC;
    typedef std::list<TraceInfo *>     TRACEPLIST;
    typedef std::vector<TreeNode>      TNODEVEC;


}

// *****************************************************************************
/// Species tree traversal.
/// Subclass this class to perform a search on a tree (or subtree).
/// This isn't an abstract class (or interface) since the user might not want to
/// define all the available methods.

struct Tree::Dfs {

    enum RC {
	/// Continue processing normally.
	CONTINUE,
	/// Discontinue downward traversal but continue overall procesing.
	STOPDOWN,
	/// Cancel DFS completely
	CANCEL
    };

    /// Hit an inner node for the first time on the way down the tree.
    /// @param tPos Current tree position
    /// @return Continuation status.
    virtual RC InnerBegin ( const Position & tPos )
	{
	    return CONTINUE;
	}

    /// After processing all children before popping.
    /// @param tPos Current tree position
    /// @return Continuation status.
    virtual RC InnerEnd   ( const Position & tPos )
	{
	    return CONTINUE;
	}

    /// Hit a leaf.
    /// @param tPos Current tree position
    /// @return Continuation status.
    virtual RC Leaf       ( const Position & tPos )
	{
	    return CONTINUE;
	}

    /// Hit the root node for the first time on the way down the tree.
    /// @param root Current tree position
    /// @return Continuation status.
    virtual RC RootBegin ( Root & root )
	{
	    return RC::CONTINUE;
	}

    /// After processing all children before ending.
    /// @param root Current tree position
    /// @return Continuation status.
    virtual RC RootEnd   ( Root & root )
	{
	    return CONTINUE;
	}

    /// Perform the search
    /// @param startPos Reference to a tree position
    virtual void operator()(const Position & startPos);

    /// Perform the search
    /// @param p Pointer to a tree position
    virtual void operator()(const Position * const p)
	{
	    (*this)(*p);
	}

    /// Perform the search
    /// @param r Reference to a tree root
    virtual void operator()(Root & r);

    /// Perform the search
    /// @param r Pointer to a tree root
    virtual void operator()(Root * const r)
	{
	    (*this)(*r);
	}

};

// *************************************************************************
/// Initialization structure for a species tree node
/// This is kept separate from the node and will only exist in the tree factory
/// not in the replicates.

struct Tree::Init {

    /// Constructor chaining this to the parent vertex instance
    Init( const Node &         node )
	: _node(node)
	{}

    const Node & _node;                       ///< Parent tree node

    /// Taxa set key string used for the hash to determine
    /// common subtrees.
    std::string  _key;

    /// Low taxa in in the current subtree
    unsigned     _txId;

    /// Locus initialization data used to build the site maps
    struct LInit {

	/// Ordered (by taxa id) vector of taxa for this node.
	std::vector<Taxa*>          _taxaVec;

	/// Mapping of keys to site data vector elements.
	std::map<UCHARVEC, Site *>  _siteMap;

    };

    std::vector< LInit > _locusVec;

};

// *****************************************************************************
/// Gene tree traversal.
/// Subclass this class to perform a search on a gene tree (or subtree).
/// This isn't an abstract class (or interface) since the user might not want to
/// define all the available methods.

struct Tree::LocusDfs {

    enum RC {
	/// Continue processing normally.
	CONTINUE,
	/// Discontinue downward traversal but continue overall procesing.
	STOPDOWN,
	/// Cancel DFS completely
	CANCEL
    };

    /// Hit an inner node for the first time on the way down the tree.
    /// @param lNode Current locus node
    /// @return Continuation status.
    virtual RC InnerBegin ( LocusNode & lNode )
	{
	    return CONTINUE;
	}

    /// After processing all children before popping.
    /// @param lNode Current locus node
    /// @return Continuation status.
    virtual RC InnerEnd   ( LocusNode & lNode )
	{
	    return CONTINUE;
	}

    /// Hit a leaf.
    /// @param lNode Current locus node
    /// @return Continuation status.
    virtual RC Leaf       ( LocusNode & lNode )
	{
	    return CONTINUE;
	}

    /// Hit the root node for the first time on the way down the tree.
    /// @param lNode Current locus node (true root)
    /// @return Continuation status.
    virtual RC RootBegin ( LocusNode & lNode )
	{
	    return RC::CONTINUE;
	}

    /// After processing all children before ending.
    /// @param lNode Current locus node (true root)
    /// @return Continuation status.
    virtual RC RootEnd   ( LocusNode & lNode )
	{
	    return CONTINUE;
	}

    /// Perform the search
    /// @param lNode Reference to a locus node
    virtual void operator()( LocusNode & lNode );

    /// Perform the search
    /// @param p Pointer to a locus node
    virtual void operator()( LocusNode * const p )
	{
	    (*this)(*p);
	}

    /// Perform the search
    /// @param r Reference to a gene tree root
    virtual void operator()(LocusRoot & r);

    /// Perform the search
    /// @param r Pointer to a gene tree root
    virtual void operator()(LocusRoot * const r)
	{
	    (*this)(*r);
	}

};

// *************************************************************************
/// Per locus block.
/// These comprise the nodes in the gene trees.
/// One of these exists for each locus in each species tree node.

struct Tree::LocusNode {

    /// Just set the "required" fields. Used in the tree factory
    LocusNode ( LocusRoot &       lRoot,      ///< Owning gene tree root
		TreeNode * const  tNode,	  ///< Owning species tree node
		LocusNode * const parent      ///< Gene tree parent of this node
	);

    /// Copy constructor used in replication
    LocusNode ( const LocusNode & lNode,      ///< Old node reference
		LocusRoot &       lRoot,      ///< Owning gene tree root
		TreeNode * const  treeNode	  ///< Owning species tree node
	);

    /// Move constructor used if the block requires reallocation.
    /// Note the incoming reference can't be const since the unique ptr in the source
    /// needs to be changed.
    LocusNode ( LocusNode && locus );

    /// Make sure it doesn't try to copy one.
    LocusNode ( const LocusNode & locus ) = delete;

    /// Needs a virtual method for typeid to work
    virtual
    ~LocusNode();

    const LocusRoot *
    AsRoot()
	const;

    inline
    bool
    IsInner()
	const
	{
	    return !IsLeaf() && !IsRoot();
	}

    inline
    bool
    IsLeaf()
	const
	{
	    return !_children.size();
	}

    inline
    bool
    IsRoot()
	const
	{
	    return !_parent;
	}

    /// Find the sibling of the current node.
    LocusNode *
    Sibling()
	const
        {
            assert (_parent && "Tree::LocusNode::Sibling");
            auto & cVec = _parent->_children;
            assert(cVec.size() == 2 && "Tree::LocusNode::Sibling");
            return cVec[0] == this
                ? cVec[1]
                : cVec[0];
        }

    /// Generate the dump string for the object.
    std::string
    str ( const std::string hdg = "" )
	const;

    /// Update the transition matrix at this node.
    /// Safe for roots and missing nodes.
    void
    UpdateTMatrix ();

    /// Pointer to the locus root instance.
    /// Note this might not be the actual root of the gene tree in cases where
    /// the root has been restricted due to the taxa set. _locusRoot._trueRoot
    /// will always point to the correct gene tree root.
    LocusRoot &                        _lRoot;

    /// Empty in LocusRoot instances. Populated in all other cases including if this
    /// is a LocusNode that is the true root of the gene tree.
    TreeNode * const                   _tNode;

    /// Indicates that for this tree node there is no locus data for this loci.
    /// This is used to handle the differences between species and gene trees.
    bool                               _missing;

    /// Indicates if this node is the left child of it's parent.
    /// Not relevant for gene tree roots.
    bool                               _isLeftChild;

    /// Pointer to the gene tree parent, if null this is the true root of the gene tree.
    LocusNode *                        _parent;

    /// Pointers to the gene tree children. Empty if this is a leaf
    LNODEPVEC                          _children;

    /// Vector of the sequence sites, this actually appears in the Tree::Node since
    /// the same vector will appear in every tree that has the Tree::Node.
    SITEVEC *                          _siteVec;

    /// Rate parameter for non-root nodes in the non-clock models.
    /// Not valued otherwise.
    Parameter *                        _rateParm;

    /// Rate parameter to use for this node.
    /// Will either point to the mean rates parm on the gene tree root or the rate parm
    /// in this node. Will always be valued.
    Parameter *                        _rateParmToUse;

    /// Node age parameter to use for this node.
    /// Will either point to the age parm of the root or the the one in the tree node.
    /// Not valued in leaf nodes.
    Parameter *                        _ageParmToUse;

    /// Each inner and leaf node in the gene trees will have a transition probability matrix.
    /// The field will not be populated for root nodes.
    TransitionMatrix *                 _tMatrix;

    /// Pointer to the likelihood functor for this node.
    /// Will only be populated for inner and root nodes as there is no
    /// computation done on the leaves.
    Likelihood *                       _lkh;

    /// Rate prior at the node
    RatesPriorNode *                   _lnPR;

};

// *************************************************************************
/// Additional data and methods associated with the root of a gene tree.

struct Tree::LocusRoot : LocusNode {

    typedef std::vector<LocusRoot> VEC;           ///< A Vector of these

    /// Constructor to set the root.
    LocusRoot( Root &  root,                      ///< Reference to specied tree root
	       Locus & locus		          ///< Associated locus block
	);

    /// Copy constructor used during replication
    LocusRoot ( const LocusRoot & locusRoot,      ///< Old block to copy
		Root &            root            ///< New tree root
	);

    /// Move constructor used if the block requires reallocation.
    /// Shouldn't actually be called. We should always know the
    /// number of loci in advance so vectors of these can be pre-allocated.
    /// Note the incoming reference can't be const since the unique ptr in the source
    /// needs to be changed.
    LocusRoot( LocusRoot && lr);

    /// Make sure it doesn't try to generate a default copy constructor.
    LocusRoot( const LocusRoot & lr ) = delete;

    virtual
    ~LocusRoot();

    LocusNode &
    AsNode()
	{
	    return static_cast<LocusNode&>(*this);
	}

    /// Generate the dump string for the object
    std::string
    str ( const std::string hdg = "" )
	const;

    Root &                         _root;           ///< Species tree root
    Locus &                        _locus;          ///< Locus information block

    EvoModel *                     _eModel;         ///< Evolutionary model instance

    Parameter *                    _ratesMeanParm;  ///< Rates locus mean
    Parameter *                    _ratesVarParm;   ///< Rates locus variance

    /// The true root of the gene tree since this node might not actually appear
    /// in the current gene tree. Will point back to this node in the case
    /// wherte this actually the gene tree root.
    LocusNode *                    _trueRoot;

    /// Log likelihood functor for the gene tree.
    Likelihood *                    _lkh;

    /// Rate prior at the gene tree root
    RatesPriorRoot *               _rLnPR;

    // Metrics on the locus sites

    unsigned                       _nInnerNodes;  ///< Number of inner nodes
    unsigned                       _nSeqSites;    ///< Sites in the alignment
    unsigned                       _nRootSites;	  ///< Site entries at root
    unsigned                       _nTotalSites;  ///< Total sites in tree

};

// *************************************************************************
/// An inner or leaf node in the species tree.
/// Also the superclass for the species tree root node.

struct Tree::Node {

    /// A child here is a node pointer and the vector of new tree indicies
    /// for each associated tree
    typedef std::pair<Node*, UINTVEC> CHILD;

    /// Vector of children
    typedef std::vector<CHILD>        CHILDREN;

    /// Empty constructor not allowed
    Node() = delete;

    /// Constructor setting up the initialization data and taxa pointer (if a leaf).
    /// Used during factory construction only
    Node( Taxa * const taxa );

    /// Copy constructor used during replication only.
    Node( const Node & node,
	  Replicate &  repl);

    /// Define a move constructor that shouldn't be called.
    Node( const Node && v);

    /// Destrtuctor removing any remaining init elements
    virtual
    ~Node();

    /// Cast this to be a root.
    Root &
    AsRoot();

    /// Return whether this is an inner node.
    bool
    IsInner()
	const
	{
	    return !_taxa && !IsRoot();
	}

    /// Return whether this is a leaf node.
    bool
    IsLeaf()
	const
	{
	    return _taxa;
	}

    /// Return whether this is a root node.
    bool
    IsRoot()
	const;

    /// Return the memory for the Tree, Locus and Site vectors
    void
    VecSize( unsigned & longTreeVec,
	     unsigned & treeMem,
	     unsigned & locusMem,
	     unsigned & siteMem )
	const;

    /// Generate the dump string for the object
    virtual
    std::string
    str ( const std::string hdg = "" )
	const;

    /// Generate the dump string for list of child pointers
    static
    std::string
    str ( const CHILDREN &  c,
	  const std::string hdg = "" );

    /// Generate the dump string for a child pointer
    static
    std::string
    str ( const CHILD &     c,
	  const std::string hdg = "" );

    /// Sequential, unique id for the node
    unsigned               _id;

    /// Set of tree positions for the children of this node.
    CHILDREN               _children;

    /// The taxa pointer will only be populated if this is a leaf;
    Taxa * const           _taxa;

    /// Vector of site data vectors, one for each locus
    std::vector< SITEVEC > _locusSiteVec;

    /// Vector of per tree information indexed by the current treePos.
    TNODEVEC               _treeVec;

    /// Pointer to the initialization structure for this vertex.
    /// This data is separate from the taxa itself as it isn't
    /// present in the replicates.
    Init *                 _init;

};

// *****************************************************************************
///  Define a path in a specific species tree.

struct Tree::Path : std::list<Position> {

    /// Construct a path. The top position is closest to the root.
    Path( const Position & top,
	  const Position & bottom );

    /// Return the branch length along the path.
    /// Note this branch length is just based on the values in the
    /// species tree which are only set from the input trees.
    /// This doesn't reflect the branch lengths being estimated in the
    /// mcmc process that are held in the transition probability matrixes.
    FLOAT  BrLen    ();

    /// Return the difference in times along the path.
    FLOAT  DeltaAge ();

};

// *************************************************************************
/// Tuple to track the position in a specific species tree.

struct Tree::Position {

    /// Construct an empty object
    Position()
	: _node(nullptr),
	  _treeIdx(0)
	{}

    /// Constructor from a pointer
    Position( Node *  n,
	      unsigned ti )
	: _node(n),
	  _treeIdx(ti)
	{}

    /// Constructor from a reference
    Position( Node &  n,
	      unsigned ti )
	: _node(&n),
	  _treeIdx(ti)
	{}

    /// Constructor from a root
    Position( Root & r );

    /// Copy constructor from a pointer to a position
    Position( const Position * tPos )
	: _node(tPos->_node),
	  _treeIdx(tPos->_treeIdx)
	{}

    /// Copy constructor from a reference to a position
    Position( const Position & tPos )
	: _node(tPos._node),
	  _treeIdx(tPos._treeIdx)
	{}

    /// Allow equality comparison between positions
    bool operator== (const Position & tp) const
	{
	    return _node == tp._node && _treeIdx == tp._treeIdx;
	}

    /// Allow inequality comparison between positions
    bool operator!= (const Position & tp) const
	{
	    return _node != tp._node || _treeIdx != tp._treeIdx;
	}

    /// Less than operator needed for map usage
    bool operator<  ( const Position &tp ) const
	{
	    return _node < tp._node || (_node == tp._node && _treeIdx < tp._treeIdx);
	}

    /// Assign from another position
    Position & operator=( const Position & tp )
	{
	    _node = tp._node;
	    _treeIdx = tp._treeIdx;
	    return *this;
	}

    /// Return the vertex as a root node
    Root &  AsRoot  () const;

    /// Return the tree node instance for a tree or fail
    TreeNode & AsTNode() const;

    /// Return the age associated with this tree position
    FLOAT   Age     () const;

    /// Return the branch length associated with the tree position.
    FLOAT   BrLen   () const;

    /// Is this an empty position
    bool    Empty   () const;

    /// Return a reference to the calibrations list
    std::list<Calibration::Data*> & GetCalList() const;

    /// Is this an inner node?
    bool    IsInner () const;

    /// Is this a leaf node?
    bool
    IsLeaf  () const;

    /// Is this a root node?
    bool
    IsRoot  () const;

    /// Return a reference to the root for this position
    Root &
    GetRoot () const;

    /// Step up the tree toward the parent.
    /// @return false if already at the root
    /// @param tpOut Output parameter to receive the position block
    bool
    Parent  ( Position & tpOut ) const;

    /// Generate the dump string for the object.
    std::string
    str ( const std::string hdg = "" ) const;

    typedef std::vector<Position> VEC;	  ///< A vector of these
    typedef std::list<Position>   LIST;	  ///< A list of these

    Node *   _node;			          ///< Target vertex
    unsigned _treeIdx;                        ///< Tree index at the vertex

};

// *****************************************************************************
/// Hash functor for Position objects to allow unordered map usage.

struct Tree::PositionHash {

    std::size_t operator()(const Position& tPos) const
	{
	    return std::hash<std::size_t>()((std::size_t)tPos._node ^ (tPos._treeIdx << 24));
	}

};

// *************************************************************************
/// Additional data and methods associated with the root of a species tree.

struct Tree::Root : Node {

    /// List of attributes returned by the attribute functions.
    typedef std::list< std::pair<std::string, std::string> > AttrList;

    /// Type of the attribute function used in generating newick strings.
    typedef void   (*AttrFn) ( AttrList &     aList,
			       const Position tPos );
    /// Type of the branch length function used in generating branch lengths.
    typedef FLOAT  (*BrLenFn)( const Position tPos );

    /// Standard constructor.
    Root( const std::string& label,           ///< Label for the tree
	  const unsigned     rootIdx,         ///< Index for this root in the tree set
	  unsigned           lc               ///< Number of loci
	);

    /// Copy constructor (sort of) use to generate replicates.
    Root (const Root & r,                    ///< Root object in built DAG.
	  Replicate &  repl                  ///< Owning replicate
	);

    /// Dummy copy constructor - should not be called
    Root (const Root & r);

    /// Dummy Move constructor in case vector decides to reallocate things
    Root (const Root && r);

    /// Destructor for a tree root.
    virtual
    ~Root();

    /// Print a tree to the log as a newick string.
    /// The tree is intentionally output as a single line to allow easy cut and paste
    /// into another file for use by something like figtree.
    void
    Log ( Logger & logger );

    /// Generate a newick string for the tree.
    /// Set of attributes and branch length are provided by the user
    /// functions passed.
    /// @param attrFn Function to generate node attributes
    /// @param brLenFn Function to generate node branch length
    /// @param useLabels Output labels or id's?
    std::string
    NewickString ( AttrFn  attrFn,
		   BrLenFn brLenFn,
		   bool    useLabels=true);

    /// Equality is defined as the root indicies being equal
    bool
    operator==(const Root & r)
	{
	    return r._rootIdx == _rootIdx;
	}

    /// Output the dump string for the root.
    virtual
    std::string
    str ( const std::string hdg = "" ) const;

    const std::string            _label;          ///< Name for the tree
    const unsigned               _rootIdx;        ///< Position of the tree in the set (rid)

    std::list<Calibration::Data*>_calList;        ///< Calibrations at the root

    LocusRoot::VEC               _locusVec;       ///< Set of loci data objects

    EvoModelRoot *               _eModel;	  ///< Evolutionary model at the root

    // parameter *                  _mixParm;        ///< Mixing parameter
    Parameter *                  _ageParm;        ///< Root age parameter

    unsigned                     _nLeaves;	  ///< Number of leaves in the tree

    FLOAT                        _sumRatesMean;   ///< Sum of the rates means for all genes
    FLOAT                        _sumRatesVar;    ///< Sum of the rates variances for all genes

    Likelihood *                 _lkh;		  ///< Likelihood function for the tree
    AgePriorRoot *               _lnPA;	          ///< Prior of the ages for this tree
    FLOAT                        _lnPR;           ///< Prior of rates (only updated in InitialValues and OutputTrac)
    FLOAT                        _lnPN;	          ///< Prior of the nuisance parameters

    Likelihood *                 _lkhNode;	  ///< Likelihood function for the root node

    IOutputFile *                _sampleFile;     ///< Sampled trees output
    IOutputFile *                _traceFile;      ///< Trace record output
    IOutputFile *                _finalTreeFile;  ///< Final dated tree output
    IOutputFile *                _detailFile;     ///< Parameter detail output

    TRACEPLIST                   _traceList;	  ///< Trace blocks for all outputs
                                                  ///< Owns the traceinfo memory.
};

// *************************************************************************
/// Per site block.
/// One of these exists for each unique site pattern of the taxa below
/// the node that owns this block.

struct Tree::Site {

    /// Constructor to initialize vectors, used when building the facroty
    Site( const unsigned idx,                     ///< Index for this element
	  const unsigned lhs,                     ///< Left side index
	  const unsigned rhs                      ///< Right side index
	);

    /// Copy constructor used when building the replicates
    Site( const Site & s                          ///< Factory entry to copy
	);

    /// Generate the dump string for the object.
    std::string
    str ( const std::string hdg = "" )
	const;

    const unsigned  _idx;                         ///< Index of this element in the site data vector.
    unsigned        _count;	                  ///< Number of repeats of this site pattern.
    const unsigned  _lhs;                         ///< Index for left child
    const unsigned  _rhs;                         ///< Index for right child

};

// *****************************************************************************
/// Info block for each item in the outputs.
/// Only exists in the replicates.

struct Tree::TraceInfo {

    TraceInfo( Root      &       root,
	       Parameter *       parm,
	       TraceType         type,
	       DATASRC           dSource,
	       int               lId,
	       int               nId,
	       unsigned          idx,
	       const std::string label,
	       const std::string heading );

    virtual ~TraceInfo()
	{
	    delete _values;
	}

    /// Compute the various statistical fields.
    void ComputeStats ();

    TraceType    _type;				  ///< Type of item.

    Root &       _root;				  ///< Owning species tree
    Parameter *  _parm;				  ///< Associate parameter (parm types only).

    DATASRC      _dSource;			  ///< Function to get data for item.

    /// Type of the sort key.
    /// 1). Type code as shown in Type enum
    /// 2). Locus (-1 if no locus)
    /// 3). Nodeid (-1 if no id)
    /// 4). Key string (e.g. "Freq_T) from label
    typedef std::tuple<TraceType, int, int, std::string> KEY;

    KEY          _key;				  ///< Item sort key
    unsigned     _idx;				  ///< Index for multi-valued items
    std::string  _label;			  ///< Label for trace files
    std::string  _heading;			  ///< Heading for trace files

    FLOAT        _sum;				  ///< Sum of values for all samples
    FLOAT        _mean;				  ///< Mean of sampled values
    FLOAT        _median;			  ///< Median of sampled values
    FLOAT        _stdDev;			  ///< Standard deviation of sampled values
    FLOAT        _ci975;			  ///< 95% confidence interval
    FLOAT        _ci025;			  ///< 95% confidence interface

    FLOATVEC *   _values;			  ///< Value list used during summarization.

};

// *************************************************************************
/// Type of trace outputs, used as part of the sort key.

enum class Tree::TraceType : unsigned char {
    Posterior,
    Likelihood,
    AgePrior,
    AgeParm,
    RatePrior,
    RateParm,
    NuisancePrior,
    NuisanceParm
};

// *************************************************************************
/// Per tree block.
/// One of these exists for each tree that is includes a given node (leaf or
/// inner node).

struct Tree::TreeNode : Position {

    typedef std::vector<TreeNode> VEC;	          ///< A vector of these


    /// Constructor setting back pointers and vector sizes
    TreeNode ( Root &         root,		  ///< Owning species tree
	       const Position node,		  ///< Owning species tree node/index
	       const unsigned nLoci,              ///< Total number of loci
	       const FLOAT    brLen               ///< Branch length leading into this node
	);

    /// Constructor used during replication.
    /// Creates a copy of the calibration data but not the locus vector.
    TreeNode ( const TreeNode & tn,
	       Tree::Node *     newNode,
	       Root &           newRoot,
	       Node *           newParentNode,
	       Replicate &      repl );

    /// Move constructor used if the containing vector is reallocated.
    /// This one will actually be used since we can't predict the number of trees
    /// in the factory. Note the incoming reference can't be const since the
    /// unique ptr in the source tree block needs to be changed.
    TreeNode ( TreeNode && tree );

    /// Make sure the compiler doesn't try to create a default copy constructor.
    TreeNode ( const TreeNode & ti ) = delete;

    ~TreeNode();

    /// Generate the dump string for the object.
    std::string
    str ( const std::string hdg = "" ) const;

    Root &                        _root;	  ///< Owning tree
    Position                      _parent;        ///< Parent vertex/index
    Parameter *                   _ageParm;       ///< Species tree node age
    std::list<Calibration::Data*> _calList;       ///< Calibrations for this tree/node
    LNODEVEC                      _locusVec;      ///< Per locus data indexed by locus id
    Likelihood *                  _lkh;		  ///< Likelihood function for the node
    FLOAT                         _brLen;	  ///< Branch length as input or calculated

};

// *************************************************************************
// inline methods moved here to allow the structures to be ordered properly

inline
void
Tree::Dfs::operator()(Root & r)
{
    (*this)(Position(r,0));
}

inline
void
Tree::LocusDfs::operator()(LocusRoot & r)
{
    (*this)(*r._trueRoot);
}

inline
const Tree::LocusRoot *
Tree::LocusNode::AsRoot() const
{
    return static_cast<const LocusRoot*>(this);
}

inline
bool
Tree::Node::IsRoot() const
{
    return typeid(*this) == typeid(Root);
}

inline
Tree::Root &
Tree::Node::AsRoot()
{
    return *static_cast<Root*>(this);
}

inline
Tree::Position::Position( Root & r )
    : _node(&r),
      _treeIdx(0)
{}

inline
Tree::Root &
Tree::Position::AsRoot() const
{
    return _node->AsRoot();
}

inline
Tree::TreeNode &
Tree::Position::AsTNode() const
{
    assert(!IsRoot() && "Attempt to get tree node for root");
    return _node->_treeVec[_treeIdx];
}

inline
FLOAT
Tree::Position::BrLen () const
{
    return IsRoot()
	? 0.0
	: _node->_treeVec[_treeIdx]._brLen;
}

inline
bool
Tree::Position::Empty () const
{
    return _node == nullptr;
}

inline
std::list<Calibration::Data*> &
Tree::Position::GetCalList() const
{
    return IsRoot()
	? AsRoot()._calList
	: AsTNode()._calList;
}

inline
Tree::Root &
Tree::Position::GetRoot() const
{
    return IsRoot()
	? AsRoot()
	: AsTNode()._root;
}

inline
bool
Tree::Position::IsInner () const
{
    return _node->IsInner();
}

inline
bool
Tree::Position::IsLeaf ()  const
{
    return _node->IsLeaf();
}

inline
bool
Tree::Position::IsRoot ()  const
{
    return _node->IsRoot();
}

inline
bool
Tree::Position::Parent ( Position & tpOut ) const
{
    if ( IsRoot() ) {
	tpOut._node  = _node;
	tpOut._treeIdx = _treeIdx;
	return false;
    }

    tpOut = _node->_treeVec[_treeIdx]._parent;
    return true;
}

inline
FLOAT
Tree::Path::BrLen ()
{
    FLOAT  bl = 0.0;
    for ( auto riter = rbegin(); riter != --rend(); ++riter )
	bl += riter->BrLen();
    return bl;
}

inline
FLOAT
Tree::Path::DeltaAge ()
{
    return front().Age() - back().Age();
}

#endif // _TREE_H_
