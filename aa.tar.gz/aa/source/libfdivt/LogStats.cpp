/// @file LogStats.cpp
/// Implementation of the log stat methods

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include <string>

#include "LogStats.h"

using namespace std;

// *****************************************************************************
/// Write a stats block to output.

/// This is a private method. the decision whether to do the logging is made
/// by the inline log method.

void
LogStats::_DoLogging( STATSLIST& stats )          ///< List of statistics to output
{

    if ( !_logFlag ) return;

    _logger.Log("");
    unsigned indent = 0;
    if (_title.length()) {
	_logger.Log("%s", _title.c_str());
	indent = Logger::indent;
    }

    unsigned width = 0;
    for ( auto si : stats )
	if ( si.first.length() > width )
	    width = si.first.length();

    width = width < Logger::minWidth ? Logger::minWidth : width;

    for ( auto si : stats )
	_logger.Log("%*s%-*s: %10u", indent, " ", width, si.first.c_str(), *si.second);

}
