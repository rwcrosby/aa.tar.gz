/// @file FDivT.cpp
/// Contains the functions that are be exposed through the shared library.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include "DivTime.h"
#include "FDivT.h"

// *****************************************************************************
// Create a div time object and return the IDivTime interface pointer

IDivTime *
CreateDivTimeObject( void )
    throw( Except::PerfError )
{

    DivTime * dt = new DivTime();

    return static_cast<IDivTime*>(dt);

}

// *****************************************************************************
// Delete the divergence time object referenced by the interface provided

void
FreeDivTimeObject( IDivTime * dt)
{

    delete dynamic_cast<DivTime*>(dt);

}
