/// @file ITransaction.h
/// Interface to provide commit and rollback of proposals.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _ITRANSACTION_H_
#define _ITRANSACTION_H_

// *****************************************************************************
/// Simple interface to rollback or commit the last changes to an object.
/// Part of the transactional interface that handles rejecting and acception proposals.
/// This interface will be implemented by any object that is capable of restoring
/// it's state on an rejected proposal or needs to do something if a proposal is
/// accepted.

struct ITransaction {

    /// Roll this object's updates back.
    virtual void Rollback() = 0;

    /// Commit this object's updates.
    virtual void Commit() = 0;

};

#endif // _ITRANSACTION_H_
