/// @file AgeParameter.cpp
/// Definitions for the age parameter methods.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include <iostream>
#include "AgeParameter.h"
#include "AgePrior.h"
#include "DivTime.h"
#include "Dump.h"
#include "Likelihood.h"
#include "Options.h"
#include "Parameter.h"
#include "ParmStats.h"
#include "RatesPrior.h"
#include "Replicates.h"
#include "StatsFn.h"
#include "Tree.h"

// *****************************************************************************
/// Base class for the age parameters.

struct AgeParameter : Parameter {

    AgeParameter( Replicate  &           repl,    ///< Chain or jackknife replicate.
		  const Tree::Position & tPos )   ///< Owning tree node
	: Parameter(repl, tPos.GetRoot(), ParmStats::AGE ),
	  _tPos(tPos),
	  _lnPrior(AgePriorNode::Factory(repl, tPos, *this)),
	  _lkh(tPos.IsRoot()
	       ? tPos.AsRoot()._lkhNode
	       : tPos.AsTNode()._lkh)
	{
	    SetTraceInfo(Tree::TraceType::AgeParm, tPos._node->_id, "Age");
	}

    virtual
    ~AgeParameter()
	{
	    delete _lnPrior;
	}

    virtual
    void
    Accept()
	{
	    _repl._ageAccepted++;
	    Parameter::Accept();
	}

    virtual
    FLOAT
    Propose()
	{
	    _repl.LogRollback(this);
	    Parameter::Propose();
	    return 1.0;
	}

    virtual
    void
    Reject()
	{
	    _repl._ageRejected++;
	    Parameter::Reject();
	}

    virtual
    void
    Rollback()
	{
	    Parameter::Rollback();
	}

    virtual
    std::string
    str()
	const
	{
	    std::stringstream ss;
	    ss << Parameter::str() << ' '
	       << Dump::str(_root._rootIdx, "tid") << ' '
	       << Dump::str(_tPos._node->_id, "nid");
	    return ss.str();
	}

    const Tree::Position _tPos;                   ///< Tree node that owns this parameter.
    AgePriorNode *       _lnPrior;                ///< Prior of the ages for this node
    Likelihood *         _lkh;			  ///< Likelihood functor for this node

};

// *****************************************************************************
/// Age parameter used for the correlated clock mode.
/// For this model the age is used in the computation of the prior of rates.

struct AgeCorrelated : AgeParameter {

    AgeCorrelated( Replicate  &           repl,    ///< Chain or jackknife replicate.
		   const Tree::Position & tPos )   ///< Owning tree node
	: AgeParameter(repl, tPos )
	{
	    _repl._stats._parms[ParmStats::AGE]._mem += sizeof(*this);
	}

    virtual ~AgeCorrelated() {};

    /// Propose a new parameter value.
    /// @return The posterior ratio.
    FLOAT virtual Propose();

    void virtual Rollback()
	{}

};

// *****************************************************************************
/// Age parameter used for models other than the correlated clock.
/// these models dont' use the age in the rates prior.

struct AgeNonCorrelated : AgeParameter {

    AgeNonCorrelated( Replicate  &           repl,    ///< Chain or jackknife replicate.
		      const Tree::Position & tPos )   ///< Owning tree node
	: AgeParameter(repl, tPos )
	{
	    _repl._stats._parms[ParmStats::AGE]._mem += sizeof(*this);
	}

    virtual ~AgeNonCorrelated() {};

    FLOAT virtual Propose();

    void virtual Rollback()
	{}

};

// *****************************************************************************

Parameter *
Ages::Factory ( Replicate &            repl,
		const Tree::Position & tPos )
{

    Parameter * p;

    if ( repl._dt._cModel == Options::ClockModel::CORRELATED )
	p = new AgeCorrelated ( repl, tPos );
    else
	p = new AgeNonCorrelated ( repl, tPos );

    return p;
}

// *****************************************************************************

FLOAT
AgeCorrelated::Propose( void )
{

    REPRENTER(Dump::pstr(&_tPos, "tPos"));

    /// - Setup to rollback if the proposal is rejected.
    AgeParameter::Propose();

    /// - Draw a new value for the parameter

    FLOAT oldLnValue = log(_value);
    FLOAT newLnValue = oldLnValue + Finetune::ages * _repl._statsObj->DrawNormalMix();
    _value            = exp(newLnValue);

    REPRDEBUG(Dump::str(_value, "New value"));

    /// - Compute the new likelihood and prior

    FLOAT lnLRatio = _lkh->Compute();
    _lnPrior->NewAge();

    /// - Compute the prior for the node rates.
    ///   Loop through the locus nodes updating the constant and prior

    if ( _tPos.IsRoot() )
	for ( auto & lRoot : _tPos.AsRoot()._locusVec ) {
	    if ( !lRoot._missing )
		lRoot._lnPR->NewAge();
	}
    else
	for ( auto & lNode : _tPos.AsTNode()._locusVec ) {
	    if ( !lNode._missing)
		lNode._lnPR->NewAge();
	}

    /// - Look back through the locus roots collecting the prior ratios

    FLOAT priorRatio = 0.0;
    for ( auto & lRoot : _root._locusVec )
	priorRatio += lRoot._rLnPR->PriorRatio();

    /// - Return the proposal ratio as
    ///   \f$\Delta \textrm{likelihood} + \Delta \textrm{age prior}  + \Delta \textrm{rates prior} + \Delta \textrm{value}\f$

    priorRatio += lnLRatio +
  	          _root._lnPA->PriorRatio() +
	          newLnValue - oldLnValue;

    REPREXIT( Dump::pstr(&_tPos, "tPos"),
	      Dump::str(_value, "value"),
	      Dump::str(priorRatio, "priorRatio"),
	      Dump::str(lnLRatio, "lnLRatio"),
	      Dump::str(_root._lnPA->PriorRatio(), "_lnPA->PriorRatio"),
	      Dump::str(newLnValue, "newLnValue"),
	      Dump::str(oldLnValue, "oldLnValue") );

    return priorRatio;

}

// *****************************************************************************

FLOAT
AgeNonCorrelated::Propose( void )
{
    REPRENTER(Dump::pstr(&_tPos, "tPos"));

    /// - Setup to rollback if the proposal is rejected.
    AgeParameter::Propose();

    /// - Draw a new value for the parameter

    FLOAT oldLnValue = log(_value);
    FLOAT newLnValue = oldLnValue + Finetune::ages * _repl._statsObj->DrawNormalMix();
    _value            = exp(newLnValue);

    /// - Compute the new likelihood and prior

    FLOAT lnLRatio = _lkh->Compute();
    _lnPrior->NewAge();

    /// - Return the proposal ratio as
    ///   \f$\Delta \textrm{likelihood} + \Delta \textrm{age prior}  + \Delta \textrm{rates prior} + \Delta \textrm{value}\f$

    FLOAT priorRatio = lnLRatio +
  	               _root._lnPA->PriorRatio() +
	               newLnValue - oldLnValue;

    REPREXIT( Dump::str(_value, "value"),
	      Dump::str(priorRatio, "priorRatio"),
	      Dump::str(lnLRatio, "lnLRatio"),
	      Dump::str(_root._lnPA->PriorRatio(), "agePriorRatio"),
	      Dump::str(newLnValue, "newLnValue"),
	      Dump::str(oldLnValue, "oldLnValue") );

    return priorRatio;

}
