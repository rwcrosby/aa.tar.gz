/// @file DivTime.cpp
/// Main divergence time module hold definitions for the functions in the
/// external interface

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include <chrono>
#include <ctime>
#include <cstdlib>
#include <iomanip>

#define GENOPTINFO

#include "Calibration.h"
#include "CalibrationFactory.h"
#include "DivTime.h"
#include "Dump.h"
#include "Environ.h"
#include "EvoModel.h"
#include "Except.h"
#ifdef OPENCL
#include "GpuInterface.h"
#endif
#include "Graphviz.h"
#include "HashStats.h"
#include "HashTable.h"
#include "InitValuesBrLen.h"
#include "Likelihood.h"
#include "Locus.h"
#include "Logger.h"
#include "OptionsInit.h"
#include "OutputManager.h"
#include "Replicates.h"
#include "PerfInterface.h"
#include "StatusPrinter.h"
#include "SequenceFactory.h"
#include "StepProcessor.h"
#include "Summarizer.h"
#include "Taxa.h"
#include "ThreadSet.h"
#include "Tree.h"
#include "TreeFactory.h"
#include "TreeSampler.h"
#include "TreeStats.h"

// *****************************************************************************
/// Constructor for the divergence time controlling object.
/// @throw PerfError Error returned from performance interface.

DivTime::DivTime( void )
    throw ( Except::PerfError )
    : _logger     (new Logger         ()),
      _perfIntf   (new PerfInterface  (*_logger)),
      _hashStats  (new HashStats      (*_logger)),
      _treeFactory(new TreeFactory    (*_hashStats,
			 	       _taxaMap,
			 	       _locusVec,
			 	       *_logger)),
      _seqFactory(new SequenceFactory("TCAG", '-', '?'))
{

    /// - Check environment for logging options.
    _logger->Debug(getenv("FDIVT_DEBUG") != 0);
    _perf  = getenv("FDIVT_PERF") != 0;

    /// - Create performance interface if required.
    if ( _perf )
	_perfIntf->Initialize();

    /// - Initialize all the options.
    for ( auto opt : OptionInit )
        if ( opt.second._initFn )
            (*opt.second._initFn)(*this);

    /// - Initialize the evolutionary model
    EvoModelRoot::Default(*this);

    _nThreads   = Environ::Cores();
    _nRuns      = _nThreads;

    _hashStats->LogFlag(_logStats);
}

// *****************************************************************************
/// Destructor for the divergence time controlling object.

DivTime::~DivTime()
{

    /// - Output final statistics.
    _treeFactory.reset(nullptr);
    _hashStats->Log();

    (*_perfIntf)("End Divergence Time Processing");

}

// *****************************************************************************
/// Set any options.

/// Options passed are either added to the option set or override a
/// default or previously set option.

/// @sa IDivTime::SetOptions

/// @throw Except::BadOpt Invalid option passed
/// @throw Except::BadOptValue Invalid option value

void
DivTime::SetOptions( const std::vector<Options::DivOpt*>& opts ) ///< List of options
    throw( Except::BadOpt,
           Except::BadOptValue )
{

    LOGENTER(*_logger, 0, Dump::ptr(this, "dt"));

    // Shouldn't really need the brackets but Visual C++ whines about the try/catch otherwise
    for ( auto opt : opts ) {
        try {
            (*OptionInit.at(opt->type)._setFn)(*this, opt);
        }
        catch (const std::out_of_range & ex) {
	    throw Except::BadOpt(opt->type);
        }
    }

}

// *****************************************************************************
/// Return the whole set of options.

/// The current state of all options (passed and defaults) is returned.
/// The caller is responsible for deleting the vector and all of it's elements.

/// @sa IDivTime::GetOptions

std::vector<Options::DivOpt> *                   ///< @return Pointer to the option set
DivTime::GetOptions( void ) const
{

    auto opts = new std::vector<Options::DivOpt>;
    opts->reserve(static_cast<unsigned>(Options::OptType::NumOptions));

    /// Generate the options from the control table.

    for ( auto key : OptionsOrder )
        if ( key != Options::OptType::NumOptions && (*OptionInit[key]._checkFn)(*this) )
            opts->push_back((*OptionInit[key]._getFn)(key, *this));

    return opts;

}

// *****************************************************************************
/// Display the current setting of all parameters.

/// @sa IDivTime::LogOptions
/// @sa OptionsInit.h

void
DivTime::LogOptions( void ) const
{

    /// @todo Output model information depending on the model. E.G. lambda to JC and not other parms.

    (*_logger)("Options Set:");
    (*_logger)("");

    for ( auto key : OptionsOrder )
        if ( key == Options::OptType::NumOptions )
            (*_logger)("");
        else if ( (*OptionInit[key]._checkFn)(*this) )
            (*_logger)("%-40.40s: %s", OptionInit[key]._caption, (*OptionInit[key]._valueFn)(*this).c_str());

}

// *****************************************************************************
/// Set the evolutionary model and associated parameters.

/// @sa:IDivTime::SetModel

/// @throw Except::ModelError Error in model specification

void
DivTime::SetModel( const Options::EvoModel     eModel,
                   const std::vector<double> & modelParms,
                   const std::vector<double> & freqParms,
                   const unsigned              gammaCats,
                   const std::vector<double> & gammaParms )
    throw(Except::ModelError)
{

    _eModel	  = eModel;
    _eMGammaCats  = gammaCats;

    _eMParms      = modelParms;
    _eMFreqParms  = freqParms;
    _eMGammaParms = gammaParms;

    EvoModelRoot::CheckParms(*this);

}

// *****************************************************************************
/// Add a taxa name.
/// Each taxa must have been added before it's referenced by a sequence or
/// a tree.
/// @throw Except::DuplicateTaxa Guess.
/// @sa IDivTime::AddTaxa

void
DivTime::AddTaxa( const std::string& label)	///< Name of the taxa
        throw( Except::DuplicateTaxa )
{
    LOGENTER(*_logger, 0, Dump::ptr(this,"dt"),
	     Dump::str(unsigned(_taxaMap.size()),"id"),
	     Dump::str(label,"label"));

    auto valPair = _taxaMap.emplace(std::pair<std::string, Taxa>
                                    (std::piecewise_construct,
                                     std::forward_as_tuple(label),
                                     std::forward_as_tuple(label,
                                                           _taxaMap.size())));
    if (!valPair.second)
	throw Except::DuplicateTaxa(label);

    _taxaVec.push_back(&valPair.first->second);
    assert ( _taxaVec.size() == valPair.first->second._id + 1 && "Bad id in taxa object");

}

// *****************************************************************************
/// Add a locus name.
/// Each locus must have been added before it's referenced by a sequence.
/// @throw Except::DuplicateLocus Guess.
/// @sa IDivTime::AddLocus

void
DivTime::AddLocus( const std::string& label) ///< Name of the locus
    throw( Except::DuplicateLocus )

{
    LOGENTER(*_logger, 0, Dump::ptr(this, "dt"),
	     Dump::str(unsigned(_locusMap.size()), "id"),
	     Dump::str(label, "label"));

    auto valPair = _locusMap.emplace(std::pair<std::string, Locus>
                                     (std::piecewise_construct,
                                      std::forward_as_tuple(label),
                                      std::forward_as_tuple(label,
                                                       _locusMap.size(),
                                                       std::ref(*_seqFactory))));

    if (!valPair.second)
	throw Except::DuplicateLocus(label);

    _locusVec.push_back(&valPair.first->second);
    assert ( _locusVec.size() == valPair.first->second._id + 1 && "Bad id in locus object");

}

// *****************************************************************************
/// Add a DNA sequence for a specific taxa at a specific locus.

/// Both the taxa and locus id's need to have been added using their
/// respective calls.

/// @sa IDivTime::AddSequence

/// @throw Except::MissingTaxa Taxa not already added.
/// @throw Except::MissingLocus Locus not already added.
/// @throw Except::InvalidSeqCh Invalid character in sequence.
/// @throw Except::InvalidSeqLength All sequence for locus must be same length.
/// @throw Except::MissingSeq All of the sequence data is missing.

void
DivTime::AddSequence( const std::string& lid,	///< Name of the locus
		      const std::string& tid,	///< Name of the taxa
		      const std::string& seq)	///< DNA sequence
    throw ( Except::MissingTaxa,
            Except::MissingLocus,
            Except::InvalidSeqCh,
            Except::InvalidSeqLength,
            Except::MissingSeq )
{

    LOGENTER(*_logger, 0, Dump::ptr(this, "dt"),
	     Dump::str(tid, "taxa"),
	     Dump::str(lid, "locus"));

    bool gotTaxa = false;

    // Get reference to the taxa object
    try {
	Taxa  & taxa  = _taxaMap.at(tid);
	gotTaxa = true;
	Locus & locus = _locusMap.at(lid);

	// Make the sequence object and associate with the approproiate locus and taxa
	auto * seqObj = _seqFactory->MakeSequence(seq, taxa, locus);

	taxa.AddSequence(seqObj);
	locus.AddSequence(seqObj);

    }
    catch (const std::out_of_range & ex) {
	if ( !gotTaxa )
	    throw Except::MissingTaxa(tid);
	else
	    throw Except::MissingLocus(lid);
    }
}

// *****************************************************************************
/// Add a tree to the set to be dated.

/// The tree will be copied into the FDivT internal structures.
/// The user is free to release the memory after the call returns.

void
DivTime::AddTree( InputTree::Node * const root,	  ///< Root of the tree
                  const std::string&      label ) ///< Identification for the tree
        throw ( Except::MissingTaxa,
                Except::InvalidTree )
{

    LOGENTER(*_logger, 0, Dump::ptr(this, "dt"),
	     Dump::ptr(root, "root"),
	     Dump::str(label, "locus"));
    (*_treeFactory)(root, label);

}

// *****************************************************************************
/// Add a fossil calibration to the set of constraints.

/// The calibration will be used for any tree that contains the clade defined
/// by the set of taxa.

/// The user does not need to specify the entire clade, only enough taxa to
/// uniquely define the MCRA that will locate the calibration are needed.

/// Multiple calibrations for the same node may be entered. This would correspond
/// to the case where there are multiple fossils for a particular ancestor.

/// If the tree specific blocks in the dag haven't been initialized yet, that's
/// done before adding the calibrations.

/// @throw Except::MissingTaxa Taxa not already added
/// @throw Except::BadOpt Invalid option detected
/// @throw Except::BadCalibrationOpt Invalid option detected

void
DivTime::AddCalibration( const std::vector<std::string>&      taxa,   ///< List of taxa comprising the clade
			 const std::vector<Options::CalOpt*>& opts,   ///< Set of options for the calibration
			 const std::string&                   label ) ///< Identification for the calibration point
    throw( Except::MissingTaxa,
           Except::BadOpt,
           Except::BadCalibrationOpt )
{
    LOGENTER(*_logger, 0, Dump::ptr(this, "dt"),
	     Dump::str(label, "label"));

    /// - At least two taxa are required to generate a point in the tree.
    if ( taxa.size() < 2 )
	throw Except::BadOpt("At least 2 taxa are required for a calibration point");

    /// - Validate the set of taxa and convert them to object pointers.
    std::list<Taxa*> taxaObjs;
    for ( auto & tx : taxa ) {
	try {
	    taxaObjs.push_back(&_taxaMap.at(tx));
	}
	catch (const std::out_of_range & ex) {
	    throw Except::MissingTaxa(tx);
	}
    }

    /// - Create the calibration object.
    _calOptList.emplace_back(taxaObjs, opts, label, _calOptList.size());

    /// - Apply to the trees in the dag.
    for ( auto& root : *_treeFactory )
	CalibrationFactory( _calOptList.back(), root, *_treeFactory );

}

// *****************************************************************************
/// Output the current configuration to the log

void
DivTime::LogConfig( GpuInterface * gpuIntf ) const
{

    /// - Log Options
    LogOptions();

#ifdef opencl
    /// - Log GPU information
    if ( gpuIntf )
	gpuIntf->Log();
#endif

    /// - Log Evolutionary Model
    (*_logger)("");
    EvoModelRoot::Log(*this);

    /// -  Dump the taxa
    (*_logger)("");
    (*_logger)("Taxa:");
    for ( auto & txItem : _taxaMap )
	txItem.second.Log(*_logger, *_seqFactory);

    /// -  Dump the loci
    (*_logger)("");
    (*_logger)("Loci:");
    for ( auto& locus : _locusVec )
	locus->Log(*_logger);

    /// -  Dump the calibrations
    (*_logger)("");
    (*_logger)("Fossil Calibrations:");
    for ( auto& calOpt : _calOptList )
	calOpt.Log(*_logger);

    /// - Dump the trees
    (*_logger)("");
    (*_logger)("Trees:");
    for ( auto & root : *_treeFactory )
	root.Log(*_logger);

}

// *****************************************************************************
/// Perform the MCMC process.
/// @throw Except::BadOpt Invalid parameter passed
/// @throw Except::BadOptValue Invalid option value.
/// @throw Except::GpuError Error returned from the GPU interface.
/// @throw Except::IOError Input/output error on file.
/// @throw Except::ModelError Error in evolutionary model.
/// @throw Except::NoCalibrations No calibrations found for tree.
/// @throw Except::NumericException Error in calculations.
/// @throw Except::OutputsExist Output files for run already exist.
/// @throw Except::PerfError Error returned from performance interface.

void
DivTime::MCMC( void )
    throw( Except::BadOpt,
	   Except::BadOptValue,
	   Except::GpuError,
	   Except::IOError,
	   Except::ModelError,
	   Except::NoCalibrations,
	   Except::NumericError,
	   Except::OutputsExist,
	   Except::PerfError )
{
    LOGENTER(*_logger, 0, Dump::ptr(this, "dt"));

    /// - Output run header with date and time

    std::time_t   now          = time(0);
    const std::tm runStartTime = *localtime(&now);

    char startstring[80];
    std::strftime(startstring,
		  80,
		  "%Y-%m-%d %H:%M:%S",
		  &runStartTime);

    (*_logger)("FDivT: %s, Version %s, Starting at %s\n", projectName, projectVersion, startstring);

    /// - Initialize the performance interface

    if ( _perfIntf->Active() )
	(*_perfIntf)("Begin MCMC Initialization");
    else if ( _perf )
	_perfIntf->Initialize();

    /// - Final checks on and defaulting of options.

    OptionChecks();

    /// - Setup GPU handling

    GpuInterface * gpuIntf = nullptr;

#ifdef OPENCL
    if ( _useGpu )
	try {
	    gpuIntf = GpuInterface::Factory(*this);
	}
	catch (Except::NoGpus e) {
	    (*_logger)("GPU use requested but no usable GPU devices found");
	}
#else
    if ( _useGpu )
	(*_logger)("GPU use requested but GPU support unavailable");
#endif

    /// - Build the opencl programs required

#ifdef OPENCL
    if ( gpuIntf )
	gpuIntf->BuildPrograms( *_logger,
				{ {"NGCAT", std::to_string(_eMGammaCats) },
		                  {"NCODES", std::to_string(_seqFactory->_alphabet.size()) } });
#endif

    /// - Complete the trees in the factory (tree blocks and site data)
    ///   and log their relevant data.

    TreeStats treeStats(*_logger);
    treeStats.LogFlag(_logStats);
    _treeFactory->Finish(treeStats);

    if ( _dumpTrees )
        Dump::Trees( *_treeFactory,
                     "Dump of trees prior to replication",
                     *_logger );

    /// - Output the configuration to the log.

    LogConfig(gpuIntf);
    treeStats.Log();

    /// - Setup Replicates and set the initial values.

    ReplicateVec  replVec(*this, gpuIntf);
    replVec._stats->Log();

    if (getenv("FDIVT_PARMCOUNTS") != 0) return;

    SetInitialValues( replVec );

    if ( _dumpRepl )
        Dump::Trees( replVec,
                     "Dump of replicates prior to MCMC",
                     *_logger);

    /// -  Can't add any more input objects, get rid of the tree factory.
    ///    Keep the sequence factory since it holds the sequence parameters.

    _treeFactory.reset(nullptr);

    /// - Setup the output files for tree samples and traces

    OutputManager outMgr( _filename, _fileOverwrite, *_logger, runStartTime );
    SetOutputFiles( replVec, outMgr );

    /// - Setup the MCMC operational objects

    ThreadSet *     threads  = ThreadSet::Factory( *this );
    StepProcessor * mcmcStep = StepProcessor::Factory ( *threads, replVec );
    TreeSampler     sampler  ( replVec );

    /// - Run the mcmc process.

    (*_logger)("");
    (*_logger)("MCMC Process Starting");
    StatusPrinter statusPrint(*_logger, _nGen);

    (*_perfIntf)("Begin MCMC Step Processing");

    for ( unsigned currGen = 0; currGen < _nGen; currGen++ ) {

        /// - Do a step of the mcmc process.
        (*mcmcStep)(currGen);

        /// - Sample the chains if needed.
        if ( !((currGen - _burnin) % _sampleFreq) && currGen > _burnin )
            sampler(currGen);

        /// - Output an info line every one percent or 10 minutes,
        ///   whichever is smaller.
        statusPrint( currGen,
		     mcmcStep->LnP(),
		     mcmcStep->LnL(),
		     mcmcStep->AgeRatio(),
		     mcmcStep->RateRatio(),
		     mcmcStep->NuisanceRatio());

    }

    (*_perfIntf)("End MCMC Step Processing");

    delete mcmcStep;

    /// - Calculate and output the final trees and parameter summaries

    Summarizer(*threads, replVec, outMgr);

    delete threads;
#ifdef OPENCL
    delete gpuIntf;
#endif

    (*_logger)("MCMC Process Completed");

    LOGEXIT(*_logger, 0, Dump::ptr(this, "dt"));
}

// *****************************************************************************

void
DivTime::OptionChecks( void )
{

    /// - Validate options.

    if ( !_nGenSet )
	throw Except::BadOptValue("NGens", "Required but not specified");

    if ( !_cModelSet )
	throw Except::BadOptValue("ClockModel", "Required but not specified");

    if ( _sampleFreq > _nGen )
	throw Except::BadOptValue("SampleFreq", std::to_string(_sampleFreq));

    if ( _burnin >= _nGen )
	throw Except::BadOptValue("Burnin", std::to_string(_nGen));

    if ( !_burninSet )
	_burnin = _nGen / 4;

    /// - Setup overall number of replicates and threads.

    if ( _nRunsSet && _nJackReplSet )
	throw Except::BadOptValue("NReplicates, NRuns", "Values are mutually exclusive");

    if ( _nRunsSet && _jackPctSet )
	throw Except::BadOptValue("ReplicatePct, NRuns", "Values are mutually exclusive");

    if ( _nJackRepl == 1 && _jackPctSet )
	throw Except::BadOptValue("NReplicates, ReplicatePct", "Replicate percentage specified but only one replicates requested");

    if ( !( 0.0 < _jackPct && _jackPct <= 100.0 ) )
    	throw Except::BadOptValue("ReplicatePct", "Replicate percentage must be > 0.0 and < 100.0");

    if ( _nThreadsSet && !_nRunsSet )
	_nRuns = _nThreads;

    _nRepl = _nJackReplSet ? _nJackRepl : _nRuns;

    /// - Seed the random generator

    if ( !_seedSet ) {
        std::random_device dev;
        _seed = dev();
        _seedSet = true;
    }
    _randomGen.seed(_seed);

    /// - Calculate the locus statistics

    for ( auto locus : _locusVec )
        locus->ComputeStatistics();

}

// *****************************************************************************
/// Setup and output the initial values for the replicates
/// If additional initial value modules are created, they would be used here.

void
DivTime::SetInitialValues( ReplicateVec & rVec ) const
{

    InitValuesBrLen initVal(*_logger);

    (*_logger)("");
    (*_logger)("Initial Log Likelihood Values:");

    for ( auto & repl : rVec ) {
        (*_logger)("Chain/Jackknife %d:", repl._id + 1);
        initVal(repl);
        for ( auto & root : repl )
            (*_logger)("%*cTree %04d: %s: %f",
                       _logger->indent, ' ',
                       root._rootIdx + 1, root._label.c_str(),
                       (*root._lkh)());
    }
}

// *****************************************************************************
void
DivTime::SetOutputFiles( ReplicateVec &  rVec,
			 OutputManager & oMgr) const

{

    (*_logger)("");
    (*_logger)("Output Files:");

    for ( auto & repl : rVec ) {

        (*_logger)("Chain/Jackknife %d:", repl._id + 1);

        for ( auto & root : repl ) {

	    root._finalTreeFile = oMgr(repl, root, OutputManager::FinalTree);
            (*_logger)( "%*cTree %04d: %-17s: %s",
                        _logger->indent, ' ',
                        root._rootIdx + 1,
		        "Final Tree",
		        root._finalTreeFile->Filename().c_str() );

	    root._sampleFile = oMgr(repl, root, OutputManager::TreeSamples);
            (*_logger)( "%*cTree %04d: %-17s: %s",
                        _logger->indent, ' ',
                        root._rootIdx + 1,
		        "Sampled Trees",
		        root._sampleFile->Filename().c_str() );

	    root._detailFile  = oMgr(repl, root, OutputManager::ParameterDetails);
            (*_logger)( "%*cTree %04d: %-17s: %s",
                        _logger->indent, ' ',
                        root._rootIdx + 1,
			"Parameter Details",
		        root._detailFile->Filename().c_str() );

	    root._traceFile  = oMgr(repl, root, OutputManager::Trace);
            (*_logger)( "%*cTree %04d: %-17s: %s",
                        _logger->indent, ' ',
                        root._rootIdx + 1,
			"Traced Parameters",
		        root._traceFile->Filename().c_str() );

	}
    }
}

// *****************************************************************************
/// Output graphviz format dot file depiction of the trees.

void
DivTime::TreeGraphviz( const std::string & dotfile,        ///< Graphviz outout file base (no extension)
                       bool                taxa,           ///< Write chart of taxa data
                       bool                calibrations,  ///< Write chart of calibrations
                       bool                geneTrees )    ///< Write chart of gene trees
    const
{

    Graphviz::Trees(*_treeFactory, dotfile + "_Trees.dot");

    if ( taxa )
	Graphviz::Taxa( *_seqFactory, _taxaMap, dotfile + "_Taxa.dot");

    if ( calibrations )
	Graphviz::Calibrations(*_treeFactory, _calOptList, dotfile + "_Calibrations.dot");

    if ( geneTrees )
	Graphviz::GeneTrees(*_treeFactory, dotfile + "_GeneTrees.dot");

}
