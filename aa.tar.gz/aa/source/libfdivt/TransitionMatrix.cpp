/// @file TransitionMatrix.cpp
/// Definitions for the transition matrix methods.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#include "Dump.h"
#include "EvoModel.h"
#include "Replicates.h"
#include "TransitionMatrix.h"

// *****************************************************************************

std::string
TransitionMatrix::str ( const std::string hdg )
    const
{
    std::stringstream ss;
    if ( hdg.size() ) ss << hdg << "<";
    ss << Dump::ptr(this) << ' '
       << Dump::ptr(&_parent, "parent") << " "
       << Dump::str(_dist, _oldDist, "dist") << " ";
    if ( hdg.size() ) ss << ">";
    return ss.str();
}

// *****************************************************************************

void
TransitionMatrix::Save()
{
    _parent._repl.LogRollback(this);
    _oldDist = _dist;
}

// *****************************************************************************

template<>
std::string
Dump::str( const TransitionMatrix & t,
	   const std::string hdg )
{
    return t.str(hdg);
}
