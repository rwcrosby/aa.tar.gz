DivTime.Loader.Newick package
=============================

.. automodule:: DivTime.Loader.Newick
    :members:
    :undoc-members:
    :show-inheritance:

