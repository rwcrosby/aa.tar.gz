DivTime package
***************

DivTime Class
=============

.. autoclass:: DivTime.DivTime
    :members:
    :show-inheritance:
    :special-members:

Newick Parsing
==============

.. class:: DivTime.ParseNewick.Parser

	   Parse a newick string containing a single tree.
	   
	   Args:
	       string: string containing newick tree.
	   

Standard Tree Construction
==========================

Tree Class
----------

.. autoclass:: DivTime.Tree
    :members:
    :show-inheritance:
    :special-members:

Inner Class
-------------

.. autoclass:: DivTime.Inner
    :members:
    :undoc-members:
    :show-inheritance:

Leaf Class
-------------

.. autoclass:: DivTime.Leaf
    :members:
    :show-inheritance:
    :special-members:

Node Class
-------------

.. autoclass:: DivTime.TreeObjs.Node
    :members:
    :show-inheritance:
    :special-members:

Edge Class
-------------

.. autoclass:: DivTime.Edge
    :members:
    :special-members:
    :show-inheritance:

Tree Traversal
==============

.. autoclass:: DivTime.TreeVisitor
    :members:
    :special-members:
    :show-inheritance:


