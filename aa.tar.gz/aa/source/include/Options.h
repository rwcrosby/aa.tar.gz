/// @file Options.h
/// Definitions for the library options

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _OPTIONS_H_
#define _OPTIONS_H_

#include <cstring>

class  ILogSink;

/// Namespace for all options.
namespace Options {

    /// Tags for the global options
    enum class OptType : unsigned char {

        // *****************************************************************
        // Parameters associated with the logger

	/// Set a log sink object.
	/// - Value is a ILogSink pointer.
	LogSink,

	/// Set file descriptor to output to
	/// - Value is an integer.
	LogFileNo,

	/// Set debugging on or off.
	/// - Value is a boolean.
	LogDebug,

	/// Set performance trace on or off.
	/// - Value is a boolean.
	LogPerf,

	/// Set statistics logging on/off (default=on).
	/// - Value is a boolean.
	LogStats,

	/// Set a log file name.
        /// This one can't be first in the list or we get python problems.
	/// - Value is a string (set chardata) containing the file name.
	LogFile,

        // *****************************************************************
        // Parameters to dump various things

	/// Dump the trees prior to creating replicates
	/// - Value is a boolean.
	DumpTrees,

	/// Dump the replicates prior to starting the MCMC process
	/// - Value is a boolean.
	DumpReplicates,

        // *****************************************************************
        // Overall process parameters

	/// Root name for the output files.
	/// This name (which may include path's) will be prepended to
	/// generate the names of the various output files.
	/// - Default is "FDivT"
	/// - Value is a string.
        Filename,

	/// Overwrite output files if they exist?
	/// - Value is a boolean.
	FileOverwrite,

	/// Random seed value.
        /// If not specified a value will be obtained from the OS.
	/// - Value is an unsigned integer.
        Seed,

	/// Clock model to use.
        /// - Parameter must be specified (no default).
	/// - Value one of the choices in the Options::ClockModel enum.
        ClockModel,

	/// Multi-tree model to use.
        /// - Default is independent
	/// - Value one of the choices in the Options::MultiTreeModel enum.
        MultiTreeModel,

        // *****************************************************************
        // Execution environmental parameters

	/// Number of bits to use in the Dag hash table.
        /// The Dag hash table is used to identify repeating subtrees
	/// during the loading of the trees.
        /// \li Default is 24.
	/// \li Value is an unsigned integer \f$1 <= i < 32\f$.
	HashBits,

	/// Number of threads to use.
	/// - Default is number of cores returned by the OS.
	/// - Value is an unsigned integer i >= 1
	NThreads,

	/// Use GPU's if available?
	/// - value is a boolean (default true).
	UseGpu,

        // *****************************************************************
        // Parameters associated with the DNA sequence alphabet

	/// Set of characters in the sequences.
        /// - Default is "ACTG".
	/// - Value is a character string.
	SeqChars,

	/// Character indicating a gap in a sequence.
        /// - Default is '-'.
	/// - Value is a single character.
	GapChar,

	/// Character indicating missing sequence data.
        /// - Default is '?'.
	/// - Value is a single character.
	MissingChar,

        // *****************************************************************
        // Parameters associated with the MCMC Process

	/// Number of MCMC generations.
	/// Total MCMC generations. Some of the generations may
	/// be discarded depending on the setting of the Burnin
	/// parameter.
	/// - Value is an unsigned integer i >= 1
	NGen,

	/// Generations to discard.
	/// The number of generations specified by this parameter will be discarded
	/// and not sampled (via SampleFreq)
	/// - Default is to ignore the number of generations equal to 25% of the total
	/// requested.
	/// - Value is an unsigned integer \f$0 <= Burnin < NGen\f$.
	Burnin,

	/// Sampling freqency.
	/// A sample of the trees will be taken every SampleFreq generations.
	/// Output will be to the <em>filename</em>.samples.run <sub>n</sub>.nexus file.
	/// Where the filename is specified with the filename option and
	/// the run number,\f$n\f$ is \f$1 <= n <= NRuns\f$.
	/// Sampling will not commence until after any burnin has been discarded.
	/// - Default is to sample every 500 generations.
	/// - Value is an unsigned integer \f$SampleFreq >= 1\f$.
	SampleFreq,

	/// Number of independent runs.
	/// Number of parallel MCMC chains.
        /// Value is mutually exclusive with NReplicates.
	/// \li Default is NThreads (or 1 if NReplicates is specified).
	/// \li Value is an unsigned integer \f$NRuns >= 1\f$.
	NRuns,

	/// Number of jackknife replicates.
	/// Jackknife replicates will be randomly generated.
        /// This value is mutually exclusive with NRuns.
	/// \li Default is 0.
	/// \li Value is an unsigned integer \f$NReplicates >= 0\f$.
	NReplicates,

	/// Percentage of the calibrations to include in each replicate.
	/// The first replicate will always contain all the calibrations.
	/// Subsequence replicates might also conain all the calibrations
	/// depending on the percentage given.
	/// This option may only be specified if NReplicates is also specified
	/// with a value > 0.
	/// Jackknife replicates will be randomly generated.
	/// \li Default is 100.0.
	/// \li Value is an positive floating point value \f$0.0 < ReplicatePct <= 100.0\f$.
	ReplicatePct,

        // *****************************************************************
        // Parameters associated with Birth Death process

	/// \f$\lambda\f$ parameter to the birth-death process.
        /// Used as part of the prior for the calibration nodes.
	/// \li Value is an real \f$ > 0.0\f$.
	BDLambda,

	/// \f$\mu\f$ parameter to the birth-death process.
        /// Used as part of the prior for the calibration nodes.
	/// \li Value is an real \f$ > 0.0\f$.
	BDMu,

	/// \f$\rho\f$ parameter to the birth-death process.
        /// Used as part of the prior for the calibration nodes.
	/// \li Value is an real \f$ > 0.0\f$.
	BDRho,

        // *****************************************************************
        // Parameters associated with the gamma dirichlet prior on rates

        /// \f$\alpha\f$ hyperparameter for mean of the rates.
        /// \li Value is a real \f$ > 0.0\f$.
        ClockMeanAlpha,

        /// \f$\beta\f$ hyperparameter for mean of the rates.
        /// \li Value is a real \f$ > 0.0\f$.
        ClockMeanBeta,

        /// Dirichlet concentration \f$\alpha\f$ hyperparameter for mean of the rates.
        /// \li Value is a real \f$ > 0.0\f$.
        ClockMeanDCon,

        /// \f$\alpha\f$ hyperparameter for variance of the rates.
        /// \li Value is a real \f$ > 0.0\f$.
        ClockVarAlpha,

        /// \f$\beta\f$ hyperparameter for variance of the rates.
        /// \li Value is a real \f$ > 0.0\f$.
        ClockVarBeta,

        /// Dirichlet concentration \f$\alpha\f$ hyperparameter for variance of the rates.
        /// \li Value is a real \f$ > 0.0\f$.
        ClockVarDCon,

	/// Dummy entry to provide the length of the options list
	NumOptions
    };

    /// Evolutionary models supported.
    enum class EvoModel : unsigned char {
        JC69,                                     ///< Jukes Cantor basic model
        K80,                                      ///< Kimura '80 1 parameter model
        F81,                                      ///< Felsenstein '81 Model
        F84,                                      ///< Felsenstein '84 Model
        HKY85,                                    ///< Hasegawa-Kishino-Yano model
        T92,                                      ///< Tamura '92 Model
        TN93,                                     ///< Tamura-Nei '93 Model
        GTR,                                      ///< Generalized Time Reversable Model
    };

    /// Set of clock models supported.
    enum class ClockModel : unsigned char {
        GLOBAL,                                   ///< Single clock per tree/locus
        INDEPENDENT,                              ///< Rates are independent
        CORRELATED                                ///< Rates are auto-correlated
    };

    /// Set of multitree sharing models supported.
    enum class MultiTreeModel : unsigned char {
        INDEPENDENT,                              ///< Rates and ages are both are independent in shared subtrees
	COMMONRATES,                              ///< Rates are common, ages are independent in shared subtrees
	COMMONBOTH 				  ///< Ages and rates are both common in shared subtrees.
    };

    /// Types of calibrations supported
    enum class CalType : unsigned char {
	LOWER_BOUND,				  ///< Lower soft bound only
	UPPER_BOUND,		                  ///< Upper soft bound only
	LOWER_UPPER,		                  ///< Both lower and upper soft bounds
	GAMMA_DIST,				  ///< Gamma distributed
	NORMAL_DIST				  ///< Normmally distributed
    };

    /// tags for the calibration options
    enum class CalOptType : unsigned char {

	/// Type of calibration.
	/// - Data is a CalType value
	Type,

	/// Minimum age bound
	/// - Data is a long value
	MinAge,

	/// Maximum age bound
	/// - Data is a long value
	MaxAge,

	/// Percentage of distribution mass to left of minimum age.
	/// If specified as a zero, a hard bound is generated.
	/// - Data is a long value
	LeftMass,

	/// Percentage of distribution mass to right of maximum age.
	/// If specified as a zero, a hard bound is generated.
	/// - Data is a long value
	RightMass,

	/// Offset used in the truncated Cauchy distribution associated
	/// with the lower only bound type.
	/// - Data is a long value
	Offset,

	/// Scale used in the truncated Cauchy distribution associated
	/// with the lower only bound type.
	/// - Data is a long value
	Scale,

	/// \f$\alpha\f$ for the gamma distribution
	/// - Data is a long value
	Alpha,

	/// \f$\beta\f$ for the gamma distribution
	/// - Data is a long value
	Beta,

	/// Mean for the normal and lognormal distributions
	/// - Data is a long value
	Mu,

	/// Standard deviation for the normal and lognormal distributions
	/// - Data is a long value
	Sigma,

    };

    /// Union to contain the option values.
    /// needs to be outside of the class due to swig.
    union OptData {
        ClockModel     cmodel;                    ///< Clock model
        MultiTreeModel mtmodel;                   ///< Clock model
        CalType        calType;		          ///< Calibration type
        ILogSink*      logSink;			  ///< Log sink object
        char*          cstr;			  ///< Character data
        char           ch;			  ///< Single character
        bool           tf;                        ///< True/False
        unsigned       uintVal;			  ///< Unsigned integer
        int            intVal;			  ///< Signed integer
        double         doubleVal;	          ///< Any of the float values
    };

    /// Definition of a single options to the divergence time process.
    /// Basically a name/value pair although the name is really the
    /// value in the OptType enum.
    struct DivOpt {

        OptType type;                             ///< Option Type
        OptData data;                             ///< Option value

        /// Basic constructor
        DivOpt() {};

        /// Destructor.
        /// Delete a generated character string
        ~DivOpt()
            {
                if (type == OptType::LogFile  ||
                    type == OptType::SeqChars)
                    delete[] data.cstr;
            }

        /// Copy Constructor.
        DivOpt( const DivOpt & o )
            {
                /// Copy the type and data fields.
                type = o.type;
                data = o.data;

                /// If a string type, allocate a new one.
                if ( type == OptType::LogFile  ||
                     type == OptType::SeqChars ) {
                    data.cstr = new char[strlen(o.data.cstr) + 1];
                    strcpy(data.cstr, o.data.cstr);
                }
            }

        /// Constructor initializing the name/value pair with a option data object.
        DivOpt(const OptType  t,                  ///< Name (Type)
               const OptData& d)                  ///< Value (Data Object)
            : type(t), data(d) {};

        /// Constructor initializing an option with clock model value.
        DivOpt(const OptType    t,		  ///< Name (Type)
               const ClockModel e)		  ///< Value (Model)
            : type(t)
            {
                data.cmodel = e;
            }

        /// Constructor initializing an option with multi-tree sharing model value.
        DivOpt(const OptType        t,		  ///< Name (Type)
               const MultiTreeModel e)		  ///< Value (Model)
            : type(t)
            {
                data.mtmodel = e;
            }

        /// Constructor initializing an option with log sink object
        DivOpt(const OptType  t,		  ///< Name (Type)
               ILogSink *     s)		  ///< Value (LogSink)
            : type(t)
            {
                data.logSink = s;
            }

        /// Constructor initializing an option with string value.
        DivOpt(const OptType t,                   ///< Name (Type)
               const char *  c)                   ///< Value (String)
            : type(t)
            {
                data.cstr = new char[strlen(c) + 1];
                strcpy(data.cstr, c);
            }

        /// Constructor initializing an option with a single character
        DivOpt(const OptType t,                   ///< Name (Type)
               const char    ch)		  ///< Value (character)
            : type(t)
            {
                data.ch = ch;
            }

        /// Constructor initializing an option with a boolean value
        DivOpt(const OptType t,                ///< Name (Type)
               const bool tf)                  ///< Value (True/False)
            : type(t)
            {
                data.tf = tf;
            }

        /// Constructor initializing an option with an unsigned int
        DivOpt(const OptType  t,                  ///< Name (Type)
               const unsigned uint)               ///< Value (unsigned int)
            : type(t)
            {
                data.uintVal = uint;
            }

        /// Constructor initializing an option with an int
        DivOpt(const OptType t,                   ///< Name (Type)
               const int     i)                   ///< Value (long)
            : type(t)
            {
                data.intVal = i;
            }

        /// Constructor initializing an option with an double float
        DivOpt(const OptType t,                   ///< Name (Type)
               const double  d)                   ///< Value (long)
            : type(t)
            {
                data.doubleVal = d;
            }

    };

    /// Definition of a single calibration option.
    /// Basically a name/value pair although the name is really the
    /// value in the IDivTime::CalOptType enum.
    struct CalOpt {
        CalOptType type;			  ///< Option Type
        OptData    data;			  ///< Option value

        CalOpt() {}
        ~CalOpt() {}

        /// Constructor initializing an option with statistical distribution type
        CalOpt(const CalOptType t,                ///< Name (Type)
               const CalType    ct)               ///< Value (Cakibration type)
            : type(t)
            {
                data.calType = ct;
            }

        /// Constructor initializing the name/value pair with a floating point value.
        CalOpt(const CalOptType t,                ///< Name (Type)
               const double     d)                ///< Value (long)
            : type(t)
            {
                data.doubleVal = d;
            }

    };

}

#endif // _OPTIONS_H_
