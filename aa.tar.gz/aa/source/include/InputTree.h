/// @file InputTree.h
/// Definitions for the elements of the tree passed to FDivT

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _INPUTTREE_H_
#define _INPUTTREE_H_

#include <string>
#include <list>

/// The InputTree namespace defines the interface format for trees passed to FDivT.
/// All classes are represented as structures since everything is public.

namespace InputTree {

    /// Node types returned

    enum class NodeType : unsigned char {
	INNER,
	LEAF
    };

    // *****************************************************************************
    /// Base class for all the types of tree nodes

    struct Node {

	Node()          {}

	virtual ~Node() {};

	virtual const NodeType Type() const = 0;

    };

    // *****************************************************************************
    /// Definition of a tree branch

    struct Branch {

	Node * target;	                          ///< Target of the branch
	double length;				  ///< Branch length

	Branch(Node * t,	                  ///< Target node for the branch
	       double l)	                  ///< Branch length
	    : target(t), length(l)
	    {}

	virtual ~Branch() {}

    };

    // *****************************************************************************
    /// Inner node for a tree.

    struct Inner : Node {

	std::list<Branch*>     children;

	Inner() {}

	/// Constructor adding a list of branches at the same time
	Inner(std::list<Branch*> branches)	  ///< List of branches
	    {
		children.insert(children.end(), branches.begin(), branches.end());
	    }

	virtual ~Inner() {}

	virtual const NodeType Type() const { return NodeType::INNER; }

    };

    // *****************************************************************************
    /// Leaf node in a tree.

    struct Leaf : Node {

	std::string     label;

	Leaf(const std::string l )
	    : label(l)
	    {}

	virtual ~Leaf() {}

	virtual const NodeType Type() const { return NodeType::LEAF; }

    };

}

#endif // _INPUTTREE_H_
