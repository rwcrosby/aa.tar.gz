/// @file DllHdr.h
/// Control definitions for building shared libraries.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University, 
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _DLLHDR_H_
#define _DLLHDR_H_

#ifdef _WIN32

// Remove this with ms c++ supports the keyword.
#define noexcept

// For windows setup either imports or exports for the functions in this module
#ifdef DLLEXPORT
#define DLL __declspec(dllexport)
#else
#define DLL __declspec(dllimport)
#endif

#else

// Under unix variants setup to only expose the functions in this module
// when building the library.
#ifdef SWIG
#define DLL
#else
#define DLL __attribute__((visibility("default")))
#endif

#endif

#endif // _DLLHDR_H_
