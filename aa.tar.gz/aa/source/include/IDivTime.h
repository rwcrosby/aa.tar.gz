/// @file IDivTime.h

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _IDIVTIME_H_
#define _IDIVTIME_H_

#include <cstring>
#include <map>
#include <string>
#include <vector>

#include "Except.h"
#include "Options.h"

namespace InputTree {
    struct  Node;
}

// *****************************************************************************
/// Divergence time interface.
///
/// A pointer to an instance of this interface is returned from the
/// call to CreateDivTimeObject. The methods on this object are then used to
/// setup and run the divergence time operations.

class IDivTime {

public:

    virtual ~IDivTime()
        {};

    /// Add or override options in the current set.
    /// @param opts Set of options to add/replace
    /// @throw Except::BadOpt Invalid option code.
    /// @throw Except::BadOptValue Invalid option value.

    virtual void SetOptions (const std::vector<Options::DivOpt*>& opts)
        throw( Except::BadOpt,
               Except::BadOptValue ) = 0;

    /// Return the full set of options with all values resolved.
    /// @returns Pointer to the full option set.

    virtual std::vector<Options::DivOpt>* GetOptions () const  = 0;

    /// Write formatted output of the options to log

    virtual void LogOptions () const = 0;

    /// Set the evolutionary model and it's parameters.
    /// Specific parameters and their defaults vary depending on the model.
    /// Any of the models may have gamma categories.
    /// @param eModel Evolutionary model code.
    /// @param modelParms Hyperparameters required by the model.
    /// @param freqParms Hyperparameters for character frequence parameters.
    /// @param gammaCats Number of discrete gamma categories.
    /// @param gammaParms Hyperparameters (\f$\alpha\f$, \f$\beta\f$)for the discrete gamma \f$\alpha\f$ value.
    /// @throw Except::ModelError Error in model specification

    virtual void SetModel (const Options::EvoModel    eModel,
                           const std::vector<double>& modelParms,
                           const std::vector<double>& freqParms,
                           const unsigned             gammaCats,
                           const std::vector<double>& gammaParms)
        throw (Except::ModelError) = 0;

    /// Add a taxa.
    /// @param taxa Name of the taxa to add
    /// @throw Except::DuplicateTaxa Trying to add existing taxa

    virtual void AddTaxa (const std::string& taxa)
        throw( Except::DuplicateTaxa )= 0;

    /// Add a locus.
    /// This identifier will be used in the add sequence calls
    /// to identify the locus for the sequence.
    /// @param locus Identifier for the locus.
    /// @throw Except::DuplicateLocus Trying to add existing locus

    virtual void AddLocus (const std::string& locus)
        throw( Except::DuplicateLocus ) = 0;

    /// Add a DNA sequence for a taxa at a specific locus.
    /// Each taxa name should have been added using the AddTaxa method.
    /// Each locus should have been added using the AddLoci method.
    /// @param locus Name of the locus to associate sequence with
    /// @param taxa  Name of the taxa to associate sequence with. Taxa
    ///              label must have been set with the TaxaLabel parameter.
    /// @param seq   String containing sequence data
    /// @throw Except::MissingTaxa Taxa not already added.
    /// @throw Except::MissingLocus Locus not already added.
    /// @throw Except::InvalidSeqCh Invalid character in sequence.
    /// @throw Except::InvalidSeqLength All sequence for locus must be same length.
    /// @throw Except::MissingSeq All of the sequence data is missing.

    virtual void AddSequence (const std::string& locus,
			      const std::string& taxa,
			      const std::string& seq)
        throw ( Except::MissingTaxa,
                Except::MissingLocus,
                Except::InvalidSeqCh,
                Except::InvalidSeqLength,
                Except::MissingSeq ) = 0;

    /// Add a tree to the set to be dated.
    /// Each taxa name should have been added using the "TaxaLabel" option.
    /// @param root  Reference to the root node for the tree
    ///              Tree structure is defined by the FDivT objects
    /// @param label User supplied identifier for the tree.
    /// @throw Except::MissingTaxa Taxa not defined
    /// @throw Except::InvalidTree Error in tree structure

    virtual void AddTree ( InputTree::Node * const root,
			   const std::string&      label = "" )
        throw ( Except::MissingTaxa,
                Except::InvalidTree ) = 0;

    /// Add a fossil calibration to the set of calibrations.
    /// The data is copied to internal structures, the use is
    /// free to release any of the memory associated with the
    /// parameters.
    /// @param descendents List of taxa comprising the clade
    /// @param opts Set of calibration options
    /// @param label User supplied identified for the calibration
    /// @throw Except::MissingTaxa Taxa not already added
    /// @throw Except::BadOpt Invalid parameter passed

    virtual void AddCalibration ( const std::vector<std::string>&      descendents,
				  const std::vector<Options::CalOpt*>& opts,
				  const std::string&                   label = "" )
        throw( Except::MissingTaxa,
               Except::BadOpt,
               Except::BadCalibrationOpt ) = 0;

    /// Write a graphviz dot file depiction of the tree structure.
    /// @param dotfile Output graphviz dot file name.
    /// @param taxa Output taxa information.
    /// @param calibrations Output calibration information.
    /// @param geneTrees Output gene tree information.

    virtual void TreeGraphviz    ( const std::string & dotfile,
                                   bool                taxa = false,
                                   bool                calibrations = false,
                                   bool                geneTrees = false) const = 0;

    /// Do the actual MCMC process.
    /// @throw Except::BadOpt Invalid parameter passed
    /// @throw Except::BadOptValue Invalid option value.
    /// @throw Except::GpuError Error returned from the GPU interface.
    /// @throw Except::IOError Input/output error on file.
    /// @throw Except::ModelError Error in evolutionary model
    /// @throw Except::NoCalibrations No calibrations found for tree.
    /// @throw Except::NumericException Error in calculations.
    /// @throw Except::OutputsExist Output files for run already exist.
    /// @throw Except::PerfException Error returned from performance interface.

    virtual void MCMC()
        throw( Except::BadOpt,
               Except::BadOptValue,
               Except::GpuError,
	       Except::IOError,
               Except::ModelError,
               Except::NoCalibrations,
               Except::NumericError,
	       Except::OutputsExist,
               Except::PerfError ) = 0;

};

#endif // _IDIVTIME_H_
