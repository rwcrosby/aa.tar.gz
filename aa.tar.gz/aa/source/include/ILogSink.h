/// @file ILogSink.h
/// Interface class to define a sink to accept logger output

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University, 
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _ILOGSINK_H_
#define _ILOGSINK_H_

// *****************************************************************************
/// Log sink interface.

/// 

class ILogSink {
    
public:

    virtual ~ILogSink() {};

    /// Open the sink.
    /// Called when the sink is first instantiated.
    virtual void Open() {};

    /// Write a buffer of data to the log.
    /// Data will be terminated with a newline.
    /// This function must be implemented, the others are optional.
    /// @param buffer Buffer of data to output.
    virtual void Log(const char * buffer) = 0;

    /// Close the sink.
    /// Called with the destination is being deleted.
    virtual void Close() {};

};

#endif // _ILOGSINK_H_
