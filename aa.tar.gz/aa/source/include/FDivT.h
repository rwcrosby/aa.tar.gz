/// @file FDivT.h
/// Definitions for the functions exposed by the shared library
///
/// This file defines the public interface to the library.
/// To use the interface the [CreateDivTimeObject](\ref CreateDivTimeObject) function should be called which will
/// create an instance of the DivTime class and return an IDivTime interface pointer.
/// All subsequence interface operations
/// will occur across that interface.
///
/// Note: it's possible, althought I'm not sure
/// why anyone would want to, create and work with multiple interfaces at the same
/// time.

// *************************************************************************

// Copyright© 2010-2015 Texas A&M University,
//                      College Station, Texas
//                      Contact: R Crosby <rwc@cs.tamu.edu>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// *************************************************************************

#ifndef _FDIVT_H_
#define _FDIVT_H_

#include "DllHdr.h"
#include "IDivTime.h"

/// Create a div time object.

/// Factory method to create a divergence time object.
/// This object is used for all other operations, see the documentation
/// on the IDivTime interface for all other operations.
/// @return Pointer to the IDivTime interface on a DivTime object.
/// @throw Except::PerfError Error from performance interface.
/// @sa IDivTime

DLL IDivTime * CreateDivTimeObject()
    throw( Except::PerfError );

/// Free a divergence time object.

/// All memory and processes associated with the object are freed.
/// The pointer becomes invalid.
/// @param dt IDivTime interface pointer

DLL void FreeDivTimeObject(IDivTime *dt);

#endif // _FDIVT_H_
