"""
Loader for yaml input.

Any or all portions of the FDivT data can be loaded through
this interface.

Yaml Format::

  options :
    option_1 : value_1
    ...
    option_n : value_n

  emodel:
    model     : K80
    parms     : [p1, p2]
    freq      : [f1, f2, f3, f4]
    gammacats : 4
    gammaparms: [g1, g2]

  rates:
    clock     : correlated
    mean      : [ag, bg, ad]
    variance  : [ag, bg, ad]

  times:
    bdparms   : [lambda, mu, rho]

  loci :
    - loci_1
      ...
    - loci_n

  taxa :
    - taxa_1
      ...
    - taxa_n

  sequences :
    taxa_1 :
      loci_1 : actg....actg
      ...
      loci_2 : actg....actg
    taxa_2 :
      loci_1 : actg....actg
      ...
      loci_2 : actg....actg

  trees :
    tree_1 : (a,b);
    ...
    tree_n : (c,d);

  calibrations :
    - descendents
      - taxa_1
        ...
      - taxa_n
      option_1 : value_1
      ...
      option_n : value_n

"""

__author__ = """
Ralph W. Crosby
rwc@cs.tamu.edu
Department of Computer Science and Engineering
Texas A&M University
College Station, TX 77843
"""

__license__ = """
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

__copyright__ = """
Copyright© 2010-2015 Texas A&M University,
                     College Station, Texas
                     Contact: R Crosby <rwc@cs.tamu.edu>
"""

__all__ = ['load']

# **************************************************

import os
import sys
import yaml
try:
    from yaml import CLoader as Loader, CDumper as Dumper
except ImportError:
    from yaml import Loader, Dumper

# **************************************************

def _check_options(v):
    """Just make sure it's a dictionary"""

    if not isinstance(v, dict):
        raise AttributeError("Options must be a dictionary")

# **************************************************

def _check_emodel(v):
    """Make sure it's a dictionary and that the parms are lists.
    """

    flist = lambda l : [float(f) for f in v[l]]

    if not isinstance(v, dict):
        raise AttributeError("Evolutionary model must be a dictionary")

    if 'parms' in v:
        if not isinstance(v['parms'], list):
            raise AttributeError("Evolutionary model parms must be a list")
        v['parms'] = flist('parms')

    if 'freq' in v:
        if not isinstance(v['freq'], list):
            raise AttributeError("Evolutionary model character frequencies must be a list")
        v['freq'] = flist('freq')

    if 'gammacats' in v:
        try:
            v['gammacats'] = int(v['gammacats'])
        except ValueError:
            raise AttributeError("Evolutionary model discrete gamma categories must be an integer")
    else:
        if not 'gammaparms' in v:
            v['gammacats'] = 1

    if 'gammaparms' in v:
        if not isinstance(v['gammaparms'], list):
            raise AttributeError("Evolutionary model discrete gamma parms frequencies must be a list")
        v['gammaparms'] = flist('gammaparms')

# **************************************************

def _check_loci(v):
    """Just make sure it's a list of strings"""

    if not isinstance(v, list):
        raise AttributeError("Loci set must be a list")

# **************************************************

def _check_taxa(v):
    """Just make sure it's a list of strings"""

    if not isinstance(v, list):
        raise AttributeError("Taxa set must be a list")

# **************************************************

def _check_sequences(v):
    """Just make sure it's a dictionary of dictionaries"""

    if not isinstance(v, dict):
        raise AttributeError("Sequence set must be a dictionary")

    for loci in v.values():
        if not isinstance(loci, dict):
            raise AttributeError("Sequences for a taxa must be a dictionary")

# **************************************************

def _check_trees(v):
    """Make sure it's a dictionary of strings"""

    if not isinstance(v,dict):
        raise AttributeError("Tree set must be a dictionary")

    for k, n in v.items():
        if not isinstance(k, str):
            raise AttributeError("Tree id  must be a string")
        if not isinstance(n, str):
            raise AttributeError("Tree newick must be a string")

# **************************************************

def _check_calibrations(v):
    """Make sure it's a list of dictionaries
    and that the descendentss are specified
    """

    if not isinstance(v, list):
        raise AttributeError("Calibration set must be a list")

    for c in v:
        if not isinstance(c, dict):
            raise AttributeError("Calibration data must be a dictionary")
        if "descendents" not in c:
            raise AttributeError("Calibration data must include a list of descendents")

# **************************************************

def _check_outgroup(v):
    """Make sure it's a list of strings
    """

    if not isinstance(v, list):
        raise AttributeError("Outgroup set must be a list")

    for c in v:
        if not isinstance(c, str):
            raise AttributeError("Outgroup taxa must be strings")

# **************************************************

_kwFunctionMap = dict( options      = _check_options,
                       emodel       = _check_emodel,
                       loci         = _check_loci,
                       taxa         = _check_taxa,
                       sequences    = _check_sequences,
                       trees        = _check_trees,
                       calibrations = _check_calibrations,
                       outgroup     = _check_outgroup)

# **************************************************

def load(src):
    """Load a yaml file or string.

    Basic type validation is done on the input.

    Args:
        src: Yaml input. An open file pointer, a string containing yaml source
        or a string that is a file name.

    Returns:
        A dictionary containing the various parameters found. See DivTime.load
        for a description of the keys and parameters.

    Raises:
        AttributeError: Invalid data format.

        KeyError: Key not defined for FDivT input.
    """

    if isinstance(src, str) and os.path.isfile(src):
        with open(src, 'r') as fp:
            y = yaml.load(fp,Loader=Loader)
    else:
        y = yaml.load(src,Loader=Loader)

    # Process the dictionary received

    if not isinstance(y, dict):
        raise AttributeError("Yaml input file must be a dictionary")

    for k, v in y.items():
        try:
            _kwFunctionMap[k](v)
        except KeyError:
            raise KeyError("Key {} is not defined for FDivT input".format(k))

    return y

# **************************************************

if __name__ == '__main__':
    sys.exit("Not a main program")
