"""
Load newick strings from a file.

Largely copied from Thomas Mailund's newick parser.

Trees are generally unrooted unless a single degree 2 node is found 
in which case it is considered the root.
"""

__author__ = """
Ralph W. Crosby
rwc@cs.tamu.edu
Department of Computer Science and Engineering
Texas A&M University
College Station, TX 77843
"""

__license__ = """
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

__copyright__ = """
Copyright© 2010-2015 Texas A&M University, 
                     College Station, Texas
                     Contact: R Crosby <rwc@cs.tamu.edu>
"""

__all__ = ["load"]

# *************************************************************************

import os

from   ..ParseNewick import Parser

# **************************************************

def _Reader(inputFile, delimiter, buffersize=100000):
    """Generator to return newick strings"""

    lines = ['']

    for data in iter(lambda: inputFile.read(buffersize), ''):
        lines = (lines[-1] + data).split(delimiter)
        for line in lines[:-1]:
            yield line

    yield lines[-1]

    inputFile.close()

# **************************************************

def load(input):
    """Output a set of tree objects as a dictionary.

    The newick strings contained in the input source will be
    parsed into standard trees a collection of which will be
    returned as the "Trees" of a FDivT parameter collection

    Args:
        input: Newick string(s). An open file pointer, a string containing newick format trees 
        or a string that is a file name.

    Returns:
        A dictionary containing a "trees" key and the set of trees found.
    """

    if isinstance(input, str):
        if os.path.isfile(input):
            fp = open(input, 'r')
            initer = _Reader(fp, ';')
        else:
            initer = input.split(';')
    else:
        initer = _Reader(input, ';')

    parser = Parser()

    return {"trees" : (parser(s + ';') for s in initer if len(s.strip()))}
