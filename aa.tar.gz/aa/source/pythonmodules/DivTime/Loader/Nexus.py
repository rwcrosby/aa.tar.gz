"""
Loader for nexus input.

Any or all portions of the FDivT data can be loaded through
this interface.
"""

__author__ = """
Ralph W. Crosby
rwc@cs.tamu.edu
Department of Computer Science and Engineering
Texas A&M University
College Station, TX 77843
"""

__license__ = """
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

__copyright__ = """
Copyright© 2010-2015 Texas A&M University,
                     College Station, Texas
                     Contact: R Crosby <rwc@cs.tamu.edu>
"""

__all__ = ['load']

# **************************************************

import os
import re
import sys

from Bio.Nexus.Nexus import Nexus

from ..Options  import optionsInMap, optionsOutMap
from ..TreeObjs import Tree, Edge, Inner, Leaf

# **************************************************

_defaultLocus = "default locus"                   # Used of no charsets defined

# **************************************************

class load(dict):
    """Load a nexus file or string.

    The constructor may be passed either an open file pointer,
    a string containing the name of a nexus file or a string
    containing the nexus source.

    Note, this class violates naming conventions since it's used as
    a closure and must be 'findable' from the DivTime.load method.

    Args:
        src: Nexus input. An open file pointer, string containing file name or string containing nexus souce.

    Raises:
        SyntaxError: Error in Nexus input format.
    """

    # **************************************************

    def _get_outgroup(self, opts):
        """Process an outgroup command"""

        og = [tx.strip().strip('"') for tx in opts.strip('()').split(',')]
        if len(og) == 0:
            raise SyntaxError("Invalid outgroup option: {}".format(opts))

        if 'outgroup' in self:
            self['outgroup'] += og
        else:
            self['outgroup'] = og

        return []

    # **************************************************

    _re_opts   = re.compile(r'(\S+)\s*=\s*(\(.*\)|".*"|\S+)')

    def _get_opts_line(self, opts):
        """Process a single command line"""

        plist = load._re_opts.findall(opts)
        if not plist:
            raise SyntaxError("Invalid options in FDivT command: {}".format(opts))

        outList = []

        for opt in plist:
            try:
                outList.append((opt[0], optionsInMap[opt[0]][3](opt[1])))
            except KeyError:
                raise SyntaxError("Invalid option in FDivT command: {}".format(opt[0]))

        return outList

    # **************************************************

    _eMParseOpts = dict( model      = lambda p : p,
                         parms      = lambda p : [float(v) for v in p.strip('()').split(',')],
                         freq       = lambda p : [float(v) for v in p.strip('()').split(',')],
                         gammacats  = lambda p : int(p),
                         gammaparms = lambda p : [float(v) for v in p.strip('()').split(',')])

    _re_emodel   = re.compile(r'(\S+)\s*=\s*(\([^\)]+\)|"[^"]"|\S+)')

    def _get_emodel_line(self, opts):
        """Save the evolutionary model parms to associated with the proper key"""

        plist = load._re_emodel.findall(opts)
        if not plist:
            raise SyntaxError("Invalid evolutionary model parms in FDivT block: {}".format(opts))

        self['emodel'] = {}

        for opt in plist:
            try:
                self['emodel'][opt[0]] = self._eMParseOpts[opt[0]](opt[1])
            except KeyError:
                raise SyntaxError("Invalid evolutionary model option name in FDivT section: {}".format(opt[0]))

        return []

    # **************************************************

    _re_command = re.compile(r'(".*"|\S+)\s+(.*)')

    _opts_cmds = dict( options  = _get_opts_line,
                       emodel   = _get_emodel_line,
                       outgroup = _get_outgroup )

    def _get_options(self):

        outList = []                          # Set of parameters found

        # pick up the sequence characteristics

        if hasattr(self.nexus, 'gap'):
            outList.append(('gapchar', self.nexus.gap))

        if hasattr(self.nexus, 'missing'):
            outList.append(('missingchar', self.nexus.missing))

        if hasattr(self.nexus, 'unambiguous_letters'):
            outList.append(('seqchars', self.nexus.unambiguous_letters))

        # Find the parameters section
        try:

            cmds = next(blk for blk in self.nexus.unknown_blocks if blk.title == 'fdivt').commandlines

            # Process through the command lines
            for cmd in cmds[0]:
                m = load._re_command.match(cmd)
                if not m:
                    raise SyntaxError("Invalid command in FDivT section: {}".format(cmd))

                try:
                    outList += load._opts_cmds[m.group(1).lower()](self, m.group(2))
                except KeyError:
                    raise SyntaxError("Invalid command in FDivT section: {}".format(cmd))

            if not len(outList):
                raise KeyError()

        except StopIteration:                     # No fdivt section found
            raise KeyError()

        return dict(outList)

    # **************************************************

    def _get_loci(self):

        if hasattr(self.nexus, 'charsets'):
            return self.nexus.charsets.keys()

        # if there are sequences but no charsets, generate a single locus

        if hasattr(self.nexus, 'matrix'):
            return [_defaultLocus]

        raise KeyError();

    # **************************************************

    def _get_taxa(self):

        if len(self.nexus.taxlabels) == 0:
            raise KeyError();

        self.taxa = set(self.nexus.taxlabels)

        return None

    # **************************************************

    def _get_sequences(self):

        if not self.nexus.matrix:
            raise KeyError();

        seqList = {}

        for tx, seq in self.nexus.matrix.items():

            lociList = {}

            if len(self.nexus.charsets) == 0:
                lociList[_defaultLocus] = str(seq)
            else:
                for locus, posList in self.nexus.charsets.items():
                    lociList[locus] = ''.join(seq[p] for p in posList)

            seqList[tx] = lociList

        if len(seqList) == 0:
            raise KeyError();

        return seqList

    # **************************************************

    def _dfs(self, nodes, node, inner, tree):
        """Traverse the tree"""

        for n in nodes[node].succ:
            e = Edge(nodes=[inner], length = nodes[node].data.branchlength, tree=tree)
            if nodes[n].data.taxon:
                l = Leaf(edge=e, label=nodes[n].data.taxon, tree=tree)
                # Since Biopython ignores the taxlabels command, we add any we need here
                self.taxa.add(nodes[n].data.taxon)
            else:
                i = Inner(edges=[e], tree=tree)
                self._dfs(nodes, n, i, tree)

    # **************************************************

    def _get_tree(self, treeIn):
        """Convert a single tree"""

        treeOut = Tree()
        inner = Inner(tree=treeOut)
        self._dfs(treeIn.chain, treeIn.root, inner , treeOut)

        # Set the root somehow

        # If the nexus file indicated the tree was rooted,
        # just go with it...
        if treeIn.rooted:
            treeOut.root = inner

        else:

            # Look for a single degree two node to use as the root
            try:
                treeOut.set_root()
            except AttributeError:

                # If an outgroup was specified, use that
                if hasattr(self, 'outgroup'):
                    try:
                        treeOut.set_root(self.outgroup)
                    except KeyError:
                        raise SyntaxError("Outgroup not found in tree {}".format(treeIn.name))

        return treeOut

    # **************************************************

    def _get_trees(self):
        """ Convert all the trees"""

        tlist = {t.name : self._get_tree(t) for t in self.nexus.trees}

        if len(tlist) == 0:
            raise KeyError();

        return tlist

    # **************************************************

    def _get_calibration(self, label, cl):
        """Parse a single calibration line"""

        plist = load._re_opts.findall(cl)
        if not plist:
            raise SyntaxError("Invalid parameters in calibration command: {} {}".format(label, opts))

        outDict = dict(plist)
        outDict['label'] = label.strip('"').strip()

        if "descendents" not in outDict:
            raise SyntaxError("Invalid parameters in calibration command: {} {}".format(label, opts))

        outDict['descendents'] = [d.strip().strip('"') for d in outDict['descendents'].strip('()').split(',')]

        return outDict

    # **************************************************

    def _get_calibrations(self):

        outList = []                          # Set of calibrations found

        # Find the calibrations section
        try:

            cmds = next(blk for blk in self.nexus.unknown_blocks if blk.title == 'calibrations').commandlines

            # Process through the command lines
            for cmd in cmds[0]:
                m = load._re_command.match(cmd)
                if not m:
                    raise SyntaxError("Invalid command in calibrations section: {}".format(cmd))

                try:
                    outList.append(self._get_calibration(m.group(1), m.group(2)))
                except KeyError:
                    raise SyntaxError("Invalid calibration: {}".format(cmd))

            if not len(outList):
                raise KeyError()

        except StopIteration:                     # No fdivt section found
            raise KeyError()

        return outList

    # **************************************************

    _kwFunctionMap = [ ( 'options',      _get_options),
                       ( 'loci',         _get_loci),
                       ( 'taxa',         _get_taxa),
                       ( 'sequences',    _get_sequences),
                       ( 'trees',        _get_trees),
                       ( 'calibrations', _get_calibrations) ]

    # **********************************************

    def __init__(self, src):

        self.nexus = Nexus()
        self.nexus.read(src)

        self.taxa = set()

        for k, v in load._kwFunctionMap:
            try:
                rtn = v(self)
                if rtn:
                    self[k] = rtn
            except KeyError:
                pass

        if len(self.taxa):
            self['taxa'] = list(self.taxa)

        print(self)

# **************************************************

if __name__ == '__main__':
    sys.exit("Not a main program")
