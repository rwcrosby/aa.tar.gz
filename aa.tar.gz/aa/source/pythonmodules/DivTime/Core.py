"""
Python front end to the divergence time library.

This module provides a pythonic interface to the divergence time process.
"""

__author__ = """
Ralph W. Crosby
rwc@cs.tamu.edu
Department of Computer Science and Engineering
Texas A&M University
College Station, TX 77843
"""

__license__ = """
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

__copyright__ = """
Copyright 2010-2015 Texas A&M University,
                    College Station, Texas
                    Contact: R Crosby <rwc@cs.tamu.edu>
"""

__all__ = ["DivTime"]

# **************************************************

import collections
import importlib
import os
import re
import sys

import FDivT
from   .TreeObjs    import TreeVisitor, Tree
from   .Options     import optionsInMap, optionsOutMap
from   .ParseNewick import Parser

# **************************************************

class DivTime(object):
    """
    Factory to manage the life of FDivT objects.

    Most of the methods correspond directly to the IDivTime methods
    with the addition of management of the connection to libfdivt.

    Additionally there is a loader interface. The Load method
    takes a dictionary of parameters that are loaded into the current
    connection.

    To load other file formats there is a "magic" connection to
    the Load method. If a method this class is called that is not
    explicitly defined, an attempt will be made to load a module from
    the loader subdirectory with the same name as the method called.
    If this load is successful, the Load method of that module will be
    called. This method is expected to return members of the parameter
    dictionary that will be in turn passed to the Load method of this
    class.

    *Environment Variables:*

    Additional parameters may be supplied through the use of the
    FDIVT_PARMS environment variable. If present this variable should
    contain sets of key=value pairs seperated by commas::

        FDIVT_PARMS=logdebug=1,logfile=/dev/stderr
    """

    # **********************************************

    _evoModelInMap = dict(
        jc69  = FDivT.EvoModel_JC69,
        k80   = FDivT.EvoModel_K80,
        f81   = FDivT.EvoModel_F81,
        f84   = FDivT.EvoModel_F84,
        hky85 = FDivT.EvoModel_HKY85,
        t92   = FDivT.EvoModel_T92,
        tn93  = FDivT.EvoModel_TN93,
        gtr   = FDivT.EvoModel_GTR,
    )

    _evoModelOutMap = {v : k for k,v in _evoModelInMap.items()}

    _calOptInMap = {
        "type"      : FDivT.CalOptType_Type,
        "minage"    : FDivT.CalOptType_MinAge,
        "maxage"    : FDivT.CalOptType_MaxAge,
        "leftmass"  : FDivT.CalOptType_LeftMass,
        "rightmass" : FDivT.CalOptType_RightMass,
        "offset"    : FDivT.CalOptType_Offset,
        "scale"     : FDivT.CalOptType_Scale,
        "alpha"     : FDivT.CalOptType_Alpha,
        "beta"      : FDivT.CalOptType_Beta,
        "mu"        : FDivT.CalOptType_Mu,
        "sigma"     : FDivT.CalOptType_Sigma,
    }

    _calTypeInMap = {
        "lowerbound" : FDivT.CalType_LOWER_BOUND,
        "upperbound" : FDivT.CalType_UPPER_BOUND,
        "lowerupper" : FDivT.CalType_LOWER_UPPER,
        "gammadist"  : FDivT.CalType_GAMMA_DIST,
        "normaldist" : FDivT.CalType_NORMAL_DIST
    }

    _calValueTransform = {
        "type"         : lambda p : DivTime._calTypeInMap[p.lower()],
        "minage"       : lambda p : float(p),
        "maxage"       : lambda p : float(p),
        "leftmass"     : lambda p : float(p),
        "rightmass"    : lambda p : float(p),
        "offset"       : lambda p : float(p),
        "scale"        : lambda p : float(p),
        "alpha"        : lambda p : float(p),
        "beta"         : lambda p : float(p),
        "mu"           : lambda p : float(p),
        "sigma"        : lambda p : float(p),
    }

    # **********************************************

    def __init__(self):
        """
        Create the interface object.
        """
        self.idt            = FDivT.CreateDivTimeObject()
        self._loaders       = {}
        self._newick_parser = Parser()

        try:
            opts = os.environ['FDIVT_OPTS']
            if opts:
                self._opts_from_environ(opts)
        except KeyError:
            pass

    # **********************************************

    def __del__(self):
        """
        Remove the interface object.
        """
        if self.idt:
            FDivT.FreeDivTimeObject(self.idt)

    # **********************************************

    def __enter__(self):
        """
        Just return the div time object
        """
        return self

    # **********************************************

    def __exit__(self, type, val, tb):
        """
        Delete the IDivTime object.
        """
        if self.idt:
            FDivT.FreeDivTimeObject(self.idt)
            self.idt = None

    # **********************************************

    def __getattr__(self, name):
        """
        Called for any undefined attribute.

        Will attempt to import a module named or the attribute
        and invoke it's load function/class.

        Args:
            name: Module name

        Returns:
            A closure containing the call to the load function/class.

        Raises:
            AttributeError: If the module specified doesn't exist or doesn't contain a
            'load' method/class.
        """

        if name in self._loaders:
            mod = self._loaders[name]
        else:
            try:
                mod = importlib.import_module("..Loader.{}".format(name),package=__name__)
            except ImportError:
                raise AttributeError("No loader module named <{}>".format(name))
            try:
                if not callable(mod.load):
                    raise AttributeError("No 'load' function in module {}".format(mod.__name__))
            except AttributeError:
                raise AttributeError("No 'load' function in module {}".format(mod.__name__))
            self._loaders[name] = mod

        class Inner():
            def __init__(self, fn_load, mod):
                self.fn_load = fn_load
                self.mod = mod

            def __call__(self, *args, **kwargs):
                r = self.mod(*args, **kwargs)
                return self.fn_load(**r)

        return Inner(self.load, mod.load)

    # **********************************************

    def add_calibration(self,
                       descendents,
                       opts,
                       label=None):
        """Add a calibration point to all possible trees.

        Args:
            descendents (list): List of taxa to locate the calibration point.

            opts (list): Set of calibration parameters as a list of  tuples (opt name, opt value).

            label (str): Optional name to apply to the calibration

        Returns:
            Nothing

        Raises:
            ExceptMissingTaxa: Taxa not added.
        """

        opts = [FDivT.CalOpt(DivTime._calOptInMap[p[0].lower()],
                             DivTime._calValueTransform[p[0].lower()](p[1])) \
                 for p in opts]
        if label:
            self.idt.AddCalibration(descendents, opts, label)
        else:
            self.idt.AddCalibration(descendents, opts)

    # **********************************************

    def add_locus(self, label):
        """Add a locus.

        This identifier will be used in the add sequence calls
        to identify the locus for the sequence.

        Args:
          label (str): Identifier for the locus.

        Returns:
            Nothing

        Raises:
          Except::DuplicateLocus
        """

        self.idt.AddLocus(label)

    # **********************************************

    def add_sequence(self, locus, taxa, seq):
        """Add a DNA sequence for a taxa at a specific locus.

        Each taxa name should have been added using the AddTaxa method.
        Each locus should have been added using the AddLoci method.

        Args:
          locus (str): Name of the locus to associate sequence with.

          taxa (str): Name of the taxa to associate sequence with.

          seq (str): String containing sequence data

        Returns:
            Nothing

        Exceptions:
          Except::MissingTaxa: Taxa not defined

          Except::MissingLocus: Locus not defined

          Except::InvalidSeqLength: Length of the sequence is diffenent from the length
          in the locus.
        """

        self.idt.AddSequence(locus, taxa, seq)

    # **********************************************

    def add_taxa(self, label):
        """Add a taxa.

        Args:
          label (str): Taxa name.

        Returns:
            Nothing

        Exceptions:
          Except::DuplicateTaxa
	"""

        self.idt.AddTaxa(label)

    # **********************************************

    def add_tree(self, root, label = None):
        """Add a tree to the set to be dated.

        Each taxa name should have been added using the "TaxaLabel" opt.
        Tree is composed using the FDivT.* tree classes.

        Args:
          root: Reference to the root node for the tree.

          label (str): User supplied identifier for the tree.

        Returns:
            Nothing

        Exceptions:
          Except::MissingTaxa: Taxa not defined (via AddTaxa).

          Except::InvalidTree: Error in tree structure
        """

        if label:
            self.idt.AddTree(root, label)
        else:
            self.idt.AddTree(root)

    # **********************************************

    def get_options(self):
        """Return the full set of parameters with all values resolved.

        Returns:
          Values as a list of tuples (opt name, opt value).
        """

        opts = self.idt.GetOptions()
        return [(optionsOutMap[p.type][0],
                 optionsOutMap[p.type][2](p.data)) for p in opts]

    # **********************************************

    def graphviz(self,
                 filename,
                 taxa = False,
                 calibrations = False,
                 genetrees = False):
        """Produce a graphviz .dot file for the trees loaded.

        Args;
            filename (str): Name for the .dot output file.

            taxa (bool): Output taxa graph.

            calibrations (bool): Output calibrations graph.

            genetrees (bool): Output graphs for the gene trees.

        Returns:
            Nothing
        """

        self.idt.TreeGraphviz(filename, taxa, calibrations, genetrees)

    # **********************************************

    def log_options(self):
        """Write parameter values to the log.

        Returns:
          Values as a list of tuples (opt name, opt value).
        """

        self.idt.LogOptions()

    # **************************************************

    def set_model(self,
                  model,
                  parms = [],
                  freq = [],
                  gammacats = 0,
                  gammaparms = []):
        """Set evolutionary model and associated parameters

        Args:
          model: Evolutionary model (see evoModelInMap).
          parms: List of model specific parameters.
          freq:  List of nucleotide dirichlet parameters.
          gammacats: Number of discrete gamma categories
          gammaparms: List of discrete gamma parameters (alpha, beta)

        Exceptions:
          Except::ModelError: Error in model parameters
        """

        self.idt.SetModel(DivTime._evoModelInMap[model.lower()],
                          [float(p) for p in parms],
                          [float(p) for p in freq],
                          int(gammacats),
                          [float(p) for p in gammaparms])

    # **********************************************

    def set_options(self, opts ):
        """Add or override parameters in the current set.

        Parameters:
           opts (list of tuples): Tuples of opt types and values.

        Returns:
          Values as a list of tuples (opt name, opt value).
        """

        popts = [FDivT.DivOpt(optionsInMap[p[0].lower()][0],
                              optionsInMap[p[0].lower()][1](p[1])) \
                 for p in opts]

        self.idt.SetOptions(popts)

    # **************************************************

    def mcmc(self):
        """Perform the actual divergence time inference

        Args:

        Returns:
            Nothing

        Raises:
        """

        self.idt.MCMC()

    # **********************************************

    def _load_options(self, opts):
        self.set_options(list(opts.items()))

    # **************************************************

    def _load_emodel(self, emodel):
        self.set_model(**emodel)

    # **********************************************

    def _load_loci(self, loci):
        [self.add_locus(l) for l in loci]

    # **********************************************

    def _load_taxa(self, taxa):
        [self.add_taxa(t) for t in taxa]

    # **********************************************

    def _load_sequences(self, seqs):
        [ self.add_sequence(locus, taxa, seq) \
          for taxa, lcd in seqs.items() \
          for locus, seq in lcd.items() ]

    # **************************************************

    def _save_outgroup(self, og):
        self.outgroup = og

    # **********************************************

    def _load_trees(self, trees):

        # A single tree input file
        if isinstance(trees, Tree):
            self._convert_load_tree(trees)

        # If a dictionary assume it's a set of label:tree pairs
        elif isinstance(trees, dict):
            for label in sorted(trees):
                self._convert_load_tree(trees[label], label)

        # If some other iterable type assume it's just a set of trees
        elif isinstance(trees, collections.Iterable):
            for tree in trees:
                self._convert_load_tree(tree)

    # **********************************************

    def _load_calibrations(self, cals):
        for cal in cals:
            descendents = cal['descendents']
            del cal['descendents']
            label=cal.pop("label", None)
            try:
                self.add_calibration(descendents,
                                     list(cal.items()),
                                     label)
            except KeyError as ke:
                raise AttributeError("Unknown calibration attribute: {!s}".format(ke))

    # **********************************************

    _kwFunctionMap = [ ( "options",      _load_options),
                       ( "emodel",       _load_emodel),
                       ( "loci",         _load_loci),
                       ( "taxa",         _load_taxa),
                       ( "sequences",    _load_sequences),
                       ( "outgroup",     _save_outgroup),
                       ( "trees",        _load_trees),
                       ( "calibrations", _load_calibrations) ]

    def load(self, **kwargs):
        """Load FDivT inputs

        This is a general purpose function to load data into
        the FDivT interface. The keyword arguments correspond
        to the various inputs.

        Args:
          options:      FDivT library options, option is a set of tuples
          (opt name, opt value).

          emodel:       Evolutionary model parameters, parameter is a dictionary
          containing the parameters (see Loader/Yaml.py for details.

          loci:         Locus definitions, parameter is a list of strings containing
          loci names.

          taxa:         Taxa definitions, parameter is a list of strings containing
          taxa names.

          seqences:     DNA sequences, parameter is a dictionary keyed by taxa names.
          Values in the taxa dictionary are dictionaries keyed by loci name with
          the sequence string as the value.

          trees:        Trees, parameter is a dictionary keyed by tree name with
          values of either newick strings or standard tree objects.

          calibrations: Fossil calibrations, parameter is a list of calibrations.
          Each calibration is a dictionary of parameters for the calibration.

        Raises:
          AttributeError: Bad configuration attribute
        """

        # Validate keys
        badKeys = set(kwargs.keys()) - set(t[0] for t in self._kwFunctionMap)
        if len(badKeys):
            raise KeyError("Invalid load keyword(s) <{:s}>".format(','.join(badKeys)))

        # Work through the keyword list
        for opt in self._kwFunctionMap:
            if opt[0] not in kwargs:
                continue
            opt[1](self, kwargs[opt[0]])

    # **************************************************

    def _convert_load_tree(self, input, label=None):
        """Convert and load either a standard or a newick tree

        Each taxa name should have been added using the "TaxaLabel" opt.
        Tree is composed using the Tree.* classes.
	"""

        class Visitor(TreeVisitor):

            def __init__(self):
                super().__init__()
                self.stack = []

            def root_pre_visit(self, node):
                self.stack.append((node, None))

            def root_post_visit(self, node):
                edges = []
                while True:

                    tpl = self.stack.pop()
                    if tpl[0] is node:
                        break
                    edges.append(tpl[1])
                self.root = FDivT.Inner(edges)

            def inner_pre_visit(self, node, incoming):
                self.stack.append((node, None))

            def inner_post_visit(self, node, incoming):
                edges = []
                while True:
                    tpl = self.stack.pop()
                    if tpl[0] is node:
                        break
                    edges.append(tpl[1])
                i = FDivT.Inner(edges)
                self.stack.append((node,
                                   FDivT.Branch(i, incoming.length)))

            def leaf_visit(self, node, incoming):
                self.stack.append((node,
                                   FDivT.Branch(FDivT.Leaf(node.label), incoming.length)))

        # If it's a string convert it to a standard tree then convert to FDivT
        # It's an extra step but it's probably not a performance hit in general
        if isinstance(input, str):
            input = self._newick_parser(input)
        elif not isinstance(input, Tree):
            raise AttributeError("Only standard trees or newick strings may be loaded")

        # If the tree isn't rooted, attempt to root it...
        if not input.root:
            if hasattr(self, 'outgroup'):
                input.set_root(self.outgroup)
            else:
                input.set_root()

        # Convert the tree to internal format
        visitor = Visitor()
        input.dfs(visitor)


        self.add_tree(visitor.root, label)

    # **************************************************

    _re_opts   = re.compile(r'(\S+)=(\(.*\)|".*"|[^\s,]+)')

    def _opts_from_environ (self, opts):
        """Process opt string from the environment variable"""

        plist = DivTime._re_opts.findall(opts)
        if not plist:
            raise SyntaxError("Invalid parameters in FDIVT_OPTS environment variable: {}".format(opts))

        self.set_options( [(opt[0], opt[1]) for opt in plist] )

# **************************************************

if __name__ == '__main__':
    sys.exit("Not a main program")
