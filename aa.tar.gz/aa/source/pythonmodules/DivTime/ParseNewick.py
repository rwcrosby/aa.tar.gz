"""
Basic newick parser implemented as a generator

Largely copied from Thomas Mailund's newick parser.

Parses a single string containing a newick tree into
a standard tree.
"""

__author__ = """
Ralph W. Crosby
rwc@cs.tamu.edu
Department of Computer Science and Engineering
Texas A&M University
College Station, TX 77843
"""

__license__ = """
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

__copyright__ = """
Copyright© 2010-2015 Texas A&M University,
                     College Station, Texas
                     Contact: R Crosby <rwc@cs.tamu.edu>
"""

__all__ = ["Parser"]

# *************************************************************************

import tpg

from   .TreeObjs import Tree, Leaf, Inner, Edge

# *************************************************************************

class Parser(tpg.Parser):
    r"""

    separator space	'\s+' 							;

    token label		'[^,:;() \t\n]+' ;

    START/t ->                                    $ self.tree = Tree()
        Subtree/t Length/length ';'               $ t = self._check_for_root(t)
    ;

    Subtree/node ->
    	Internal/node
      | Leaf/node
    ;

    Leaf/node ->
        Name/name                                 $ node = Leaf(label=name, tree=self.tree)
    ;

    Internal/node ->
    '\(' BranchList/brl '\)' Name/n	          $ node = Inner(edges=brl, tree=self.tree)
    ;

    BranchList/blist ->
        Branch/b                                  $ blist = [b]
                 (',' BranchList/bl               $ blist += bl
                 )*
    ;

    Branch/branch ->
    	Subtree/nd Length/l                       $ branch = Edge(nodes=[nd], length=l, tree=self.tree)
    ;

    Name/name ->
    	label/name
      | Empty			                  $ name = ""
    ;

    Length/length ->
    	':' Number/length
      | Empty			                  $ length = 0
    ;

    Number/n ->
        label/l			                  $ n = float(l)
    ;

    Empty -> ;

    """

    # **************************************************

    def _check_for_root(self, node):
        """
        If the top level node has two edges, call it the root.
        """

        if len(node.edges) == 2:
            self.tree.root = node

        return self.tree
