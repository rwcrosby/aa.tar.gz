"""
Definitions of the DivTime options mapa.

All code referring to the options should be located here so that
adding an options only requires changes to this module.

There are two option maps, the first keyed by the text name of the option and the
second by the swig definition of the option.
The text name is also the key used in the nexus and yaml input formats.
The value for the map entry is a tuple with the following entries:

 1. The name of the option in the  swig interface
 2. Conversion function for the value from python to the FDivT interface format.
 3. Conversion function to format the value returned from the FDivT interface
    GetOpts method for python. Not used if the value will not be returned via getopts.
 4. Conversions fumction for the value from text to the FDivT interface format.
 5. If a command line argument, text associated with the argument. If empty the parameter
    will not be valid on the command line.
 6. Type of the parameter (int, bool, float or none). If none the type is handled via the
    fourth entry in the tuple.
 7. Type to display is the parameter help ('STRING', 'CHAR' etc.)

There are two evolutionary model maps, one keyed by the text for for the model returning
the swig definition and the second going the other way.
"""

__author__ = """
Ralph W. Crosby
rwc@cs.tamu.edu
Department of Computer Science and Engineering
Texas A&M University
College Station, TX 77843
"""

__all__ = ['evoModelInMap',
           'evoModelOutMap',
           'optionsInMap',
           'optionsOutMap' ]

# **************************************************

import sys

import FDivT

clockModelInMap = {
    'global'      : FDivT.ClockModel_GLOBAL,
    'independent' : FDivT.ClockModel_INDEPENDENT,
    'correlated'  : FDivT.ClockModel_CORRELATED,
}

clockModelOutMap = {v : k for k,v in clockModelInMap.items()}

multiTreeModelInMap = {
    'independent' : FDivT.MultiTreeModel_INDEPENDENT,
    'commonrates' : FDivT.MultiTreeModel_COMMONRATES,
    'commonboth'  : FDivT.MultiTreeModel_COMMONBOTH,
}

multiTreeModelOutMap = {v : k for k,v in multiTreeModelInMap.items()}

# **************************************************

def _mkopt( fdivtOpt,
            p2cFn = lambda p : p,
            c2pFn = lambda p : p,
            t2cFn = lambda p : p,
            desc  = None,
            metavar = None):
    return (fdivtOpt, p2cFn, c2pFn, t2cFn, desc, None, metavar)

def _mkopt_bool ( fdivtOpt,
                  p2cFn = lambda p : p,
                  c2pFn = lambda p : bool(p.tf),
                  t2cFn = lambda p : bool(p),
                  desc  = None ):
    return (fdivtOpt, p2cFn, c2pFn, t2cFn, desc, bool, None)

def _mkopt_uint ( fdivtOpt,
                  p2cFn = lambda p : p,
                  c2pFn = lambda p : int(p.uintVal),
                  t2cFn = lambda p : int(p),
                  desc  = None ):
    return (fdivtOpt, p2cFn, c2pFn, t2cFn, desc, int, 'INT')

def _mkopt_float( fdivtOpt,
                  p2cFn = lambda p : p,
                  c2pFn = lambda p : float(p.doubleVal),
                  t2cFn = lambda p : float(p),
                  desc  = None ):
    return (fdivtOpt, p2cFn, c2pFn, t2cFn, desc, float, 'FLOAT')

optionsInMap =  dict(

    # *****************************************************************
    # Parameters associated with printed output

    logfile         = _mkopt     ( FDivT.OptType_LogFile,
                                   metavar='FILENAME',
                                   desc="""Write console output to this file as well as stdout.
                                   If the file already exists it will be overridden"""),
    logfileno       = _mkopt_uint( FDivT.OptType_LogFileNo),
    logsink         = _mkopt     ( FDivT.OptType_LogSink),
    logdebug        = _mkopt_bool( FDivT.OptType_LogDebug,
                                   desc="""Enable debugging output. The module must have been
                                   compiled with debugging specified (DEBUG=1 on the scons command
                                   line). If debugging wasn't compiled in this option is ignored"""),
    logperf         = _mkopt_bool( FDivT.OptType_LogPerf,
                                   desc="Enable performance data output (if compiled in)"),
    logstats        = _mkopt_bool( FDivT.OptType_LogStats,
                                   desc="Enable run statistics output"),

    # *****************************************************************
    # Parameters to dump various stuff...

    dumptrees       = _mkopt_bool( FDivT.OptType_DumpTrees,
                                   desc="Dump trees after load prior to replication"),
    dumpreplicates  = _mkopt_bool( FDivT.OptType_DumpReplicates,
                                   desc="Dump trees after replication"),

    # *****************************************************************
    # Overall process parameters

    filename        = _mkopt     ( FDivT.OptType_Filename,
                                   c2pFn=lambda p : str(p.cstr),
                                   metavar="FILENAME",
                                   desc="""File name root for all output files.
                                   This name is used as the base of all the non-console
                                   output files (e.g. trace, tree files). If the files
                                   already exist the run will be aborted without overwriting
                                   the files. If the value '%%(date)' is included in the filename,
                                   the current date of the form yy-mm-dd will be included in the
                                   generated names. If the value '%%(time)' is included in the
                                   filename, the current time of the form hh-mm-ss will be
                                   included in the generated names."""),
    fileoverwrite   = _mkopt_bool( FDivT.OptType_FileOverwrite,
                                   desc="""Allow any existing output files to be overwritten.
                                   Default action is to abort if existing output files are found."""),
    seed            = _mkopt_uint( FDivT.OptType_Seed,
                                   desc="""Random seed to use. If not specified
                                   a value will be generated."""),
    clockmodel      = _mkopt     ( FDivT.OptType_ClockModel,
                                   p2cFn=lambda p : clockModelInMap[p.lower()],
                                   c2pFn=lambda p : clockModelOutMap[p.cmodel],
                                   t2cFn=lambda p : p.upper(),
                                   metavar="CMODEL",
                                   desc="Clock model (global, independend, correlated)."),

    multitreemodel  = _mkopt     ( FDivT.OptType_MultiTreeModel,
                                   p2cFn=lambda p : multiTreeModelInMap[p.lower()],
                                   c2pFn=lambda p : multiTreeModelOutMap[p.cmodel],
                                   t2cFn=lambda p : p.upper(),
                                   metavar="MTMODEL",
                                   desc="Multi tree sharing model (independent, commonrates, commonboth)."),

    # *****************************************************************
    # Execution environmental parameters

    nthreads        = _mkopt_uint( FDivT.OptType_NThreads,
                                   desc="""Number of parallel CPU threads.
                                   Default is the number of cores available."""),
    hashbits        = _mkopt_uint( FDivT.OptType_HashBits,
                                   desc="""Number of bits in the subtree hash table.
                                   Default is 24 which should be adequite for most analysis.
                                   Performance of the subtree hash can be monitored by enabling
                                   --logstats"""),
    usegpu          = _mkopt_bool( FDivT.OptType_UseGpu,
                                   desc="""Enable GPU support. If GPU support is unavailable,
                                   this value will be ignored.
                                   Default will be to enable supprt."""),

    # *****************************************************************
    # Parameters associated with the DNA sequences

    seqchars        = _mkopt ( FDivT.OptType_SeqChars,
                               c2pFn = lambda p : str(p.cstr),
                               metavar="STRING",
                               desc="""Sequence alignment: set of characters in the alignment.
                               Default is 'TCAG'.""" ),
    gapchar         = _mkopt ( FDivT.OptType_GapChar,
                               c2pFn=lambda p : str(p.ch),
                               metavar="CHAR",
                               desc="""Sequence alignment: gap character.
                               Default is '-'."""),
    missingchar     = _mkopt ( FDivT.OptType_MissingChar,
                               c2pFn=lambda p : str(p.ch),
                               metavar="CHAR",
                               desc="""Sequence alignment: missing data character.
                               Default is '?'."""),

    # *****************************************************************
    # Parameters associated with the MCMC Process

    ngen            = _mkopt_uint( FDivT.OptType_NGen,
                                   desc="""Number of MCMC generations.
                                   This includes any burnin generations requested.
                                   A value must be specified for this parameter,
                                   there is no default"""),
    burnin          = _mkopt_uint( FDivT.OptType_Burnin,
                                   desc="""Numer of burnin generations to exclude from output.
                                   The value must be less than the number of generations
                                   specified (ngen). Default is zero."""),
    samplefreq      = _mkopt_uint( FDivT.OptType_SampleFreq,
                                   desc="""Number of generations between samples of the chains.
                                   Both trees and all parameter values are sampled at the
                                   same time. Default is to take 1000 samples across the
                                   non-burnin generations if the number of generations will
                                   support it (non-burnin generations >= 10,000). If the number
                                   of non-burnin generations is less than 10,000 a value is
                                   choosen to produce at least 100 samples."""),

    # *****************************************************************
    # Parameters associated with replication

    nruns           = _mkopt_uint(  FDivT.OptType_NRuns,
                                    desc="""Number of MCMC chains. This value determines the
                                    number of MCMC chains (runs) to be done on each input tree.
                                    This value is mutually exclusive with jackknife replication
                                    (nreplicates)."""),
    nreplicates     = _mkopt_uint(  FDivT.OptType_NReplicates,
                                    desc="""Number of jackknife replicates to generate. The first
                                    replicate always contains all the calibrations. Subsequent
                                    replicates might or might not contain all the calibrations depending
                                    on the replication percentage requested. This value is mutually
                                    exclusive with the number of MCMC chains (nruns)."""),
    replicatepct    = _mkopt_float( FDivT.OptType_ReplicatePct,
                                    desc="""Percentage of calibrations to include in each jackknife
                                    replicates. The value must be > 0.0 and < 100.0. The default is to
                                    100.0 which will include all calibrations in all replicates."""),

    # *****************************************************************
    # Parameters associated with Birth Death process

    bdlambda        = _mkopt_float( FDivT.OptType_BDLambda,
                                    desc="""Time prior - Birth death lambda.
                                    Value is a floating point number"""),
    bdmu            = _mkopt_float( FDivT.OptType_BDMu,
                                    desc="""Time prior - Birth death mu.
                                    Value is a floating point number"""),
    bdrho           = _mkopt_float( FDivT.OptType_BDRho,
                                    desc="""Time prior - Birth death rho.
                                    Value is a floating point number"""),

    # *****************************************************************
    # Parameters associated with the dirichlet prior on rates

    clockmeanalpha  = _mkopt_float( FDivT.OptType_ClockMeanAlpha,
                                    desc="""Clock models - mean of rates gamma alpha hyperparameter.
                                    Value is a floating point number.
                                    Default is 1.0"""),
    clockmeanbeta   = _mkopt_float( FDivT.OptType_ClockMeanBeta,
                                    desc="""Clock models - mean of rates gamma beta hyperparameter
                                    Value is a floating point number.
                                    Default is 1.0"""),
    clockmeandcon   = _mkopt_float( FDivT.OptType_ClockMeanDCon,
                                    desc="""Clock models - mean of rates dirichlet concentration hyperparameter.
                                    Value is a floating point number.
                                    Default is 1.0"""),
    clockvaralpha   = _mkopt_float( FDivT.OptType_ClockVarAlpha,
                                    desc="Clock models - variance of rates gamma alpha hyperparameter"),
    clockvarbeta    = _mkopt_float( FDivT.OptType_ClockVarBeta,
                                    desc="Clock models - variance of rates gamma beta hyperparameter"),
    clockvardcon    = _mkopt_float( FDivT.OptType_ClockVarDCon,
                                    desc="Clock models - variance of rates dirichlet concentration hyperparameter")

)

optionsOutMap = {v[0] : (k, v[1], v[2], v[3]) for k, v in optionsInMap.items()}

# **************************************************

if __name__ == '__main__':
    sys.exit("Not a main program")
