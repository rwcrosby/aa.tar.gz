"""
Definitions for the tree objects.

The primary entity is the Tree class.
An instance of the tree class should be created first and the appropriate
Leaf, Edge and Inner objects added to it.

Modeled after Thomas Mailund's tree in his newick parser.
"""

__author__ = """
Ralph W. Crosby
rwc@cs.tamu.edu
Department of Computer Science and Engineering
Texas A&M University
College Station, TX 77843
"""

__license__ = """
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

__copyright__ = """
Copyright© 2010-2015 Texas A&M University,
                     College Station, Texas
                     Contact: R Crosby <rwc@cs.tamu.edu>
"""

__all__ = ["Tree", "Edge", "Inner", "Leaf", "TreeVisitor"]

# *************************************************************************

try:
    from   pympler.asizeof import asizeof
except ImportError as e:
    asizeof = None

import scipy.special
import sys

# *************************************************************************

class Tree(object):
    """Container class for trees.

    The trees are acyclic graphics with nodes of any degree.
    Leaf nodes are unique in the tree, labeled and of degree one (or degree zero
    if the tree is composed only of a single leaf node).
    Non-leaf verticies in the tree are of at least degree three.
    If a single degree two vertex is present in the tree it is considered the root.

    Attributes:
        edges: List of edges in the tree.

        vertices: List of verticies in the tree.
    """

    def __init__(self):

        self.edges          = []                  # List of edges
        self.vertices       = []                  # List of vertices

        self._leaf_dict     = {}                  # Dictionary indexed by leaf label
        self._diameter      = 0                   # Tree diameter, 0 indicates not set
        self._cache_leaves  = False               # Don't initially allow caching leaf sets
        self._n_leaves      = 0                   # Number of leaves in the current tree
        self._tot_leaf_len  = 0                   # Total taxa label length
        self._root          = None                # Assume unrooted

    @property
    def binary(self):
        """Property to determine if the tree is properly binary."""

        return self.maxDegree == 3

    @property
    def cache_leaves(self):
        """Get/set the leaf cache status.

        When the cache is enabled, the set of leaves contained in the
        subtree below the current node is maintained at each inner node.

        Chaning the structure or set of leaves in the tree does not
        automatically update the cache."""

        return self._cache_leaves

    @cache_leaves.setter
    def cache_leaves(self, v):
        """Set the leaf cache status."""

        # If the cache is being turned off, clear the cache
        if self._cache_leaves and not v:
            for v in self.vertices:
                if type(v) == Inner:
                    v.leaves = None

        self._cache_leaves = v

    @property
    def diameter(self):
        """Return the diameter of the tree.

        The diameter is the longest path between any two nodes in the tree.

        If the diameter has already been set the existing value is returned.
        """

        if not self.binary:
            raise ValueError("Tree not binary, diameter can only be computed for binary trees.");

        if not self._diameter:
            self._diameter = _Diameter(self.vertices[0])
            return self._diameter

    @property
    def leaf_name_set(self):
        """Get the names of the leaves in the tree as a set."""

        return set(str(l) for l in self.vertices if type(l) is Leaf)

    @property
    def leaf_obj_list(self):
        """Get a iterator over the leaf objects in the tree."""

        return (l for l in self.vertices if type(l) is Leaf)

    @property
    def maxDegree(self):
        """Get the degree of the tree"""

        return max(len(v.edges) for v in self.vertices)

    @property
    def meanLeafLen(self):
        """Return average leaf label length."""

        return self._tot_leaf_len / self._n_leaves

    @property
    def memory(self):
        """Return memory utilization for the tree.

        Note this method is only available if pympler package
        is available.
        """

        if not asizeof:
            raise AttributeError("Memory sizing unavailable, pympler module not imported.")
        return asizeof(self)

    @property
    def n_leaves(self):
        """Get the number of leaf nodes in tree."""

        return self._n_leaves

    @property
    def n_quartets(self):
        """Get the number of quartets in the tree."""

        return int(scipy.special.binom(len(self.leaves), 4))

    @property
    def root(self):
        """Get/Set the root of the tree.

        If an Inner node is passed it is just accepted as the root.
        If an edge is passed a new Inner node is created and inserted
        as the edge.

        Parameters:
            o: vertex or edge.

        Raises:
            TypeError: Raised if anything other than an edge or Inner node is passed.
        """

        return self._root

    @root.setter
    def root(self, o):

        if type(o) is Inner:
            self._root = o
        elif type(o) is Edge:
            rightInner = o.remove_node(o.nodes[1])
            newEdge = Edge(nodes=[rightInner],
                           tree=self)
            self._root = Inner(edges=[o, newEdge],
                               tree=self,
                               label="Root")
        else:
            raise TypeError("Root attribute requires an edge or inner node")

    # **************************************************

    def dfs(self,
            visitor,
            edge=None):
        """Depth first search of the tree.

        For rooted trees, the search always starts at the root,
        For unrooted trees, an edge may be specified to start the
        search or an arbitrary edge will be used.

        Args:
            visitor: Object derived from the TreeVisitor class that provides the set of callbacks
            for the traversal.

            edge: Optional starting edge for the traversal. If omitted the first edge loaded
            is used.

        Returns:
            Nothing
        """

        if self._root:
            visitor.root_pre_visit(self._root)
            [e.other(self._root).dfs(visitor, e) for e in self._root.edges]
            visitor.root_post_visit(self._root)
        else:
            if not edge:
                edge = self.edges[0]
            [n.dfs(visitor, edge) for n in edge.nodes]

    # **************************************************

    def find_subtree(self, leafObjs):
        """Return the vertex corresponding to the set of leaves passed.

        The contents of the leaf list must be found as the
        complete contents of one side of a bipartition.

        Args:
            leafObjs (list): Leaf objects that comprise the outgroup

        Returns:
            A node object corresponding to the subtree with the leaves.

        Raises:
            IndexError: No unique subtree corresponding to the outgroup found.
        """

        dfsV = _FindSubtreeVisitor(leafObjs, set(self.leaf_obj_list))
        try:
            self.dfs(dfsV)
        except _FoundBipartition as f:
            return f

        raise KeyError("No subtree for leaf list found")

    # **************************************************

    def invalidate(self):
        """Invalidate any saved info (e.g. leaf cache, diameter, bipartitons).

        The intent is for this method to be used prior to structural
        changes to the tree.

        Returns:
            Nothing
        """

        self.cache_leaves = False
        self._diameter = 0

    # **************************************************

    def remove(self, o):
        """Remove an edge or vertex from the tree.

        This method needs to be called when a tree component is removed
        from the tree. It is not called automatically.
        It does not alter the structure of the tree.

        Args:
            o: Node or edge object to remove from the tree.

        Returns:
            Nothing
        """

        if type(o) is Edge:
            self.edges.remove(o)
        else:
            self.vertices.remove(o)
            if type(o) is Leaf:
                self._n_leaves -= 1
                self._tot_leaf_len -= len(o.label)
                self._leaf_dict.pop(o.label, None)
        self._diameter = 0

    # **************************************************

    def set_root(self,
             leaves = None):
        """Try to set a root the tree.

        Two methods are supported. If the leaves parameter is passed
        it is assumed to be a list of leaf names that will comprise the outgroup.
        If the leaves parameter is not passed the vertex collection will be
        searched for a single node of degree two.

        Either method will override any existing root.

        Args:
            leaves: Collection of leaf names to use to locate the root. The set
            of names must map to a complete subtree.

        Returns:
            Nothing

        Raises:
            AttributeError: Thrown if no leaves are passed and a single degree two vertex is
            not found in the tree.

            KeyError: Throw if a subtree could not be found that contains the set of leaves passed.
        """

        if leaves:
            # If a single taxa outgroup, just use it's parent node
            if not isinstance(leaves, list) or len(leaves) == 1:
                if isinstance(leaves, list) and len(leaves) == 1:
                    leaves = leaves[0]
                self.root = self._leaf_dict[leaves].edges[0]
            else:
                # Find the edge associated with the subtree for the set of leaves
                f = self.find_subtree(set(self._leaf_dict[l] for l in leaves))
                self.root = f.incoming
        else:
            # Look for a degree 2 vertex
            v2 = [v for v in self.vertices if len(v.edges) == 2]
            if len(v2) == 1:
                self.root = v2[0]
            else:
                raise AttributeError("No degree 2 vertex found for root")

    # **************************************************

    def write_dot(self, outfile):
        """Generate a dot output file for use with graphviz.

        Returns:
            Nothing

        Args:
            outfile (str): Name of the output file to write.
        """

        with open(outfile, 'w') as of:
            print("digraph G {", file=of)
            self.dfs(_WriteDotVisitor(of))
            if not self.root:
                print(_gvEdge(self.edges[0]), file=of)
            print("}", file=of)

    # **************************************************

    def __repr__(self):
        """Return a string representation of the whole tree for debugging."""

        return '\n'.join(repr(v) for v in self.vertices) + '\n' + '\n'.join(repr(e) for e in self.edges)

    # **************************************************

    def _add(self, o):
        """Add an edge or vertex to the tree.

        Internal method called from the Leaf, Inner and Edge objects.
        Not intended to be used directly.
        """

        if type(o) is Edge:
            self.edges.append(o)
        else:
            self.vertices.append(o)
            if type(o) is Leaf:
                self._n_leaves += 1
                self._tot_leaf_len += len(o.label)
                self._leaf_dict[o.label] = o
        self._diameter = 0

# *************************************************************************

class Edge(object):
    """
    Representation of a edge on the tree.
    Contains parent and child pointers as well as the branch length.

    Args:
        nodes (list): Initial nodes to connect to the edge (optional).

        tree: Associate edge with this tree (optional but highly recommended).

        length (float): Branch length (optional).
    """

    def __init__(self,
                 nodes=[],                        # Connected nodes
                 tree=None,                       # Parent tree
                 length=0.0):                     # Edge length (weight)

        self.length = length

        self.nodes  = []
        [self.add_node(n) for n in nodes]

        if tree:
            tree._add(self)

    def __repr__(self):
        """Return a string for debugging."""

        return "E[{},{},{}]".format(self.nodes[0].id() if len(self.nodes) > 0 else "None",
                                    self.length,
                                    self.nodes[1].id() if len(self.nodes) > 1 else "None")

    def add_node(self, node):
        """
        Add the connection to a node connecting the node to the edge as well
        Returns the node added.

        Args:
            node: Node to add

        Returns:
            The node that was added. This allows an object to be instantiated
            in the call and still get the new node.
        """

        self.nodes.append(node)
        if self not in set(node.edges):
            node.edges.append(self)

        return node

    def remove_node(self, node):
        """Remove the connection to a node disconnecting the edge from the node as well.

        Args:
            node: Node to remove.

        Returns:
            The node removed.
        """
        self.nodes = [n for n in self.nodes if not n is node]
        if self in set(node.edges):
            node.edges = list(set(node.edges) - set([self]))

        return node

    def depth(self, node):
        """
        Return the depth of the tree pointing downward from the
        specified node.

        Args:
            node: Node to use as the "parent" for the edge.

        Returns:
            The longest path to a contained leaf.
        """

        depth = _DepthVisitor()
        self.other(node).dfs(depth, self)
        return depth.depth

    def other(self, node):
        """Return reference to the other end of the edge from node

        Args:
            node: The end to start from.

        Returns:
            The other end of the edge.

        Raises:
            IndexError: The node was missing an edge.
        """

        ni = self.nodes.index(node)

        try:
            other = self.nodes[not ni]
        except IndexError:
            other = None

        return other

# *************************************************************************

class Node(object):
    """
    Class with a edge list and node id.
    The node id is not the same as a taxa label,
    it's just an id for this particular node.

    Instances of this class shouldn't be directly constructucted. The Inner and
    Leaf subclasses should be used instead.

    Args:
        edges (list): Optinal edge objects to start the nodes edge collection.

        tree: Optional (but highly recommended) tree that contains the edge.

        label (str): Optional label for the edge.
    """

    nodeid = 0

    def __init__(self,
                 edges=[],                        # List of edges to connect
                 label=None,                      # Label for the node
                 tree=None):                      # Parent tree

        self.edges = []
        [self.add_edge(e) for e in edges]

        self.label = label
        self.nodeid = Node.nodeid

        if tree:
            tree._add(self)
            self.tree = tree

        self.nodeid = Node.nodeid
        Node.nodeid += 1

    def __repr__(self):
        """Return debugging representation including edges"""
        return "{},{}".format(self.id(), ','.join([repr(e) for e in self.edges]))

    def id(self):
        """Return just the node id and label.

        Returns:
            A string containing the node id and the label.
        """

        return "N{}-'{}'".format(self.nodeid, self.label if self.label else "")

    def add_edge(self, edge):
        """
        Add an edge setting the pointer in the edge object.

        Args:
            edge: Edge to add.

        Returns:
            The edge that was added.
        """
        self.edges.append(edge)
        if self not in set(edge.nodes):
            edge.nodes.append(self)

        return edge

    def remove_edge(self, edge):
        """
        Remove an edge cleaning up the pointer in the edge object.

        Args:
            edge: Edge to remove.

        Returns:
            The edge that was removed.
        """

        self.edges.remove(edge)
        if self in set(edge.nodes):
            edge.nodes.remove(self)

        return edge

# *************************************************************************

class Inner(Node):
    """Define an inner node with a a set of edges.

    Args:
        edges (list): Edge objects to start the nodes edge collection (optional).

        tree:  Tree that contains the edge (optional but highly recommended).

        label (str): Label for the edge (optional).
    """

    def __init__(self,
                 edges=[],
                 tree=None,                       # Ref to base tree
                 label=None):
        super().__init__(edges=edges, label=label, tree=tree)
        self.leaves = []

    def __str__(self):
        """Return a string with only the nodeid."""
        return "N{}".format(self.nodeid)

    def __repr__(self):
        """Generate debugging string for the node"""
        return "I[{}]".format(super().__repr__())

    def dfs(self, visitor, incoming):
        """Perform a depth first search of the subtree.

        Args:
            visitor: Object derived from the TreeVisitor class that provides the set of callbacks
            for the traversal.

            incoming: Edge that was used to arrive at this node.
        """

        visitor.inner_pre_visit(self, incoming)
        [e.other(self).dfs(visitor, e) for e in self.edges if not e is incoming]
        visitor.inner_post_visit(self, incoming)

    def leaves(self, incoming):
        """Return list of leaves in a subtree

        Args:
            incoming: Edge to be considered the upward (parent) pointer
        """

        if not self.tree.cache_leaves:
            self.leaves = None

        if not self.leaves:
            edges = self.other(incoming)
            self.leaves = []
            for e in edges:
                self.leaves.extend(e.other(self).Leaves(e))

        return self.leaves

    def other(self, incoming):
        """Return an iterator to other edges associated with a node.

        Args:
            incoming: Edge to be considered the parent.
        """

        return (e for e in self.edges if not e is incoming)

# *************************************************************************

class Leaf(Node):
    """
    Leaf just has a label in addition to the base node class attributes.

    Args:
        edges : Edge object that connects to this leaf (optional).

        tree:  Tree that contains the edge (optional but highly recommended).

        label (str): Label for the edge (optional but highly recommended).
    """

    def __init__(self,
                 label= None,
                 tree = None,                      # Ref to base unrooted tree
                 edge = None):                     # One outgoing edge only
        super().__init__(edges=[edge] if edge else [],
                         label=label,
                         tree=tree)

    def __str__(self):
        """Just return a string with the label"""
        return self.label

    def __repr__(self):
        """Generate debugging string for the node"""
        return "L[{}]".format(super().__repr__())

    def __lt__(self, other):
        """Compare the labels."""
        return self.label < other.label

    def leaves(self, incoming):
        """Return this node as a list."""
        return [self]

    def dfs(self, visitor, incoming):
        """Call the leaf visit method.

        Used with depth first search(dfs) visitor classes.

        Args:
            visitor: TreeVisitor subclass instance.

            incoming: Edge leading into this node.
        """
        visitor.leaf_visit(self, incoming)

# *************************************************************************

class TreeVisitor(object):
    """Visitor base class.

    This class should be subclassed to receive the various
    events associated with the depth first search."""

    def root_pre_visit(self, t):
        """Called before exploring the root.

        Args:
            t: Root node.

        Returns:
            Nothing
        """

        pass

    def root_post_visit(self, t):
        """Called after exploring the root.

        Args:
            t: Root node.

        Returns:
            Nothing
        """

        pass

    def inner_pre_visit(self, t, incoming):
        """Called before exploring a subtree

        Args:
            t: Inner node.

        Returns:
            Nothing
        """

        pass

    def inner_post_visit(self, t, incoming):
        """Called after exploring a subtree

        Args:
            t: Inner node.

        Returns:
            Nothing
        """

        pass

    def leaf_visit(self, l, incoming):
        """Called when visiting a leaf node

        Args:
            t: Leaf node.

        Returns:
            Nothing
        """
        pass

# *************************************************************************

class _DepthVisitor(TreeVisitor):
    """
    Depth first search visitor class to find the depth of the tree
    """

    def __init__(self):
        self.depth = 0;
        self.__curdepth = 0

    def inner_pre_visit(self, t, incoming):
        self.__curdepth += 1

    def inner_post_visit(self, t, incoming):
        self.__curdepth -=1

    def leaf_visit(self, l, incoming):
        if self.__curdepth > self.depth:
            self.depth = self.__curdepth

# *************************************************************************

class _FindSubtreeVisitor(TreeVisitor):

    def __init__(self, leafSet, allLeaves):
        self._leafSet    = leafSet
        self._notLeafSet = allLeaves - leafSet

    def inner_post_visit(self, t, incoming):

        # Accumulate the set of leaves for the current subtrees
        leafObjs = set()
        for e in t.edges:
            if e != incoming:
                leafObjs |= e.other(t).leafObjs
                e.other(t).leafObjs = None

        # Is this the subtree of interest?
        if leafObjs == self._leafSet:
            raise _FoundBipartition(t, incoming)
        elif leafObjs == self._notLeafSet:
            raise _FoundBipartition(incoming.other(t), incoming)

        t.leafObjs = leafObjs

    def leaf_visit(self, l, incoming):
        l.leafObjs = set([l])

# *************************************************************************

class _FoundBipartition(BaseException):

    def __init__(self, v, e):
        self.vertex = v
        self.incoming = e

# *************************************************************************

_gv_font_size=9

_gv_edge = lambda e : "{src} -> {trg} [dir=none];".format(src=e.nodes[0].nodeid,
                                                          trg=e.nodes[1].nodeid)

_gv_node = lambda **kwargs : """{nid} [shape=none,
                                fontsize={fsz},
                                fontcolor="{color}"
                                label=<
                                   <table border="1" cellborder="0">
                                      <tr><td>{lbl:s}</td></tr>
                                   </table>
                                >];""".format(**kwargs)

class _WriteDotVisitor(TreeVisitor):

    def __init__(self, of):
        self._of = of

    def root_pre_visit(self, r):
        print(_gv_node(nid=r.nodeid,
                      lbl="R{}".format(r.nodeid),
                      fsz=_gv_font_size,
                      color="red"),
              file=self._of)
        for e in r.edges:
            print(_gv_edge(e), file=self._of)

    def inner_pre_visit(self, i, incoming):
        print(_gv_node(nid=i.nodeid,
                      lbl="N{}".format(i.nodeid),
                      fsz=_gv_font_size,
                      color="green"),
              file=self._of)
        for e in i.edges:
            if not e is incoming:
                print(_gv_edge(e), file=self._of)

    def leaf_visit(self, l, incoming):
        print(_gv_node(nid=l.nodeid,
                      lbl=str(l),
                      fsz=_gv_font_size,
                      color="brown"),
              file=self._of)

# *************************************************************************

def _diameter(leaf):
    """Return the diameter of the tree"""

    if not leaf or not len(leaf.edges):
        return 0

    diameter, height = _diameter2(leaf.edges[0].other(leaf), leaf.edges[0])
    return diameter

def _diameter2(node, inedge):
    """
    Compute the subtree diameter,
    inedge is the incomming edges from the parent
    """

    if type(node) is Leaf:
        return 0, 0

    # Go through the other edges incident to the current node other
    # than the parent

    dh = [(_Diameter2(e.other(node), e)) for e in node.edges if not e is inedge]

    heights = sorted([v[1] for v in dh], reverse=True)
    diameter = max(heights[0] + heights[1] + 1, max([v[0] for v in dh]))

    return diameter, heights[0] + 1

def _newick(n, incoming):
    """return the newick string for the subtree passed"""

    if type(n) is Leaf:
        return str(n)
    else:
        return '({})'.format(','.join([_newick(e.other(n), e) for e in n.edges if not e is incoming]))

# *************************************************************************

if __name__ == '__main__':
    sys.exit("Not a main program")
